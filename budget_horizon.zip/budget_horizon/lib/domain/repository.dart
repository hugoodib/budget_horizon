import 'models.dart';

/// Contrat de persistance. Implémentation locale (Hive) aujourd'hui,
/// implémentation cloud/authentifiée possible demain sans toucher au domaine.
abstract class AppRepository {
  AppData? load();
  Future<void> save(AppData data);
  Future<void> clear();

  /// Petites valeurs annexes (session, préférences de synchro...).
  String? readMeta(String key);
  Future<void> writeMeta(String key, String? value);
}
