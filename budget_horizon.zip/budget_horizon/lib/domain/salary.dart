import '../core/ym.dart';
import 'business.dart';
import 'models.dart';

/// Durée d'un poste de la tournante 3×8 (heures).
const kShiftHours = 8.0;

/// Nombre moyen de semaines dans un mois (comme dans le calcul des forfaits).
const kWeeksPerMonth = 4.33;

/// Un mois du récapitulatif : revenu (net) et heures travaillées.
class MonthPoint {
  final Ym ym;
  final double amount;
  final double hours;
  const MonthPoint(this.ym, this.amount, this.hours);
}

/// Classement d'un client : net sur la période, heures et taux horaire net.
class ClientStat {
  final String name;
  final double net;
  final double hours;
  const ClientStat(this.name, this.net, this.hours);
  double? get hourly => hours > 0.01 ? net / hours : null;
}

/// Résultat d'un récapitulatif de salaire sur plusieurs mois.
class SalaryStats {
  final int months; // mois pris en compte (ceux où il y a un revenu)
  final double avgMonthly; // moyenne par mois
  final double? hourly; // taux horaire (null si les heures sont inconnues)
  final double? hoursPerWeek; // heures par semaine (null si inconnues)
  final List<MonthPoint> points; // détail mois par mois (mois avec revenu)
  const SalaryStats({
    this.months = 0,
    this.avgMonthly = 0,
    this.hourly,
    this.hoursPerWeek,
    this.points = const [],
  });

  bool get hasData => months > 0;
  double get total => avgMonthly * months;
  double get yearly => avgMonthly * 12;
  MonthPoint? get best => points.isEmpty
      ? null
      : points.reduce((a, b) => b.amount > a.amount ? b : a);
  MonthPoint? get worst => points.isEmpty
      ? null
      : points.reduce((a, b) => b.amount < a.amount ? b : a);
}

/// [Mode dev] Récapitulatif : salaire moyen, taux horaire et heures par semaine,
/// pour le salaire (3×8 ou autre) et pour l'auto-entreprise (net après URSSAF).
class SalaryRecap {
  /// Revenus récurrents considérés comme « salaire » : salaire 3×8, ou nommés « salaire ».
  /// S'il n'y en a aucun, tous les revenus récurrents sont pris.
  static List<RecurringIncome> salaryIncomes(AppData d) {
    final flagged = d.recurringIncomes
        .where((r) => r.isShiftSalary || r.label.toLowerCase().contains('salaire'))
        .toList();
    return flagged.isNotEmpty ? flagged : d.recurringIncomes;
  }

  static int _days(Ym ym) => DateTime(ym.year, ym.month + 1, 0).day;

  /// Salaire : moyenne sur [window] mois, mois en cours inclus : les derniers mois, ou les
  /// prochains si [future] est vrai (d'après les revenus récurrents et la tournante).
  /// Les heures viennent de la tournante 3×8 (postes de 8 h) ; sinon on utilise
  /// [manualHoursPerWeek] (à renseigner).
  static SalaryStats employee(AppData d, Ym now, int window,
      {double? manualHoursPerWeek, bool future = false}) {
    final incomes = salaryIncomes(d);
    final usesShift = d.shiftSchedule != null && incomes.any((r) => r.isShiftSalary);
    var months = 0;
    var total = 0.0;
    var hours = 0.0;
    var weeks = 0.0;
    final pts = <MonthPoint>[];
    for (var i = 0; i < window; i++) {
      final ym = now.add(future ? i : -i);
      var pay = 0.0;
      for (final r in incomes) {
        if (!r.activeIn(ym)) continue;
        pay += (r.isShiftSalary ? d.shiftSalaryAmountIn(r, ym) : null) ?? r.amountIn(ym);
      }
      if (pay <= 0.005) continue;
      months++;
      total += pay;
      var mh = 0.0;
      if (usesShift) {
        mh = d.shiftSchedule!.workingDayCountIn(ym) * kShiftHours;
        hours += mh;
        weeks += _days(ym) / 7;
      }
      pts.add(MonthPoint(ym, pay, mh));
    }
    pts.sort((a, b) => a.ym.compareTo(b.ym));
    if (months == 0) return const SalaryStats();
    final avg = total / months;
    if (usesShift && hours > 0.01) {
      return SalaryStats(
          months: months,
          avgMonthly: avg,
          hourly: total / hours,
          hoursPerWeek: hours / weeks,
          points: pts);
    }
    final h = manualHoursPerWeek;
    if (h != null && h > 0) {
      return SalaryStats(
          months: months,
          avgMonthly: avg,
          hourly: avg / (h * kWeeksPerMonth),
          hoursPerWeek: h,
          points: pts);
    }
    return SalaryStats(months: months, avgMonthly: avg, points: pts);
  }

  /// Auto-entreprise : net moyen (après URSSAF) des factures émises sur les [window]
  /// derniers mois. Les heures = passages réalisés × durée de chaque passage.
  /// [person] : 1 ou 2 pour un seul auto-entrepreneur, null pour tous.
  static SalaryStats autoEntrepreneur(AppData d, Ym now, int window,
      {int? person, bool future = false}) {
    var months = 0;
    var net = 0.0;
    var hours = 0.0;
    var weeks = 0.0;
    final pts = <MonthPoint>[];
    for (var i = 0; i < window; i++) {
      final ym = now.add(future ? i : -i);
      var gross = 0.0;
      var h = 0.0;
      for (final v in d.invoicesIssuedIn(ym)) {
        if (person != null && v.client.owner != person) continue;
        gross += d.afterCoop(v);
        h += v.visits * v.client.durationMin / 60;
      }
      if (gross <= 0.005) continue;
      months++;
      final n = d.netFromGross(gross);
      net += n;
      hours += h;
      weeks += _days(ym) / 7;
      pts.add(MonthPoint(ym, n, h));
    }
    pts.sort((a, b) => a.ym.compareTo(b.ym));
    if (months == 0) return const SalaryStats();
    return SalaryStats(
      months: months,
      avgMonthly: net / months,
      hourly: hours > 0.01 ? net / hours : null,
      hoursPerWeek: hours > 0.01 ? hours / weeks : null,
      points: pts,
    );
  }

  /// Classement des clients réguliers de l'auto-entreprise par net horaire décroissant
  /// (les factures ponctuelles n'y figurent pas).
  static List<ClientStat> clients(AppData d, Ym now, int window,
      {int? person, bool future = false}) {
    final net = <String, double>{};
    final hrs = <String, double>{};
    for (var i = 0; i < window; i++) {
      final ym = now.add(future ? i : -i);
      for (final v in d.invoicesIssuedIn(ym)) {
        if (person != null && v.client.owner != person) continue;
        if (v.amount <= 0.005 || v.client.isOneOff) continue; // pas les factures ponctuelles
        final k = v.client.name;
        net[k] = (net[k] ?? 0) + d.netFromGross(d.afterCoop(v));
        hrs[k] = (hrs[k] ?? 0) + v.visits * v.client.durationMin / 60;
      }
    }
    final out = [for (final k in net.keys) ClientStat(k, net[k]!, hrs[k] ?? 0)];
    out.sort((a, b) {
      final ha = a.hourly, hb = b.hourly;
      if (ha != null && hb != null) return hb.compareTo(ha);
      if (ha != null) return -1;
      if (hb != null) return 1;
      return b.net.compareTo(a.net);
    });
    return out;
  }
}
