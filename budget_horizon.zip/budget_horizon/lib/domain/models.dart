import 'dart:math';
import '../core/ym.dart';
import 'business_models.dart';
export 'business_models.dart';

double _d(dynamic v) => (v as num).toDouble();

/// Catégories spéciales (hors budgets) : les dépenses « imprévues » et celles d'un voyage.
const kUnexpectedId = '__unexpected';
const kTripCatId = '__trip';

class UserProfile {
  final String id;
  final String name;
  final bool isPremium; // prévu pour l'abonnement premium
  final bool isCouple; // si vrai : budgets et dépenses par personne
  final String person1;
  final String person2;
  final double uiScale; // taille de l'interface (texte) : 0.8 / 0.9 / 1.0
  final bool reduceMotion; // (inutilisé : animations supprimées)
  final bool onboarded; // false = l'assistant de configuration doit s'afficher
  final bool tourSeen; // false = la démonstration guidée doit se lancer
  final bool ae1; // la personne 1 est auto-entrepreneur
  final bool ae2; // la personne 2 (conjoint) est auto-entrepreneur
  final double urssafRate; // taux de charges URSSAF en % (ex. 23,68)
  final String? photo1; // photo de profil (JPEG en base64)
  final String? photo2;
  final bool isDemo;    // true = données d'exemple, affiche le bandeau démo
  final int themeIndex; // 0=Violet (défaut), 1=Océan, 2=Soleil, 3=Forêt
  final bool leaveEnabled; // [Mode dev] compteur de congés activé
  const UserProfile({
    required this.id,
    required this.name,
    this.isPremium = false,
    this.isCouple = false,
    this.person1 = 'Moi',
    this.person2 = 'Conjoint',
    this.uiScale = 0.9,
    this.reduceMotion = true,
    this.onboarded = true,
    this.tourSeen = true,
    this.ae1 = false,
    this.ae2 = false,
    this.urssafRate = 23.68,
    this.photo1,
    this.photo2,
    this.isDemo = false,
    this.themeIndex = 0,
    this.leaveEnabled = false,
  });

  UserProfile copyWith(
          {String? name,
          bool? isCouple,
          String? person1,
          String? person2,
          double? uiScale,
          bool? reduceMotion,
          bool? onboarded,
          bool? tourSeen,
          bool? ae1,
          bool? ae2,
          double? urssafRate,
          String? photo1,
          String? photo2,
          bool? isDemo,
          int? themeIndex,
          bool? leaveEnabled,
          bool clearPhoto1 = false,
          bool clearPhoto2 = false}) =>
      UserProfile(
      id: id,
      name: name ?? this.name,
      isPremium: isPremium,
      isCouple: isCouple ?? this.isCouple,
      person1: person1 ?? this.person1,
      person2: person2 ?? this.person2,
      uiScale: uiScale ?? this.uiScale,
      reduceMotion: reduceMotion ?? this.reduceMotion,
      onboarded: onboarded ?? this.onboarded,
      tourSeen: tourSeen ?? this.tourSeen,
      ae1: ae1 ?? this.ae1,
      ae2: ae2 ?? this.ae2,
      urssafRate: urssafRate ?? this.urssafRate,
      photo1: clearPhoto1 ? null : (photo1 ?? this.photo1),
      photo2: clearPhoto2 ? null : (photo2 ?? this.photo2),
      isDemo: isDemo ?? this.isDemo,
      themeIndex: themeIndex ?? this.themeIndex,
      leaveEnabled: leaveEnabled ?? this.leaveEnabled);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'isPremium': isPremium,
        'isCouple': isCouple,
        'person1': person1,
        'person2': person2,
        'uiScale': uiScale,
        'reduceMotion': reduceMotion,
        'onboarded': onboarded,
        'tourSeen': tourSeen,
        'ae1': ae1,
        'ae2': ae2,
        'urssafRate': urssafRate,
        'photo1': photo1,
        'photo2': photo2,
        'isDemo': isDemo,
        'themeIndex': themeIndex,
        'leaveEnabled': leaveEnabled,
      };
  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
      id: j['id'],
      name: j['name'],
      isPremium: j['isPremium'] ?? false,
      isCouple: j['isCouple'] ?? false,
      person1: j['person1'] ?? 'Moi',
      person2: j['person2'] ?? 'Conjoint',
      uiScale: ((j['uiScale'] ?? 0.9) as num).toDouble(),
      reduceMotion: j['reduceMotion'] ?? true,
      onboarded: j['onboarded'] ?? true,
      tourSeen: j['tourSeen'] ?? true,
      ae1: j['ae1'] ?? false,
      ae2: j['ae2'] ?? false,
      urssafRate: ((j['urssafRate'] ?? 23.68) as num).toDouble(),
      isDemo: j['isDemo'] as bool? ?? false,
      themeIndex: (j['themeIndex'] as int?) ?? 0,
      leaveEnabled: j['leaveEnabled'] as bool? ?? false,
      photo1: j['photo1'] as String?,
      photo2: j['photo2'] as String?);
}

class Category {
  final String id;
  final String name;
  final String emoji;
  final int colorValue;
  const Category({required this.id, required this.name, required this.emoji, required this.colorValue});

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'emoji': emoji, 'color': colorValue};
  factory Category.fromJson(Map<String, dynamic> j) => Category(
      id: j['id'], name: j['name'], emoji: j['emoji'], colorValue: j['color']);
}

/// Budget mensuel récurrent d'une catégorie (une enveloppe).
/// [person] : 0 = seul(e), 1 ou 2 = conjoint 1 / 2 en mode couple.
/// [overrides] : montants modifiés pour un mois précis ("yyyy-MM").
class Budget {
  final String id;
  final String categoryId;
  final double amount;
  final int person;
  final Map<String, double> overrides;
  /// [Mode dev] Règle de débit par défaut pour toutes les dépenses de ce budget.
  /// Peut être surchargée par la debitDate d'une dépense individuelle.
  final ReceiptDayRule debitDay;
  const Budget({
    required this.id,
    required this.categoryId,
    required this.amount,
    this.person = 0,
    this.overrides = const {},
    this.debitDay = ReceiptDayRule.none,
  });

  bool hasOverride(Ym ym) => overrides.containsKey(ym.key);
  double amountIn(Ym ym) => overrides[ym.key] ?? amount;

  Budget copyWith({String? id, double? amount, int? person, Map<String, double>? overrides,
      ReceiptDayRule? debitDay}) => Budget(
      id: id ?? this.id,
      categoryId: categoryId,
      amount: amount ?? this.amount,
      person: person ?? this.person,
      overrides: overrides ?? this.overrides,
      debitDay: debitDay ?? this.debitDay);

  Map<String, dynamic> toJson() => {
        'id': id,
        'categoryId': categoryId,
        'amount': amount,
        'person': person,
        'overrides': overrides,
        'debitDay': debitDay.toJson(),
      };
  factory Budget.fromJson(Map<String, dynamic> j) => Budget(
      id: j['id'],
      categoryId: j['categoryId'],
      amount: _d(j['amount']),
      person: j['person'] ?? 0,
      overrides: ((j['overrides'] ?? {}) as Map).map((k, v) => MapEntry(k as String, _d(v))),
      debitDay: j['debitDay'] == null
          ? ReceiptDayRule.none
          : ReceiptDayRule.fromJson(Map<String, dynamic>.from(j['debitDay'] as Map)));
}

class Transaction {
  final String id;
  final String categoryId;
  final String description;
  final double amount;
  final DateTime date;
  final int person; // 0 = seul(e), 1 / 2 = conjoints
  final String? tripId; // dépense rattachée à un voyage
  final bool checked; // pointée (comme dans une appli bancaire)
  final DateTime? movedFrom; // date d'origine, si reportée car non pointée à la clôture
  /// [Mode dev] Date effective de débit bancaire (peut être dans le mois suivant).
  final DateTime? debitDate;
  const Transaction({
    required this.id,
    required this.categoryId,
    required this.description,
    required this.amount,
    required this.date,
    this.person = 0,
    this.tripId,
    this.checked = false,
    this.movedFrom,
    this.debitDate,
  });

  /// Imprévu ou dépense de voyage : hors budgets mensuels.
  bool get isSpecial => categoryId == kUnexpectedId || tripId != null;

  Transaction copyWith(
          {int? person, bool? checked, DateTime? date, DateTime? movedFrom, bool clearMovedFrom = false,
           DateTime? debitDate, bool clearDebitDate = false}) =>
      Transaction(
          id: id,
          categoryId: categoryId,
          description: description,
          amount: amount,
          date: date ?? this.date,
          person: person ?? this.person,
          tripId: tripId,
          checked: checked ?? this.checked,
          movedFrom: clearMovedFrom ? null : (movedFrom ?? this.movedFrom),
          debitDate: clearDebitDate ? null : (debitDate ?? this.debitDate));

  Map<String, dynamic> toJson() => {
        'id': id,
        'categoryId': categoryId,
        'description': description,
        'amount': amount,
        'date': date.toIso8601String(),
        'person': person,
        'tripId': tripId,
        'checked': checked,
        'movedFrom': movedFrom?.toIso8601String(),
        'debitDate': debitDate?.toIso8601String(),
      };
  factory Transaction.fromJson(Map<String, dynamic> j) => Transaction(
      id: j['id'],
      categoryId: j['categoryId'],
      description: j['description'],
      amount: _d(j['amount']),
      date: DateTime.parse(j['date']),
      person: j['person'] ?? 0,
      tripId: j['tripId'] as String?,
      checked: j['checked'] == true,
      movedFrom: j['movedFrom'] == null ? null : DateTime.parse(j['movedFrom'] as String),
      debitDate: j['debitDate'] == null ? null : DateTime.parse(j['debitDate'] as String));
}

enum IncomeKind { salary, bonus, refund, sale }

extension IncomeKindX on IncomeKind {
  String get label => switch (this) {
        IncomeKind.salary => 'Salaire',
        IncomeKind.bonus => 'Prime',
        IncomeKind.refund => 'Remboursement',
        IncomeKind.sale => 'Vente',
      };
}

/// Revenu ponctuel : versé une seule fois, dans le mois [ym]
/// (salaire ponctuel, prime, remboursement, vente).
class Income {
  final String id;
  final IncomeKind kind;
  final String label;
  final double amount;
  final Ym ym;
  final bool checked; // pointée : le versement a bien été reçu
  final Ym? movedFrom; // mois d'origine, si reporté car non pointé à la clôture
  const Income({
    required this.id,
    required this.kind,
    required this.label,
    required this.amount,
    required this.ym,
    this.checked = false,
    this.movedFrom,
  });

  Income copyWith({String? label, double? amount, Ym? ym, bool? checked, Ym? movedFrom, bool clearMovedFrom = false}) =>
      Income(
          id: id,
          kind: kind,
          label: label ?? this.label,
          amount: amount ?? this.amount,
          ym: ym ?? this.ym,
          checked: checked ?? this.checked,
          movedFrom: clearMovedFrom ? null : (movedFrom ?? this.movedFrom));

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'label': label,
        'amount': amount,
        'ym': ym.key,
        'checked': checked,
        'movedFrom': movedFrom?.key,
      };
  factory Income.fromJson(Map<String, dynamic> j) => Income(
      id: j['id'],
      kind: IncomeKind.values.byName(j['kind']),
      label: j['label'],
      amount: _d(j['amount']),
      ym: Ym.parse(j['ym']),
      checked: j['checked'] == true,
      movedFrom: j['movedFrom'] == null ? null : Ym.parse(j['movedFrom'] as String));
}

/// Revenu récurrent (salaire...) : chaque mois à partir de [start],
/// jusqu'à [end] (null = à l'infini). Le montant peut être modifié
/// pour un mois précis via [overrides] sans toucher aux autres mois.
/// [Mode dev] Règle de réception d'un revenu récurrent.
enum ReceiptDayKind {
  /// Pas de règle : le revenu est comptabilisé dès le 1er du mois.
  none,
  /// Jour fixe du mois (ex. le 26).
  fixedDay,
  /// Dernier jour ouvré du mois.
  lastWorkingDay,
}

/// [Mode dev] Règle de réception pour un revenu récurrent.
class ReceiptDayRule {
  final ReceiptDayKind kind;
  final int day; // utilisé uniquement si kind == fixedDay
  const ReceiptDayRule({required this.kind, this.day = 1});

  static const none = ReceiptDayRule(kind: ReceiptDayKind.none);

  /// Retourne le jour du mois auquel ce revenu est reçu.
  int dayForYm(Ym ym) {
    switch (kind) {
      case ReceiptDayKind.none:
        return 1;
      case ReceiptDayKind.fixedDay:
        final lastDay = DateTime(ym.year, ym.month + 1, 0).day;
        return day.clamp(1, lastDay);
      case ReceiptDayKind.lastWorkingDay:
        final lastDay = DateTime(ym.year, ym.month + 1, 0).day;
        var d = DateTime(ym.year, ym.month, lastDay);
        while (d.weekday == DateTime.saturday || d.weekday == DateTime.sunday) {
          d = d.subtract(const Duration(days: 1));
        }
        return d.day;
    }
  }

  Map<String, dynamic> toJson() => {'kind': kind.name, 'day': day};
  factory ReceiptDayRule.fromJson(Map<String, dynamic> j) => ReceiptDayRule(
      kind: ReceiptDayKind.values.byName(j['kind'] ?? 'none'),
      day: (j['day'] ?? 1) as int);
}

class RecurringIncome {
  final String id;
  final String label;
  final double amount;
  final Ym start;
  final Ym? end;
  final int intervalMonths; // 1 = chaque mois, 2 = un mois sur deux, etc.
  final Map<String, double> overrides; // "yyyy-MM" -> montant du mois
  final List<String> excludedMonths; // "yyyy-MM" supprimés individuellement (une seule occurrence)
  final List<String> checkedMonths; // "yyyy-MM" où le versement est pointé (bien reçu)
  final List<String> carriedMonths; // "yyyy-MM" non pointés à la clôture : reportés au mois suivant
  /// [Mode dev] Règle de réception (jour fixe ou dernier jour ouvré).
  final ReceiptDayRule receiptDay;
  /// [Mode dev] Vrai = salaire 3×8 : montant = baseSalary + primes tournante de M-2.
  final bool isShiftSalary;
  /// [Mode dev] Salaire fixe de base (utilisé quand isShiftSalary = true).
  final double baseSalary;
  const RecurringIncome({
    required this.id,
    required this.label,
    required this.amount,
    required this.start,
    this.end,
    this.intervalMonths = 1,
    this.overrides = const {},
    this.excludedMonths = const [],
    this.checkedMonths = const [],
    this.carriedMonths = const [],
    this.receiptDay = ReceiptDayRule.none,
    this.isShiftSalary = false,
    this.baseSalary = 0,
  });

  bool activeIn(Ym ym) =>
      !ym.isBefore(start) &&
      (end == null || !ym.isAfter(end!)) &&
      (intervalMonths <= 1 || (ym.index - start.index) % intervalMonths == 0) &&
      !excludedMonths.contains(ym.key);
  bool hasOverride(Ym ym) => overrides.containsKey(ym.key);
  double amountIn(Ym ym) => overrides[ym.key] ?? amount;
  bool isChecked(Ym ym) => checkedMonths.contains(ym.key);

  String get frequencyLabel => switch (intervalMonths) {
        <= 1 => 'Chaque mois',
        12 => 'Une fois par an',
        _ => 'Tous les $intervalMonths mois',
      };

  RecurringIncome copyWith(
          {String? label,
          double? amount,
          Ym? start,
          Ym? end,
          bool clearEnd = false,
          int? intervalMonths,
          Map<String, double>? overrides,
          List<String>? excludedMonths,
          List<String>? checkedMonths,
          List<String>? carriedMonths,
          ReceiptDayRule? receiptDay,
          bool? isShiftSalary,
          double? baseSalary}) =>
      RecurringIncome(
          id: id,
          label: label ?? this.label,
          amount: amount ?? this.amount,
          start: start ?? this.start,
          end: clearEnd ? null : (end ?? this.end),
          intervalMonths: intervalMonths ?? this.intervalMonths,
          overrides: overrides ?? this.overrides,
          excludedMonths: excludedMonths ?? this.excludedMonths,
          checkedMonths: checkedMonths ?? this.checkedMonths,
          carriedMonths: carriedMonths ?? this.carriedMonths,
          receiptDay: receiptDay ?? this.receiptDay,
          isShiftSalary: isShiftSalary ?? this.isShiftSalary,
          baseSalary: baseSalary ?? this.baseSalary);

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'amount': amount,
        'start': start.key,
        'end': end?.key,
        'intervalMonths': intervalMonths,
        'overrides': overrides,
        'excludedMonths': excludedMonths,
        'checkedMonths': checkedMonths,
        'carriedMonths': carriedMonths,
        'receiptDay': receiptDay.toJson(),
        'isShiftSalary': isShiftSalary,
        'baseSalary': baseSalary,
      };
  factory RecurringIncome.fromJson(Map<String, dynamic> j) => RecurringIncome(
      id: j['id'],
      label: j['label'],
      amount: _d(j['amount']),
      start: Ym.parse(j['start']),
      end: j['end'] == null ? null : Ym.parse(j['end']),
      intervalMonths: (j['intervalMonths'] ?? 1) as int,
      overrides: ((j['overrides'] ?? {}) as Map).map((k, v) => MapEntry(k as String, _d(v))),
      excludedMonths: ((j['excludedMonths'] ?? []) as List).map((e) => e as String).toList(),
      checkedMonths: ((j['checkedMonths'] ?? []) as List).map((e) => e as String).toList(),
      carriedMonths: ((j['carriedMonths'] ?? []) as List).map((e) => e as String).toList(),
      receiptDay: j['receiptDay'] == null
          ? ReceiptDayRule.none
          : ReceiptDayRule.fromJson(Map<String, dynamic>.from(j['receiptDay'] as Map)),
      isShiftSalary: j['isShiftSalary'] as bool? ?? false,
      baseSalary: ((j['baseSalary'] ?? 0) as num).toDouble());
}

class FixedExpense {
  final String id;
  final String name;
  final double amount;
  final Ym start;
  final Ym? end; // null = toujours
  final String emoji; // vide = première lettre du nom
  final int? colorValue; // null = couleur automatique
  final String? categoryId; // null = sans catégorie
  final int intervalMonths; // 1 = chaque mois, 2 = un mois sur deux, 6 = tous les 6 mois...
  final List<String> checkedMonths; // mois "yyyy-MM" où la charge est pointée
  final List<String> carriedMonths; // mois "yyyy-MM" non cochés à la clôture : reportés au mois suivant
  final List<String> excludedMonths; // mois "yyyy-MM" supprimés (un mois seul ou une période)
  /// [Mode dev] Lien vers un type de congé : quand cette charge est cochée,
  /// les jours de congé posés sont synchronisés avec l'onglet Congés.
  final String? leaveTypeId;
  const FixedExpense({
    required this.id,
    required this.name,
    required this.amount,
    required this.start,
    this.end,
    this.emoji = '',
    this.colorValue,
    this.categoryId,
    this.intervalMonths = 1,
    this.checkedMonths = const [],
    this.carriedMonths = const [],
    this.excludedMonths = const [],
    this.leaveTypeId,
  });

  bool activeIn(Ym ym) =>
      !ym.isBefore(start) &&
      (end == null || !ym.isAfter(end!)) &&
      (intervalMonths <= 1 || (ym.index - start.index) % intervalMonths == 0) &&
      !excludedMonths.contains(ym.key);
  bool isChecked(Ym ym) => checkedMonths.contains(ym.key);

  String get frequencyLabel => switch (intervalMonths) {
        <= 1 => 'Chaque mois',
        12 => 'Une fois par an',
        _ => 'Tous les $intervalMonths mois',
      };

  FixedExpense copyWith(
          {List<String>? checkedMonths, List<String>? carriedMonths, List<String>? excludedMonths,
           String? leaveTypeId, bool clearLeaveTypeId = false,
           String? categoryId, bool clearCategoryId = false}) =>
      FixedExpense(
          id: id,
          name: name,
          amount: amount,
          start: start,
          end: end,
          emoji: emoji,
          colorValue: colorValue,
          categoryId: clearCategoryId ? null : (categoryId ?? this.categoryId),
          intervalMonths: intervalMonths,
          checkedMonths: checkedMonths ?? this.checkedMonths,
          carriedMonths: carriedMonths ?? this.carriedMonths,
          excludedMonths: excludedMonths ?? this.excludedMonths,
          leaveTypeId: clearLeaveTypeId ? null : (leaveTypeId ?? this.leaveTypeId));

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'amount': amount,
        'start': start.key,
        'end': end?.key,
        'emoji': emoji,
        'colorValue': colorValue,
        'intervalMonths': intervalMonths,
        'checkedMonths': checkedMonths,
        'carriedMonths': carriedMonths,
        'excludedMonths': excludedMonths,
        'leaveTypeId': leaveTypeId,
        'categoryId': categoryId,
      };
  factory FixedExpense.fromJson(Map<String, dynamic> j) => FixedExpense(
      id: j['id'],
      name: j['name'],
      amount: _d(j['amount']),
      start: Ym.parse(j['start']),
      end: j['end'] == null ? null : Ym.parse(j['end']),
      emoji: (j['emoji'] ?? '') as String,
      colorValue: j['colorValue'] as int?,
      intervalMonths: (j['intervalMonths'] ?? 1) as int,
      checkedMonths: ((j['checkedMonths'] ?? []) as List).map((e) => e as String).toList(),
      carriedMonths: ((j['carriedMonths'] ?? []) as List).map((e) => e as String).toList(),
      excludedMonths: ((j['excludedMonths'] ?? []) as List).map((e) => e as String).toList(),
      leaveTypeId: j['leaveTypeId'] as String?,
      categoryId: j['categoryId'] as String?);
}

enum ProjectMode {
  /// On met de côté un montant chaque mois jusqu'à la date objectif.
  savings,

  /// Le montant total est débité en une fois le mois choisi.
  expense,
}

class Project {
  final String id;
  final String name;
  final double target;
  final Ym startYm;
  final Ym targetYm;
  final Map<String, double> contributions; // clé "yyyy-MM" -> montant versé
  final ProjectMode mode;
  final DateTime? tripStart; // premier jour du voyage (absence)
  final DateTime? tripEnd; // dernier jour du voyage
  final int who; // 0 = les deux, 1 / 2 = une seule personne part
  final bool isTrip; // vrai = voyage ; faux = autre projet d'épargne (voiture, apport…)
  const Project({
    required this.id,
    required this.name,
    required this.target,
    required this.startYm,
    required this.targetYm,
    this.contributions = const {},
    this.mode = ProjectMode.savings,
    this.tripStart,
    this.tripEnd,
    this.who = 0,
    this.isTrip = true,
  });

  String get emoji => isTrip ? '✈️' : '🎯';

  bool get isExpense => mode == ProjectMode.expense;

  /// Part du voyage qui tombe dans le mois [ym] (0 à 1), au prorata du nombre de jours.
  /// Ex. 9 jours en juillet et 1 en août : 0,9 pour juillet et 0,1 pour août.
  /// Sans dates : tout le voyage compte le mois du voyage.
  double shareIn(Ym ym) {
    final s = tripStart, e = tripEnd;
    if (s == null || e == null || e.isBefore(s)) return ym == targetYm ? 1.0 : 0.0;
    final start = DateTime(s.year, s.month, s.day);
    final end = DateTime(e.year, e.month, e.day);
    final total = end.difference(start).inDays + 1;
    final mFirst = DateTime(ym.year, ym.month, 1);
    final mLast = DateTime(ym.year, ym.month + 1, 0);
    final from = start.isAfter(mFirst) ? start : mFirst;
    final to = end.isBefore(mLast) ? end : mLast;
    if (to.isBefore(from)) return 0.0;
    return (to.difference(from).inDays + 1) / total;
  }

  /// Le voyage a lieu (au moins un jour) pendant ce mois.
  bool tripIn(Ym ym) => shareIn(ym) > 0;

  /// Budget du voyage pour ce mois (au prorata des jours).
  double budgetIn(Ym ym) => target * shareIn(ym);
  int get months => max(1, targetYm.index - startYm.index);
  double get monthlyPlan => target / months;
  double get saved => isExpense ? 0 : contributions.values.fold(0.0, (a, b) => a + b);
  double get progress => (isExpense || target <= 0) ? 0 : (saved / target).clamp(0.0, 1.0);
  int monthsLeft(Ym now) => max(0, targetYm.index - max(now.index, startYm.index));

  Project copyWith({Map<String, double>? contributions}) => Project(
      id: id,
      name: name,
      target: target,
      startYm: startYm,
      targetYm: targetYm,
      contributions: contributions ?? this.contributions,
      mode: mode,
      tripStart: tripStart,
      tripEnd: tripEnd,
      who: who,
      isTrip: isTrip);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'target': target,
        'startYm': startYm.key,
        'targetYm': targetYm.key,
        'contributions': contributions,
        'mode': mode.name,
        'tripStart': tripStart?.toIso8601String(),
        'tripEnd': tripEnd?.toIso8601String(),
        'who': who,
        'trip': isTrip,
      };
  factory Project.fromJson(Map<String, dynamic> j) => Project(
      id: j['id'],
      name: j['name'],
      target: _d(j['target']),
      startYm: Ym.parse(j['startYm']),
      targetYm: Ym.parse(j['targetYm']),
      contributions: (j['contributions'] as Map).map((k, v) => MapEntry(k as String, _d(v))),
      mode: ProjectMode.values.byName(j['mode'] ?? 'savings'),
      tripStart: j['tripStart'] == null ? null : DateTime.parse(j['tripStart']),
      tripEnd: j['tripEnd'] == null ? null : DateTime.parse(j['tripEnd']),
      who: j['who'] ?? 0,
      isTrip: j['trip'] ?? true);
}

/// Entrée dans l'historique des modifications (30 jours glissants).
class HistoryEntry {
  final String id;
  final DateTime date;
  final String description; // ex. "Dépense ajoutée : Carrefour · 42,50 €"
  const HistoryEntry({required this.id, required this.date, required this.description});

  Map<String, dynamic> toJson() => {'id': id, 'date': date.toIso8601String(), 'description': description};

  factory HistoryEntry.fromJson(Map<String, dynamic> j) => HistoryEntry(
      id: j['id'] as String,
      date: DateTime.parse(j['date'] as String),
      description: j['description'] as String);
}

/// Photo d'un mois clôturé : prévu vs réel.
class MonthSnapshot {
  final Ym ym;
  final double planned;
  final double spent;
  final Map<String, double> savingsByCategory; // prévu - dépensé
  final DateTime closedAt;
  const MonthSnapshot({
    required this.ym,
    required this.planned,
    required this.spent,
    required this.savingsByCategory,
    required this.closedAt,
  });

  double get savings => planned - spent;

  Map<String, dynamic> toJson() => {
        'ym': ym.key,
        'planned': planned,
        'spent': spent,
        'savingsByCategory': savingsByCategory,
        'closedAt': closedAt.toIso8601String(),
      };
  factory MonthSnapshot.fromJson(Map<String, dynamic> j) => MonthSnapshot(
      ym: Ym.parse(j['ym']),
      planned: _d(j['planned']),
      spent: _d(j['spent']),
      savingsByCategory: (j['savingsByCategory'] as Map)
          .map((k, v) => MapEntry(k as String, _d(v))),
      closedAt: DateTime.parse(j['closedAt']));
}

// ── [Mode dev] Tournante 3x8 ──────────────────────────────────────────────────

enum ShiftType { morning, afternoon, night, rest }

extension ShiftTypeX on ShiftType {
  String get label => switch (this) {
        ShiftType.morning => 'Matin',
        ShiftType.afternoon => 'Après-midi',
        ShiftType.night => 'Nuit',
        ShiftType.rest => 'Repos',
      };
  String get short => switch (this) {
        ShiftType.morning => 'M',
        ShiftType.afternoon => 'AM',
        ShiftType.night => 'N',
        ShiftType.rest => 'R',
      };
  bool get isWorking => this != ShiftType.rest;
}

/// Tournante 3x8 : cycle fixe de [cycle.length] jours à partir de [startDate].
/// Les primes déplacement et panier sont calculées par jour travaillé.
class ShiftSchedule {
  /// Séquence du cycle (34 jours par défaut).
  final List<ShiftType> cycle;
  /// Date du jour 1 du cycle.
  final DateTime startDate;
  /// Prime de déplacement par jour travaillé (€).
  final double transportAllowance;
  /// Panier repas par jour travaillé (€).
  final double mealAllowance;
  /// Jours de congés par mois : clé "yyyy-MM", valeur = nombre de jours posés.
  final Map<String, int> leaveDays;

  const ShiftSchedule({
    required this.cycle,
    required this.startDate,
    this.transportAllowance = 39.58,
    this.mealAllowance = 4.33,
    this.leaveDays = const {},
  });

  /// Cycle par défaut : M M AM N N R R R R M AM AM N N R R R M M AM AM N N R R R M M AM AM N R R R R
  static final List<ShiftType> defaultCycle = [
    ShiftType.morning, ShiftType.morning,
    ShiftType.afternoon,
    ShiftType.night, ShiftType.night,
    ShiftType.rest, ShiftType.rest, ShiftType.rest, ShiftType.rest,
    ShiftType.morning,
    ShiftType.afternoon, ShiftType.afternoon,
    ShiftType.night, ShiftType.night,
    ShiftType.rest, ShiftType.rest, ShiftType.rest,
    ShiftType.morning, ShiftType.morning,
    ShiftType.afternoon, ShiftType.afternoon,
    ShiftType.night, ShiftType.night,
    ShiftType.rest, ShiftType.rest, ShiftType.rest,
    ShiftType.morning, ShiftType.morning,
    ShiftType.afternoon, ShiftType.afternoon,
    ShiftType.night,
    ShiftType.rest, ShiftType.rest, ShiftType.rest, ShiftType.rest,
  ]; // 34 jours

  /// Retourne le type de poste pour une date donnée.
  ShiftType shiftOn(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    final s = DateTime(startDate.year, startDate.month, startDate.day);
    final diff = d.difference(s).inDays;
    if (diff < 0) return ShiftType.rest; // avant le début du cycle → repos
    final idx = diff % cycle.length;
    return cycle[idx];
  }

  /// Retourne tous les jours travaillés dans un mois donné avec leur type.
  List<({DateTime date, ShiftType shift})> workingDaysIn(Ym ym) {
    final result = <({DateTime date, ShiftType shift})>[];
    final lastDay = DateTime(ym.year, ym.month + 1, 0).day;
    for (var day = 1; day <= lastDay; day++) {
      final date = DateTime(ym.year, ym.month, day);
      final shift = shiftOn(date);
      if (shift.isWorking) result.add((date: date, shift: shift));
    }
    return result;
  }

  /// Nombre de jours travaillés dans un mois, après déduction des congés.
  int workingDayCountIn(Ym ym) {
    final raw = workingDaysIn(ym).length;
    final leave = leaveDays[ym.key] ?? 0;
    return (raw - leave).clamp(0, raw);
  }

  /// Nombre de jours de congés posés pour un mois.
  int leaveCountIn(Ym ym) => leaveDays[ym.key] ?? 0;

  /// Prime totale (déplacement + panier) pour un mois, congés déduits.
  double totalAllowanceIn(Ym ym) =>
      workingDayCountIn(ym) * (transportAllowance + mealAllowance);

  /// Détail par type de poste dans un mois.
  Map<ShiftType, int> shiftCountIn(Ym ym) {
    final counts = <ShiftType, int>{};
    for (final w in workingDaysIn(ym)) {
      counts[w.shift] = (counts[w.shift] ?? 0) + 1;
    }
    return counts;
  }

  ShiftSchedule copyWith({
    List<ShiftType>? cycle,
    DateTime? startDate,
    double? transportAllowance,
    double? mealAllowance,
    Map<String, int>? leaveDays,
  }) =>
      ShiftSchedule(
        cycle: cycle ?? this.cycle,
        startDate: startDate ?? this.startDate,
        transportAllowance: transportAllowance ?? this.transportAllowance,
        mealAllowance: mealAllowance ?? this.mealAllowance,
        leaveDays: leaveDays ?? this.leaveDays,
      );

  Map<String, dynamic> toJson() => {
        'cycle': cycle.map((s) => s.name).toList(),
        'startDate': startDate.toIso8601String(),
        'transportAllowance': transportAllowance,
        'mealAllowance': mealAllowance,
        'leaveDays': leaveDays,
      };

  factory ShiftSchedule.fromJson(Map<String, dynamic> j) => ShiftSchedule(
        cycle: ((j['cycle'] ?? []) as List)
            .map((s) => ShiftType.values.byName(s as String))
            .toList(),
        startDate: DateTime.parse(j['startDate'] as String),
        transportAllowance: ((j['transportAllowance'] ?? 39.58) as num).toDouble(),
        mealAllowance: ((j['mealAllowance'] ?? 4.33) as num).toDouble(),
        leaveDays: ((j['leaveDays'] ?? {}) as Map)
            .map((k, v) => MapEntry(k as String, (v as num).toInt())),
      );
}

/// Agrégat racine, persisté en bloc (facile à synchroniser plus tard).
class AppData {
  final UserProfile user;
  final Ym startYm; // premier mois suivi
  final double startBalance; // solde au 1er jour de startYm
  final List<Category> categories;
  final List<Budget> budgets;
  final List<Transaction> transactions;
  final List<RecurringIncome> recurringIncomes;
  final List<Income> incomes; // ponctuels
  final List<FixedExpense> fixedExpenses;
  final List<Project> projects;
  final Map<String, MonthSnapshot> snapshots;
  final List<Client> clients; // clients d'un auto-entrepreneur
  final List<InvoiceRecord> invoices; // suivi des factures (modifs, envoyée, payée, report)
  final List<HistoryEntry> historyLog; // journal des modifications (30 jours)
  /// [Mode dev] Tournante 3x8 : null = non configurée.
  final ShiftSchedule? shiftSchedule;
  /// [Mode dev] Types de congés (CP, RTT…).
  final List<LeaveType> leaveTypes;
  /// [Mode dev] Poses de congés par mois.
  final List<LeaveEntry> leaveEntries;

  const AppData({
    required this.user,
    required this.startYm,
    required this.startBalance,
    required this.categories,
    required this.budgets,
    required this.transactions,
    required this.recurringIncomes,
    required this.incomes,
    required this.fixedExpenses,
    required this.projects,
    required this.snapshots,
    this.clients = const [],
    this.invoices = const [],
    this.historyLog = const [],
    this.shiftSchedule,
    this.leaveTypes = const [],
    this.leaveEntries = const [],
  });

  AppData copyWith({
    UserProfile? user,
    Ym? startYm,
    double? startBalance,
    List<Category>? categories,
    List<Budget>? budgets,
    List<Transaction>? transactions,
    List<RecurringIncome>? recurringIncomes,
    List<Income>? incomes,
    List<FixedExpense>? fixedExpenses,
    List<Project>? projects,
    Map<String, MonthSnapshot>? snapshots,
    List<Client>? clients,
    List<InvoiceRecord>? invoices,
    List<HistoryEntry>? historyLog,
    ShiftSchedule? shiftSchedule,
    bool clearShiftSchedule = false,
    List<LeaveType>? leaveTypes,
    List<LeaveEntry>? leaveEntries,
  }) =>
      AppData(
        user: user ?? this.user,
        startYm: startYm ?? this.startYm,
        startBalance: startBalance ?? this.startBalance,
        categories: categories ?? this.categories,
        budgets: budgets ?? this.budgets,
        transactions: transactions ?? this.transactions,
        recurringIncomes: recurringIncomes ?? this.recurringIncomes,
        incomes: incomes ?? this.incomes,
        fixedExpenses: fixedExpenses ?? this.fixedExpenses,
        projects: projects ?? this.projects,
        snapshots: snapshots ?? this.snapshots,
        clients: clients ?? this.clients,
        invoices: invoices ?? this.invoices,
        historyLog: historyLog ?? this.historyLog,
        shiftSchedule: clearShiftSchedule ? null : (shiftSchedule ?? this.shiftSchedule),
        leaveTypes: leaveTypes ?? this.leaveTypes,
        leaveEntries: leaveEntries ?? this.leaveEntries,
      );

  Category? category(String id) {
    if (id == kUnexpectedId) {
      return const Category(id: kUnexpectedId, name: 'Imprévu', emoji: '⚡', colorValue: 0xFFFF9F0A);
    }
    if (id == kTripCatId) {
      return const Category(id: kTripCatId, name: 'Voyage', emoji: '✈️', colorValue: 0xFF0A84FF);
    }
    for (final c in categories) {
      if (c.id == id) return c;
    }
    return null;
  }

  RecurringIncome? recurring(String id) {
    for (final r in recurringIncomes) {
      if (r.id == id) return r;
    }
    return null;
  }

  /// [Mode dev] Calcule le montant d'un salaire 3×8 pour le mois [ym].
  /// = baseSalary + primes tournante du mois M-2.
  /// Retourne null si pas de tournante configurée ou si [r.isShiftSalary] est false.
  double? shiftSalaryAmountIn(RecurringIncome r, Ym ym) {
    if (!r.isShiftSalary || shiftSchedule == null) return null;
    final primeYm = ym.add(-2); // primes du mois M-2
    final primes = shiftSchedule!.totalAllowanceIn(primeYm);
    return r.baseSalary + primes;
  }

  List<Income> extraIncomes(Ym ym) => incomes.where((i) => i.ym == ym).toList();

  bool isClosed(Ym ym) => snapshots.containsKey(ym.key);

  List<Transaction> transactionsIn(Ym ym, {String? categoryId, int? person}) => transactions
      .where((t) =>
          t.date.year == ym.year &&
          t.date.month == ym.month &&
          (categoryId == null || t.categoryId == categoryId) &&
          (person == null || t.person == person))
      .toList()
    ..sort((a, b) => b.date.compareTo(a.date));

  /// Dépenses « normales » (soumises aux budgets) : hors imprévus et voyages.
  double spentIn(Ym ym, {String? categoryId, int? person}) =>
      transactionsIn(ym, categoryId: categoryId, person: person)
          .where((t) => !t.isSpecial)
          .fold(0.0, (s, t) => s + t.amount);

  /// Toutes les dépenses du mois, y compris imprévus et voyages.
  double allSpentIn(Ym ym) => transactionsIn(ym).fold(0.0, (s, t) => s + t.amount);

  /// Compteur d'imprévus : chaque dépense baisse directement l'estimation de fin de mois.
  double unexpectedIn(Ym ym) =>
      transactionsIn(ym, categoryId: kUnexpectedId).fold(0.0, (s, t) => s + t.amount);

  double tripSpentIn(Ym ym, String tripId) => transactionsIn(ym)
      .where((t) => t.tripId == tripId)
      .fold(0.0, (s, t) => s + t.amount);

  // ---- Couple & enveloppes ----
  bool get isCouple => user.isCouple;

  String personName(int p) => p == 1 ? user.person1 : (p == 2 ? user.person2 : '');

  /// Total des budgets prévus pour un mois (modifications de mois incluses).
  double plannedIn(Ym ym) => budgets.fold(0.0, (s, b) => s + b.amountIn(ym));

  double spentForBudget(Budget b, Ym ym) =>
      spentIn(ym, categoryId: b.categoryId, person: b.person == 0 ? null : b.person);

  /// Budgets triés par catégorie puis par personne (Loisirs Alex, Loisirs Sam, ...).
  List<Budget> get sortedBudgets {
    final idx = {for (var i = 0; i < categories.length; i++) categories[i].id: i};
    final l = [...budgets];
    l.sort((a, b) {
      final c = (idx[a.categoryId] ?? 999).compareTo(idx[b.categoryId] ?? 999);
      return c != 0 ? c : a.person.compareTo(b.person);
    });
    return l;
  }

  String budgetTitle(Budget b) {
    final n = category(b.categoryId)?.name ?? 'Budget';
    return isCouple && b.person != 0 ? '$n · ${personName(b.person)}' : n;
  }

  Map<String, dynamic> toJson() => {
        'user': user.toJson(),
        'startYm': startYm.key,
        'startBalance': startBalance,
        'categories': categories.map((e) => e.toJson()).toList(),
        'budgets': budgets.map((e) => e.toJson()).toList(),
        'transactions': transactions.map((e) => e.toJson()).toList(),
        'recurringIncomes': recurringIncomes.map((e) => e.toJson()).toList(),
        'incomes': incomes.map((e) => e.toJson()).toList(),
        'fixedExpenses': fixedExpenses.map((e) => e.toJson()).toList(),
        'projects': projects.map((e) => e.toJson()).toList(),
        'snapshots': snapshots.map((k, v) => MapEntry(k, v.toJson())),
        'clients': clients.map((e) => e.toJson()).toList(),
        'invoices': invoices.map((e) => e.toJson()).toList(),
        'historyLog': historyLog.map((e) => e.toJson()).toList(),
        'shiftSchedule': shiftSchedule?.toJson(),
        'leaveTypes': leaveTypes.map((e) => e.toJson()).toList(),
        'leaveEntries': leaveEntries.map((e) => e.toJson()).toList(),
      };

  factory AppData.fromJson(Map<String, dynamic> j) {
    List<Map<String, dynamic>> maps(String k) =>
        ((j[k] ?? []) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final startYm = Ym.parse(j['startYm']);

    late final List<RecurringIncome> recurring;
    late final List<Income> oneOff;
    if (j['recurringIncomes'] != null) {
      recurring = maps('recurringIncomes').map(RecurringIncome.fromJson).toList();
      oneOff = maps('incomes').map(Income.fromJson).toList();
    } else {
      // Migration de l'ancien format (salaire de base + modifications de mois)
      final raw = maps('incomes');
      final base = raw.where((e) => e['kind'] == 'salary' && e['ym'] == null).toList();
      final overrides = raw.where((e) => e['kind'] == 'salary' && e['ym'] != null).toList();
      recurring = [
        if (base.isNotEmpty)
          RecurringIncome(
            id: 'salary',
            label: 'Salaire',
            amount: _d(base.first['amount']),
            start: startYm,
            overrides: {for (final o in overrides) o['ym'] as String: _d(o['amount'])},
          ),
      ];
      oneOff = raw
          .where((e) => e['kind'] != 'salary' && e['ym'] != null)
          .map(Income.fromJson)
          .toList();
    }

    return AppData(
      user: UserProfile.fromJson(Map<String, dynamic>.from(j['user'] as Map)),
      startYm: startYm,
      startBalance: _d(j['startBalance']),
      categories: maps('categories').map(Category.fromJson).toList(),
      budgets: maps('budgets').map(Budget.fromJson).toList(),
      transactions: maps('transactions').map(Transaction.fromJson).toList(),
      recurringIncomes: recurring,
      incomes: oneOff,
      fixedExpenses: maps('fixedExpenses').map(FixedExpense.fromJson).toList(),
      projects: maps('projects').map(Project.fromJson).toList(),
      clients: maps('clients').map(Client.fromJson).toList(),
      invoices: maps('invoices').map(InvoiceRecord.fromJson).toList(),
      historyLog: maps('historyLog').map(HistoryEntry.fromJson).toList(),
      shiftSchedule: j['shiftSchedule'] == null
          ? null
          : ShiftSchedule.fromJson(Map<String, dynamic>.from(j['shiftSchedule'] as Map)),
      leaveTypes: maps('leaveTypes').map(LeaveType.fromJson).toList(),
      leaveEntries: maps('leaveEntries').map(LeaveEntry.fromJson).toList(),
      snapshots: (j['snapshots'] as Map).map((k, v) => MapEntry(
          k as String, MonthSnapshot.fromJson(Map<String, dynamic>.from(v as Map)))),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// [Mode dev] Compteur de congés
// ═══════════════════════════════════════════════════════════════════════════

/// Un type de congé (ex. CP, RTT, récup).
class LeaveType {
  final String id;
  final String name;       // "Congés payés", "RTT"…
  final double accrualPerMonth; // cumul mensuel (ex. 2.5 pour CP)
  final double initialBalance;  // solde de départ (au 1er mois suivi)
  final int colorValue;
  final int priority;      // ordre de prélèvement préféré (0 = premier)

  const LeaveType({
    required this.id,
    required this.name,
    this.accrualPerMonth = 0,
    this.initialBalance = 0,
    this.colorValue = 0xFF0A84FF,
    this.priority = 0,
  });

  LeaveType copyWith({
    String? name,
    double? accrualPerMonth,
    double? initialBalance,
    int? colorValue,
    int? priority,
  }) => LeaveType(
    id: id,
    name: name ?? this.name,
    accrualPerMonth: accrualPerMonth ?? this.accrualPerMonth,
    initialBalance: initialBalance ?? this.initialBalance,
    colorValue: colorValue ?? this.colorValue,
    priority: priority ?? this.priority,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'accrualPerMonth': accrualPerMonth,
    'initialBalance': initialBalance,
    'colorValue': colorValue,
    'priority': priority,
  };

  factory LeaveType.fromJson(Map<String, dynamic> j) => LeaveType(
    id: j['id'] as String,
    name: j['name'] as String,
    accrualPerMonth: _d(j['accrualPerMonth']),
    initialBalance: _d(j['initialBalance']),
    colorValue: (j['colorValue'] as num?)?.toInt() ?? 0xFF0A84FF,
    priority: (j['priority'] as num?)?.toInt() ?? 0,
  );
}

/// Une pose de congé dans un mois donné.
class LeaveEntry {
  final String id;
  final String leaveTypeId;
  final Ym month;
  final double days;       // jours posés
  final String note;

  const LeaveEntry({
    required this.id,
    required this.leaveTypeId,
    required this.month,
    required this.days,
    this.note = '',
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'leaveTypeId': leaveTypeId,
    'month': month.key,
    'days': days,
    'note': note,
  };

  factory LeaveEntry.fromJson(Map<String, dynamic> j) => LeaveEntry(
    id: j['id'] as String,
    leaveTypeId: j['leaveTypeId'] as String,
    month: Ym.parse(j['month'] as String),
    days: _d(j['days']),
    note: (j['note'] as String?) ?? '',
  );
}

/// Conflit de congés : un mois futur n'a plus assez de solde.
class LeaveConflict {
  final Ym month;
  final double demande;      // total demandé ce mois
  final double disponible;   // total réellement disponible après simulation

  const LeaveConflict({
    required this.month,
    required this.demande,
    required this.disponible,
  });

  double get manque => demande - disponible;
}
