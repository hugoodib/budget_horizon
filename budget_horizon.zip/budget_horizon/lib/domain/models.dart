import 'dart:math';
import '../core/ym.dart';
import 'business_models.dart';
export 'business_models.dart';

double _d(dynamic v) => (v as num).toDouble();

/// Mode de versement du salaire (mode développeur).
enum PayDayMode { none, fixed, lastWorkingDay, firstWorkingDayNextMonth }

int _daysInMonth(int y, int m) => DateTime(y, m + 1, 0).day;

bool _isWorkingDay(DateTime d) => d.weekday != DateTime.saturday && d.weekday != DateTime.sunday;

DateTime _lastWorkingDay(int y, int m) {
  var d = DateTime(y, m, _daysInMonth(y, m));
  while (!_isWorkingDay(d)) d = d.subtract(const Duration(days: 1));
  return d;
}

DateTime _firstWorkingDay(int y, int m) {
  var d = DateTime(y, m, 1);
  while (!_isWorkingDay(d)) d = d.add(const Duration(days: 1));
  return d;
}

/// Catégories spéciales (hors budgets) : les dépenses « imprévues » et celles d'un voyage.
const kUnexpectedId = '__unexpected';
const kTripCatId = '__trip';

class UserProfile {
  final String id;
  final String name;
  final bool isPremium; // prévu pour l'abonnement premium
  final bool isCouple; // si vrai : budgets et dépenses par personne
  final String person1;
  final String person2;
  final double uiScale; // taille de l'interface (texte) : 0.8 / 0.9 / 1.0
  final bool reduceMotion; // (inutilisé : animations supprimées)
  final bool onboarded; // false = l'assistant de configuration doit s'afficher
  final bool tourSeen; // false = la démonstration guidée doit se lancer
  final bool ae1; // la personne 1 est auto-entrepreneur
  final bool ae2; // la personne 2 (conjoint) est auto-entrepreneur
  final double urssafRate; // taux de charges URSSAF en % (ex. 23,68)
  final String? photo1; // photo de profil (JPEG en base64)
  final String? photo2;
  final bool isDemo;    // true = données d'exemple, affiche le bandeau démo
  final int themeIndex; // 0=Violet (défaut), 1=Océan, 2=Soleil, 3=Forêt
  final bool devMode;   // mode développeur (code 0807)
  final bool realDebitMode; // flux réels : date de débit différée + date de salaire réelle
  const UserProfile({
    required this.id,
    required this.name,
    this.isPremium = false,
    this.isCouple = false,
    this.person1 = 'Moi',
    this.person2 = 'Conjoint',
    this.uiScale = 0.9,
    this.reduceMotion = true,
    this.onboarded = true,
    this.tourSeen = true,
    this.ae1 = false,
    this.ae2 = false,
    this.urssafRate = 23.68,
    this.photo1,
    this.photo2,
    this.isDemo = false,
    this.themeIndex = 0,
    this.devMode = false,
    this.realDebitMode = false,
  });

  UserProfile copyWith(
          {String? name,
          bool? isCouple,
          String? person1,
          String? person2,
          double? uiScale,
          bool? reduceMotion,
          bool? onboarded,
          bool? tourSeen,
          bool? ae1,
          bool? ae2,
          double? urssafRate,
          String? photo1,
          String? photo2,
          bool? isDemo,
          int? themeIndex,
          bool? devMode,
          bool? realDebitMode,
          bool clearPhoto1 = false,
          bool clearPhoto2 = false}) =>
      UserProfile(
      id: id,
      name: name ?? this.name,
      isPremium: isPremium,
      isCouple: isCouple ?? this.isCouple,
      person1: person1 ?? this.person1,
      person2: person2 ?? this.person2,
      uiScale: uiScale ?? this.uiScale,
      reduceMotion: reduceMotion ?? this.reduceMotion,
      onboarded: onboarded ?? this.onboarded,
      tourSeen: tourSeen ?? this.tourSeen,
      ae1: ae1 ?? this.ae1,
      ae2: ae2 ?? this.ae2,
      urssafRate: urssafRate ?? this.urssafRate,
      photo1: clearPhoto1 ? null : (photo1 ?? this.photo1),
      photo2: clearPhoto2 ? null : (photo2 ?? this.photo2),
      isDemo: isDemo ?? this.isDemo,
      themeIndex: themeIndex ?? this.themeIndex,
      devMode: devMode ?? this.devMode,
      realDebitMode: realDebitMode ?? this.realDebitMode);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'isPremium': isPremium,
        'isCouple': isCouple,
        'person1': person1,
        'person2': person2,
        'uiScale': uiScale,
        'reduceMotion': reduceMotion,
        'onboarded': onboarded,
        'tourSeen': tourSeen,
        'ae1': ae1,
        'ae2': ae2,
        'urssafRate': urssafRate,
        'photo1': photo1,
        'photo2': photo2,
        'isDemo': isDemo,
        'themeIndex': themeIndex,
        'devMode': devMode,
        'realDebitMode': realDebitMode,
      };
  factory UserProfile.fromJson(Map<String, dynamic> j) => UserProfile(
      id: j['id'],
      name: j['name'],
      isPremium: j['isPremium'] ?? false,
      isCouple: j['isCouple'] ?? false,
      person1: j['person1'] ?? 'Moi',
      person2: j['person2'] ?? 'Conjoint',
      uiScale: ((j['uiScale'] ?? 0.9) as num).toDouble(),
      reduceMotion: j['reduceMotion'] ?? true,
      onboarded: j['onboarded'] ?? true,
      tourSeen: j['tourSeen'] ?? true,
      ae1: j['ae1'] ?? false,
      ae2: j['ae2'] ?? false,
      urssafRate: ((j['urssafRate'] ?? 23.68) as num).toDouble(),
      isDemo: j['isDemo'] as bool? ?? false,
      themeIndex: (j['themeIndex'] as int?) ?? 0,
      devMode: j['devMode'] as bool? ?? false,
      realDebitMode: j['realDebitMode'] as bool? ?? false,
      photo1: j['photo1'] as String?,
      photo2: j['photo2'] as String?);
}

class Category {
  final String id;
  final String name;
  final String emoji;
  final int colorValue;
  const Category({required this.id, required this.name, required this.emoji, required this.colorValue});

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'emoji': emoji, 'color': colorValue};
  factory Category.fromJson(Map<String, dynamic> j) => Category(
      id: j['id'], name: j['name'], emoji: j['emoji'], colorValue: j['color']);
}

/// Budget mensuel récurrent d'une catégorie (une enveloppe).
/// [person] : 0 = seul(e), 1 ou 2 = conjoint 1 / 2 en mode couple.
/// [overrides] : montants modifiés pour un mois précis ("yyyy-MM").
class Budget {
  final String id;
  final String categoryId;
  final double amount;
  final int person;
  final Map<String, double> overrides;
  const Budget({
    required this.id,
    required this.categoryId,
    required this.amount,
    this.person = 0,
    this.overrides = const {},
  });

  bool hasOverride(Ym ym) => overrides.containsKey(ym.key);
  double amountIn(Ym ym) => overrides[ym.key] ?? amount;

  Budget copyWith({String? id, double? amount, int? person, Map<String, double>? overrides}) => Budget(
      id: id ?? this.id,
      categoryId: categoryId,
      amount: amount ?? this.amount,
      person: person ?? this.person,
      overrides: overrides ?? this.overrides);

  Map<String, dynamic> toJson() => {
        'id': id,
        'categoryId': categoryId,
        'amount': amount,
        'person': person,
        'overrides': overrides,
      };
  factory Budget.fromJson(Map<String, dynamic> j) => Budget(
      id: j['id'],
      categoryId: j['categoryId'],
      amount: _d(j['amount']),
      person: j['person'] ?? 0,
      overrides: ((j['overrides'] ?? {}) as Map).map((k, v) => MapEntry(k as String, _d(v))));
}

class Transaction {
  final String id;
  final String categoryId;
  final String description;
  final double amount;
  final DateTime date;
  final int person; // 0 = seul(e), 1 / 2 = conjoints
  final String? tripId; // dépense rattachée à un voyage
  final bool checked; // pointée (comme dans une appli bancaire)
  final DateTime? movedFrom; // date d'origine, si reportée car non pointée à la clôture
  final DateTime? debitDate; // date réelle de débit (mode développeur : paiement différé)
  const Transaction({
    required this.id,
    required this.categoryId,
    required this.description,
    required this.amount,
    required this.date,
    this.person = 0,
    this.tripId,
    this.checked = false,
    this.movedFrom,
    this.debitDate,
  });

  /// Imprévu ou dépense de voyage : hors budgets mensuels.
  bool get isSpecial => categoryId == kUnexpectedId || tripId != null;

  Transaction copyWith(
          {int? person, bool? checked, DateTime? date, DateTime? movedFrom,
           DateTime? debitDate, bool clearMovedFrom = false, bool clearDebitDate = false}) =>
      Transaction(
          id: id,
          categoryId: categoryId,
          description: description,
          amount: amount,
          date: date ?? this.date,
          person: person ?? this.person,
          tripId: tripId,
          checked: checked ?? this.checked,
          movedFrom: clearMovedFrom ? null : (movedFrom ?? this.movedFrom),
          debitDate: clearDebitDate ? null : (debitDate ?? this.debitDate));

  /// Date à utiliser pour les calculs de flux (mode débit réel activé ou non).
  DateTime effectiveDate(bool useRealDebit) =>
      useRealDebit && debitDate != null ? debitDate! : date;

  Map<String, dynamic> toJson() => {
        'id': id,
        'categoryId': categoryId,
        'description': description,
        'amount': amount,
        'date': date.toIso8601String(),
        'person': person,
        'tripId': tripId,
        'checked': checked,
        'movedFrom': movedFrom?.toIso8601String(),
        'debitDate': debitDate?.toIso8601String(),
      };
  factory Transaction.fromJson(Map<String, dynamic> j) => Transaction(
      id: j['id'],
      categoryId: j['categoryId'],
      description: j['description'],
      amount: _d(j['amount']),
      date: DateTime.parse(j['date']),
      person: j['person'] ?? 0,
      tripId: j['tripId'] as String?,
      checked: j['checked'] == true,
      movedFrom: j['movedFrom'] == null ? null : DateTime.parse(j['movedFrom'] as String),
      debitDate: j['debitDate'] == null ? null : DateTime.parse(j['debitDate'] as String));
}

enum IncomeKind { salary, bonus, refund, sale }

extension IncomeKindX on IncomeKind {
  String get label => switch (this) {
        IncomeKind.salary => 'Salaire',
        IncomeKind.bonus => 'Prime',
        IncomeKind.refund => 'Remboursement',
        IncomeKind.sale => 'Vente',
      };
}

/// Revenu ponctuel : versé une seule fois, dans le mois [ym]
/// (salaire ponctuel, prime, remboursement, vente).
class Income {
  final String id;
  final IncomeKind kind;
  final String label;
  final double amount;
  final Ym ym;
  final bool checked; // pointée : le versement a bien été reçu
  final Ym? movedFrom; // mois d'origine, si reporté car non pointé à la clôture
  const Income({
    required this.id,
    required this.kind,
    required this.label,
    required this.amount,
    required this.ym,
    this.checked = false,
    this.movedFrom,
  });

  Income copyWith({String? label, double? amount, Ym? ym, bool? checked, Ym? movedFrom, bool clearMovedFrom = false}) =>
      Income(
          id: id,
          kind: kind,
          label: label ?? this.label,
          amount: amount ?? this.amount,
          ym: ym ?? this.ym,
          checked: checked ?? this.checked,
          movedFrom: clearMovedFrom ? null : (movedFrom ?? this.movedFrom));

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind.name,
        'label': label,
        'amount': amount,
        'ym': ym.key,
        'checked': checked,
        'movedFrom': movedFrom?.key,
      };
  factory Income.fromJson(Map<String, dynamic> j) => Income(
      id: j['id'],
      kind: IncomeKind.values.byName(j['kind']),
      label: j['label'],
      amount: _d(j['amount']),
      ym: Ym.parse(j['ym']),
      checked: j['checked'] == true,
      movedFrom: j['movedFrom'] == null ? null : Ym.parse(j['movedFrom'] as String));
}

/// Revenu récurrent (salaire...) : chaque mois à partir de [start],
/// jusqu'à [end] (null = à l'infini). Le montant peut être modifié
/// pour un mois précis via [overrides] sans toucher aux autres mois.
class RecurringIncome {
  final String id;
  final String label;
  final double amount;
  final Ym start;
  final Ym? end;
  final int intervalMonths; // 1 = chaque mois, 2 = un mois sur deux, etc.
  final Map<String, double> overrides; // "yyyy-MM" -> montant du mois
  final List<String> excludedMonths; // "yyyy-MM" supprimés individuellement (une seule occurrence)
  final List<String> checkedMonths; // "yyyy-MM" où le versement est pointé (bien reçu)
  final List<String> carriedMonths; // "yyyy-MM" non pointés à la clôture : reportés au mois suivant
  // Mode développeur : date de versement réelle
  final PayDayMode payDayMode; // fixe, dernier jour ouvré, premier jour ouvré mois suivant
  final int payDay; // jour du mois pour le mode fixe (ex: 28)
  const RecurringIncome({
    required this.id,
    required this.label,
    required this.amount,
    required this.start,
    this.end,
    this.intervalMonths = 1,
    this.overrides = const {},
    this.excludedMonths = const [],
    this.checkedMonths = const [],
    this.carriedMonths = const [],
    this.payDayMode = PayDayMode.none,
    this.payDay = 28,
  });

  /// Calcule la date réelle de versement pour un mois donné.
  DateTime? realPayDate(Ym ym) {
    if (payDayMode == PayDayMode.none) return null;
    if (payDayMode == PayDayMode.fixed) {
      final d = payDay.clamp(1, _daysInMonth(ym.year, ym.month));
      return DateTime(ym.year, ym.month, d);
    }
    if (payDayMode == PayDayMode.lastWorkingDay) {
      return _lastWorkingDay(ym.year, ym.month);
    }
    if (payDayMode == PayDayMode.firstWorkingDayNextMonth) {
      final next = ym.add(1);
      return _firstWorkingDay(next.year, next.month);
    }
    return null;
  }

  bool activeIn(Ym ym) =>
      !ym.isBefore(start) &&
      (end == null || !ym.isAfter(end!)) &&
      (intervalMonths <= 1 || (ym.index - start.index) % intervalMonths == 0) &&
      !excludedMonths.contains(ym.key);
  bool hasOverride(Ym ym) => overrides.containsKey(ym.key);
  double amountIn(Ym ym) => overrides[ym.key] ?? amount;
  bool isChecked(Ym ym) => checkedMonths.contains(ym.key);

  String get frequencyLabel => switch (intervalMonths) {
        <= 1 => 'Chaque mois',
        12 => 'Une fois par an',
        _ => 'Tous les $intervalMonths mois',
      };

  RecurringIncome copyWith(
          {String? label,
          double? amount,
          Ym? start,
          Ym? end,
          bool clearEnd = false,
          int? intervalMonths,
          Map<String, double>? overrides,
          List<String>? excludedMonths,
          List<String>? checkedMonths,
          List<String>? carriedMonths,
          PayDayMode? payDayMode,
          int? payDay}) =>
      RecurringIncome(
          id: id,
          label: label ?? this.label,
          amount: amount ?? this.amount,
          start: start ?? this.start,
          end: clearEnd ? null : (end ?? this.end),
          intervalMonths: intervalMonths ?? this.intervalMonths,
          overrides: overrides ?? this.overrides,
          excludedMonths: excludedMonths ?? this.excludedMonths,
          checkedMonths: checkedMonths ?? this.checkedMonths,
          carriedMonths: carriedMonths ?? this.carriedMonths,
          payDayMode: payDayMode ?? this.payDayMode,
          payDay: payDay ?? this.payDay);

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'amount': amount,
        'start': start.key,
        'end': end?.key,
        'intervalMonths': intervalMonths,
        'overrides': overrides,
        'excludedMonths': excludedMonths,
        'checkedMonths': checkedMonths,
        'carriedMonths': carriedMonths,
        'payDayMode': payDayMode.name,
        'payDay': payDay,
      };
  factory RecurringIncome.fromJson(Map<String, dynamic> j) => RecurringIncome(
      id: j['id'],
      label: j['label'],
      amount: _d(j['amount']),
      start: Ym.parse(j['start']),
      end: j['end'] == null ? null : Ym.parse(j['end']),
      intervalMonths: (j['intervalMonths'] ?? 1) as int,
      overrides: ((j['overrides'] ?? {}) as Map).map((k, v) => MapEntry(k as String, _d(v))),
      excludedMonths: ((j['excludedMonths'] ?? []) as List).map((e) => e as String).toList(),
      checkedMonths: ((j['checkedMonths'] ?? []) as List).map((e) => e as String).toList(),
      carriedMonths: ((j['carriedMonths'] ?? []) as List).map((e) => e as String).toList(),
      payDayMode: PayDayMode.values.firstWhere(
          (e) => e.name == (j['payDayMode'] ?? 'none'), orElse: () => PayDayMode.none),
      payDay: (j['payDay'] as int?) ?? 28);
}

class FixedExpense {
  final String id;
  final String name;
  final double amount;
  final Ym start;
  final Ym? end; // null = toujours
  final String emoji; // vide = première lettre du nom
  final int? colorValue; // null = couleur automatique
  final int intervalMonths; // 1 = chaque mois, 2 = un mois sur deux, 6 = tous les 6 mois...
  final List<String> checkedMonths; // mois "yyyy-MM" où la charge est pointée
  final List<String> carriedMonths; // mois "yyyy-MM" non cochés à la clôture : reportés au mois suivant
  final List<String> excludedMonths; // mois "yyyy-MM" supprimés (un mois seul ou une période)
  const FixedExpense({
    required this.id,
    required this.name,
    required this.amount,
    required this.start,
    this.end,
    this.emoji = '',
    this.colorValue,
    this.intervalMonths = 1,
    this.checkedMonths = const [],
    this.carriedMonths = const [],
    this.excludedMonths = const [],
  });

  bool activeIn(Ym ym) =>
      !ym.isBefore(start) &&
      (end == null || !ym.isAfter(end!)) &&
      (intervalMonths <= 1 || (ym.index - start.index) % intervalMonths == 0) &&
      !excludedMonths.contains(ym.key);
  bool isChecked(Ym ym) => checkedMonths.contains(ym.key);

  String get frequencyLabel => switch (intervalMonths) {
        <= 1 => 'Chaque mois',
        12 => 'Une fois par an',
        _ => 'Tous les $intervalMonths mois',
      };

  FixedExpense copyWith(
          {List<String>? checkedMonths, List<String>? carriedMonths, List<String>? excludedMonths}) =>
      FixedExpense(
          id: id,
          name: name,
          amount: amount,
          start: start,
          end: end,
          emoji: emoji,
          colorValue: colorValue,
          intervalMonths: intervalMonths,
          checkedMonths: checkedMonths ?? this.checkedMonths,
          carriedMonths: carriedMonths ?? this.carriedMonths,
          excludedMonths: excludedMonths ?? this.excludedMonths);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'amount': amount,
        'start': start.key,
        'end': end?.key,
        'emoji': emoji,
        'colorValue': colorValue,
        'intervalMonths': intervalMonths,
        'checkedMonths': checkedMonths,
        'carriedMonths': carriedMonths,
        'excludedMonths': excludedMonths,
      };
  factory FixedExpense.fromJson(Map<String, dynamic> j) => FixedExpense(
      id: j['id'],
      name: j['name'],
      amount: _d(j['amount']),
      start: Ym.parse(j['start']),
      end: j['end'] == null ? null : Ym.parse(j['end']),
      emoji: (j['emoji'] ?? '') as String,
      colorValue: j['colorValue'] as int?,
      intervalMonths: (j['intervalMonths'] ?? 1) as int,
      checkedMonths: ((j['checkedMonths'] ?? []) as List).map((e) => e as String).toList(),
      carriedMonths: ((j['carriedMonths'] ?? []) as List).map((e) => e as String).toList(),
      excludedMonths: ((j['excludedMonths'] ?? []) as List).map((e) => e as String).toList());
}

enum ProjectMode {
  /// On met de côté un montant chaque mois jusqu'à la date objectif.
  savings,

  /// Le montant total est débité en une fois le mois choisi.
  expense,
}

class Project {
  final String id;
  final String name;
  final double target;
  final Ym startYm;
  final Ym targetYm;
  final Map<String, double> contributions; // clé "yyyy-MM" -> montant versé
  final ProjectMode mode;
  final DateTime? tripStart; // premier jour du voyage (absence)
  final DateTime? tripEnd; // dernier jour du voyage
  final int who; // 0 = les deux, 1 / 2 = une seule personne part
  final bool isTrip; // vrai = voyage ; faux = autre projet d'épargne (voiture, apport…)
  const Project({
    required this.id,
    required this.name,
    required this.target,
    required this.startYm,
    required this.targetYm,
    this.contributions = const {},
    this.mode = ProjectMode.savings,
    this.tripStart,
    this.tripEnd,
    this.who = 0,
    this.isTrip = true,
  });

  String get emoji => isTrip ? '✈️' : '🎯';

  bool get isExpense => mode == ProjectMode.expense;

  /// Part du voyage qui tombe dans le mois [ym] (0 à 1), au prorata du nombre de jours.
  /// Ex. 9 jours en juillet et 1 en août : 0,9 pour juillet et 0,1 pour août.
  /// Sans dates : tout le voyage compte le mois du voyage.
  double shareIn(Ym ym) {
    final s = tripStart, e = tripEnd;
    if (s == null || e == null || e.isBefore(s)) return ym == targetYm ? 1.0 : 0.0;
    final start = DateTime(s.year, s.month, s.day);
    final end = DateTime(e.year, e.month, e.day);
    final total = end.difference(start).inDays + 1;
    final mFirst = DateTime(ym.year, ym.month, 1);
    final mLast = DateTime(ym.year, ym.month + 1, 0);
    final from = start.isAfter(mFirst) ? start : mFirst;
    final to = end.isBefore(mLast) ? end : mLast;
    if (to.isBefore(from)) return 0.0;
    return (to.difference(from).inDays + 1) / total;
  }

  /// Le voyage a lieu (au moins un jour) pendant ce mois.
  bool tripIn(Ym ym) => shareIn(ym) > 0;

  /// Budget du voyage pour ce mois (au prorata des jours).
  double budgetIn(Ym ym) => target * shareIn(ym);
  int get months => max(1, targetYm.index - startYm.index);
  double get monthlyPlan => target / months;
  double get saved => isExpense ? 0 : contributions.values.fold(0.0, (a, b) => a + b);
  double get progress => (isExpense || target <= 0) ? 0 : (saved / target).clamp(0.0, 1.0);
  int monthsLeft(Ym now) => max(0, targetYm.index - max(now.index, startYm.index));

  Project copyWith({Map<String, double>? contributions}) => Project(
      id: id,
      name: name,
      target: target,
      startYm: startYm,
      targetYm: targetYm,
      contributions: contributions ?? this.contributions,
      mode: mode,
      tripStart: tripStart,
      tripEnd: tripEnd,
      who: who,
      isTrip: isTrip);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'target': target,
        'startYm': startYm.key,
        'targetYm': targetYm.key,
        'contributions': contributions,
        'mode': mode.name,
        'tripStart': tripStart?.toIso8601String(),
        'tripEnd': tripEnd?.toIso8601String(),
        'who': who,
        'trip': isTrip,
      };
  factory Project.fromJson(Map<String, dynamic> j) => Project(
      id: j['id'],
      name: j['name'],
      target: _d(j['target']),
      startYm: Ym.parse(j['startYm']),
      targetYm: Ym.parse(j['targetYm']),
      contributions: (j['contributions'] as Map).map((k, v) => MapEntry(k as String, _d(v))),
      mode: ProjectMode.values.byName(j['mode'] ?? 'savings'),
      tripStart: j['tripStart'] == null ? null : DateTime.parse(j['tripStart']),
      tripEnd: j['tripEnd'] == null ? null : DateTime.parse(j['tripEnd']),
      who: j['who'] ?? 0,
      isTrip: j['trip'] ?? true);
}

/// Entrée dans l'historique des modifications (30 jours glissants).
class HistoryEntry {
  final String id;
  final DateTime date;
  final String description; // ex. "Dépense ajoutée : Carrefour · 42,50 €"
  const HistoryEntry({required this.id, required this.date, required this.description});

  Map<String, dynamic> toJson() => {'id': id, 'date': date.toIso8601String(), 'description': description};

  factory HistoryEntry.fromJson(Map<String, dynamic> j) => HistoryEntry(
      id: j['id'] as String,
      date: DateTime.parse(j['date'] as String),
      description: j['description'] as String);
}

/// Photo d'un mois clôturé : prévu vs réel.
class MonthSnapshot {
  final Ym ym;
  final double planned;
  final double spent;
  final Map<String, double> savingsByCategory; // prévu - dépensé
  final DateTime closedAt;
  const MonthSnapshot({
    required this.ym,
    required this.planned,
    required this.spent,
    required this.savingsByCategory,
    required this.closedAt,
  });

  double get savings => planned - spent;

  Map<String, dynamic> toJson() => {
        'ym': ym.key,
        'planned': planned,
        'spent': spent,
        'savingsByCategory': savingsByCategory,
        'closedAt': closedAt.toIso8601String(),
      };
  factory MonthSnapshot.fromJson(Map<String, dynamic> j) => MonthSnapshot(
      ym: Ym.parse(j['ym']),
      planned: _d(j['planned']),
      spent: _d(j['spent']),
      savingsByCategory: (j['savingsByCategory'] as Map)
          .map((k, v) => MapEntry(k as String, _d(v))),
      closedAt: DateTime.parse(j['closedAt']));
}

/// Agrégat racine, persisté en bloc (facile à synchroniser plus tard).
class AppData {
  final UserProfile user;
  final Ym startYm; // premier mois suivi
  final double startBalance; // solde au 1er jour de startYm
  final List<Category> categories;
  final List<Budget> budgets;
  final List<Transaction> transactions;
  final List<RecurringIncome> recurringIncomes;
  final List<Income> incomes; // ponctuels
  final List<FixedExpense> fixedExpenses;
  final List<Project> projects;
  final Map<String, MonthSnapshot> snapshots;
  final List<Client> clients; // clients d'un auto-entrepreneur
  final List<InvoiceRecord> invoices; // suivi des factures (modifs, envoyée, payée, report)
  final List<HistoryEntry> historyLog; // journal des modifications (30 jours)

  const AppData({
    required this.user,
    required this.startYm,
    required this.startBalance,
    required this.categories,
    required this.budgets,
    required this.transactions,
    required this.recurringIncomes,
    required this.incomes,
    required this.fixedExpenses,
    required this.projects,
    required this.snapshots,
    this.clients = const [],
    this.invoices = const [],
    this.historyLog = const [],
  });

  AppData copyWith({
    UserProfile? user,
    Ym? startYm,
    double? startBalance,
    List<Category>? categories,
    List<Budget>? budgets,
    List<Transaction>? transactions,
    List<RecurringIncome>? recurringIncomes,
    List<Income>? incomes,
    List<FixedExpense>? fixedExpenses,
    List<Project>? projects,
    Map<String, MonthSnapshot>? snapshots,
    List<Client>? clients,
    List<InvoiceRecord>? invoices,
    List<HistoryEntry>? historyLog,
  }) =>
      AppData(
        user: user ?? this.user,
        startYm: startYm ?? this.startYm,
        startBalance: startBalance ?? this.startBalance,
        categories: categories ?? this.categories,
        budgets: budgets ?? this.budgets,
        transactions: transactions ?? this.transactions,
        recurringIncomes: recurringIncomes ?? this.recurringIncomes,
        incomes: incomes ?? this.incomes,
        fixedExpenses: fixedExpenses ?? this.fixedExpenses,
        projects: projects ?? this.projects,
        snapshots: snapshots ?? this.snapshots,
        clients: clients ?? this.clients,
        invoices: invoices ?? this.invoices,
        historyLog: historyLog ?? this.historyLog,
      );

  Category? category(String id) {
    if (id == kUnexpectedId) {
      return const Category(id: kUnexpectedId, name: 'Imprévu', emoji: '⚡', colorValue: 0xFFFF9F0A);
    }
    if (id == kTripCatId) {
      return const Category(id: kTripCatId, name: 'Voyage', emoji: '✈️', colorValue: 0xFF0A84FF);
    }
    for (final c in categories) {
      if (c.id == id) return c;
    }
    return null;
  }

  RecurringIncome? recurring(String id) {
    for (final r in recurringIncomes) {
      if (r.id == id) return r;
    }
    return null;
  }

  List<Income> extraIncomes(Ym ym) => incomes.where((i) => i.ym == ym).toList();

  bool isClosed(Ym ym) => snapshots.containsKey(ym.key);

  List<Transaction> transactionsIn(Ym ym, {String? categoryId, int? person}) => transactions
      .where((t) =>
          t.date.year == ym.year &&
          t.date.month == ym.month &&
          (categoryId == null || t.categoryId == categoryId) &&
          (person == null || t.person == person))
      .toList()
    ..sort((a, b) => b.date.compareTo(a.date));

  /// Dépenses « normales » (soumises aux budgets) : hors imprévus et voyages.
  double spentIn(Ym ym, {String? categoryId, int? person}) =>
      transactionsIn(ym, categoryId: categoryId, person: person)
          .where((t) => !t.isSpecial)
          .fold(0.0, (s, t) => s + t.amount);

  /// Toutes les dépenses du mois, y compris imprévus et voyages.
  double allSpentIn(Ym ym) => transactionsIn(ym).fold(0.0, (s, t) => s + t.amount);

  /// Compteur d'imprévus : chaque dépense baisse directement l'estimation de fin de mois.
  double unexpectedIn(Ym ym) =>
      transactionsIn(ym, categoryId: kUnexpectedId).fold(0.0, (s, t) => s + t.amount);

  double tripSpentIn(Ym ym, String tripId) => transactionsIn(ym)
      .where((t) => t.tripId == tripId)
      .fold(0.0, (s, t) => s + t.amount);

  // ---- Couple & enveloppes ----
  bool get isCouple => user.isCouple;

  String personName(int p) => p == 1 ? user.person1 : (p == 2 ? user.person2 : '');

  /// Total des budgets prévus pour un mois (modifications de mois incluses).
  double plannedIn(Ym ym) => budgets.fold(0.0, (s, b) => s + b.amountIn(ym));

  double spentForBudget(Budget b, Ym ym) =>
      spentIn(ym, categoryId: b.categoryId, person: b.person == 0 ? null : b.person);

  /// Budgets triés par catégorie puis par personne (Loisirs Alex, Loisirs Sam, ...).
  List<Budget> get sortedBudgets {
    final idx = {for (var i = 0; i < categories.length; i++) categories[i].id: i};
    final l = [...budgets];
    l.sort((a, b) {
      final c = (idx[a.categoryId] ?? 999).compareTo(idx[b.categoryId] ?? 999);
      return c != 0 ? c : a.person.compareTo(b.person);
    });
    return l;
  }

  String budgetTitle(Budget b) {
    final n = category(b.categoryId)?.name ?? 'Budget';
    return isCouple && b.person != 0 ? '$n · ${personName(b.person)}' : n;
  }

  Map<String, dynamic> toJson() => {
        'user': user.toJson(),
        'startYm': startYm.key,
        'startBalance': startBalance,
        'categories': categories.map((e) => e.toJson()).toList(),
        'budgets': budgets.map((e) => e.toJson()).toList(),
        'transactions': transactions.map((e) => e.toJson()).toList(),
        'recurringIncomes': recurringIncomes.map((e) => e.toJson()).toList(),
        'incomes': incomes.map((e) => e.toJson()).toList(),
        'fixedExpenses': fixedExpenses.map((e) => e.toJson()).toList(),
        'projects': projects.map((e) => e.toJson()).toList(),
        'snapshots': snapshots.map((k, v) => MapEntry(k, v.toJson())),
        'clients': clients.map((e) => e.toJson()).toList(),
        'invoices': invoices.map((e) => e.toJson()).toList(),
        'historyLog': historyLog.map((e) => e.toJson()).toList(),
      };

  factory AppData.fromJson(Map<String, dynamic> j) {
    List<Map<String, dynamic>> maps(String k) =>
        ((j[k] ?? []) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final startYm = Ym.parse(j['startYm']);

    late final List<RecurringIncome> recurring;
    late final List<Income> oneOff;
    if (j['recurringIncomes'] != null) {
      recurring = maps('recurringIncomes').map(RecurringIncome.fromJson).toList();
      oneOff = maps('incomes').map(Income.fromJson).toList();
    } else {
      // Migration de l'ancien format (salaire de base + modifications de mois)
      final raw = maps('incomes');
      final base = raw.where((e) => e['kind'] == 'salary' && e['ym'] == null).toList();
      final overrides = raw.where((e) => e['kind'] == 'salary' && e['ym'] != null).toList();
      recurring = [
        if (base.isNotEmpty)
          RecurringIncome(
            id: 'salary',
            label: 'Salaire',
            amount: _d(base.first['amount']),
            start: startYm,
            overrides: {for (final o in overrides) o['ym'] as String: _d(o['amount'])},
          ),
      ];
      oneOff = raw
          .where((e) => e['kind'] != 'salary' && e['ym'] != null)
          .map(Income.fromJson)
          .toList();
    }

    return AppData(
      user: UserProfile.fromJson(Map<String, dynamic>.from(j['user'] as Map)),
      startYm: startYm,
      startBalance: _d(j['startBalance']),
      categories: maps('categories').map(Category.fromJson).toList(),
      budgets: maps('budgets').map(Budget.fromJson).toList(),
      transactions: maps('transactions').map(Transaction.fromJson).toList(),
      recurringIncomes: recurring,
      incomes: oneOff,
      fixedExpenses: maps('fixedExpenses').map(FixedExpense.fromJson).toList(),
      projects: maps('projects').map(Project.fromJson).toList(),
      clients: maps('clients').map(Client.fromJson).toList(),
      invoices: maps('invoices').map(InvoiceRecord.fromJson).toList(),
      historyLog: maps('historyLog').map(HistoryEntry.fromJson).toList(),
      snapshots: (j['snapshots'] as Map).map((k, v) => MapEntry(
          k as String, MonthSnapshot.fromJson(Map<String, dynamic>.from(v as Map)))),
    );
  }
}
