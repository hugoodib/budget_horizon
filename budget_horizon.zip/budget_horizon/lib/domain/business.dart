import 'dart:math';
import '../core/ym.dart';
import 'models.dart';

/// Onglet Factures et report des factures impayées : activés à l'étape 2.
/// Tant que c'est faux, toutes les factures sont considérées comme reçues dans leur mois.
const kInvoicesEnabled = true;

/// Une facture (client × mois) avec son calcul.
class InvoiceView {
  final Client client;
  final Ym ym; // mois de la facture
  final double plannedVisits; // passages prévus par le planning (voyages déduits)
  final int absentVisits; // passages perdus à cause d'un voyage
  final double visits; // passages retenus (modifiés à la main ou prévus)
  final double amount; // montant brut de la facture
  final InvoiceRecord? record;
  /// Client au forfait : montant du forfait (null = facturation au passage).
  final double? forfait;
  /// Client au forfait : passages manqués déduits (voyages + saisis à la main).
  final double missed;
  const InvoiceView({
    required this.client,
    required this.ym,
    required this.plannedVisits,
    required this.absentVisits,
    required this.visits,
    required this.amount,
    this.record,
    this.forfait,
    this.missed = 0,
  });

  bool get overridden => record?.overrideVisits != null || record?.overrideAmount != null;
  bool get sent => record?.sent ?? false;
  bool get paid => record?.paid ?? false;

  /// Mois où l'argent est compté (report si la facture n'a pas été payée à la clôture).
  Ym get receivedYm => record?.receivedYm ?? ym;
  bool get isLate => receivedYm != ym;
}

int _dayKey(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

extension BusinessX on AppData {
  /// Au moins une personne est auto-entrepreneur.
  bool get hasAE => user.ae1 || (isCouple && user.ae2);

  bool aeActive(int person) => person == 2 ? (isCouple && user.ae2) : user.ae1;

  Client? clientById(String id) {
    for (final c in clients) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// Ce jour tombe-t-il pendant un voyage (avec dates) qui concerne [owner] ?
  bool isAbsent(DateTime day, int owner) {
    final k = _dayKey(day);
    for (final p in projects) {
      final s = p.tripStart;
      final e = p.tripEnd;
      if (s == null || e == null) continue;
      if (p.who != 0 && p.who != owner) continue;
      if (k >= _dayKey(s) && k <= _dayKey(e)) return true;
    }
    return false;
  }

  /// Passages prévus par le planning du client pour un mois, et passages perdus (voyages).
  ({double visits, int absent}) plannedVisits(Client c, Ym ym) {
    if (!c.activeIn(ym)) return (visits: 0.0, absent: 0);
    switch (c.kind) {
      case FreqKind.weekdays:
        var n = 0;
        var lost = 0;
        final days = DateTime(ym.year, ym.month + 1, 0).day;
        for (var day = 1; day <= days; day++) {
          final dt = DateTime(ym.year, ym.month, day);
          if (!c.weekdays.contains(dt.weekday)) continue;
          if (isAbsent(dt, c.owner)) {
            lost++;
          } else {
            n++;
          }
        }
        return (visits: n.toDouble(), absent: lost);
      case FreqKind.weekly:
        var mondays = 0;
        final days = DateTime(ym.year, ym.month + 1, 0).day;
        for (var day = 1; day <= days; day++) {
          if (DateTime(ym.year, ym.month, day).weekday == DateTime.monday) mondays++;
        }
        return (visits: (mondays * c.times).toDouble(), absent: 0);
      case FreqKind.monthly:
        return (visits: c.times.toDouble(), absent: 0);
      case FreqKind.everyMonths:
        final diff = ym.index - c.start.index;
        return (visits: (diff % max(1, c.interval) == 0) ? c.times.toDouble() : 0.0, absent: 0);
      case FreqKind.yearly:
        return (visits: ym.month == c.start.month ? 1.0 : 0.0, absent: 0);
    }
  }

  InvoiceRecord? invoiceRecord(String clientId, Ym ym) {
    for (final r in invoices) {
      if (r.clientId == clientId && r.ym == ym) return r;
    }
    return null;
  }

  InvoiceView invoiceView(Client c, Ym ym) {
    final planned = plannedVisits(c, ym);
    final r = invoiceRecord(c.id, ym);
    double visits;
    double amount;
    double missed = 0;
    final forfait = c.forfait;
    if (r != null && r.overrideAmount != null) {
      amount = r.overrideAmount!;
      visits = c.amount > 0 ? amount / c.amount : 0.0;
    } else if (forfait != null && c.activeIn(ym)) {
      // Forfait lissé : même montant chaque mois, moins (passages manqués × prix d'un passage).
      missed = planned.absent + (r?.missedVisits ?? 0);
      amount = max(0.0, forfait - missed * c.amount);
      visits = max(0.0, planned.visits - (r?.missedVisits ?? 0));
    } else if (r != null && r.overrideVisits != null) {
      visits = r.overrideVisits!;
      amount = visits * c.amount;
    } else {
      visits = planned.visits;
      amount = visits * c.amount;
    }
    return InvoiceView(
      client: c,
      ym: ym,
      plannedVisits: planned.visits,
      absentVisits: planned.absent,
      visits: visits,
      amount: amount,
      record: r,
      forfait: forfait != null && c.activeIn(ym) ? forfait : null,
      missed: missed,
    );
  }

  /// Factures émises pour un mois (une par client concerné).
  List<InvoiceView> invoicesIssuedIn(Ym ym) {
    final out = <InvoiceView>[];
    for (final c in clients) {
      if (!aeActive(c.owner)) continue;
      final v = invoiceView(c, ym);
      if (v.amount > 0.005 || v.plannedVisits > 0 || v.record != null) out.add(v);
    }
    return out;
  }

  /// Factures dont l'argent est compté dans ce mois (y compris les retards reportés).
  List<InvoiceView> invoicesReceivedIn(Ym ym, {int? person}) {
    final out = <InvoiceView>[];
    for (final c in clients) {
      if (!aeActive(c.owner)) continue;
      if (person != null && c.owner != person) continue;
      final v = invoiceView(c, ym);
      if (v.receivedYm == ym && v.amount > 0.005) out.add(v);
    }
    for (final r in invoices) {
      if (r.ym == ym || r.receivedYm != ym) continue;
      final c = clientById(r.clientId);
      if (c == null || !aeActive(c.owner)) continue;
      if (person != null && c.owner != person) continue;
      final v = invoiceView(c, r.ym);
      if (v.amount > 0.005) out.add(v);
    }
    return out;
  }

  /// [Mode privé] Retenue de la coopérative Unipro sur une facture (0 pour un client classique).
  double coopCut(InvoiceView v) =>
      (user.privateMode && v.client.unipro) ? v.amount * user.uniproRate / 100 : 0.0;

  /// Montant de la facture réellement perçu avant URSSAF (après retenue Unipro).
  double afterCoop(InvoiceView v) => v.amount - coopCut(v);

  /// Brut perçu (après retenue Unipro éventuelle), avant charges URSSAF.
  double grossReceivedIn(Ym ym, int person) =>
      invoicesReceivedIn(ym, person: person).fold(0.0, (s, v) => s + afterCoop(v));

  /// Part du brut du mois qui vient de mois précédents (retards de paiement).
  double lateGrossReceivedIn(Ym ym, int person) => invoicesReceivedIn(ym, person: person)
      .where((v) => v.ym != ym)
      .fold(0.0, (s, v) => s + afterCoop(v));

  /// Salaire net = brut moins les charges URSSAF.
  double netFromGross(double gross) => gross * (1 - user.urssafRate / 100);

  /// Factures non payées dont l'argent devrait arriver ce mois-ci (à la clôture : report).
  List<InvoiceView> unpaidReceivedIn(Ym ym) =>
      invoicesReceivedIn(ym).where((v) => !v.paid).toList();
}
