import 'dart:math';
import '../core/ym.dart';
import 'models.dart';

/// Onglet Factures et report des factures impayées : activés à l'étape 2.
/// Tant que c'est faux, toutes les factures sont considérées comme reçues dans leur mois.
const kInvoicesEnabled = true;

/// Une facture (client × mois) avec son calcul.
class InvoiceView {
  final Client client;
  final Ym ym; // mois de la facture
  final double plannedVisits; // passages prévus par le planning (voyages déduits)
  final int absentVisits; // passages perdus à cause d'un voyage
  final double visits; // passages retenus (modifiés à la main ou prévus)
  final double amount; // montant brut de la facture
  final InvoiceRecord? record;
  /// Client au forfait : montant du forfait (null = facturation au passage).
  final double? forfait;
  /// Client au forfait : passages manqués déduits (voyages + saisis à la main).
  final double missed;
  const InvoiceView({
    required this.client,
    required this.ym,
    required this.plannedVisits,
    required this.absentVisits,
    required this.visits,
    required this.amount,
    this.record,
    this.forfait,
    this.missed = 0,
  });

  bool get overridden => record?.overrideVisits != null || record?.overrideAmount != null;
  bool get sent => record?.sent ?? false;
  bool get paid => record?.paid ?? false;

  /// Mois où l'argent est compté (report si la facture n'a pas été payée à la clôture).
  Ym get receivedYm => record?.receivedYm ?? ym;
  bool get isLate => receivedYm != ym;
}

int _dayKey(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

extension BusinessX on AppData {
  /// Au moins une personne est auto-entrepreneur.
  bool get hasAE => user.ae1 || (isCouple && user.ae2);

  bool aeActive(int person) => person == 2 ? (isCouple && user.ae2) : user.ae1;

  Client? clientById(String id) {
    for (final c in clients) {
      if (c.id == id) return c;
    }
    return null;
  }

  /// Ce jour tombe-t-il pendant un voyage (avec dates) qui concerne [owner] ?
  bool isAbsent(DateTime day, int owner, {String? clientId}) {
    final k = _dayKey(day);
    for (final p in projects) {
      final s = p.tripStart;
      final e = p.tripEnd;
      if (s == null || e == null) continue;
      if (p.who != 0 && p.who != owner) continue;
      if (clientId != null && !_tripRemoves(p, clientId)) continue;
      if (k >= _dayKey(s) && k <= _dayKey(e)) return true;
    }
    return false;
  }

  /// Le voyage retire-t-il les passages de ce client ? (défaut : oui)
  bool _tripRemoves(Project p, String clientId) {
    final plan = p.clientPlans[clientId];
    return plan == null || plan.mode == ClientTripPlan.remove;
  }

  /// Passages que le client [c] ne pourra pas faire dans le mois [ym] à cause du voyage [p]
  /// (sans tenir compte du choix fait pour ce client).
  /// Clients sans jour précis dans le mois (1 fois par mois, tous les N mois, 1 fois par an).
  bool isFlexible(Client c) =>
      c.kind == FreqKind.monthly || c.kind == FreqKind.everyMonths || c.kind == FreqKind.yearly;

  /// Nombre de passages « possibles » du client dans le mois [ym] pendant le voyage [p]
  /// (0 si le voyage ne touche pas ce mois ou si le client n'a pas de passage ce mois-là).
  double capacityInMonth(Client c, Project p, Ym ym) {
    final s = p.tripStart, e = p.tripEnd;
    if (s == null || e == null || !c.activeIn(ym) || !isFlexible(c)) return 0;
    if (p.who != 0 && p.who != c.owner) return 0;
    if (ym.isBefore(Ym.of(s)) || ym.isAfter(Ym.of(e))) return 0;
    switch (c.kind) {
      case FreqKind.monthly:
        return c.times.toDouble();
      case FreqKind.everyMonths:
        return (ym.index - c.start.index) % max(1, c.interval) == 0 ? c.times.toDouble() : 0;
      default:
        return ym.month == c.start.month ? 1.0 : 0.0;
    }
  }

  /// Passages possibles au total pendant le voyage (clients sans jour précis).
  double tripCapacity(Client c, Project p) {
    final s = p.tripStart, e = p.tripEnd;
    if (s == null || e == null) return 0;
    var t = 0.0;
    for (var ym = Ym.of(s); !ym.isAfter(Ym.of(e)); ym = ym.add(1)) {
      t += capacityInMonth(c, p, ym);
    }
    return t;
  }

  double lostInMonth(Client c, Project p, Ym ym, {bool estimate = false}) {
    final s = p.tripStart, e = p.tripEnd;
    if (s == null || e == null || !c.activeIn(ym)) return 0;
    if (p.who != 0 && p.who != c.owner) return 0;
    final mFirst = DateTime(ym.year, ym.month, 1);
    final mLast = DateTime(ym.year, ym.month + 1, 0);
    final start = DateTime(s.year, s.month, s.day);
    final end = DateTime(e.year, e.month, e.day);
    final from = start.isAfter(mFirst) ? start : mFirst;
    final to = end.isBefore(mLast) ? end : mLast;
    if (to.isBefore(from)) return 0;
    final days = to.difference(from).inDays + 1;
    switch (c.kind) {
      case FreqKind.weekdays:
        var n = 0;
        for (var i = 0; i < days; i++) {
          if (c.weekdays.contains(from.add(Duration(days: i)).weekday)) n++;
        }
        return n.toDouble();
      case FreqKind.weekly:
        var n = 0;
        for (var i = 0; i < days; i++) {
          if (from.add(Duration(days: i)).weekday == DateTime.monday) n++;
        }
        return (n * c.times).toDouble();
      case FreqKind.monthly:
      case FreqKind.everyMonths:
      case FreqKind.yearly:
        final cap = capacityInMonth(c, p, ym);
        if (cap <= 0) return 0;
        final chosen = p.clientPlans[c.id]?.lost;
        if (!estimate && chosen != null) {
          // Le nombre choisi est réparti sur les premiers mois du voyage où le client a un passage.
          var remaining = chosen;
          for (var m = Ym.of(s); !m.isAfter(ym); m = m.add(1)) {
            final take = min(capacityInMonth(c, p, m), remaining);
            if (m == ym) return take;
            remaining -= take;
          }
          return 0;
        }
        final raw = cap * days / mLast.day;
        return estimate ? raw : raw.round().toDouble();
    }
  }

  /// Passages perdus au total pendant le voyage [p] pour le client [c].
  double tripLost(Client c, Project p) {
    final s = p.tripStart, e = p.tripEnd;
    if (s == null || e == null) return 0;
    var total = 0.0;
    for (var ym = Ym.of(s); !ym.isAfter(Ym.of(e)); ym = ym.add(1)) {
      total += lostInMonth(c, p, ym, estimate: true);
    }
    return total;
  }

  /// Clients (auto-entreprise) touchés par le voyage [p] : au moins un passage perdu.
  List<({Client client, double lost})> tripImpact(Project p) {
    final out = <({Client client, double lost})>[];
    if (p.tripStart == null || p.tripEnd == null) return out;
    for (final c in clients) {
      if (!aeActive(c.owner) || c.isOneOff) continue;
      final l = tripLost(c, p);
      if (l > 0.01) out.add((client: c, lost: l));
    }
    return out;
  }

  /// Passages prévus par le planning du client pour un mois, et passages perdus (voyages).
  ({double visits, int absent}) plannedVisits(Client c, Ym ym) {
    if (!c.activeIn(ym)) return (visits: 0.0, absent: 0);
    switch (c.kind) {
      case FreqKind.weekdays:
        var n = 0;
        var lost = 0;
        final days = DateTime(ym.year, ym.month + 1, 0).day;
        for (var day = 1; day <= days; day++) {
          final dt = DateTime(ym.year, ym.month, day);
          if (!c.weekdays.contains(dt.weekday)) continue;
          if (isAbsent(dt, c.owner, clientId: c.id)) {
            lost++;
          } else {
            n++;
          }
        }
        return (visits: n.toDouble(), absent: lost);
      case FreqKind.weekly:
        var mondays = 0;
        final days = DateTime(ym.year, ym.month + 1, 0).day;
        for (var day = 1; day <= days; day++) {
          if (DateTime(ym.year, ym.month, day).weekday == DateTime.monday) mondays++;
        }
        return _withTrips(c, ym, (mondays * c.times).toDouble());
      case FreqKind.monthly:
        return _withTrips(c, ym, c.times.toDouble());
      case FreqKind.everyMonths:
        final diff = ym.index - c.start.index;
        return _withTrips(c, ym, (diff % max(1, c.interval) == 0) ? c.times.toDouble() : 0.0);
      case FreqKind.yearly:
        return _withTrips(c, ym, ym.month == c.start.month ? 1.0 : 0.0);
    }
  }

  /// Retire des passages prévus ceux qu'un voyage empêche (sauf si le client est gardé ou sous-traité).
  ({double visits, int absent}) _withTrips(Client c, Ym ym, double base) {
    if (base <= 0) return (visits: base, absent: 0);
    var lost = 0.0;
    for (final p in projects) {
      if (!_tripRemoves(p, c.id)) continue;
      lost += lostInMonth(c, p, ym);
    }
    lost = min(lost, base);
    return (visits: base - lost, absent: lost.round());
  }

  InvoiceRecord? invoiceRecord(String clientId, Ym ym) {
    for (final r in invoices) {
      if (r.clientId == clientId && r.ym == ym) return r;
    }
    return null;
  }

  InvoiceView invoiceView(Client c, Ym ym) {
    final planned = plannedVisits(c, ym);
    final r = invoiceRecord(c.id, ym);
    double visits;
    double amount;
    double missed = 0;
    final forfait = c.forfait;
    if (r != null && r.overrideAmount != null) {
      amount = r.overrideAmount!;
      visits = c.amount > 0 ? amount / c.amount : 0.0;
    } else if (forfait != null && c.activeIn(ym)) {
      // Forfait lissé : même montant chaque mois, moins (passages manqués × prix d'un passage).
      missed = planned.absent + (r?.missedVisits ?? 0);
      amount = max(0.0, forfait - missed * c.amount);
      visits = max(0.0, planned.visits - (r?.missedVisits ?? 0));
    } else if (r != null && r.overrideVisits != null) {
      visits = r.overrideVisits!;
      amount = visits * c.amount;
    } else {
      visits = planned.visits;
      amount = visits * c.amount;
    }
    return InvoiceView(
      client: c,
      ym: ym,
      plannedVisits: planned.visits,
      absentVisits: planned.absent,
      visits: visits,
      amount: amount,
      record: r,
      forfait: forfait != null && c.activeIn(ym) ? forfait : null,
      missed: missed,
    );
  }

  /// Factures émises pour un mois (une par client concerné).
  List<InvoiceView> invoicesIssuedIn(Ym ym) {
    final out = <InvoiceView>[];
    for (final c in clients) {
      if (!aeActive(c.owner)) continue;
      final v = invoiceView(c, ym);
      if (v.amount > 0.005 || v.plannedVisits > 0 || v.record != null) out.add(v);
    }
    return out;
  }

  /// Factures dont l'argent est compté dans ce mois (y compris les retards reportés).
  List<InvoiceView> invoicesReceivedIn(Ym ym, {int? person}) {
    final out = <InvoiceView>[];
    for (final c in clients) {
      if (!aeActive(c.owner)) continue;
      if (person != null && c.owner != person) continue;
      final v = invoiceView(c, ym);
      if (v.receivedYm == ym && v.amount > 0.005) out.add(v);
    }
    for (final r in invoices) {
      if (r.ym == ym || r.receivedYm != ym) continue;
      final c = clientById(r.clientId);
      if (c == null || !aeActive(c.owner)) continue;
      if (person != null && c.owner != person) continue;
      final v = invoiceView(c, r.ym);
      if (v.amount > 0.005) out.add(v);
    }
    return out;
  }

  /// [Mode privé] Retenue de la coopérative Unipro sur une facture (0 pour un client classique).
  double coopCut(InvoiceView v) =>
      (user.privateMode && v.client.unipro) ? v.amount * user.uniproRate / 100 : 0.0;

  /// Montant de la facture réellement perçu avant URSSAF (après retenue Unipro).
  double afterCoop(InvoiceView v) => v.amount - coopCut(v);

  /// Brut perçu (après retenue Unipro éventuelle), avant charges URSSAF.
  double grossReceivedIn(Ym ym, int person) =>
      invoicesReceivedIn(ym, person: person).fold(0.0, (s, v) => s + afterCoop(v));

  /// Part du brut du mois qui vient de mois précédents (retards de paiement).
  double lateGrossReceivedIn(Ym ym, int person) => invoicesReceivedIn(ym, person: person)
      .where((v) => v.ym != ym)
      .fold(0.0, (s, v) => s + afterCoop(v));

  /// Salaire net = brut moins les charges URSSAF.
  double netFromGross(double gross) => gross * (1 - user.urssafRate / 100);

  /// Factures non payées dont l'argent devrait arriver ce mois-ci (à la clôture : report).
  List<InvoiceView> unpaidReceivedIn(Ym ym) =>
      invoicesReceivedIn(ym).where((v) => !v.paid).toList();
}
