import '../core/ym.dart';

double _d(dynamic v) => (v as num).toDouble();

/// Fréquence des passages chez un client.
enum FreqKind {
  weekdays, // certains jours de la semaine (ex. tous les lundis et mardis)
  weekly, // N fois par semaine (jour non fixé)
  monthly, // N fois par mois
  everyMonths, // tous les N mois (2, 3…)
  yearly, // une fois par an
}

const weekdayNames = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
const _weekdayPlural = ['lundis', 'mardis', 'mercredis', 'jeudis', 'vendredis', 'samedis', 'dimanches'];

/// Un client d'un auto-entrepreneur : montant et fréquence des passages.
class Client {
  final String id;
  final String name;
  final int owner; // 1 ou 2 : à qui appartient ce client (auto-entrepreneur)
  final double amount; // montant d'un passage (brut)
  final int durationMin; // durée d'un passage, en minutes
  final FreqKind kind;
  final List<int> weekdays; // 1 = lundi … 7 = dimanche
  final int times; // fois par semaine / par mois
  final int interval; // tous les N mois
  final Ym start; // premier mois (sert aussi de repère pour « tous les N mois » et « par an »)
  final Ym? end;
  /// [Mode dev] Forfait mensuel lissé sur l'année (ex. 700 €) : null = facturation au passage.
  /// Seuls les passages manqués sont déduits (montant d'un passage × nombre d'absences).
  final double? forfait;
  const Client({
    required this.id,
    required this.name,
    this.owner = 1,
    required this.amount,
    this.durationMin = 60,
    required this.kind,
    this.weekdays = const [],
    this.times = 1,
    this.interval = 2,
    required this.start,
    this.end,
    this.forfait,
  });

  bool activeIn(Ym ym) => !ym.isBefore(start) && (end == null || !ym.isAfter(end!));

  /// Facture ponctuelle : un « client » actif un seul mois, créé par « Facture ponctuelle ».
  /// Il n'apparaît pas dans la liste des clients, seulement dans les factures du mois.
  bool get isOneOff => end != null && end == start && kind == FreqKind.monthly && times == 1;

  String get durationLabel {
    final h = durationMin ~/ 60;
    final m = durationMin % 60;
    if (h == 0) return '$m min';
    return m == 0 ? '$h h' : '$h h ${m.toString().padLeft(2, '0')}';
  }

  String get frequencyLabel {
    switch (kind) {
      case FreqKind.weekdays:
        final names = [for (final d in ([...weekdays]..sort())) _weekdayPlural[d - 1]];
        if (names.isEmpty) return 'Aucun jour choisi';
        if (names.length == 1) return 'Tous les ${names.first}';
        return 'Tous les ${names.sublist(0, names.length - 1).join(', ')} et ${names.last}';
      case FreqKind.weekly:
        return times == 1 ? '1 fois par semaine' : '$times fois par semaine';
      case FreqKind.monthly:
        return times == 1 ? '1 fois par mois' : '$times fois par mois';
      case FreqKind.everyMonths:
        return interval <= 1 ? 'Chaque mois' : 'Tous les $interval mois';
      case FreqKind.yearly:
        return '1 fois par an (${Ym(start.year, start.month).longName.toLowerCase()})';
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'owner': owner,
        'amount': amount,
        'durationMin': durationMin,
        'kind': kind.name,
        'weekdays': weekdays,
        'times': times,
        'interval': interval,
        'start': start.key,
        'end': end?.key,
        'forfait': forfait,
      };

  factory Client.fromJson(Map<String, dynamic> j) => Client(
        id: j['id'],
        name: j['name'],
        owner: j['owner'] ?? 1,
        amount: _d(j['amount']),
        durationMin: j['durationMin'] ?? 60,
        kind: FreqKind.values.byName(j['kind'] ?? 'monthly'),
        weekdays: ((j['weekdays'] ?? []) as List).map((e) => e as int).toList(),
        times: j['times'] ?? 1,
        interval: j['interval'] ?? 2,
        start: Ym.parse(j['start']),
        end: j['end'] == null ? null : Ym.parse(j['end']),
        forfait: j['forfait'] == null ? null : _d(j['forfait']),
      );
}

/// Suivi d'une facture (client × mois) : modifications manuelles, envoyée, payée, report.
/// Les factures sans modification n'ont pas d'enregistrement (calculées automatiquement).
class InvoiceRecord {
  final String clientId;
  final Ym ym; // mois de la facture
  final double? overrideVisits; // nombre de passages saisi à la main
  final double? overrideAmount; // montant saisi à la main
  final bool sent;
  final bool paid;
  final Ym? receivedYm; // mois où l'argent est compté (null = mois de la facture)
  final List<String> carryLog; // mois de clôture où la facture impayée a été reportée
  /// Client au forfait : passages manqués saisis à la main ce mois-là (en plus des voyages).
  final double? missedVisits;
  const InvoiceRecord({
    required this.clientId,
    required this.ym,
    this.overrideVisits,
    this.overrideAmount,
    this.sent = false,
    this.paid = false,
    this.receivedYm,
    this.carryLog = const [],
    this.missedVisits,
  });

  InvoiceRecord copyWith({
    double? overrideVisits,
    double? overrideAmount,
    bool clearOverrides = false,
    bool? sent,
    bool? paid,
    Ym? receivedYm,
    bool clearReceived = false,
    List<String>? carryLog,
    double? missedVisits,
    bool clearMissed = false,
  }) =>
      InvoiceRecord(
        clientId: clientId,
        ym: ym,
        overrideVisits: clearOverrides ? null : (overrideVisits ?? this.overrideVisits),
        overrideAmount: clearOverrides ? null : (overrideAmount ?? this.overrideAmount),
        sent: sent ?? this.sent,
        paid: paid ?? this.paid,
        receivedYm: clearReceived ? null : (receivedYm ?? this.receivedYm),
        carryLog: carryLog ?? this.carryLog,
        missedVisits: clearMissed ? null : (missedVisits ?? this.missedVisits),
      );

  Map<String, dynamic> toJson() => {
        'clientId': clientId,
        'ym': ym.key,
        'overrideVisits': overrideVisits,
        'overrideAmount': overrideAmount,
        'sent': sent,
        'paid': paid,
        'receivedYm': receivedYm?.key,
        'carryLog': carryLog,
        'missedVisits': missedVisits,
      };

  factory InvoiceRecord.fromJson(Map<String, dynamic> j) => InvoiceRecord(
        clientId: j['clientId'],
        ym: Ym.parse(j['ym']),
        overrideVisits: j['overrideVisits'] == null ? null : _d(j['overrideVisits']),
        overrideAmount: j['overrideAmount'] == null ? null : _d(j['overrideAmount']),
        sent: j['sent'] == true,
        paid: j['paid'] == true,
        receivedYm: j['receivedYm'] == null ? null : Ym.parse(j['receivedYm']),
        carryLog: ((j['carryLog'] ?? []) as List).map((e) => e as String).toList(),
        missedVisits: j['missedVisits'] == null ? null : _d(j['missedVisits']),
      );
}
