import 'dart:math';
import '../core/ym.dart';
import 'business.dart';
import 'models.dart';

enum LineKind { income, fixed, budget, project, info }

class CalLine {
  final String label;
  final double amount; // signé : + entrée, - sortie
  final LineKind kind;
  final String? note;
  final String? refId; // id d'un revenu ponctuel (suppression)
  final String? recurringId; // id d'un revenu récurrent (modification du mois)
  const CalLine(this.label, this.amount, this.kind, {this.note, this.refId, this.recurringId});
}

class MonthForecast {
  final Ym ym;
  final double startBalance;
  final double salary;
  final double extraIncome;
  final double fixed;
  final double budgets;
  final double projects; // voyages
  final double unexpected; // compteur d'imprévus
  final double tripActual; // part des dépenses de voyage déjà réellement sorties
  final bool closed;
  final List<CalLine> lines;
  const MonthForecast({
    required this.ym,
    required this.startBalance,
    required this.salary,
    required this.extraIncome,
    required this.fixed,
    required this.budgets,
    required this.projects,
    required this.unexpected,
    required this.tripActual,
    required this.closed,
    required this.lines,
  });

  double get income => salary + extraIncome;

  /// Solde fin du mois = début + revenus - charges - budgets/dépenses - projets
  double get endBalance => startBalance + income - fixed - budgets - projects - unexpected;

  /// Capacité d'épargne = ce qui reste avant les projets.
  double get savingCapacity => income - fixed - budgets;
}

extension ForecastLookup on List<MonthForecast> {
  MonthForecast? at(Ym ym) {
    for (final f in this) {
      if (f.ym == ym) return f;
    }
    return null;
  }
}

class Forecaster {
  /// Calcule chaque mois de [d.startYm] à [to]. Chaque mois reprend le solde
  /// de fin du mois précédent.
  static List<MonthForecast> compute(AppData d, {required Ym now, required Ym to}) {
    final out = <MonthForecast>[];
    var balance = d.startBalance;
    final pot = <String, double>{}; // épargne déjà déduite pour chaque voyage
    for (var i = d.startYm.index; i <= to.index; i++) {
      final ym = Ym.fromIndex(i);
      final closed = d.isClosed(ym);
      final lines = <CalLine>[];

      // Revenus récurrents (salaires...) actifs ce mois, avec modifications éventuelles.
      // Un mois non pointé à la clôture est retiré de ce mois et reporté au suivant.
      var salary = 0.0;
      for (final r in d.recurringIncomes) {
        final deferredFromThis = r.carriedMonths.contains(ym.key);
        final deferredFromPrev = r.carriedMonths.contains(ym.add(-1).key);
        var amt = 0.0;
        if (r.activeIn(ym) && !deferredFromThis) amt += r.amountIn(ym);
        if (deferredFromPrev) amt += r.amountIn(ym.add(-1));
        if (amt <= 0.005) continue;
        salary += amt;
        lines.add(CalLine(r.label, amt, LineKind.income,
            note: deferredFromPrev
                ? 'Dont report du mois précédent (non pointé)'
                : (r.hasOverride(ym) ? 'Modifié pour ce mois' : 'Chaque mois'),
            recurringId: r.id));
      }
      // Revenus ponctuels
      var extra = 0.0;
      for (final inc in d.extraIncomes(ym)) {
        extra += inc.amount;
        lines.add(CalLine(inc.label.isEmpty ? inc.kind.label : inc.label, inc.amount,
            LineKind.income, note: '${inc.kind.label} · ponctuel', refId: inc.id));
      }

      // Salaire d'auto-entrepreneur : factures reçues ce mois-ci, moins les charges URSSAF
      for (final person in [1, 2]) {
        if (!d.aeActive(person)) continue;
        final gross = d.grossReceivedIn(ym, person);
        if (gross <= 0.005) continue;
        final net = d.netFromGross(gross);
        final late = d.lateGrossReceivedIn(ym, person);
        salary += net;
        lines.add(CalLine(
          d.isCouple ? 'Salaire auto-entrepreneur · ${d.personName(person)}' : 'Salaire auto-entrepreneur',
          net,
          LineKind.income,
          note: 'Brut ${gross.round()} € − URSSAF ${d.user.urssafRate.toStringAsFixed(2).replaceAll('.', ',')} %'
              '${late > 0.005 ? ' · dont ${late.round()} € de retard de paiement' : ''}',
        ));
      }

      var fixed = 0.0;
      for (final f in d.fixedExpenses) {
        final deferredFromThis = f.carriedMonths.contains(ym.key); // non cochée à la clôture de ce mois
        final deferredFromPrev = f.carriedMonths.contains(ym.add(-1).key); // reportée du mois précédent
        var amt = 0.0;
        if (f.activeIn(ym) && !deferredFromThis) amt += f.amount;
        if (deferredFromPrev) amt += f.amount;
        if (amt <= 0.005) continue;
        fixed += amt;
        lines.add(CalLine(f.name, -amt, LineKind.fixed,
            note: deferredFromPrev ? 'Dont report du mois précédent (non débitée)' : null));
      }

      // Budgets = enveloppes. Coût du mois = max(total prévu, total dépensé) :
      // un dépassement d'une enveloppe ne compte que s'il dépasse le budget global.
      // Mois clôturé : coût = dépenses réelles.
      final totalPlanned = d.plannedIn(ym);
      final totalSpent = d.spentIn(ym);
      final budgetCost = closed ? totalSpent : max(totalPlanned, totalSpent);
      var budgetedSpent = 0.0;
      for (final b in d.sortedBudgets) {
        final spent = d.spentForBudget(b, ym);
        budgetedSpent += spent;
        if (closed) {
          lines.add(CalLine(d.budgetTitle(b), -spent, LineKind.budget, note: 'Réel (clôturé)'));
        } else {
          lines.add(CalLine(d.budgetTitle(b), -b.amountIn(ym), LineKind.budget,
              note: b.hasOverride(ym) ? 'Prévu · modifié pour ce mois' : 'Prévu'));
        }
      }
      final other = totalSpent - budgetedSpent;
      if (closed && other > 0.005) {
        lines.add(CalLine('Autres dépenses', -other, LineKind.budget, note: 'Réel (clôturé)'));
      }
      if (!closed && totalSpent > totalPlanned) {
        lines.add(CalLine('Dépassement du budget global', -(totalSpent - totalPlanned),
            LineKind.budget,
            note: 'Dépensé ${totalSpent.round()} € pour ${totalPlanned.round()} € prévus'));
      }

      // Imprévus : compteur, chaque dépense est déduite directement
      final unexpected = d.unexpectedIn(ym);
      if (unexpected > 0) {
        lines.add(CalLine('Imprévus', -unexpected, LineKind.budget, note: 'Compteur · déduit directement'));
      }

      // Voyages
      //  - « Payer au moment du voyage » : le mois du voyage, budget = max(prévu, dépensé)
      //    (mois clôturé : dépensé réel, la différence est remise dans le solde).
      //  - « Épargner chaque mois » : versements avant le voyage (déjà déduits), puis le mois
      //    du voyage on ne déduit que ce qui dépasse l'épargne (ou on rend le reste à la clôture).
      var projectCost = 0.0;
      var tripActual = 0.0;
      for (final p in d.projects) {
        final tripSpent = d.tripSpentIn(ym, p.id);
        if (p.isExpense) {
          if (ym == p.targetYm) {
            final cost = closed ? tripSpent : max(p.target, tripSpent);
            projectCost += cost;
            tripActual += tripSpent;
            lines.add(CalLine(p.name, -cost, LineKind.project,
                note: closed
                    ? 'Budget voyage · réel (clôturé)'
                    : (tripSpent > p.target ? 'Budget voyage dépassé' : 'Budget voyage prévu')));
          }
          continue;
        }
        final rec = p.contributions[ym.key];
        if (rec != null) {
          projectCost += rec;
          pot[p.id] = (pot[p.id] ?? 0) + rec;
          lines.add(CalLine(p.name, -rec, LineKind.project, note: 'Versé'));
        } else if (!ym.isBefore(now) && !ym.isBefore(p.startYm) && ym.isBefore(p.targetYm)) {
          projectCost += p.monthlyPlan;
          pot[p.id] = (pot[p.id] ?? 0) + p.monthlyPlan;
          lines.add(CalLine(p.name, -p.monthlyPlan, LineKind.project, note: 'Prévu'));
        }
        if (ym == p.targetYm) {
          final funded = pot[p.id] ?? 0;
          final base = closed ? tripSpent : max(p.target, tripSpent);
          final extra = base - funded; // peut être négatif : reste de l'épargne rendu
          projectCost += extra;
          tripActual += max(0.0, tripSpent - funded);
          if (extra.abs() > 0.005 || tripSpent > 0) {
            lines.add(CalLine(p.name, -extra, LineKind.project,
                note: extra < 0
                    ? 'Épargne non dépensée remise dans le solde'
                    : (closed ? 'Voyage · au-delà de l\'épargne (réel)' : 'Voyage · au-delà de l\'épargne')));
          }
        }
      }

      // Information : économies de clôture du mois précédent (déjà dans le solde)
      final prev = d.snapshots[ym.add(-1).key];
      if (prev != null && prev.savings != 0) {
        lines.add(CalLine('Économies de ${prev.ym.longName} reportées', prev.savings,
            LineKind.info, note: 'Déjà incluses dans le solde de départ'));
      }

      final f = MonthForecast(
        ym: ym,
        startBalance: balance,
        salary: salary,
        extraIncome: extra,
        fixed: fixed,
        budgets: budgetCost,
        projects: projectCost,
        unexpected: unexpected,
        tripActual: tripActual,
        closed: closed,
        lines: lines,
      );
      out.add(f);
      balance = f.endBalance;
    }
    return out;
  }

  /// Solde réel à l'instant T du mois courant (dépenses saisies, versements marqués).
  static double currentBalance(AppData d, MonthForecast f) {
    final marked = d.projects.fold(0.0, (s, p) => s + (p.contributions[f.ym.key] ?? 0));
    // Salaire d'auto-entrepreneur : seules les factures déjà payées sont sur le compte
    final unpaidNet = kInvoicesEnabled
        ? d.netFromGross(d.unpaidReceivedIn(f.ym).fold(0.0, (s, v) => s + v.amount))
        : 0.0;
    return f.startBalance + f.income - unpaidNet - f.fixed - d.spentIn(f.ym) - f.unexpected - f.tripActual - marked;
  }
}
