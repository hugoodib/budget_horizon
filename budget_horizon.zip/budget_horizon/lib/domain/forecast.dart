import 'dart:math';
import '../core/money.dart';
import '../core/ym.dart';
import 'business.dart';
import 'models.dart';

enum LineKind { income, fixed, budget, project, info }

class CalLine {
  final String label;
  final double amount; // signé : + entrée, - sortie
  final LineKind kind;
  final String? note;
  final String? refId; // id d'un revenu ponctuel (suppression)
  final String? recurringId; // id d'un revenu récurrent (modification du mois)
  const CalLine(this.label, this.amount, this.kind, {this.note, this.refId, this.recurringId});
}

class MonthForecast {
  final Ym ym;
  final double startBalance;
  final double salary;
  final double extraIncome;
  final double fixed;
  final double budgets;
  final double projects; // voyages
  final double unexpected; // compteur d'imprévus
  final double tripActual; // part des dépenses de voyage déjà réellement sorties
  final bool closed;
  final List<CalLine> lines;
  /// Part des revenus déjà cochés (reçus sur le compte).
  final double receivedIncome;
  /// Part des charges fixes déjà cochées (prélevées).
  final double fixedPaid;
  /// Détail des revenus cochés / des charges cochées (pour le détail du solde actuel).
  final List<BalItem> incomeItems;
  final List<BalItem> fixedItems;
  const MonthForecast({
    required this.ym,
    required this.startBalance,
    required this.salary,
    required this.extraIncome,
    required this.fixed,
    required this.budgets,
    required this.projects,
    required this.unexpected,
    required this.tripActual,
    required this.closed,
    required this.lines,
    this.receivedIncome = 0,
    this.fixedPaid = 0,
    this.incomeItems = const [],
    this.fixedItems = const [],
  });

  double get income => salary + extraIncome;

  /// Solde fin du mois = début + revenus - charges - budgets/dépenses - projets
  double get endBalance => startBalance + income - fixed - budgets - projects - unexpected;

  /// Capacité d'épargne = ce qui reste avant les projets.
  double get savingCapacity => income - fixed - budgets;
}

enum BalKind { start, income, fixed, spend, other }

/// Une ligne du détail du solde actuel. [checked] = elle compte déjà dans le solde actuel.
/// [action] + [id] + [ym] permettent de la pointer / d'y accéder depuis le détail.
class BalItem {
  final BalKind kind;
  final String label;
  final String? note;
  final double amount; // signé : + entrée, - sortie
  final bool checked; // pointée (le rond est coché)
  /// [Mode dev] Débit différé : même pointée, la dépense n'est pas encore sortie du compte.
  final bool deferred;
  final String? action; // recurring | carried | income | fixed | tx | invoices | trips
  final String? id;
  final Ym? ym;
  final String? emoji;
  const BalItem(this.kind, this.label, this.amount,
      {this.note, this.checked = true, this.deferred = false, this.action, this.id, this.ym, this.emoji});

  /// La ligne compte dans le solde actuel : pointée ET pas en débit différé.
  bool get counts => checked && !deferred;
}

/// Détail du calcul du solde actuel.
class BalanceDetail {
  final double start;
  final List<BalItem> items;
  const BalanceDetail(this.start, this.items);
  Iterable<BalItem> _of(BalKind k) => items.where((i) => i.kind == k);
  double sumChecked(BalKind k) => _of(k).where((i) => i.counts).fold(0.0, (s, i) => s + i.amount);
  double sumPending(BalKind k) => _of(k).where((i) => !i.counts).fold(0.0, (s, i) => s + i.amount);
  double get total => start + items.where((i) => i.counts).fold(0.0, (s, i) => s + i.amount);
}

extension ForecastLookup on List<MonthForecast> {
  MonthForecast? at(Ym ym) {
    for (final f in this) {
      if (f.ym == ym) return f;
    }
    return null;
  }
}

class Forecaster {
  /// Calcule chaque mois de [d.startYm] à [to]. Chaque mois reprend le solde
  /// de fin du mois précédent.
  /// [devMode] : si true, les dates de débit/réception sont prises en compte.
  static List<MonthForecast> compute(AppData d, {required Ym now, required Ym to, bool devMode = false}) {
    final out = <MonthForecast>[];
    var balance = d.startBalance;
    final pot = <String, double>{}; // épargne déjà déduite pour chaque voyage
    for (var i = d.startYm.index; i <= to.index; i++) {
      final ym = Ym.fromIndex(i);
      // « Repartir de zéro » : le solde saisi à la main devient le solde de départ de ce mois.
      final isResetMonth = d.resetYm != null && ym == d.resetYm;
      if (isResetMonth) balance = d.resetBalance;
      final closed = d.isClosed(ym);
      final lines = <CalLine>[];

      // Revenus récurrents (salaires...) actifs ce mois, avec modifications éventuelles.
      // Un mois non pointé à la clôture est retiré de ce mois et reporté au suivant.
      // [Mode dev] : si receiptDay est défini, le revenu est décalé selon la règle.
      //   - receiptDay dans ce mois → compté normalement dans ce mois.
      //   - receiptDay dans le mois précédent (ex. 26 déc pour un salaire de déc)
      //     → le revenu du mois précédent arrive dans ce mois (et non dans prev).
      var salary = 0.0;
      var received = 0.0; // revenus cochés = déjà reçus sur le compte
      final incomeItems = <BalItem>[];
      final fixedItems = <BalItem>[];
      for (final r in d.recurringIncomes) {
        final deferredFromThis = r.carriedMonths.contains(ym.key);
        final deferredFromPrev = !isResetMonth && r.carriedMonths.contains(ym.add(-1).key);

        // [Mode dev] Le revenu du mois PRÉCÉDENT est-il reçu dans CE mois ?
        // Ex. salaire de décembre reçu le 26 déc → il appartient à décembre.
        // Pas de décalage inter-mois ici : la règle dit QUAND dans le mois on reçoit,
        // pas sur quel mois est imputé le salaire.
        // On ajoute juste une note indiquant le jour de réception.
        String _receiptNote(RecurringIncome r, Ym ym) {
          if (!devMode || r.receiptDay.kind == ReceiptDayKind.none) {
            return r.hasOverride(ym) ? 'Modifié pour ce mois' : r.frequencyLabel;
          }
          final day = r.receiptDay.dayForYm(ym);
          final kindLabel = r.receiptDay.kind == ReceiptDayKind.lastWorkingDay
              ? 'Dernier jour ouvré'
              : 'Le $day du mois';
          return '${r.hasOverride(ym) ? 'Modifié · ' : ''}$kindLabel';
        }

        // Versement du mois et versement reporté : deux lignes distinctes (pas additionnées).
        if (r.activeIn(ym) && !deferredFromThis) {
          // Salaire 3×8 : montant = fixe + primes de M-2 (toujours, dès que isShiftSalary)
          final shiftAmt = r.isShiftSalary ? d.shiftSalaryAmountIn(r, ym) : null;
          final amt = shiftAmt ?? r.amountIn(ym);
          if (amt > 0.005) {
            salary += amt;
            if (r.isChecked(ym)) received += amt;
            incomeItems.add(BalItem(BalKind.income, r.label, amt,
                checked: r.isChecked(ym), action: 'recurring', id: r.id, ym: ym,
                note: r.hasOverride(ym) ? 'Modifié pour ce mois' : r.frequencyLabel));
            String note = _receiptNote(r, ym);
            if (r.isShiftSalary && d.shiftSchedule != null) {
              final primeYm = ym.add(-2);
              final jours = d.shiftSchedule!.workingDayCountIn(primeYm);
              final primes = d.shiftSchedule!.totalAllowanceIn(primeYm);
              note = '${eur(r.baseSalary)} fixe + ${eur(primes)} primes ($jours j · ${primeYm.longName})';
            }
            lines.add(CalLine(r.label, amt, LineKind.income,
                note: note, recurringId: r.id));
          }
        }
        if (deferredFromPrev) {
          final prevYm = ym.add(-1);
          final shiftAmtPrev = r.isShiftSalary ? d.shiftSalaryAmountIn(r, prevYm) : null;
          final amt = shiftAmtPrev ?? r.amountIn(prevYm);
          if (amt > 0.005) {
            salary += amt;
            if (r.isChecked(prevYm)) received += amt;
            incomeItems.add(BalItem(BalKind.income, '${r.label} · ${prevYm.longName.toLowerCase()}', amt,
                checked: r.isChecked(prevYm), action: 'carried', id: r.id, ym: prevYm,
                note: 'Reporté de ${prevYm.longName.toLowerCase()}'));
            lines.add(CalLine('${r.label} · ${prevYm.longName.toLowerCase()}', amt, LineKind.income,
                note: 'Report de ${prevYm.longName.toLowerCase()} (non pointé)'));
          }
        }
      }
      // Revenus ponctuels
      var extra = 0.0;
      for (final inc in d.extraIncomes(ym)) {
        extra += inc.amount;
        if (inc.checked) received += inc.amount;
        incomeItems.add(BalItem(BalKind.income, inc.label.isEmpty ? inc.kind.label : inc.label, inc.amount,
            checked: inc.checked, action: 'income', id: inc.id, ym: ym, note: '${inc.kind.label} · ponctuel'));
        lines.add(CalLine(inc.label.isEmpty ? inc.kind.label : inc.label, inc.amount,
            LineKind.income, note: '${inc.kind.label} · ponctuel', refId: inc.id));
      }

      // Salaire d'auto-entrepreneur : factures reçues ce mois-ci, moins les charges URSSAF
      for (final person in [1, 2]) {
        if (!d.aeActive(person)) continue;
        final gross = d.grossReceivedIn(ym, person);
        if (gross <= 0.005) continue;
        final late = d.lateGrossReceivedIn(ym, person);
        final current = gross - late;
        final rateTxt = d.user.urssafRate.toStringAsFixed(2).replaceAll('.', ',');
        final baseLabel =
            d.isCouple ? 'Salaire auto-entrepreneur · ${d.personName(person)}' : 'Salaire auto-entrepreneur';
        salary += d.netFromGross(gross);
        // Seules les factures déjà payées sont sur le compte : les impayées restent « à venir ».
        final unpaid = kInvoicesEnabled
            ? d.unpaidReceivedIn(ym).where((v) => v.client.owner == person).toList()
            : <InvoiceView>[];
        final unpaidGross = unpaid.fold(0.0, (s, v) => s + v.amount);
        final paidNet = d.netFromGross(max(0.0, gross - unpaidGross));
        received += paidNet;
        if (paidNet > 0.005) {
          incomeItems.add(BalItem(BalKind.income, baseLabel, paidNet,
              checked: true, action: 'invoices', ym: ym, note: 'Factures payées · net après URSSAF'));
        }
        for (final v in unpaid) {
          incomeItems.add(BalItem(BalKind.income, 'Facture ${v.client.name}', d.netFromGross(v.amount),
              checked: false,
              action: 'invoices',
              ym: ym,
              note: 'Pas encore payée${v.ym != ym ? ' · facture de ${v.ym.longName.toLowerCase()}' : ''}'));
        }
        if (current > 0.005) {
          lines.add(CalLine(baseLabel, d.netFromGross(current), LineKind.income,
              note: 'Brut ${current.round()} € − URSSAF $rateTxt %'));
        }
        if (late > 0.005) {
          lines.add(CalLine('$baseLabel · retard', d.netFromGross(late), LineKind.income,
              note: 'Factures de mois précédents payées en retard · brut ${late.round()} €'));
        }
      }

      var fixed = 0.0;
      var fixedPaid = 0.0; // charges cochées = déjà prélevées
      for (final f in d.fixedExpenses) {
        final deferredFromThis = f.carriedMonths.contains(ym.key); // non cochée à la clôture de ce mois
        final deferredFromPrev = !isResetMonth && f.carriedMonths.contains(ym.add(-1).key); // reportée du mois précédent
        if (f.activeIn(ym) && !deferredFromThis && f.amount > 0.005) {
          fixed += f.amount;
          if (f.isChecked(ym)) fixedPaid += f.amount;
          fixedItems.add(BalItem(BalKind.fixed, f.name, -f.amount,
              checked: f.isChecked(ym), action: 'fixed', id: f.id, ym: ym, emoji: f.emoji));
          lines.add(CalLine(f.name, -f.amount, LineKind.fixed));
        }
        if (deferredFromPrev && f.amount > 0.005) {
          final prevYm = ym.add(-1);
          fixed += f.amount;
          if (f.isChecked(prevYm)) fixedPaid += f.amount;
          fixedItems.add(BalItem(BalKind.fixed, '${f.name} · ${prevYm.longName.toLowerCase()}', -f.amount,
              checked: f.isChecked(prevYm), action: 'fixed', id: f.id, ym: prevYm, emoji: f.emoji,
              note: 'Reportée de ${prevYm.longName.toLowerCase()}'));
          lines.add(CalLine('${f.name} · ${prevYm.longName.toLowerCase()}', -f.amount, LineKind.fixed,
              note: 'Report de ${prevYm.longName.toLowerCase()} (non débitée)'));
        }
      }

      // ── Budgets & dépenses ──────────────────────────────────────────────────
      var budgetCost = 0.0;
      var unexpected = 0.0;
      if (devMode) {
        // [Mode dev] Une dépense compte dans le mois où elle est DÉBITÉE (date de débit explicite,
        // sinon règle du budget, sinon jour de saisie). Chaque enveloppe est prévue à son montant
        // (ou au dépensé si dépassé) et débitée selon sa règle : un budget à débit différé est
        // donc payé le mois SUIVANT (« paiement différé »). Rien de ce qui a été saisi avant le
        // mois de reprise (« repartir de zéro ») n'est compté.
        final reset = d.resetYm;
        var lo = ym.add(-3);
        if (lo.isBefore(d.startYm)) lo = d.startYm;
        if (reset != null && !ym.isBefore(reset) && lo.isBefore(reset)) lo = reset;

        for (final b in d.sortedBudgets) {
          var cost = 0.0;
          final parts = <String>[];
          for (var mi = lo.index; mi <= ym.index; mi++) {
            final m = Ym.fromIndex(mi);
            final amt = _envelopeDebits(d, b, m)[ym.index] ?? 0.0;
            if (amt <= 0.005) continue;
            cost += amt;
            parts.add(m == ym ? 'Débité ce mois' : 'Paiement différé · ${m.longName.toLowerCase()}');
          }
          budgetCost += cost;
          if (cost > 0.005) {
            lines.add(CalLine(d.budgetTitle(b), -cost, LineKind.budget, note: parts.join(' · ')));
          }
        }
        // Dépenses sans enveloppe (catégorie sans budget) : débitées à leur date de débit.
        var other = 0.0;
        for (final t in d.transactions) {
          if (t.isSpecial || _hasBudget(d, t)) continue;
          final saisie = Ym.of(t.date);
          if (saisie.isBefore(lo) || saisie.isAfter(ym)) continue;
          if (Ym.of(effectiveDebitDate(d, t)) == ym) other += t.amount;
        }
        if (other > 0.005) {
          budgetCost += other;
          lines.add(CalLine('Autres dépenses', -other, LineKind.budget, note: 'Hors budgets · débitées ce mois'));
        }
        // Imprévus débités ce mois (ceux à débit différé sont comptés le mois de leur débit).
        for (final t in d.transactions) {
          if (t.categoryId != kUnexpectedId || t.tripId != null) continue;
          final saisie = Ym.of(t.date);
          if (saisie.isBefore(lo) || saisie.isAfter(ym)) continue;
          if (Ym.of(effectiveDebitDate(d, t)) == ym) unexpected += t.amount;
        }
        if (unexpected > 0) {
          lines.add(CalLine('Imprévus', -unexpected, LineKind.budget, note: 'Débités ce mois'));
        }
      } else {
        // Budgets = enveloppes, chacune avec son plafond.
        // Mois clôturé : coût = dépenses réelles.
        // Mois ouvert : coût de chaque enveloppe = MAX(dépensé, prévu).
        //   - Si dépensé < prévu  → on soustrait le prévu en entier (projection prudente).
        //   - Si dépensé > prévu  → le plafond est atteint : chaque nouvelle dépense de
        //     cette catégorie baisse immédiatement le solde de fin de mois.
        // Les dépenses hors de toute enveloppe sont déduites directement.
        final totalSpent = d.spentIn(ym);
        var budgetedSpent = 0.0;
        var envelopesCost = 0.0;
        for (final b in d.sortedBudgets) {
          final spent = d.spentForBudget(b, ym);
          final planned = b.amountIn(ym);
          budgetedSpent += spent;
          if (closed) {
            envelopesCost += spent;
            lines.add(CalLine(d.budgetTitle(b), -spent, LineKind.budget, note: 'Réel (clôturé)'));
          } else {
            final cost = max(planned, spent);
            envelopesCost += cost;
            lines.add(CalLine(d.budgetTitle(b), -cost, LineKind.budget,
                note: spent > planned
                    ? 'Plafond dépassé · dépensé ${spent.round()} € pour ${planned.round()} € prévus'
                    : (b.hasOverride(ym) ? 'Prévu · modifié pour ce mois' : 'Prévu')));
          }
        }
        final other = max(0.0, totalSpent - budgetedSpent);
        if (other > 0.005) {
          lines.add(CalLine('Autres dépenses', -other, LineKind.budget,
              note: closed ? 'Réel (clôturé)' : 'Hors budgets · déduit directement'));
        }
        budgetCost = envelopesCost + other;

        // Imprévus : compteur, chaque dépense est déduite directement
        unexpected = d.unexpectedIn(ym);
        if (unexpected > 0) {
          lines.add(CalLine('Imprévus', -unexpected, LineKind.budget, note: 'Compteur · déduit directement'));
        }
      }

      // Voyages
      //  - « Payer au moment du voyage » : le mois du voyage, budget = max(prévu, dépensé)
      //    (mois clôturé : dépensé réel, la différence est remise dans le solde).
      //  - « Épargner chaque mois » : versements avant le voyage (déjà déduits), puis le mois
      //    du voyage on ne déduit que ce qui dépasse l'épargne (ou on rend le reste à la clôture).
      var projectCost = 0.0;
      var tripActual = 0.0;

      // Dépenses de voyage payées ce mois-ci pour un voyage dans un AUTRE mois
      // (ex. hôtel réglé en octobre pour un voyage en mars 2027).
      // Ces dépenses ont t.date dans ce mois, mais tripIn(ym) == false pour leur voyage.
      // Elles sont exclues de spentIn (isSpecial) donc on les ajoute explicitement ici.
      for (final t in d.transactions.where((t) =>
          t.tripId != null &&
          t.date.year == ym.year &&
          t.date.month == ym.month)) {
        final trip = d.projects.where((p) => p.id == t.tripId).firstOrNull;
        if (trip == null) continue;
        // Si le mois de la dépense == mois du voyage → elle sera comptée dans tripSpentIn
        if (trip.targetYm == ym) continue;
        projectCost += t.amount;
        tripActual += t.amount;
        lines.add(CalLine(trip.name, -t.amount, LineKind.project,
            note: 'Acompte réglé ce mois · voyage ${trip.targetYm.longName}'));
      }
      for (final p in d.projects) {
        final tripSpent = d.tripSpentIn(ym, p.id);
        final share = p.shareIn(ym); // part du voyage dans ce mois (au prorata des jours)
        if (p.isExpense) {
          if (share > 0) {
            final planned = p.target * share;
            final cost = closed ? tripSpent : max(planned, tripSpent);
            projectCost += cost;
            tripActual += tripSpent;
            lines.add(CalLine(p.name, -cost, LineKind.project,
                note: closed
                    ? (p.isTrip ? 'Budget voyage · réel (clôturé)' : 'Réel (clôturé)')
                    : (tripSpent > planned
                        ? (p.isTrip ? 'Budget voyage dépassé' : 'Budget dépassé')
                        : (share < 1
                            ? (p.isTrip
                                ? 'Budget voyage prévu · ${(share * 100).round()} % du voyage ce mois-ci'
                                : 'Budget prévu · ${(share * 100).round()} %')
                            : (p.isTrip ? 'Budget voyage prévu' : 'Budget prévu')))));
          }
          continue;
        }
        final rec = p.contributions[ym.key];
        if (rec != null) {
          projectCost += rec;
          pot[p.id] = (pot[p.id] ?? 0) + rec;
          lines.add(CalLine(p.name, -rec, LineKind.project, note: 'Épargne versée'));
        } else if (!ym.isBefore(now) && !ym.isBefore(p.startYm) && ym.isBefore(p.targetYm)) {
          projectCost += p.monthlyPlan;
          pot[p.id] = (pot[p.id] ?? 0) + p.monthlyPlan;
          lines.add(CalLine(p.name, -p.monthlyPlan, LineKind.project, note: 'Épargne prévue'));
        }
        if (share > 0) {
          // L'épargne et le budget sont répartis entre les mois du voyage au prorata des jours.
          final funded = (pot[p.id] ?? 0) * share;
          final base = closed ? tripSpent : max(p.target * share, tripSpent);
          final extra = base - funded; // peut être négatif : reste de l'épargne rendu
          projectCost += extra;
          tripActual += max(0.0, tripSpent - funded);
          if (extra.abs() > 0.005 || tripSpent > 0) {
            lines.add(CalLine(p.name, -extra, LineKind.project,
                note: extra < 0
                    ? 'Épargne non dépensée remise dans le solde'
                    : (closed ? 'Au-delà de l\'épargne (réel)' : 'Au-delà de l\'épargne')));
          }
        }
      }

      // Information : économies de clôture du mois précédent (déjà dans le solde)
      final prev = d.snapshots[ym.add(-1).key];
      if (prev != null && prev.savings != 0) {
        lines.add(CalLine('Économies de ${prev.ym.longName} reportées', prev.savings,
            LineKind.info, note: 'Déjà incluses dans le solde de départ'));
      }

      final f = MonthForecast(
        ym: ym,
        startBalance: balance,
        salary: salary,
        extraIncome: extra,
        fixed: fixed,
        budgets: budgetCost,
        projects: projectCost,
        unexpected: unexpected,
        tripActual: tripActual,
        closed: closed,
        lines: lines,
        receivedIncome: received,
        fixedPaid: fixedPaid,
        incomeItems: incomeItems,
        fixedItems: fixedItems,
      );
      out.add(f);
      balance = f.endBalance;
    }
    return out;
  }

  /// [Mode dev] Date de débit effective d'une dépense.
  /// Priorité : date de débit explicite > règle de débit du budget > jour de saisie.
  static DateTime effectiveDebitDate(AppData d, Transaction t) {
    if (t.debitDate != null) return t.debitDate!;
    final budget = d.budgets
        .where((b) => b.categoryId == t.categoryId && (b.person == 0 || b.person == t.person))
        .firstOrNull;
    if (budget != null) {
      final saisieYm = Ym.of(t.date);
      switch (budget.debitDay.kind) {
        case ReceiptDayKind.none:
          break;
        case ReceiptDayKind.lastWorkingDay:
          return DateTime(saisieYm.year, saisieYm.month, budget.debitDay.dayForYm(saisieYm));
        case ReceiptDayKind.fixedDay:
          final targetDay = budget.debitDay.day;
          if (targetDay > t.date.day) {
            // Le jour de débit est encore dans ce mois
            return DateTime(saisieYm.year, saisieYm.month, targetDay);
          }
          // Jour de débit déjà passé : débit le mois suivant
          final next = saisieYm.add(1);
          final lastDayNext = DateTime(next.year, next.month + 1, 0).day;
          return DateTime(next.year, next.month, targetDay.clamp(1, lastDayNext));
      }
    }
    return t.date;
  }

  /// Texte d'état d'une dépense (pointée ou non). [Mode dev] : une dépense à débit différé n'est
  /// jamais « débitée sur votre compte » tant que sa date de débit n'est pas passée.
  static String txStatus(AppData d, Transaction t, bool devMode) {
    if (devMode) {
      final debit = effectiveDebitDate(d, t);
      final today = DateTime.now();
      if (debit.isAfter(DateTime(today.year, today.month, today.day, 23, 59, 59))) {
        return '${t.checked ? 'Pointée' : 'Pas encore pointée'} · débit différé le ${debit.day} ${Ym.of(debit).short.toLowerCase()}';
      }
    }
    return t.checked ? 'Débité sur votre compte' : 'En attente de débit';
  }

  static bool _hasBudget(AppData d, Transaction t) =>
      d.budgets.any((b) => b.categoryId == t.categoryId && (b.person == 0 || b.person == t.person));

  /// [Mode dev] Répartit le coût de l'enveloppe [b] du mois [m] par mois de débit (clé = Ym.index).
  /// Dépensé : à la date de débit de chaque dépense. Reste du budget non dépensé (mois non
  /// clôturé) : au mois suivant si le budget est à débit différé (jour fixe), sinon le même mois.
  static Map<int, double> _envelopeDebits(AppData d, Budget b, Ym m) {
    final out = <int, double>{};
    var spent = 0.0;
    for (final t in d.transactionsIn(m,
        categoryId: b.categoryId, person: b.person == 0 ? null : b.person)) {
      if (t.isSpecial) continue;
      spent += t.amount;
      final idx = Ym.of(effectiveDebitDate(d, t)).index;
      out[idx] = (out[idx] ?? 0) + t.amount;
    }
    if (!d.isClosed(m)) {
      final rest = max(0.0, b.amountIn(m) - spent);
      if (rest > 0.005) {
        final idx = (b.debitDay.kind == ReceiptDayKind.fixedDay ? m.add(1) : m).index;
        out[idx] = (out[idx] ?? 0) + rest;
      }
    }
    return out;
  }

  /// Détail du solde actuel : tout ce qui est COCHÉ est passé sur le compte.
  ///  - revenu coché → reçu (le solde monte) ; charge ou dépense cochée → débitée (le solde baisse).
  ///  - versements d'épargne marqués et dépenses de voyage déjà sorties : retirés comme avant.
  /// Les lignes non cochées sont listées aussi ([BalItem.checked] = false) mais ne comptent pas.
  /// Identique avec ou sans mode développeur.
  static BalanceDetail balanceDetail(AppData d, MonthForecast f, {bool devMode = false}) {
    final items = <BalItem>[...f.incomeItems, ...f.fixedItems];
    if (f.tripActual > 0.005) {
      items.add(BalItem(BalKind.other, 'Voyages déjà payés', -f.tripActual,
          action: 'trips', ym: f.ym, emoji: '✈️'));
    }
    for (final p in d.projects) {
      final m = p.contributions[f.ym.key] ?? 0;
      if (m > 0.005) {
        items.add(BalItem(BalKind.other, p.name, -m,
            action: 'trips', ym: f.ym, note: 'Épargne versée', emoji: '🐷'));
      }
    }
    // Dépenses (budgets, imprévus) : cochée = débitée du compte.
    // [Mode dev] Sauf si le débit est différé : tant que la date de débit n'est pas passée, la
    // dépense est pointée (visible sur le compte) mais ne change pas le solde actuel. Les dépenses
    // saisies plus tôt et débitées ce mois-ci sont listées aussi (sans remonter avant « repartir
    // de zéro »).
    final today = DateTime.now();
    final endOfToday = DateTime(today.year, today.month, today.day, 23, 59, 59);
    final reset = d.resetYm;
    var lo = f.ym.add(-3);
    if (lo.isBefore(d.startYm)) lo = d.startYm;
    if (reset != null && !f.ym.isBefore(reset) && lo.isBefore(reset)) lo = reset;
    for (final t in d.transactions) {
      if (t.tripId != null) continue;
      final saisie = Ym.of(t.date);
      final debit = devMode ? effectiveDebitDate(d, t) : t.date;
      final inMonth = devMode
          ? (Ym.of(debit) == f.ym || saisie == f.ym) && !saisie.isBefore(lo) && !saisie.isAfter(f.ym)
          : saisie == f.ym;
      if (!inMonth) continue;
      final deferred = devMode && debit.isAfter(endOfToday);
      final cat = d.category(t.categoryId)?.name ?? 'Dépense';
      final debitTxt = '${debit.day} ${Ym.of(debit).short.toLowerCase()}';
      items.add(BalItem(BalKind.spend, t.description.isEmpty ? 'Dépense' : t.description, -t.amount,
          checked: t.checked,
          deferred: deferred,
          action: 'tx',
          id: t.id,
          ym: f.ym,
          emoji: d.category(t.categoryId)?.emoji,
          note: deferred
              ? '$cat · débit différé le $debitTxt'
              : (saisie != f.ym
                  ? '$cat · saisie en ${saisie.longName.toLowerCase()} · débitée le $debitTxt'
                  : '$cat · ${t.date.day}/${t.date.month}')));
    }
    return BalanceDetail(f.startBalance, items);
  }

  /// Solde réel à l'instant T du mois courant (total du détail ci-dessus).
  static double currentBalance(AppData d, MonthForecast f, {bool devMode = false}) =>
      balanceDetail(d, f, devMode: devMode).total;
}
