import '../core/ym.dart';

/// Paiement en plusieurs fois (canapé en 4 fois, abonnement annuel étalé…).
/// Chaque échéance est proposée au bon mois : l'utilisateur la confirme (en ajustant les
/// détails, par exemple un débit différé) et elle devient une dépense du budget choisi.
class InstallmentPlan {
  final String id;
  final String name;
  final String categoryId; // catégorie de budget (ou Imprévu)
  final int person; // 0 = seul(e), 1 / 2 = conjoint
  final double total; // montant total à payer
  final int count; // nombre d'échéances
  final Ym start; // mois de la première échéance
  final int day; // jour du mois prévu
  final List<String> done; // mois « yyyy-MM » ajoutés au budget
  final List<String> skipped; // mois « yyyy-MM » ignorés

  const InstallmentPlan({
    required this.id,
    required this.name,
    required this.categoryId,
    this.person = 0,
    required this.total,
    required this.count,
    required this.start,
    this.day = 1,
    this.done = const [],
    this.skipped = const [],
  });

  Ym ymAt(int i) => start.add(i);

  /// Montant de l'échéance [i] (la dernière absorbe l'arrondi).
  double amountAt(int i) {
    final base = (total / count * 100).round() / 100;
    return i == count - 1 ? double.parse((total - base * (count - 1)).toStringAsFixed(2)) : base;
  }

  DateTime dateAt(int i) {
    final ym = ymAt(i);
    final last = DateTime(ym.year, ym.month + 1, 0).day;
    return DateTime(ym.year, ym.month, day > last ? last : day);
  }

  bool isDone(int i) => done.contains(ymAt(i).key);
  bool isSkipped(int i) => skipped.contains(ymAt(i).key);
  bool isResolved(int i) => isDone(i) || isSkipped(i);

  int get doneCount => List.generate(count, (i) => i).where(isDone).length;
  bool get finished => List.generate(count, (i) => i).every(isResolved);

  /// Échéances arrivées à leur mois (ou en retard) et pas encore traitées.
  List<int> dueIndexes(Ym now) =>
      [for (var i = 0; i < count; i++) if (!ymAt(i).isAfter(now) && !isResolved(i)) i];

  /// Prochaine échéance à venir (pas encore traitée).
  int? nextIndex() {
    for (var i = 0; i < count; i++) {
      if (!isResolved(i)) return i;
    }
    return null;
  }

  double get remaining {
    var r = 0.0;
    for (var i = 0; i < count; i++) {
      if (!isResolved(i)) r += amountAt(i);
    }
    return r;
  }

  InstallmentPlan copyWith({
    String? name,
    String? categoryId,
    int? person,
    double? total,
    int? count,
    Ym? start,
    int? day,
    List<String>? done,
    List<String>? skipped,
  }) =>
      InstallmentPlan(
        id: id,
        name: name ?? this.name,
        categoryId: categoryId ?? this.categoryId,
        person: person ?? this.person,
        total: total ?? this.total,
        count: count ?? this.count,
        start: start ?? this.start,
        day: day ?? this.day,
        done: done ?? this.done,
        skipped: skipped ?? this.skipped,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'categoryId': categoryId,
        'person': person,
        'total': total,
        'count': count,
        'start': start.key,
        'day': day,
        'done': done,
        'skipped': skipped,
      };

  factory InstallmentPlan.fromJson(Map<String, dynamic> j) => InstallmentPlan(
        id: j['id'] as String,
        name: j['name'] as String,
        categoryId: j['categoryId'] as String,
        person: (j['person'] as num?)?.toInt() ?? 0,
        total: (j['total'] as num).toDouble(),
        count: (j['count'] as num).toInt(),
        start: Ym.parse(j['start'] as String),
        day: (j['day'] as num?)?.toInt() ?? 1,
        done: [for (final e in (j['done'] as List? ?? const [])) e as String],
        skipped: [for (final e in (j['skipped'] as List? ?? const [])) e as String],
      );
}
