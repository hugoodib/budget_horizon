import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/share_link.dart';
import '../data/cloud_api.dart';
import '../data/firebase_config.dart';
import '../domain/models.dart';
import '../domain/repository.dart';
import 'providers.dart';

class AuthState {
  final Session? session;
  final bool skipped; // "Continuer sans compte"
  final bool busy;
  final String? error;
  final String? info;
  final DateTime? lastSync;
  final bool offline;
  final String? shareId; // code du budget partagé (si partagé)
  const AuthState({
    this.session,
    this.skipped = false,
    this.busy = false,
    this.error,
    this.info,
    this.lastSync,
    this.offline = false,
    this.shareId,
  });

  AuthState copyWith({
    Session? session,
    bool clearSession = false,
    bool? skipped,
    bool? busy,
    String? error,
    bool clearError = false,
    String? info,
    bool clearInfo = false,
    DateTime? lastSync,
    bool? offline,
    String? shareId,
    bool clearShare = false,
  }) =>
      AuthState(
        session: clearSession ? null : (session ?? this.session),
        skipped: skipped ?? this.skipped,
        busy: busy ?? this.busy,
        error: clearError ? null : (error ?? this.error),
        info: clearInfo ? null : (info ?? this.info),
        lastSync: lastSync ?? this.lastSync,
        offline: offline ?? this.offline,
        shareId: clearShare ? null : (shareId ?? this.shareId),
      );
}

/// Code d'invitation reçu par lien (`?join=CODE`) : rejoint automatiquement une fois connecté.
final pendingJoinProvider = StateProvider<String?>((ref) => ShareLink.initialCode());

final authProvider =
    StateNotifierProvider<AuthController, AuthState>((ref) => AuthController(ref));

/// Compte utilisateur + synchronisation des données avec Firestore.
/// Les données restent d'abord stockées en local (Hive) ; la synchro est
/// un envoi différé après chaque modification.
class AuthController extends StateNotifier<AuthState> {
  final Ref _ref;
  final CloudApi? _api;
  Timer? _pushTimer;
  Timer? _poll;
  bool _syncing = false;
  bool _dirty = false;

  AuthController(Ref ref)
      : _ref = ref,
        _api = FirebaseConfig.enabled
            ? CloudApi(FirebaseConfig.apiKey, FirebaseConfig.projectId)
            : null,
        super(_initial(ref)) {
    if (state.session != null) {
      unawaited(_startup());
    }
    // Budget partagé : on récupère régulièrement les modifications du conjoint.
    _poll = Timer.periodic(const Duration(seconds: 45), (_) {
      final s = state.session;
      if (s != null && s.emailVerified && state.shareId != null && !_dirty && !state.busy) {
        syncNow(checkShare: false);
      }
    });
  }

  static AuthState _initial(Ref ref) {
    final repo = ref.read(repositoryProvider);
    Session? s;
    final raw = repo.readMeta('session');
    if (raw != null) {
      try {
        s = Session.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
      } catch (_) {
        s = null;
      }
    }
    return AuthState(
      session: s,
      skipped: repo.readMeta('skip_auth') == '1',
      shareId: repo.readMeta('share_id'),
    );
  }

  AppRepository get _repo => _ref.read(repositoryProvider);

  @override
  void dispose() {
    _pushTimer?.cancel();
    _poll?.cancel();
    super.dispose();
  }

  // ---------- Session ----------
  Future<void> _saveSession(Session s) async {
    await _repo.writeMeta('session', jsonEncode(s.toJson()));
    state = state.copyWith(session: s);
  }

  Future<void> _dropSession() async {
    await _repo.writeMeta('session', null);
    state = state.copyWith(clearSession: true);
  }

  Future<void> _setShareLocal(String? id) async {
    if (id == state.shareId) return;
    await _repo.writeMeta('share_id', id);
    state = state.copyWith(shareId: id, clearShare: id == null);
  }

  /// Renouvelle le jeton si nécessaire. Faux si impossible (hors ligne ou session invalide).
  Future<bool> _ensureToken() async {
    final s = state.session;
    final api = _api;
    if (s == null || api == null) return false;
    if (!s.needsRefresh) return true;
    try {
      final n = await api.refresh(s);
      await _saveSession(n);
      return true;
    } on CloudException catch (e) {
      if (e.isAuthInvalid) await _dropSession();
      return false;
    } catch (_) {
      state = state.copyWith(offline: true);
      return false;
    }
  }

  Future<void> _startup() async {
    if (!await _ensureToken()) return;
    try {
      final s = state.session!;
      final ok = await _api!.isEmailVerified(s.idToken);
      if (ok != s.emailVerified) await _saveSession(s.copyWith(emailVerified: ok));
      if (ok) await syncNow();
    } catch (_) {
      state = state.copyWith(offline: true);
    }
  }

  // ---------- Synchronisation ----------
  /// Au démarrage / à la demande : la version la plus récente gagne.
  Future<void> syncNow({bool checkShare = true}) async {
    if (_syncing) return;
    _syncing = true;
    try {
      if (!await _ensureToken()) return;
      final s = state.session!;
      if (!s.emailVerified) return;
      try {
        if (checkShare) await _setShareLocal(await _api!.loadUserShareId(s));
        final doc = await _api!.loadDoc(s, shareId: state.shareId);
        final localTs = DateTime.tryParse(_repo.readMeta('updated_at') ?? '');
        if (doc == null) {
          if (state.shareId != null) {
            // Le budget partagé n'existe plus : retour à l'espace personnel.
            await _api!.setUserShareId(s, null);
            await _setShareLocal(null);
            state = state.copyWith(info: 'Le budget partagé n\'existe plus : vos données sont désormais personnelles.');
          }
          await _push();
        } else if (localTs == null || doc.updatedAt.isAfter(localTs)) {
          await _apply(doc);
        } else if (localTs.isAfter(doc.updatedAt)) {
          await _push();
        } else {
          state = state.copyWith(lastSync: DateTime.now(), offline: false);
        }
      } on CloudException catch (e) {
        if (state.shareId != null && e.code == 'PERMISSION_DENIED') {
          // On n'est plus membre du budget partagé.
          try {
            await _api!.setUserShareId(s, null);
          } catch (_) {}
          await _setShareLocal(null);
          state = state.copyWith(info: 'Vous ne faites plus partie de ce budget partagé.');
        } else {
          state = state.copyWith(error: e.message);
        }
      } catch (_) {
        state = state.copyWith(offline: true);
      }
    } finally {
      _syncing = false;
    }
  }

  Future<void> _apply(CloudDoc doc) async {
    final data = AppData.fromJson(Map<String, dynamic>.from(jsonDecode(doc.data) as Map));
    _ref.read(appProvider.notifier).replace(data);
    await _repo.writeMeta('updated_at', doc.updatedAt.toUtc().toIso8601String());
    state = state.copyWith(lastSync: DateTime.now(), offline: false);
  }

  Future<void> _push() async {
    if (!await _ensureToken()) return;
    var ts = DateTime.tryParse(_repo.readMeta('updated_at') ?? '');
    if (ts == null) {
      ts = DateTime.now().toUtc();
      await _repo.writeMeta('updated_at', ts.toIso8601String());
    }
    try {
      final data = _ref.read(appProvider);
      await _api!.saveDoc(state.session!, jsonEncode(data.toJson()), ts, shareId: state.shareId);
      _dirty = false;
      state = state.copyWith(lastSync: DateTime.now(), offline: false, clearError: true);
    } on CloudException catch (e) {
      state = state.copyWith(error: e.message);
    } catch (_) {
      state = state.copyWith(offline: true);
    }
  }

  /// Appelé après chaque modification des données.
  void markChanged() {
    _repo.writeMeta('updated_at', DateTime.now().toUtc().toIso8601String());
    final s = state.session;
    if (s == null || !s.emailVerified) return;
    _dirty = true;
    _pushTimer?.cancel();
    _pushTimer = Timer(const Duration(seconds: 2), () {
      _push();
    });
  }

  // ---------- Actions ----------
  Future<void> _run(Future<void> Function() body) async {
    if (_api == null) return;
    state = state.copyWith(busy: true, clearError: true, clearInfo: true);
    try {
      await body();
    } on CloudException catch (e) {
      state = state.copyWith(error: e.message);
    } catch (_) {
      state = state.copyWith(error: 'Connexion impossible. Vérifiez votre réseau.');
    } finally {
      state = state.copyWith(busy: false);
    }
  }

  /// Création de compte : un e-mail de confirmation est envoyé.
  Future<void> signUp(String email, String password) => _run(() async {
        final s = await _api!.signUp(email.trim(), password);
        await _repo.writeMeta('skip_auth', null);
        await _saveSession(s);
        state = state.copyWith(skipped: false);
        try {
          await _api!.sendVerification(s.idToken);
        } catch (_) {}
      });

  /// Connexion : les données du compte remplacent celles de l'appareil.
  Future<void> signIn(String email, String password) => _run(() async {
        final api = _api!;
        final s0 = await api.signIn(email.trim(), password);
        final verified = await api.isEmailVerified(s0.idToken);
        final s = s0.copyWith(emailVerified: verified);
        var needPush = false;
        if (verified) {
          var sid = await api.loadUserShareId(s);
          var doc = await api.loadDoc(s, shareId: sid);
          if (sid != null && doc == null) {
            sid = null; // budget partagé supprimé
            doc = await api.loadDoc(s);
          }
          await _setShareLocal(sid);
          if (doc != null) {
            await _apply(doc);
          } else {
            await _repo.writeMeta('updated_at', DateTime.now().toUtc().toIso8601String());
            needPush = true;
          }
        }
        await _repo.writeMeta('skip_auth', null);
        await _saveSession(s);
        state = state.copyWith(skipped: false);
        if (needPush) await _push();
      });

  /// Après avoir cliqué sur le lien reçu par e-mail.
  Future<void> checkVerification() => _run(() async {
        if (!await _ensureToken()) {
          throw const CloudException('OFFLINE');
        }
        final s = state.session!;
        final ok = await _api!.isEmailVerified(s.idToken);
        if (ok) {
          await _saveSession(s.copyWith(emailVerified: true));
          await syncNow();
        } else {
          state = state.copyWith(error: 'Adresse pas encore confirmée : ouvrez le lien reçu par e-mail.');
        }
      });

  Future<void> resendVerification() => _run(() async {
        if (!await _ensureToken()) throw const CloudException('OFFLINE');
        await _api!.sendVerification(state.session!.idToken);
        state = state.copyWith(info: 'E-mail envoyé de nouveau (pensez aux spams).');
      });

  Future<void> sendReset(String email) => _run(() async {
        await _api!.sendPasswordReset(email.trim());
        state = state.copyWith(info: 'E-mail de réinitialisation envoyé (pensez à vérifier les spams).');
      });

  Future<void> signOut() async {
    _pushTimer?.cancel();
    _dirty = false;
    await _dropSession();
    await _setShareLocal(null);
    await _repo.writeMeta('skip_auth', null);
    // L'appareil est remis à zéro : les données restent dans le compte.
    await _ref.read(appProvider.notifier).resetDemo(onboarded: false);
    await _repo.writeMeta('updated_at', null);
    state = state.copyWith(skipped: false, clearError: true, clearInfo: true);
  }

  /// Suppression définitive du compte et de ses données (mot de passe demandé).
  Future<bool> deleteAccount(String password) async {
    var ok = false;
    await _run(() async {
      final email = state.session!.email;
      final s = await _api!.signIn(email, password); // ré-authentification
      final sid = state.shareId;
      if (sid != null) {
        try {
          await _leaveShareRemote(s, sid);
        } catch (_) {}
      }
      await _api!.deleteDoc(s, 'users/${s.uid}');
      await _api!.deleteAccount(s.idToken);
      _pushTimer?.cancel();
      _dirty = false;
      await _dropSession();
      await _setShareLocal(null);
      await _repo.writeMeta('skip_auth', null);
      await _ref.read(appProvider.notifier).resetDemo(onboarded: false);
      await _repo.writeMeta('updated_at', null);
      state = state.copyWith(skipped: false);
      ok = true;
    });
    return ok;
  }

  Future<void> continueWithoutAccount() async {
    await _repo.writeMeta('skip_auth', '1');
    state = state.copyWith(skipped: true, clearError: true, clearInfo: true);
  }

  /// Ré-affiche l'écran de connexion (depuis les réglages).
  Future<void> showAuth() async {
    await _repo.writeMeta('skip_auth', null);
    state = state.copyWith(skipped: false, clearError: true, clearInfo: true);
  }

  // ---------- Budget partagé (deux comptes, mêmes données) ----------
  static const _alphabet = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';

  String _newCode() {
    final r = Random.secure();
    return List.generate(12, (_) => _alphabet[r.nextInt(_alphabet.length)]).join();
  }

  /// Crée le budget partagé à partir des données actuelles ; renvoie le code à donner au conjoint.
  Future<String?> createShare() async {
    String? code;
    await _run(() async {
      if (state.shareId != null) {
        code = state.shareId;
        return;
      }
      if (!await _ensureToken()) throw const CloudException('OFFLINE');
      final s = state.session!;
      final c = _newCode();
      final ts = DateTime.tryParse(_repo.readMeta('updated_at') ?? '') ?? DateTime.now().toUtc();
      await _repo.writeMeta('updated_at', ts.toUtc().toIso8601String());
      final data = _ref.read(appProvider);
      await _api!.createShare(s, c, jsonEncode(data.toJson()), ts);
      await _api!.setUserShareId(s, c);
      await _setShareLocal(c);
      code = c;
    });
    return code;
  }

  /// Rejoint le budget partagé d'un conjoint : ses données remplacent celles de l'appareil.
  Future<bool> joinShare(String raw) async {
    var ok = false;
    final code = raw.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    await _run(() async {
      if (code.length < 8) throw const CloudException('SHARE_NOT_FOUND');
      if (!await _ensureToken()) throw const CloudException('OFFLINE');
      final s = state.session!;
      CloudDoc? doc;
      try {
        doc = await _api!.loadDoc(s, shareId: code);
      } on CloudException catch (e) {
        if (e.code == 'PERMISSION_DENIED') throw const CloudException('SHARE_FULL');
        rethrow;
      }
      if (doc == null) throw const CloudException('SHARE_NOT_FOUND');
      if (!doc.members.contains(s.uid)) {
        if (doc.members.length >= 2) throw const CloudException('SHARE_FULL');
        await _api!.setShareMembers(s, code, [...doc.members, s.uid]);
      }
      await _api!.setUserShareId(s, code);
      await _setShareLocal(code);
      await _apply(doc);
      ok = true;
    });
    return ok;
  }

  Future<void> _leaveShareRemote(Session s, String sid) async {
    final doc = await _api!.loadDoc(s, shareId: sid);
    if (doc != null) {
      final rest = doc.members.where((m) => m != s.uid).toList();
      if (rest.isEmpty) {
        await _api!.deleteDoc(s, 'shares/$sid');
      } else {
        await _api!.setShareMembers(s, sid, rest);
      }
    }
    await _api!.setUserShareId(s, null);
  }

  /// Quitte le budget partagé : la copie actuelle reste dans votre espace personnel.
  Future<void> leaveShare() => _run(() async {
        final sid = state.shareId;
        if (sid == null) return;
        if (!await _ensureToken()) throw const CloudException('OFFLINE');
        await _leaveShareRemote(state.session!, sid);
        await _setShareLocal(null);
        await _repo.writeMeta('updated_at', DateTime.now().toUtc().toIso8601String());
        await _push();
      });
}
