import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../domain/business.dart';
import 'providers.dart';
import 'screens/analysis_screen.dart';
import 'screens/budgets_screen.dart';
import 'screens/clients_screen.dart';
import 'screens/fixed_expenses_screen.dart';
import 'screens/forecast_screen.dart';
import 'screens/home_screen.dart';
import 'screens/incomes_screen.dart';
import 'screens/invoices_screen.dart';
import 'screens/projects_screen.dart';
import 'tour.dart';
import 'widgets/close_month.dart';
import 'widgets/common.dart';
import 'widgets/forms.dart';

class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});
  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _TabDef {
  final AppTab tab;
  final String label;
  final IconData icon;
  final IconData selectedIcon;
  const _TabDef(this.tab, this.label, this.icon, this.selectedIcon);
}

class _RootShellState extends ConsumerState<RootShell> {
  @override
  void initState() {
    super.initState();
    // Première utilisation : la démonstration guidée démarre toute seule.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !ref.read(appProvider).user.tourSeen) {
        ref.read(tourProvider.notifier).start();
      }
    });
  }

  Widget _page(AppTab t) => switch (t) {
        AppTab.home => const HomeScreen(),
        AppTab.forecast => const ForecastScreen(),
        AppTab.budgets => const BudgetsScreen(),
        AppTab.charges => const FixedExpensesScreen(),
        AppTab.incomes => const IncomesScreen(),
        AppTab.clients => const ClientsScreen(),
        AppTab.invoices => const InvoicesScreen(),
        AppTab.trips => const ProjectsScreen(),
        AppTab.analysis => const AnalysisScreen(),
      };

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final due = closeIsDue(d, ref.watch(nowProvider));
    final defs = <_TabDef>[
      const _TabDef(AppTab.home, 'Accueil', Icons.home_outlined, Icons.home_rounded),
      const _TabDef(AppTab.forecast, 'Prévisions', Icons.query_stats_rounded, Icons.insights_rounded),
      const _TabDef(AppTab.budgets, 'Budgets', Icons.account_balance_wallet_outlined,
          Icons.account_balance_wallet_rounded),
      const _TabDef(AppTab.charges, 'Charges', Icons.receipt_long_outlined, Icons.receipt_long_rounded),
      const _TabDef(AppTab.incomes, 'Revenus', Icons.payments_outlined, Icons.payments_rounded),
      // Clients et Factures : un seul onglet, avec un sélecteur en haut de page
      if (d.hasAE)
        const _TabDef(AppTab.clients, 'Clients', Icons.groups_outlined, Icons.groups_rounded),
      const _TabDef(AppTab.trips, 'Voyages', Icons.flight_takeoff_outlined, Icons.flight_takeoff_rounded),
    ];
    var current = ref.watch(tabProvider);
    var index = defs.indexWhere((e) => e.tab == (current == AppTab.invoices ? AppTab.clients : current));
    if (index < 0) {
      // L'onglet affiché n'existe plus (ex. mode auto-entrepreneur désactivé)
      current = AppTab.home;
      index = 0;
    }
    return Scaffold(
      // Seule la page affichée est construite ; la position de défilement
      // est conservée grâce aux PageStorageKey.
      body: _page(current),
      // Bouton + : noter une dépense depuis n'importe quel onglet
      floatingActionButton: _AddExpenseFab(key: TourKeys.fab),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.black.withAlpha(12)))),
        child: NavigationBar(
          selectedIndex: index,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) => ref.read(tabProvider.notifier).state = defs[i].tab,
          destinations: [
            for (final t in defs)
              NavigationDestination(
                key: TourKeys.tab[t.tab],
                icon: t.tab == AppTab.budgets
                    ? Badge(
                        isLabelVisible: due,
                        smallSize: 9,
                        backgroundColor: AppColors.pink,
                        child: Icon(t.icon))
                    : Icon(t.icon),
                selectedIcon: t.tab == AppTab.budgets
                    ? Badge(
                        isLabelVisible: due,
                        smallSize: 9,
                        backgroundColor: AppColors.pink,
                        child: Icon(t.selectedIcon))
                    : Icon(t.selectedIcon),
                label: t.label,
              ),
          ],
        ),
      ),
    );
  }
}

/// Bouton flottant : « + Dépense » partout, sauf « + Revenu » sur Revenus
/// et « + Client » sur Clients.
class _AddExpenseFab extends ConsumerWidget {
  const _AddExpenseFab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tab = ref.watch(tabProvider);
    final String label;
    final Future<void> Function() onTap;
    switch (tab) {
      case AppTab.incomes:
        label = 'Revenu';
        onTap = () async {
          final month = ref.read(nowProvider);
          await showSheet<bool>(context, title: 'Nouveau revenu', child: AddIncomeSheet(month: month));
        };
        break;
      case AppTab.clients:
        label = 'Client';
        onTap = () async {
          await showSheet<void>(context, title: 'Nouveau client', child: const ClientSheet());
        };
        break;
      case AppTab.charges:
        label = 'Charge';
        onTap = () async {
          await showSheet<void>(context, title: 'Nouvelle charge fixe', child: const AddFixedExpenseSheet());
        };
        break;
      case AppTab.trips:
        label = 'Voyage';
        onTap = () async {
          await showSheet<void>(context, title: 'Nouveau voyage', child: const AddProjectSheet());
        };
        break;
      default:
        label = 'Dépense';
        onTap = () async {
          final month = ref.read(nowProvider);
          final ok = await showSheet<bool>(
            context,
            title: 'Nouvelle dépense',
            child: AddExpenseSheet(month: month),
          );
          if (ok == true && context.mounted) snack(context, 'Dépense ajoutée');
        };
    }
    // « + » toujours visible : on comprend tout de suite que c'est un ajout.
    const icon = Icons.add_rounded;
    return Container(
      decoration: BoxDecoration(
        gradient: brandGradient,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(color: tint(AppColors.violet, .35), blurRadius: 16, offset: const Offset(0, 6)),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(28),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(icon, color: AppColors.text, size: 24),
              const SizedBox(width: 6),
              Text(label, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w800, fontSize: 15)),
            ]),
          ),
        ),
      ),
    );
  }
}
