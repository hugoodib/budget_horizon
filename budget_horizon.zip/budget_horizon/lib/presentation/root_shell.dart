import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/money.dart';
import '../core/theme.dart';
import '../core/ym.dart';
import '../domain/business.dart';
import '../domain/models.dart';
import 'providers.dart';
import 'screens/analysis_screen.dart';
import 'screens/budgets_screen.dart';
import 'screens/clients_screen.dart';
import 'screens/fixed_expenses_screen.dart';
import 'screens/forecast_screen.dart';
import 'screens/home_screen.dart';
import 'screens/incomes_screen.dart';
import 'screens/invoices_screen.dart';
import 'screens/projects_screen.dart';
import 'tour.dart';
import 'widgets/close_month.dart';
import 'widgets/common.dart';
import 'widgets/assistant.dart';
import 'widgets/forms.dart';

class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});
  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _TabDef {
  final AppTab tab;
  final String label;
  final IconData icon;
  final IconData selectedIcon;
  const _TabDef(this.tab, this.label, this.icon, this.selectedIcon);
}

class _RootShellState extends ConsumerState<RootShell> {
  int _prevIndex = 0;          // pour savoir le sens du slide
  bool _showSuccessOverlay = false; // animation confetti après clôture
  bool _showAddOverlay = false; // overlay menu ajout

  @override
  void initState() {
    super.initState();
    // La démonstration guidée automatique est désactivée.
    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   if (mounted && !ref.read(appProvider).user.tourSeen) {
    //     ref.read(tourProvider.notifier).start();
    //   }
    // });
  }

  /// Popup rappelant de terminer le mois avec la liste des éléments non pointés.
  Widget _page(AppTab t) => switch (t) {
        AppTab.home => const HomeScreen(),
        AppTab.forecast => const ForecastScreen(),
        AppTab.budgets => const BudgetsScreen(),
        AppTab.charges => const FixedExpensesScreen(),
        AppTab.incomes => const IncomesScreen(),
        AppTab.clients => const ClientsScreen(),
        AppTab.invoices => const InvoicesScreen(),
        AppTab.trips => const ProjectsScreen(),
        AppTab.analysis => const AnalysisScreen(),
      };

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final due = closeIsDue(d, now);

    // Écouter le tick de succès pour déclencher l'overlay confetti
    ref.listen<int>(closeSuccessTickProvider, (_, __) {
      if (mounted) setState(() => _showSuccessOverlay = true);
    });

    final defs = <_TabDef>[
      const _TabDef(AppTab.home, 'Accueil', Icons.home_outlined, Icons.home_rounded),
      const _TabDef(AppTab.forecast, 'Prévisions', Icons.query_stats_rounded, Icons.insights_rounded),
      const _TabDef(AppTab.budgets, 'Budgets', Icons.account_balance_wallet_outlined,
          Icons.account_balance_wallet_rounded),
      // « Fixes » regroupe Charges et Revenus (sélecteur en haut de page)
      const _TabDef(AppTab.charges, 'Mensuel', Icons.repeat_rounded, Icons.repeat_on_rounded),
      // Clients et Factures : leur propre onglet (auto-entrepreneur), sélecteur en haut de page
      if (d.hasAE) const _TabDef(AppTab.clients, 'Clients', Icons.groups_outlined, Icons.groups_rounded),
      const _TabDef(AppTab.trips, 'Projets', Icons.flag_outlined, Icons.flag_rounded),
    ];
    var current = ref.watch(tabProvider);
    var index = defs.indexWhere((e) =>
        e.tab ==
        (current == AppTab.incomes ? AppTab.charges : (current == AppTab.invoices ? AppTab.clients : current)));
    if (index < 0) {
      // L'onglet affiché n'existe plus (ex. mode auto-entrepreneur désactivé)
      current = AppTab.home;
      index = 0;
    }
    return Scaffold(
      body: Stack(children: [
        Positioned.fill(
          child: KeyedSubtree(
            key: ValueKey(current),
            child: _page(current),
          ),
        ),
        // Overlay de succès : confetti après clôture
        if (_showSuccessOverlay)
          Positioned.fill(child: _SuccessOverlay(onDone: () => setState(() => _showSuccessOverlay = false))),
        // Overlay menu ajout
        if (_showAddOverlay)
          Positioned.fill(
            child: _AddMenuOverlay(
              onClose: () => setState(() => _showAddOverlay = false),
              ref: ref,
            ),
          ),
        // Bouton IA + bouton + groupés en bas à droite
        Positioned(
          key: TourKeys.fab,
          right: 16,
          bottom: 16,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            // Bouton IA
            GestureDetector(
              onTap: () => showSheet(context, title: 'Assistant', child: const AssistantSheet()),
              child: Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: tint(AppColors.violet, .35), blurRadius: 14, offset: const Offset(0, 5))],
                ),
                child: ShaderMask(
                  shaderCallback: (r) => brandGradient.createShader(r),
                  child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 24),
                ),
              ),
            ),
            const SizedBox(width: 10),
            // Bouton +
            _AddFabButton(
              onTap: () => setState(() => _showAddOverlay = true),
            ),
          ]),
        ),
      ]),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.black.withAlpha(12)))),
        child: NavigationBar(
          selectedIndex: index,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) {
            if (i == index) {
              ref.read(scrollTopTickProvider.notifier).state++;
            } else {
              setState(() => _prevIndex = index);
              ref.read(tabProvider.notifier).state = defs[i].tab;
            }
          },
          destinations: [
            for (final t in defs)
              NavigationDestination(
                key: TourKeys.tab[t.tab],
                icon: t.tab == AppTab.budgets
                    ? Badge(
                        isLabelVisible: due,
                        smallSize: 9,
                        backgroundColor: AppColors.pink,
                        child: Icon(t.icon))
                    : Icon(t.icon),
                selectedIcon: t.tab == AppTab.budgets
                    ? Badge(
                        isLabelVisible: due,
                        smallSize: 9,
                        backgroundColor: AppColors.pink,
                        child: Icon(t.selectedIcon))
                    : Icon(t.selectedIcon),
                label: t.label,
              ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Bouton + circulaire (positionné dans le Stack du body)
// ═══════════════════════════════════════════════════════════════
class _AddFabButton extends StatelessWidget {
  final VoidCallback onTap;
  const _AddFabButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        color: AppColors.violet,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: tint(AppColors.violet, .50),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 28),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// Overlay menu ajout (plein écran, au-dessus de tout)
// ═══════════════════════════════════════════════════════════════
class _AddMenuOverlay extends StatefulWidget {
  final VoidCallback onClose;
  final WidgetRef ref;
  const _AddMenuOverlay({required this.onClose, required this.ref});
  @override
  State<_AddMenuOverlay> createState() => _AddMenuOverlayState();
}

class _AddMenuOverlayState extends State<_AddMenuOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 260));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
            begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _close() {
    _ctrl.reverse().then((_) => widget.onClose());
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.ref.read(appProvider);
    final month = widget.ref.read(nowProvider);
    final items = [
      _AddMenuItemData(
        icon: Icons.arrow_upward_rounded,
        color: AppColors.danger,
        title: 'Une dépense',
        subtitle: 'Un achat dans votre budget',
        onTap: () async {
          _close();
          await Future.delayed(const Duration(milliseconds: 200));
          if (context.mounted) {
            final ok = await showSheet<bool>(context,
                title: 'Nouvelle dépense', child: AddExpenseSheet(month: month));
            if (ok == true && context.mounted) snack(context, 'Dépense ajoutée');
          }
        },
      ),
      _AddMenuItemData(
        icon: Icons.arrow_downward_rounded,
        color: AppColors.teal,
        title: 'Un revenu',
        subtitle: 'Salaire, prime ou remboursement',
        onTap: () async {
          _close();
          await Future.delayed(const Duration(milliseconds: 200));
          if (context.mounted) {
            await showSheet<bool>(context,
                title: 'Nouveau revenu', child: AddIncomeSheet(month: month));
          }
        },
      ),
      _AddMenuItemData(
        icon: Icons.repeat_rounded,
        color: AppColors.pink,
        title: 'Une charge',
        subtitle: 'Mensuelle, trimestrielle ou annuelle',
        onTap: () async {
          _close();
          await Future.delayed(const Duration(milliseconds: 200));
          if (context.mounted) {
            await showSheet<void>(context,
                title: 'Nouvelle charge',
                child: const AddFixedExpenseSheet());
          }
        },
      ),
      if (d.hasAE)
        _AddMenuItemData(
          icon: Icons.description_rounded,
          color: AppColors.violet,
          title: 'Une facture',
          subtitle: 'Émettre une facture client',
          onTap: () async {
            _close();
            await Future.delayed(const Duration(milliseconds: 200));
            if (context.mounted) {
              final invoiceMonth = widget.ref.read(invoiceMonthProvider);
              await showSheet<void>(context,
                  title: 'Nouvelle facture · ${invoiceMonth.label}',
                  child: ManualInvoiceSheet(month: invoiceMonth));
            }
          },
        ),
      _AddMenuItemData(
        icon: Icons.flight_rounded,
        color: AppColors.violet,
        title: 'Un projet',
        subtitle: 'Voyage, achat ou objectif d\'épargne',
        onTap: () async {
          _close();
          await Future.delayed(const Duration(milliseconds: 200));
          if (context.mounted) {
            await showSheet<void>(context,
                title: 'Nouveau projet',
                child: const AddProjectSheet());
          }
        },
      ),
      _AddMenuItemData(
        icon: Icons.account_balance_wallet_rounded,
        color: AppColors.teal,
        title: 'Une catégorie de budget',
        subtitle: 'Créer une enveloppe de dépenses',
        onTap: () async {
          _close();
          await Future.delayed(const Duration(milliseconds: 200));
          if (context.mounted) {
            await showSheet<void>(context,
                title: 'Nouvelle catégorie',
                child: const AddCategorySheet());
          }
        },
      ),
    ];

    final bottomPad = MediaQuery.of(context).padding.bottom;

    return FadeTransition(
      opacity: _fade,
      child: GestureDetector(
        onTap: _close,
        child: Container(
          color: Colors.black.withAlpha(160),
          child: SafeArea(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: SlideTransition(
                position: _slide,
                child: GestureDetector(
                  onTap: () {}, // empêche la fermeture au tap sur le panel
                  child: Container(
                    width: double.infinity,
                    margin: EdgeInsets.fromLTRB(16, 0, 16, bottomPad + 82),
                    decoration: BoxDecoration(
                      color: context.cardColor,
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(60),
                          blurRadius: 32,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          const Expanded(
                            child: Text('Que souhaitez-vous enregistrer ?',
                                style: TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w800)),
                          ),
                          GestureDetector(
                            onTap: _close,
                            child: Container(
                              width: 30, height: 30,
                              decoration: BoxDecoration(
                                color: context.fieldColor,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(Icons.close_rounded,
                                  size: 17, color: context.mutedColor),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 16),
                        for (int i = 0; i < items.length; i++) ...[
                          if (i > 0) const SizedBox(height: 10),
                          _AddMenuTile(item: items[i]),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AddMenuItemData {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _AddMenuItemData({
    required this.icon, required this.color,
    required this.title, required this.subtitle, required this.onTap,
  });
}

class _AddMenuTile extends StatelessWidget {
  final _AddMenuItemData item;
  const _AddMenuTile({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: tint(item.color, .13),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: item.onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                color: item.color,
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(item.icon, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 15)),
                Text(item.subtitle,
                    style: TextStyle(
                        color: context.mutedColor, fontSize: 12.5)),
              ],
            )),
            Icon(Icons.chevron_right_rounded,
                color: item.color, size: 20),
          ]),
        ),
      ),
    );
  }
}



// ═══════════════════════════════════════════════════════════════
// Animation de succès après clôture du mois
// ═══════════════════════════════════════════════════════════════
class _SuccessOverlay extends StatefulWidget {
  final VoidCallback onDone;
  const _SuccessOverlay({required this.onDone});
  @override
  State<_SuccessOverlay> createState() => _SuccessOverlayState();
}

class _SuccessOverlayState extends State<_SuccessOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  final _rng = Random();
  final _particles = <_Particle>[];

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
      ..forward().whenComplete(() {
        if (mounted) widget.onDone();
      });
    // Générer 60 confettis
    for (var i = 0; i < 60; i++) {
      _particles.add(_Particle(
        x: _rng.nextDouble(),
        delay: _rng.nextDouble() * 0.4,
        speed: 0.4 + _rng.nextDouble() * 0.6,
        size: 6 + _rng.nextDouble() * 10,
        color: [
          AppColors.violet, AppColors.teal, AppColors.warning,
          AppColors.pink, AppColors.success, const Color(0xFF0A84FF),
        ][_rng.nextInt(6)],
        rotation: _rng.nextDouble() * 2 * pi,
        wobble: _rng.nextDouble() * 2 * pi,
      ));
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, _) {
        final t = _ctrl.value;
        return Stack(children: [
          // Fond semi-transparent qui s'estompe
          Positioned.fill(
            child: GestureDetector(
              onTap: widget.onDone,
              child: Container(
                color: Colors.black.withAlpha(((1 - t) * 120).round()),
              ),
            ),
          ),
          // Message central
          if (t < 0.85)
            Center(
              child: Transform.scale(
                scale: t < 0.15
                    ? Curves.elasticOut.transform(t / 0.15)
                    : (t > 0.7 ? 1 - ((t - 0.7) / 0.15).clamp(0.0, 1.0) : 1.0),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
                  decoration: BoxDecoration(
                    color: context.cardColor,
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [BoxShadow(color: Colors.black.withAlpha(30), blurRadius: 30)],
                  ),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('🎉', style: TextStyle(fontSize: 52)),
                    const SizedBox(height: 8),
                    Text('Mois terminé !',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900,
                            color: context.textColor)),
                    const SizedBox(height: 4),
                    Text('Bravo, tout est en ordre.',
                        style: TextStyle(fontSize: 15, color: context.mutedColor)),
                  ]),
                ),
              ),
            ),
          // Confettis
          for (final p in _particles)
            Builder(builder: (_) {
              final progress = ((t - p.delay) / p.speed).clamp(0.0, 1.0);
              if (progress <= 0) return const SizedBox.shrink();
              final screenH = MediaQuery.of(context).size.height;
              final screenW = MediaQuery.of(context).size.width;
              return Positioned(
                left: p.x * screenW + sin(p.wobble + t * 8) * 30,
                top: -30 + progress * (screenH + 60),
                child: Transform.rotate(
                  angle: p.rotation + t * 5,
                  child: Opacity(
                    opacity: progress < 0.1 ? progress * 10 : (progress > 0.8 ? (1 - progress) * 5 : 1.0),
                    child: Container(
                      width: p.size,
                      height: p.size * 0.5,
                      decoration: BoxDecoration(
                        color: p.color,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                ),
              );
            }),
        ]);
      },
    );
  }
}

class _Particle {
  final double x, delay, speed, size, rotation, wobble;
  final Color color;
  const _Particle({
    required this.x, required this.delay, required this.speed,
    required this.size, required this.color, required this.rotation,
    required this.wobble,
  });
}
