import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/business.dart';
import 'providers.dart';

/// Repères (clés) posés sur les éléments présentés pendant la démonstration.
class TourKeys {
  static final balance = GlobalKey(debugLabel: 'tour_balance');
  static final timeline = GlobalKey(debugLabel: 'tour_timeline');
  static final stats = GlobalKey(debugLabel: 'tour_stats');
  static final budgetsCard = GlobalKey(debugLabel: 'tour_budgets_card');
  static final addExpense = GlobalKey(debugLabel: 'tour_add_expense');
  static final closeMonth = GlobalKey(debugLabel: 'tour_close_month');
  static final addProject = GlobalKey(debugLabel: 'tour_add_project');
  static final forecastPicker = GlobalKey(debugLabel: 'tour_forecast_picker');
  static final fab = GlobalKey(debugLabel: 'tour_fab');
  static final settings = GlobalKey(debugLabel: 'tour_settings');
  static final navBar = GlobalKey(debugLabel: 'tour_nav_bar');
  static final firstCheck = GlobalKey(debugLabel: 'tour_first_check');
  static final tab = {for (final t in AppTab.values) t: GlobalKey(debugLabel: 'tour_tab_${t.name}')};
  static final addClient = GlobalKey(debugLabel: 'tour_add_client');
  static final invoiceSummary = GlobalKey(debugLabel: 'tour_invoice_summary');
}

/// Petit exemple animé montré dans la bulle (une ligne qui se coche).
enum TourDemo { expense, charge, income, envelopes, clients, invoices, project, forecast }

class TourStep {
  final String title;
  final String text;
  final AppTab? tab; // onglet à afficher pour cette étape
  final GlobalKey? target; // élément à mettre en lumière (null = message centré)
  final TourDemo? demo; // exemple animé sous le texte
  const TourStep(this.title, this.text, {this.tab, this.target, this.demo});
}

/// Étapes de la démonstration (les onglets Clients et Factures n'existent que pour un auto-entrepreneur).
List<TourStep> buildTourSteps(bool ae) {
  GlobalKey? navTab(AppTab t) => TourKeys.tab[t];
  return [
    const TourStep(
      'Bienvenue ! 👋',
      'Je te fais visiter l\'appli en 1 minute, onglet par onglet. Touche « Suivant » quand tu es prêt(e).',
      tab: AppTab.home,
    ),

    // ── Accueil ─────────────────────────────────────────────
    TourStep(
      'Accueil 🏠',
      'Ta page de départ : tout ton budget, d\'un seul coup d\'œil.',
      tab: AppTab.home,
      target: navTab(AppTab.home),
    ),
    TourStep(
      'Ton argent en un coup d\'œil',
      'À gauche : ce que tu as sur ton compte maintenant. À droite : ce qu\'il te restera à la fin du mois. Touche-les pour voir le calcul.',
      tab: AppTab.home,
      target: TourKeys.balance,
    ),
    TourStep(
      'Tes enveloppes 💌',
      'Une enveloppe, c\'est une somme à ne pas dépasser (courses, essence…). Vert : il en reste. Rouge : trop dépensé ! Voici un exemple :',
      tab: AppTab.home,
      target: TourKeys.budgetsCard,
      demo: TourDemo.envelopes,
    ),

    // ── Le bouton + ─────────────────────────────────────────
    TourStep(
      'Le bouton + ✨',
      'Le bouton magique : il ajoute tout ce que tu veux (dépense, revenu, charge, projet…). Et le bouton ✨ à côté, c\'est l\'assistant : écris « 23 € au McDo » et c\'est noté !',
      tab: AppTab.home,
      target: TourKeys.fab,
    ),
    TourStep(
      'Astuce n°1 : note tes dépenses',
      'Tu viens de payer quelque chose ? Touche +, puis « Une dépense ». Tape le montant, choisis l\'enveloppe : terminé !',
      tab: AppTab.home,
      target: TourKeys.fab,
    ),

    // ── Prévisions ──────────────────────────────────────────
    TourStep(
      'Prévisions 🔮',
      'Ici, tu vois le futur : combien il te restera, mois après mois.',
      tab: AppTab.forecast,
      target: navTab(AppTab.forecast),
    ),
    TourStep(
      'Choisis un mois',
      'Touche un mois, même dans 1 an, et vois ce qu\'il te restera. Idéal pour savoir si tu peux partir en voyage ! Exemple :',
      tab: AppTab.forecast,
      target: TourKeys.forecastPicker,
      demo: TourDemo.forecast,
    ),

    // ── Budgets ─────────────────────────────────────────────
    TourStep(
      'Budgets 🛒',
      'Toutes tes dépenses du mois, rangées par enveloppe. Un coup dur (panne, amende…) ? Mets-le dans « Imprévu ».',
      tab: AppTab.budgets,
      target: navTab(AppTab.budgets),
    ),
    TourStep(
      'Astuce n°2 : coche quand c\'est passé ✅',
      'Une dépense notée n\'est pas encore sortie de ton compte. Quand tu la vois sur ton relevé, touche le rond : il devient vert, et ton solde baisse. Regarde :',
      tab: AppTab.budgets,
      target: TourKeys.firstCheck,
      demo: TourDemo.expense,
    ),
    TourStep(
      'Astuce n°3 : ferme le mois 🔒',
      'À la fin du mois, touche « Fin du mois ». Hever te montre ce que tu as oublié de cocher, et le reporte au mois suivant.',
      tab: AppTab.budgets,
      target: TourKeys.closeMonth,
    ),

    // ── Mensuel ─────────────────────────────────────────────
    TourStep(
      'Mensuel 🔁',
      'Tout ce qui revient chaque mois : loyer, abonnements, assurances. Même geste : tu coches quand c\'est prélevé.',
      tab: AppTab.charges,
      target: navTab(AppTab.charges),
      demo: TourDemo.charge,
    ),
    TourStep(
      'Tes revenus 💶',
      'Toujours dans Mensuel : touche « Revenus » en haut. Coche chaque revenu quand l\'argent arrive. Pas coché = pas encore reçu.',
      tab: AppTab.incomes,
      target: navTab(AppTab.charges),
      demo: TourDemo.income,
    ),

    // ── Clients (auto-entrepreneur) ─────────────────────────
    if (ae) ...[
      TourStep(
        'Clients 👥',
        'Ajoute tes clients avec leur prix et leur rythme. Hever calcule ton salaire tout seul : tu n\'as rien à taper ! Exemple :',
        tab: AppTab.clients,
        target: navTab(AppTab.clients),
        demo: TourDemo.clients,
      ),
      if (kInvoicesEnabled)
        TourStep(
          'Factures 🧾',
          'Chaque mois, une facture par client. Marque-la « envoyée », puis « payée ». Une facture en retard est reportée au mois suivant. Exemple :',
          tab: AppTab.invoices,
          target: TourKeys.invoiceSummary,
          demo: TourDemo.invoices,
        ),
    ],

    // ── Projets ─────────────────────────────────────────────
    TourStep(
      'Projets 🎯',
      'Un voyage, une voiture, un apport… Dis combien et pour quand : Hever calcule la somme à mettre de côté chaque mois. Exemple :',
      tab: AppTab.trips,
      target: navTab(AppTab.trips),
      demo: TourDemo.project,
    ),

    TourStep(
      'Réglages ⚙️',
      'Ton profil, les rappels, le mode couple… Tu peux aussi revoir cette visite ici, quand tu veux.',
      tab: AppTab.home,
      target: TourKeys.settings,
    ),
    const TourStep(
      'C\'est parti ! 🎉',
      'Retiens 3 astuces : 1) note tes dépenses, 2) coche quand c\'est passé, 3) ferme le mois. Un doute ? Cherche le petit « i » : il explique tout !',
      tab: AppTab.home,
    ),
  ];
}

class TourState {
  final bool active;
  final int step;
  const TourState(this.active, this.step);
}

final tourStepsProvider = Provider<List<TourStep>>(
    (ref) => buildTourSteps(ref.watch(appProvider.select((d) => d.hasAE))));

final tourProvider =
    StateNotifierProvider<TourController, TourState>((ref) => TourController(ref));

class TourController extends StateNotifier<TourState> {
  final Ref _ref;
  TourController(this._ref) : super(const TourState(false, 0));

  void start() {
    FocusManager.instance.primaryFocus?.unfocus();
    state = const TourState(true, 0);
    _applyTab();
  }

  void next() {
    if (state.step >= _ref.read(tourStepsProvider).length - 1) {
      finish();
      return;
    }
    state = TourState(true, state.step + 1);
    _applyTab();
  }

  void back() {
    if (state.step == 0) return;
    state = TourState(true, state.step - 1);
    _applyTab();
  }

  void finish() {
    state = const TourState(false, 0);
    _ref.read(tabProvider.notifier).state = AppTab.home;
    _ref.read(appProvider.notifier).markTourSeen();
  }

  void _applyTab() {
    final steps = _ref.read(tourStepsProvider);
    if (state.step >= steps.length) return;
    final t = steps[state.step].tab;
    if (t != null) _ref.read(tabProvider.notifier).state = t;
  }
}
