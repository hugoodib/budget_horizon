import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/business.dart';
import 'providers.dart';

/// Repères (clés) posés sur les éléments présentés pendant la démonstration.
class TourKeys {
  static final balance = GlobalKey(debugLabel: 'tour_balance');
  static final timeline = GlobalKey(debugLabel: 'tour_timeline');
  static final stats = GlobalKey(debugLabel: 'tour_stats');
  static final budgetsCard = GlobalKey(debugLabel: 'tour_budgets_card');
  static final addExpense = GlobalKey(debugLabel: 'tour_add_expense');
  static final closeMonth = GlobalKey(debugLabel: 'tour_close_month');
  static final addProject = GlobalKey(debugLabel: 'tour_add_project');
  static final forecastPicker = GlobalKey(debugLabel: 'tour_forecast_picker');
  static final fab = GlobalKey(debugLabel: 'tour_fab');
  static final settings = GlobalKey(debugLabel: 'tour_settings');
  static final tab = {for (final t in AppTab.values) t: GlobalKey(debugLabel: 'tour_tab_${t.name}')};
  static final addClient = GlobalKey(debugLabel: 'tour_add_client');
  static final invoiceSummary = GlobalKey(debugLabel: 'tour_invoice_summary');
}

class TourStep {
  final String title;
  final String text;
  final AppTab? tab; // onglet à afficher pour cette étape
  final GlobalKey? target; // élément à mettre en lumière (null = message centré)
  const TourStep(this.title, this.text, {this.tab, this.target});
}

/// Étapes de la démonstration (les onglets Clients et Factures n'existent que pour un auto-entrepreneur).
List<TourStep> buildTourSteps(bool ae) => [
  const TourStep(
    'Bienvenue 👋',
    'Petit tour de l\'app. Touchez « Suivant » pour avancer, « Passer » pour quitter.',
    tab: AppTab.home,
  ),
  TourStep(
    'Votre solde',
    'Votre solde actuel, et juste dessous ce qu\'il vous restera à la fin du mois.',
    tab: AppTab.home,
    target: TourKeys.balance,
  ),
  TourStep(
    'Revenus et charges',
    'Ce qui rentre et ce qui sort chaque mois.',
    tab: AppTab.home,
    target: TourKeys.stats,
  ),
  TourStep(
    'Vos budgets',
    'Une somme à ne pas dépasser chaque mois (courses, essence…). Ce qui compte, c\'est le total.',
    tab: AppTab.home,
    target: TourKeys.budgetsCard,
  ),
  TourStep(
    'Le bouton +',
    'Touchez-le pour noter une dépense, depuis n\'importe quel onglet.',
    tab: AppTab.home,
    target: TourKeys.fab,
  ),
  TourStep(
    'Onglet Prévisions',
    'Votre solde à la fin de n\'importe quel mois, même dans des années.',
    tab: AppTab.forecast,
    target: TourKeys.tab[AppTab.forecast],
  ),
  TourStep(
    'Choisir un mois',
    'Choisissez un mois : le solde prévu s\'affiche en grand.',
    tab: AppTab.forecast,
    target: TourKeys.forecastPicker,
  ),
  TourStep(
    'Onglet Budgets',
    'Vos budgets du mois. Touchez-en un pour le modifier.',
    tab: AppTab.budgets,
    target: TourKeys.tab[AppTab.budgets],
  ),
  TourStep(
    'Clôturer le mois',
    'À la fin du mois, touchez ce bouton pour passer au mois suivant. Vous pouvez annuler.',
    tab: AppTab.budgets,
    target: TourKeys.closeMonth,
  ),
  TourStep(
    'Onglet Charges',
    'Vos dépenses fixes : loyer, abonnements… Touchez le rond pour cocher quand c\'est prélevé.',
    tab: AppTab.charges,
    target: TourKeys.tab[AppTab.charges],
  ),
  TourStep(
    'Onglet Revenus',
    'Vos revenus de chaque mois, et les revenus ponctuels (prime, vente…) du mois affiché.',
    tab: AppTab.incomes,
    target: TourKeys.tab[AppTab.incomes],
  ),
  if (ae) ...[
    TourStep(
      'Onglet Clients',
      'Ajoutez vos clients : votre salaire net est calculé pour vous.',
      tab: AppTab.clients,
      target: TourKeys.tab[AppTab.clients],
    ),
    if (kInvoicesEnabled)
      TourStep(
        'Factures',
        'Une facture par client et par mois (bouton « Factures » en haut de la page). Cochez « envoyée » et « payée ». Le brut moins l\'URSSAF donne votre salaire net.',
        tab: AppTab.invoices,
        target: TourKeys.invoiceSummary,
      ),
  ],
  TourStep(
    'Onglet Voyages',
    'Un voyage a son propre budget, à dépenser sur place.',
    tab: AppTab.trips,
    target: TourKeys.tab[AppTab.trips],
  ),
  TourStep(
    'Créer un voyage',
    'Touchez + : nom, budget et dates du voyage.',
    tab: AppTab.trips,
    target: TourKeys.addProject,
  ),
  TourStep(
    'Réglages',
    'Compte, couple, photo de profil, revenus… Vous pouvez aussi revoir cette visite ici.',
    tab: AppTab.home,
    target: TourKeys.settings,
  ),
  const TourStep(
    'C\'est parti ! 🚀',
    'Vous êtes prêt. Bon budget !',
    tab: AppTab.home,
  ),
];

class TourState {
  final bool active;
  final int step;
  const TourState(this.active, this.step);
}

final tourStepsProvider = Provider<List<TourStep>>(
    (ref) => buildTourSteps(ref.watch(appProvider.select((d) => d.hasAE))));

final tourProvider =
    StateNotifierProvider<TourController, TourState>((ref) => TourController(ref));

class TourController extends StateNotifier<TourState> {
  final Ref _ref;
  TourController(this._ref) : super(const TourState(false, 0));

  void start() {
    state = const TourState(true, 0);
    _applyTab();
  }

  void next() {
    if (state.step >= _ref.read(tourStepsProvider).length - 1) {
      finish();
      return;
    }
    state = TourState(true, state.step + 1);
    _applyTab();
  }

  void back() {
    if (state.step == 0) return;
    state = TourState(true, state.step - 1);
    _applyTab();
  }

  void finish() {
    state = const TourState(false, 0);
    _ref.read(tabProvider.notifier).state = AppTab.home;
    _ref.read(appProvider.notifier).markTourSeen();
  }

  void _applyTab() {
    final steps = _ref.read(tourStepsProvider);
    if (state.step >= steps.length) return;
    final t = steps[state.step].tab;
    if (t != null) _ref.read(tabProvider.notifier).state = t;
  }
}
