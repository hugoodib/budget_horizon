import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/business.dart';
import 'providers.dart';

/// Repères (clés) posés sur les éléments présentés pendant la démonstration.
class TourKeys {
  static final balance = GlobalKey(debugLabel: 'tour_balance');
  static final timeline = GlobalKey(debugLabel: 'tour_timeline');
  static final stats = GlobalKey(debugLabel: 'tour_stats');
  static final budgetsCard = GlobalKey(debugLabel: 'tour_budgets_card');
  static final addExpense = GlobalKey(debugLabel: 'tour_add_expense');
  static final closeMonth = GlobalKey(debugLabel: 'tour_close_month');
  static final addProject = GlobalKey(debugLabel: 'tour_add_project');
  static final forecastPicker = GlobalKey(debugLabel: 'tour_forecast_picker');
  static final fab = GlobalKey(debugLabel: 'tour_fab');
  static final settings = GlobalKey(debugLabel: 'tour_settings');
  static final tab = {for (final t in AppTab.values) t: GlobalKey(debugLabel: 'tour_tab_${t.name}')};
  static final addClient = GlobalKey(debugLabel: 'tour_add_client');
  static final invoiceSummary = GlobalKey(debugLabel: 'tour_invoice_summary');
}

class TourStep {
  final String title;
  final String text;
  final AppTab? tab; // onglet à afficher pour cette étape
  final GlobalKey? target; // élément à mettre en lumière (null = message centré)
  const TourStep(this.title, this.text, {this.tab, this.target});
}

/// Étapes de la démonstration (les onglets Clients et Factures n'existent que pour un auto-entrepreneur).
List<TourStep> buildTourSteps(bool ae) => [
  const TourStep(
    'Visite express',
    'Voici où tout se trouve, en 30 secondes. Touche « Suivant » pour avancer, ou « Passer » si tu préfères explorer seul(e).',
    tab: AppTab.home,
  ),

  TourStep(
    'Ton solde, en un coup d\'œil',
    'Voilà ce qu\'il y a sur ton compte, et ce qu\'il te restera à la fin du mois. Touche-les pour voir le détail du calcul.',
    tab: AppTab.home,
    target: TourKeys.balance,
  ),

  TourStep(
    'Geste n°1 : note chaque dépense',
    'Dès que tu paies quelque chose, touche +. C\'est l\'habitude qui fait tout marcher : sans elle, les budgets et les prévisions ne servent à rien.',
    tab: AppTab.home,
    target: TourKeys.fab,
  ),
  TourStep(
    'Choisis la bonne enveloppe',
    'Chaque dépense va dans une enveloppe : Courses, Essence, Restaurants… Un coup dur (panne, amende) ? Mets-le dans Imprévu.',
    tab: AppTab.budgets,
    target: TourKeys.addExpense,
  ),

  TourStep(
    'Geste n°2 : coche quand c\'est passé',
    'Une dépense notée n\'est pas encore sortie de ton compte. Coche-la quand tu la vois sur ton relevé : ton solde actuel baisse. Pareil pour les charges et les revenus.',
    tab: AppTab.budgets,
    target: TourKeys.budgetsCard,
  ),

  TourStep(
    'Tes enveloppes du mois',
    'Le vert, c\'est ce qu\'il te reste à dépenser. Le rouge, c\'est dépassé. Si une enveloppe déborde, ta prévision de fin de mois baisse tout de suite.',
    tab: AppTab.home,
    target: TourKeys.budgetsCard,
  ),

  TourStep(
    'Tes charges fixes',
    'Loyer, assurances, abonnements… Tout ce qui revient est ici. Coche chaque ligne quand elle est prélevée.',
    tab: AppTab.charges,
    target: TourKeys.tab[AppTab.charges],
  ),
  TourStep(
    'Tes revenus',
    'Salaire, primes… Coche chaque revenu quand il arrive sur ton compte. Pas coché = argent attendu, pas encore reçu.',
    tab: AppTab.incomes,
    target: TourKeys.tab[AppTab.incomes],
  ),

  TourStep(
    'Geste n°3 : clôture le mois',
    'À la fin du mois, touche « Fin du mois ». Hever te montre ce qui n\'est pas pointé et te propose de le reporter au mois suivant.',
    tab: AppTab.budgets,
    target: TourKeys.closeMonth,
  ),

  TourStep(
    'Regarde loin devant',
    'Choisis n\'importe quel mois futur : tu vois combien il te restera. Pratique pour planifier un voyage ou un achat.',
    tab: AppTab.forecast,
    target: TourKeys.forecastPicker,
  ),

  if (ae) ...[
    TourStep(
      'Tes clients',
      'Ajoute tes clients avec leur tarif et leur rythme. Hever calcule ton salaire net, charges URSSAF déduites, mois par mois.',
      tab: AppTab.clients,
      target: TourKeys.tab[AppTab.clients],
    ),
    if (kInvoicesEnabled)
      TourStep(
        'Tes factures',
        'Chaque mois, une facture par client. Marque-la « envoyée » puis « payée ». Les impayés sont reportés au mois suivant.',
        tab: AppTab.invoices,
        target: TourKeys.invoiceSummary,
      ),
  ],

  TourStep(
    'Voyages & projets',
    'Dans l\'onglet Projets, ajoute un voyage, une voiture ou un apport : indique le montant et la date, et Hever calcule l\'épargne par mois et la retire de ta prévision.',
    tab: AppTab.trips,
    target: TourKeys.tab[AppTab.trips],
  ),

  TourStep(
    'Les paramètres',
    'Photo, mode couple, solde de départ… Tu peux aussi revoir cette visite quand tu veux depuis ici.',
    tab: AppTab.home,
    target: TourKeys.settings,
  ),
  const TourStep(
    'C\'est à toi !',
    'Retiens 3 gestes : note chaque dépense, coche quand c\'est passé, clôture à la fin du mois. Bon budget !',
    tab: AppTab.home,
  ),
];

class TourState {
  final bool active;
  final int step;
  const TourState(this.active, this.step);
}

final tourStepsProvider = Provider<List<TourStep>>(
    (ref) => buildTourSteps(ref.watch(appProvider.select((d) => d.hasAE))));

final tourProvider =
    StateNotifierProvider<TourController, TourState>((ref) => TourController(ref));

class TourController extends StateNotifier<TourState> {
  final Ref _ref;
  TourController(this._ref) : super(const TourState(false, 0));

  void start() {
    FocusManager.instance.primaryFocus?.unfocus();
    state = const TourState(true, 0);
    _applyTab();
  }

  void next() {
    if (state.step >= _ref.read(tourStepsProvider).length - 1) {
      finish();
      return;
    }
    state = TourState(true, state.step + 1);
    _applyTab();
  }

  void back() {
    if (state.step == 0) return;
    state = TourState(true, state.step - 1);
    _applyTab();
  }

  void finish() {
    state = const TourState(false, 0);
    _ref.read(tabProvider.notifier).state = AppTab.home;
    _ref.read(appProvider.notifier).markTourSeen();
  }

  void _applyTab() {
    final steps = _ref.read(tourStepsProvider);
    if (state.step >= steps.length) return;
    final t = steps[state.step].tab;
    if (t != null) _ref.read(tabProvider.notifier).state = t;
  }
}
