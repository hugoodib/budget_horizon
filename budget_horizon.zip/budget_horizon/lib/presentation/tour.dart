import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/business.dart';
import 'providers.dart';

/// Repères (clés) posés sur les éléments présentés pendant la démonstration.
class TourKeys {
  static final balance = GlobalKey(debugLabel: 'tour_balance');
  static final timeline = GlobalKey(debugLabel: 'tour_timeline');
  static final stats = GlobalKey(debugLabel: 'tour_stats');
  static final budgetsCard = GlobalKey(debugLabel: 'tour_budgets_card');
  static final addExpense = GlobalKey(debugLabel: 'tour_add_expense');
  static final closeMonth = GlobalKey(debugLabel: 'tour_close_month');
  static final addProject = GlobalKey(debugLabel: 'tour_add_project');
  static final forecastPicker = GlobalKey(debugLabel: 'tour_forecast_picker');
  static final fab = GlobalKey(debugLabel: 'tour_fab');
  static final settings = GlobalKey(debugLabel: 'tour_settings');
  static final navBar = GlobalKey(debugLabel: 'tour_nav_bar');
  static final firstCheck = GlobalKey(debugLabel: 'tour_first_check');
  static final tab = {for (final t in AppTab.values) t: GlobalKey(debugLabel: 'tour_tab_${t.name}')};
  static final addClient = GlobalKey(debugLabel: 'tour_add_client');
  static final invoiceSummary = GlobalKey(debugLabel: 'tour_invoice_summary');
}

/// Petit exemple animé montré dans la bulle (une ligne qui se coche).
enum TourDemo { expense, charge, income }

class TourStep {
  final String title;
  final String text;
  final AppTab? tab; // onglet à afficher pour cette étape
  final GlobalKey? target; // élément à mettre en lumière (null = message centré)
  final TourDemo? demo; // exemple animé sous le texte
  const TourStep(this.title, this.text, {this.tab, this.target, this.demo});
}

/// Étapes de la démonstration (les onglets Clients et Factures n'existent que pour un auto-entrepreneur).
List<TourStep> buildTourSteps(bool ae) {
  GlobalKey? navTab(AppTab t) => TourKeys.tab[t];
  return [
    const TourStep(
      'Visite express',
      'On va parcourir l\'appli onglet par onglet, puis le bouton +. Touche « Suivant » pour avancer, ou « Passer » si tu préfères explorer seul(e).',
      tab: AppTab.home,
    ),

    // ── Accueil ─────────────────────────────────────────────
    TourStep(
      'Onglet Accueil',
      'C\'est ta page de départ : ton solde, tes enveloppes du mois et les alertes importantes.',
      tab: AppTab.home,
      target: navTab(AppTab.home),
    ),
    TourStep(
      'Ton solde, en un coup d\'œil',
      'Voilà ce qu\'il y a sur ton compte, et ce qu\'il te restera à la fin du mois. Touche-les pour voir le détail du calcul.',
      tab: AppTab.home,
      target: TourKeys.balance,
    ),
    TourStep(
      'Tes enveloppes du mois',
      'Le vert, c\'est ce qu\'il te reste à dépenser. Le rouge, c\'est dépassé. Si une enveloppe déborde, ta prévision de fin de mois baisse tout de suite.',
      tab: AppTab.home,
      target: TourKeys.budgetsCard,
    ),

    // ── Le bouton + ─────────────────────────────────────────
    TourStep(
      'Le bouton + : ajouter quelque chose',
      'C\'est le bouton que tu utiliseras le plus, partout dans l\'appli. Il propose : une dépense, un revenu, une charge fixe, un paiement en plusieurs fois, un projet, une catégorie de budget (et une facture si tu es auto-entrepreneur). À côté, le bouton ✨ est l\'assistant : écris ou dicte « 23 € au McDo » et c\'est noté.',
      tab: AppTab.home,
      target: TourKeys.fab,
    ),
    TourStep(
      'Geste n°1 : note chaque dépense',
      'Dès que tu paies quelque chose, touche + puis « Une dépense ». Tape le montant, choisis l\'enveloppe : c\'est fait. C\'est cette habitude qui fait marcher les budgets et les prévisions.',
      tab: AppTab.home,
      target: TourKeys.fab,
    ),

    // ── Prévisions ──────────────────────────────────────────
    TourStep(
      'Onglet Prévisions',
      'Ici tu regardes l\'avenir : mois après mois, combien il te restera.',
      tab: AppTab.forecast,
      target: navTab(AppTab.forecast),
    ),
    TourStep(
      'Prévisions : regarde loin devant',
      'Choisis n\'importe quel mois futur : tu vois combien il te restera. Pratique pour planifier un voyage ou un achat.',
      tab: AppTab.forecast,
      target: TourKeys.forecastPicker,
    ),

    // ── Budgets ─────────────────────────────────────────────
    TourStep(
      'Onglet Budgets',
      'Toutes tes dépenses du mois, rangées par enveloppe : Courses, Essence, Restaurants… Un coup dur (panne, amende) ? Mets-le dans Imprévu.',
      tab: AppTab.budgets,
      target: navTab(AppTab.budgets),
    ),
    TourStep(
      'Geste n°2 : coche quand c\'est passé',
      'Une dépense notée n\'est pas encore sortie de ton compte. Quand tu la vois sur ton relevé, touche le rond à droite de la ligne : il devient vert et ton solde actuel baisse. Regarde l\'exemple :',
      tab: AppTab.budgets,
      target: TourKeys.firstCheck,
      demo: TourDemo.expense,
    ),
    TourStep(
      'Geste n°3 : clôture le mois',
      'À la fin du mois, touche « Fin du mois » en bas de cet onglet. Hever te montre ce qui n\'est pas pointé et te propose de le reporter au mois suivant.',
      tab: AppTab.budgets,
      target: TourKeys.closeMonth,
    ),

    // ── Mensuel ─────────────────────────────────────────────
    TourStep(
      'Onglet Mensuel : tes charges fixes',
      'Loyer, assurances, abonnements… Tout ce qui revient chaque mois est ici. Même geste : coche chaque ligne quand elle est prélevée.',
      tab: AppTab.charges,
      target: navTab(AppTab.charges),
      demo: TourDemo.charge,
    ),
    TourStep(
      'Mensuel : tes revenus',
      'Toujours dans Mensuel, touche « Revenus » en haut de la page. Salaire, primes… Coche chaque revenu quand il arrive sur ton compte. Pas coché = argent attendu, pas encore reçu.',
      tab: AppTab.incomes,
      target: navTab(AppTab.charges),
      demo: TourDemo.income,
    ),

    // ── Clients (auto-entrepreneur) ─────────────────────────
    if (ae) ...[
      TourStep(
        'Onglet Clients',
        'Ajoute tes clients avec leur tarif et leur rythme. Hever calcule ton salaire net, charges URSSAF déduites, mois par mois.',
        tab: AppTab.clients,
        target: navTab(AppTab.clients),
      ),
      if (kInvoicesEnabled)
        TourStep(
          'Clients : tes factures',
          'Chaque mois, une facture par client. Marque-la « envoyée » puis « payée ». Les impayés sont reportés au mois suivant.',
          tab: AppTab.invoices,
          target: TourKeys.invoiceSummary,
        ),
    ],

    // ── Projets ─────────────────────────────────────────────
    TourStep(
      'Onglet Projets',
      'Ajoute un voyage, une voiture ou un apport : indique le montant et la date, et Hever calcule l\'épargne par mois et la retire de ta prévision.',
      tab: AppTab.trips,
      target: navTab(AppTab.trips),
    ),

    TourStep(
      'Les paramètres',
      'Photo, mode couple, solde de départ, rappels… Tu peux aussi revoir cette visite quand tu veux depuis ici.',
      tab: AppTab.home,
      target: TourKeys.settings,
    ),
    const TourStep(
      'C\'est à toi !',
      'Retiens 3 gestes : note chaque dépense, coche quand c\'est passé, clôture à la fin du mois. Bon budget !',
      tab: AppTab.home,
    ),
  ];
}

class TourState {
  final bool active;
  final int step;
  const TourState(this.active, this.step);
}

final tourStepsProvider = Provider<List<TourStep>>(
    (ref) => buildTourSteps(ref.watch(appProvider.select((d) => d.hasAE))));

final tourProvider =
    StateNotifierProvider<TourController, TourState>((ref) => TourController(ref));

class TourController extends StateNotifier<TourState> {
  final Ref _ref;
  TourController(this._ref) : super(const TourState(false, 0));

  void start() {
    FocusManager.instance.primaryFocus?.unfocus();
    state = const TourState(true, 0);
    _applyTab();
  }

  void next() {
    if (state.step >= _ref.read(tourStepsProvider).length - 1) {
      finish();
      return;
    }
    state = TourState(true, state.step + 1);
    _applyTab();
  }

  void back() {
    if (state.step == 0) return;
    state = TourState(true, state.step - 1);
    _applyTab();
  }

  void finish() {
    state = const TourState(false, 0);
    _ref.read(tabProvider.notifier).state = AppTab.home;
    _ref.read(appProvider.notifier).markTourSeen();
  }

  void _applyTab() {
    final steps = _ref.read(tourStepsProvider);
    if (state.step >= steps.length) return;
    final t = steps[state.step].tab;
    if (t != null) _ref.read(tabProvider.notifier).state = t;
  }
}
