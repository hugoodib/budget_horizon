import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/business.dart';
import 'providers.dart';

/// Repères (clés) posés sur les éléments présentés pendant la démonstration.
class TourKeys {
  static final balance = GlobalKey(debugLabel: 'tour_balance');
  static final timeline = GlobalKey(debugLabel: 'tour_timeline');
  static final stats = GlobalKey(debugLabel: 'tour_stats');
  static final budgetsCard = GlobalKey(debugLabel: 'tour_budgets_card');
  static final addExpense = GlobalKey(debugLabel: 'tour_add_expense');
  static final closeMonth = GlobalKey(debugLabel: 'tour_close_month');
  static final addProject = GlobalKey(debugLabel: 'tour_add_project');
  static final forecastPicker = GlobalKey(debugLabel: 'tour_forecast_picker');
  static final fab = GlobalKey(debugLabel: 'tour_fab');
  static final settings = GlobalKey(debugLabel: 'tour_settings');
  static final tab = {for (final t in AppTab.values) t: GlobalKey(debugLabel: 'tour_tab_${t.name}')};
  static final addClient = GlobalKey(debugLabel: 'tour_add_client');
  static final invoiceSummary = GlobalKey(debugLabel: 'tour_invoice_summary');
}

class TourStep {
  final String title;
  final String text;
  final AppTab? tab; // onglet à afficher pour cette étape
  final GlobalKey? target; // élément à mettre en lumière (null = message centré)
  const TourStep(this.title, this.text, {this.tab, this.target});
}

/// Étapes de la démonstration (les onglets Clients et Factures n'existent que pour un auto-entrepreneur).
List<TourStep> buildTourSteps(bool ae) => [
  const TourStep(
    'Bienvenue 👋',
    'Voici comment Hever fonctionne. Touchez « Suivant » pour avancer.',
    tab: AppTab.home,
  ),

  // ── Solde & prévision ──────────────────────────────────────────────
  TourStep(
    'Votre solde en temps réel',
    'C\'est le solde de votre compte. Modifiez-le dès que vous consultez votre banque pour que les prévisions restent justes.',
    tab: AppTab.home,
    target: TourKeys.balance,
  ),

  // ── Ajouter une dépense ───────────────────────────────────────────
  TourStep(
    'Notez CHAQUE dépense 💳',
    'Touchez + dès que vous dépensez quelque chose. C\'est l\'habitude la plus importante : sans ça, les budgets et les prévisions ne servent à rien.',
    tab: AppTab.home,
    target: TourKeys.fab,
  ),
  TourStep(
    'Choisissez le bon budget',
    'Chaque dépense va dans une enveloppe : Courses, Essence, Restaurant… Si c\'est un imprévu (panne, amende), mettez-le dans ⚡ Imprévu.',
    tab: AppTab.budgets,
    target: TourKeys.addExpense,
  ),

  // ── Pointer ───────────────────────────────────────────────────────
  TourStep(
    'Pointez comme votre banque ✓',
    'Une dépense notée n\'est pas encore pointée. Cochez-la quand vous la voyez apparaître sur votre relevé. Idem pour les charges et les revenus.',
    tab: AppTab.budgets,
    target: TourKeys.budgetsCard,
  ),

  // ── Budgets ───────────────────────────────────────────────────────
  TourStep(
    'Vos budgets du mois',
    'Ce qui reste en vert, c\'est ce que vous pouvez encore dépenser. En rouge = dépassé. Le total seul compte : si vous économisez sur les courses, vous pouvez dépenser plus au resto.',
    tab: AppTab.home,
    target: TourKeys.budgetsCard,
  ),

  // ── Charges & revenus ─────────────────────────────────────────────
  TourStep(
    'Charges et revenus fixes 📋',
    'Loyer, assurance, salaire… Tout ce qui revient chaque mois est ici. Cochez chaque ligne quand elle est prélevée ou reçue — ça confirme que tout s\'est bien passé.',
    tab: AppTab.charges,
    target: TourKeys.tab[AppTab.charges],
  ),
  TourStep(
    'Revenus du mois',
    'Votre salaire, une prime, une vente… Cochez chaque revenu quand il arrive sur votre compte. Un revenu non coché = argent attendu mais pas encore reçu.',
    tab: AppTab.incomes,
    target: TourKeys.tab[AppTab.charges],
  ),

  // ── Clôturer ──────────────────────────────────────────────────────
  TourStep(
    '⚠️  La clôture, c\'est essentiel',
    'C\'est LE geste clé. À la fin de chaque mois, clôturez pour passer au suivant. L\'app vérifie alors tout ce qui n\'est pas pointé et vous demande si vous voulez le reporter.',
    tab: AppTab.budgets,
    target: TourKeys.closeMonth,
  ),
  TourStep(
    'Sans clôture, rien ne marche',
    'Si vous ne clôturez pas, votre solde prévu part à la dérive. Faites-le le dernier jour du mois, une fois tout pointé. L\'app vous rappellera le dernier jour.',
    tab: AppTab.home,
  ),

  // ── Prévisions ────────────────────────────────────────────────────
  TourStep(
    'Prévisions sur des années 📈',
    'Choisissez n\'importe quel mois futur : vous voyez exactement combien vous aurez. Utile pour planifier un voyage, un achat ou une retraite.',
    tab: AppTab.forecast,
    target: TourKeys.forecastPicker,
  ),

  // ── Auto-entrepreneur ─────────────────────────────────────────────
  if (ae) ...[
    TourStep(
      'Onglet Clients (auto-entrepreneur)',
      'Ajoutez vos clients avec leur tarif et fréquence. L\'app calcule votre salaire net (après charges URSSAF) pour chaque mois.',
      tab: AppTab.clients,
      target: TourKeys.tab[AppTab.clients],
    ),
    if (kInvoicesEnabled)
      TourStep(
        'Factures',
        'Chaque mois, une facture est générée par client. Cochez « envoyée » puis « payée ». Les impayés sont automatiquement reportés au mois suivant à la clôture.',
        tab: AppTab.invoices,
        target: TourKeys.invoiceSummary,
      ),
  ],

  // ── Projets ───────────────────────────────────────────────────────
  TourStep(
    'Projets & voyages ✈️',
    'Un voyage, une voiture, un apport… Indiquez le montant et la date. L\'app calcule l\'épargne mensuelle nécessaire et la déduit de vos prévisions automatiquement.',
    tab: AppTab.trips,
    target: TourKeys.addProject,
  ),

  // ── Paramètres & fin ─────────────────────────────────────────────
  TourStep(
    'Paramètres',
    'Photo de profil, mode couple, solde de départ, auto-entrepreneur… Vous pouvez aussi revoir cette visite à tout moment ici.',
    tab: AppTab.home,
    target: TourKeys.settings,
  ),
  const TourStep(
    'C\'est parti ! 🚀',
    'Résumé : notez chaque dépense → cochez quand payé → clôturez à la fin du mois. Ces 3 gestes font tout fonctionner. Bon budget !',
    tab: AppTab.home,
  ),
];

class TourState {
  final bool active;
  final int step;
  const TourState(this.active, this.step);
}

final tourStepsProvider = Provider<List<TourStep>>(
    (ref) => buildTourSteps(ref.watch(appProvider.select((d) => d.hasAE))));

final tourProvider =
    StateNotifierProvider<TourController, TourState>((ref) => TourController(ref));

class TourController extends StateNotifier<TourState> {
  final Ref _ref;
  TourController(this._ref) : super(const TourState(false, 0));

  void start() {
    state = const TourState(true, 0);
    _applyTab();
  }

  void next() {
    if (state.step >= _ref.read(tourStepsProvider).length - 1) {
      finish();
      return;
    }
    state = TourState(true, state.step + 1);
    _applyTab();
  }

  void back() {
    if (state.step == 0) return;
    state = TourState(true, state.step - 1);
    _applyTab();
  }

  void finish() {
    state = const TourState(false, 0);
    _ref.read(tabProvider.notifier).state = AppTab.home;
    _ref.read(appProvider.notifier).markTourSeen();
  }

  void _applyTab() {
    final steps = _ref.read(tourStepsProvider);
    if (state.step >= steps.length) return;
    final t = steps[state.step].tab;
    if (t != null) _ref.read(tabProvider.notifier).state = t;
  }
}
