import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../core/ym.dart';
import '../data/seed.dart';
import '../domain/business.dart';
import '../domain/forecast.dart';
import '../domain/installments.dart';
import '../domain/models.dart';
import '../domain/repository.dart';
import 'auth_controller.dart';

final repositoryProvider =
    Provider<AppRepository>((ref) => throw UnimplementedError('Override in main()'));

// ── Mode développeur ──────────────────────────────────────────────────────────
// Activé/désactivé via un code dans les paramètres. Persisté en meta Hive.
// Quand actif : date de débit sur les dépenses + date de réception sur les salaires.

class DevModeNotifier extends StateNotifier<bool> {
  final AppRepository _repo;
  DevModeNotifier(this._repo) : super(_repo.readMeta('dev_mode') == '1');

  void toggle() {
    state = !state;
    _repo.writeMeta('dev_mode', state ? '1' : null);
  }

  void set(bool value) {
    state = value;
    _repo.writeMeta('dev_mode', value ? '1' : null);
  }
}

/// Qui suis-je sur cet appareil ? (1 ou 2, en mode couple). Sert de choix par défaut
/// pour « à qui est cette dépense ». Propre à chaque appareil / compte.
class MyPersonNotifier extends StateNotifier<int> {
  final AppRepository _repo;
  MyPersonNotifier(this._repo) : super(_repo.readMeta('my_person') == '2' ? 2 : 1);

  void set(int p) {
    state = p == 2 ? 2 : 1;
    _repo.writeMeta('my_person', state == 2 ? '2' : null);
  }
}

final myPersonProvider = StateNotifierProvider<MyPersonNotifier, int>((ref) {
  return MyPersonNotifier(ref.read(repositoryProvider));
});

final devModeProvider = StateNotifierProvider<DevModeNotifier, bool>((ref) {
  return DevModeNotifier(ref.read(repositoryProvider));
});

/// Mois réel (date du téléphone).
final realNowProvider = Provider<Ym>((ref) => Ym.now());

final appProvider = StateNotifierProvider<AppNotifier, AppData>((ref) => AppNotifier(
      ref.read(repositoryProvider),
      ref.read(realNowProvider),
      // Chaque modification déclenche (si connecté) une synchronisation différée.
      onChanged: () => ref.read(authProvider.notifier).markChanged(),
    ));

/// Mois courant de l'app : le mois réel, décalé au mois suivant
/// tant que le mois est clôturé (« Fin du mois ✓ » fait basculer).
final nowProvider = Provider<Ym>((ref) {
  final d = ref.watch(appProvider);
  var y = ref.watch(realNowProvider);
  while (d.isClosed(y)) {
    y = y.add(1);
  }
  return y;
});

/// Prévisions du premier mois suivi jusqu'à 24 mois dans le futur.
final forecastProvider = Provider<List<MonthForecast>>((ref) {
  final d = ref.watch(appProvider);
  final now = ref.watch(nowProvider);
  final devMode = ref.watch(devModeProvider);
  final to = Ym.fromIndex(max(now.index, d.startYm.index) + 24);
  return Forecaster.compute(d, now: now, to: to, devMode: devMode);
});

/// Onglets de l'app. « clients » et « invoices » n'apparaissent que pour un auto-entrepreneur.
enum AppTab { home, forecast, budgets, charges, incomes, clients, invoices, trips, analysis, leaves }

final tabProvider = StateProvider<AppTab>((ref) => AppTab.home);

/// Mois affiché dans l'onglet Factures.
/// Incrémenté quand on touche l'onglet déjà affiché : la page remonte en haut.
final scrollTopTickProvider = StateProvider<int>((ref) => 0);

final invoiceMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));

/// Mois affiché dans l'onglet Revenus.
final incomeMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));

final budgetMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));
final leaveMonthProvider  = StateProvider<Ym>((ref) => ref.read(nowProvider));
final chargeMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));

String _id() => DateTime.now().microsecondsSinceEpoch.toString();

class AppNotifier extends StateNotifier<AppData> {
  final AppRepository repo;
  final Ym realNow;
  final void Function()? onChanged;
  final List<AppData> _history = [];
  final List<AppData> _future = [];
  static const _maxHistory = 30;

  AppNotifier(this.repo, this.realNow, {this.onChanged})
      : super(SeedData.upgradeStyles(repo.load() ?? SeedData.create(realNow))) {
    state = _cleanOverrides(state);
    repo.save(state);
  }

  /// Montants « d'un seul mois » devenus incohérents (anciennes versions) : ils masquaient le
  /// budget habituel et faisaient diverger les prévisions.
  ///  - Toujours : on retire ceux qui sont identiques au budget habituel (inutiles).
  ///  - Une seule fois par appareil : on retire aussi ceux du mois en cours et des mois à venir,
  ///    pour que tous les budgets repartent sur leur montant habituel. Les montants modifiés
  ///    ensuite volontairement sont conservés.
  late final bool _freshClean = repo.readMeta('budget_overrides_v2') != '1';

  AppData _cleanOverrides(AppData d) {
    final first = _freshClean;
    var changed = false;
    final budgets = d.budgets.map((b) {
      if (b.overrides.isEmpty) return b;
      final o = Map<String, double>.from(b.overrides)
        ..removeWhere((k, v) =>
            (v - b.amount).abs() < 0.005 || (first && !Ym.parse(k).isBefore(realNow)));
      if (o.length == b.overrides.length) return b;
      changed = true;
      return b.copyWith(overrides: o);
    }).toList();
    if (first) repo.writeMeta('budget_overrides_v2', '1'); // la session en cours garde `_freshClean`
    return changed ? d.copyWith(budgets: budgets) : d;
  }

  /// Mois courant (après clôture, le mois suivant).
  Ym get now {
    var y = realNow;
    while (state.isClosed(y)) {
      y = y.add(1);
    }
    return y;
  }

  bool get canUndo => _history.isNotEmpty;
  bool get canRedo => _future.isNotEmpty;

  /// Revient à l'état juste avant la dernière modification.
  void undo() {
    if (_history.isEmpty) return;
    _future.add(state);
    state = _history.removeLast();
    repo.save(state);
    onChanged?.call();
  }

  /// Rétablit la modification annulée.
  void redo() {
    if (_future.isEmpty) return;
    _history.add(state);
    state = _future.removeLast();
    repo.save(state);
    onChanged?.call();
  }

  void _set(AppData d) {
    _history.add(state);
    if (_history.length > _maxHistory) _history.removeAt(0);
    _future.clear();
    state = d;
    repo.save(d);
    onChanged?.call();
  }

  /// Enregistre une modification dans le journal (30 jours glissants).
  void _log(AppData d, String description) {
    final cutoff = DateTime.now().subtract(const Duration(days: 30));
    final entry = HistoryEntry(
      id: '${DateTime.now().millisecondsSinceEpoch}',
      date: DateTime.now(),
      description: description,
    );
    final newLog = [
      ...d.historyLog.where((e) => e.date.isAfter(cutoff)),
      entry,
    ];
    _set(d.copyWith(historyLog: newLog));
  }

  /// Remplace toutes les données (ex. données du compte reçues du cloud).
  /// Ne déclenche pas de nouvelle synchronisation, et ne s'ajoute pas à l'historique.
  void replace(AppData d) {
    state = _cleanOverrides(SeedData.upgradeStyles(d));
    repo.save(state);
  }

  // ---- Dépenses ----
  void addTransaction(String categoryId, String description, double amount, DateTime date,
      {int person = 0, String? tripId, DateTime? debitDate, bool checked = false, String note = ''}) {
    final label = description.isEmpty ? 'Dépense' : description;
    final d = state.copyWith(transactions: [
      ...state.transactions,
      Transaction(
          id: _id(),
          categoryId: categoryId,
          description: label,
          amount: amount,
          date: date,
          person: person,
          tripId: tripId,
          debitDate: debitDate,
          checked: checked,
          note: note),
    ]);
    _log(d, 'Dépense ajoutée : $label · ${amount.toStringAsFixed(2)} €');
  }

  /// Pointer / dépointer une dépense (comme dans une application bancaire).
  void toggleTransactionChecked(String id) => _set(state.copyWith(
      transactions: state.transactions
          .map((t) => t.id == id ? t.copyWith(checked: !t.checked) : t)
          .toList()));

  /// Pointer / dépointer un revenu ponctuel (versement bien reçu).
  void toggleIncomeChecked(String id) => _set(state.copyWith(
      incomes:
          state.incomes.map((i) => i.id == id ? i.copyWith(checked: !i.checked) : i).toList()));

  /// Pointer / dépointer un revenu récurrent pour un mois donné.
  void toggleRecurringChecked(String id, Ym ym) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          final list = [...r.checkedMonths];
          if (!list.remove(ym.key)) list.add(ym.key);
          return r.copyWith(checkedMonths: list);
        }).toList(),
      ));

  /// Pointer / dépointer un revenu récurrent reporté (mois précédent non pointé).
  /// La ligne reste affichée (cochée) dans le mois de report : on ne touche pas à carriedMonths.
  void markCarriedRecurringChecked(String id, Ym carriedYm) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          final checked = [...r.checkedMonths];
          if (!checked.remove(carriedYm.key)) checked.add(carriedYm.key);
          return r.copyWith(checkedMonths: checked);
        }).toList(),
      ));

  /// Remplace une dépense existante (même id, pointage et report conservés).
  void updateTransaction(String id, String categoryId, String description, double amount, DateTime date,
      {int person = 0, String? tripId, DateTime? debitDate, bool? checked, String? note}) {
    final label = description.isEmpty ? 'Dépense' : description;
    final d = state.copyWith(
        transactions: state.transactions
            .map((t) => t.id != id
                ? t
                : Transaction(
                    id: t.id,
                    categoryId: categoryId,
                    description: label,
                    amount: amount,
                    date: date,
                    person: person,
                    tripId: tripId,
                    checked: checked ?? t.checked,
                    movedFrom: t.movedFrom,
                    debitDate: debitDate,
                    note: note ?? t.note))
            .toList());
    _log(d, 'Dépense modifiée : $label · ${amount.toStringAsFixed(2)} €');
  }

  void deleteTransaction(String id) {
    final t = state.transactions.firstWhere((t) => t.id == id, orElse: () => state.transactions.first);
    final d = state.copyWith(transactions: state.transactions.where((x) => x.id != id).toList());
    _log(d, 'Dépense supprimée : ${t.description.isEmpty ? 'Dépense' : t.description} · ${t.amount.toStringAsFixed(2)} €');
  }

  // ---- Budgets & catégories ----
  /// Change le budget habituel (tous les mois).
  void setBudgetAmount(String budgetId, double amount) => _set(state.copyWith(
      budgets: state.budgets.map((b) => b.id == budgetId ? b.copyWith(amount: amount) : b).toList()));

  /// Change le budget d'un seul mois (null = retour au budget habituel).
  void setBudgetOverride(String budgetId, Ym ym, double? amount) => _set(state.copyWith(
        budgets: state.budgets.map((b) {
          if (b.id != budgetId) return b;
          final o = Map<String, double>.from(b.overrides);
          if (amount == null || (amount - b.amount).abs() < 0.005) {
            o.remove(ym.key);
          } else {
            o[ym.key] = amount;
          }
          return b.copyWith(overrides: o);
        }).toList(),
      ));

  /// Retire les montants spéciaux d'un budget à partir d'un mois (ils reprennent le budget habituel).
  void clearBudgetOverridesFrom(String budgetId, Ym from) => _set(state.copyWith(
        budgets: state.budgets.map((b) {
          if (b.id != budgetId) return b;
          final o = Map<String, double>.from(b.overrides)
            ..removeWhere((k, _) => !Ym.parse(k).isBefore(from));
          return b.copyWith(overrides: o);
        }).toList(),
      ));

  /// [Mode dev] Sauvegarde la tournante 3x8.
  void setShiftSchedule(ShiftSchedule? schedule) =>
      _set(state.copyWith(shiftSchedule: schedule, clearShiftSchedule: schedule == null));

  /// [Mode dev] Définit le nombre de jours de congés pour un mois donné.
  /// [days] = 0 ou null → supprime l'entrée.
  void setLeaveDays(Ym ym, int days) {
    final s = state.shiftSchedule;
    if (s == null) return;
    final updated = Map<String, int>.from(s.leaveDays);
    if (days <= 0) updated.remove(ym.key); else updated[ym.key] = days;
    _set(state.copyWith(shiftSchedule: s.copyWith(leaveDays: updated)));
  }

  void setRtDays(Ym ym, int days) {
    final s = state.shiftSchedule;
    if (s == null) return;
    final updated = Map<String, int>.from(s.rtDays);
    if (days <= 0) updated.remove(ym.key); else updated[ym.key] = days;
    _set(state.copyWith(shiftSchedule: s.copyWith(rtDays: updated)));
  }

  void setRxDays(Ym ym, int days) {
    final s = state.shiftSchedule;
    if (s == null) return;
    final updated = Map<String, int>.from(s.rxDays);
    if (days <= 0) updated.remove(ym.key); else updated[ym.key] = days;
    _set(state.copyWith(shiftSchedule: s.copyWith(rxDays: updated)));
  }

  void setRtRxRates({double? rtRate, double? rxRate}) {
    final s = state.shiftSchedule;
    if (s == null) return;
    _set(state.copyWith(shiftSchedule: s.copyWith(
      rtRate: rtRate ?? s.rtRate,
      rxRate: rxRate ?? s.rxRate,
    )));
  }

  // ── [Mode dev] Compteur de congés ──────────────────────────────────────────

  void addLeaveType(String name, double accrualPerMonth, double initialBalance, int colorValue) {
    _set(state.copyWith(leaveTypes: [
      ...state.leaveTypes,
      LeaveType(
        id: _id(),
        name: name,
        accrualPerMonth: accrualPerMonth,
        initialBalance: initialBalance,
        colorValue: colorValue,
        priority: state.leaveTypes.length,
      ),
    ]));
  }

  void updateLeaveType(LeaveType lt) => _set(state.copyWith(
      leaveTypes: state.leaveTypes.map((t) => t.id == lt.id ? lt : t).toList()));

  void deleteLeaveType(String id) => _set(state.copyWith(
      leaveTypes: state.leaveTypes.where((t) => t.id != id).toList(),
      leaveEntries: state.leaveEntries.where((e) => e.leaveTypeId != id).toList()));

  void reorderLeaveTypes(List<LeaveType> reordered) =>
      _set(state.copyWith(leaveTypes: reordered));

  void setLeaveEntry(String leaveTypeId, Ym month, double days, {String note = ''}) {
    final existing = state.leaveEntries
        .where((e) => e.leaveTypeId == leaveTypeId && e.month == month && e.note == note)
        .firstOrNull;
    List<LeaveEntry> updatedLeaves;
    if (days <= 0) {
      updatedLeaves = existing != null
          ? state.leaveEntries.where((e) => e.id != existing.id).toList()
          : state.leaveEntries;
    } else if (existing != null) {
      updatedLeaves = state.leaveEntries
          .map((e) => e.id == existing.id
              ? LeaveEntry(id: e.id, leaveTypeId: leaveTypeId, month: month, days: days, note: note)
              : e)
          .toList();
    } else {
      updatedLeaves = [
        ...state.leaveEntries,
        LeaveEntry(id: _id(), leaveTypeId: leaveTypeId, month: month, days: days, note: note),
      ];
    }
    // Synchroniser les charges liées dans l'onglet Mensuel
    if (note != '__solde__') {
      final updatedExpenses = state.fixedExpenses.map((f) {
        if (f.leaveTypeId != leaveTypeId || !f.activeIn(month)) return f;
        final list = [...f.checkedMonths];
        if (days > 0 && !list.contains(month.key)) {
          list.add(month.key);
        } else if (days <= 0) {
          list.remove(month.key);
        }
        return f.copyWith(checkedMonths: list);
      }).toList();
      _set(state.copyWith(leaveEntries: updatedLeaves, fixedExpenses: updatedExpenses));
    } else {
      _set(state.copyWith(leaveEntries: updatedLeaves));
    }
  }

  // ── Calcul du solde d'un type à la FIN du mois [ym] ──────────────────────
  double _soldeFin(LeaveType lt, Ym ym, List<LeaveEntry> entries) {
    return _soldeDebut(lt, ym, entries) + lt.accrualPerMonth - _posesIn(lt, ym, entries);
  }

  double _soldeDebut(LeaveType lt, Ym ym, List<LeaveEntry> entries) {
    final manual = entries
        .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note == '__solde__')
        .firstOrNull;
    if (manual != null) return manual.days;
    if (ym.index <= state.startYm.index) return lt.initialBalance;
    return _soldeFin(lt, ym.add(-1), entries);
  }

  double _posesIn(LeaveType lt, Ym ym, List<LeaveEntry> entries) =>
      entries.where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note != '__solde__')
          .fold(0.0, (s, e) => s + e.days);

  // ── Répartit [totalDays] entre types selon priorité avec les soldes réels ─
  Map<String, double> _distribute(
      double totalDays, List<LeaveType> types, Ym month, List<LeaveEntry> entries) {
    final sorted = [...types]..sort((a, b) => a.priority.compareTo(b.priority));
    double remaining = totalDays;
    final result = <String, double>{};
    for (final lt in sorted) {
      if (remaining <= 0) { result[lt.id] = 0; continue; }
      final dispo = (_soldeDebut(lt, month, entries) + lt.accrualPerMonth).floorToDouble().clamp(0.0, double.infinity);
      final pose = remaining.clamp(0.0, dispo);
      result[lt.id] = pose;
      remaining -= pose;
    }
    return result;
  }

  // ── Pose [totalDays] sur [month] : redistribue les types, vérifie les conflits
  // Retourne la liste des conflits futurs (mois où le total prévu devient impossible).
  // Si [force] == true, applique quand même sans vérifier.
  List<LeaveConflict> checkTotalLeave(Ym month, double totalDays) {
    final types = [...state.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    if (types.isEmpty) return [];

    // Simuler l'application sur ce mois
    var simEntries = _applyDistribution(month, totalDays, types, [...state.leaveEntries]);

    // Vérifier chaque mois futur qui a des poses
    final futurePosedMonths = simEntries
        .where((e) =>
            types.any((t) => t.id == e.leaveTypeId) &&
            e.month.index > month.index &&
            e.note != '__solde__')
        .map((e) => e.month)
        .toSet()
        .toList()
      ..sort((a, b) => a.index.compareTo(b.index));

    final conflicts = <LeaveConflict>[];
    for (final ym in futurePosedMonths) {
      final totalDemande = types.fold(0.0, (s, lt) => s + _posesIn(lt, ym, simEntries));
      if (totalDemande <= 0) continue;

      // Calculer le total disponible ce mois-là avec les soldes simulés
      final totalDispo = types.fold(0.0, (s, lt) =>
          s + (_soldeDebut(lt, ym, simEntries) + lt.accrualPerMonth).floorToDouble().clamp(0.0, double.infinity));

      if (totalDemande > totalDispo) {
        conflicts.add(LeaveConflict(
          month: ym,
          demande: totalDemande,
          disponible: totalDispo,
        ));
      }

      // Mettre à jour la simulation pour les mois suivants (redistribue les types, garde le total)
      simEntries = _applyDistributionCapped(ym, totalDemande, types, simEntries);
    }
    return conflicts;
  }

  void setTotalLeave(Ym month, double totalDays) {
    final types = [...state.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    if (types.isEmpty) return;

    // Appliquer sur ce mois (redistribution entre types)
    var entries = _applyDistribution(month, totalDays, types, [...state.leaveEntries]);

    // Redistribuer les types des mois futurs SANS changer leur total
    // Si un mois futur n'a plus assez de solde, on fait du mieux possible
    // mais on ne touche pas au total demandé (l'avertissement a déjà été montré)
    entries = _rebalanceFutureTypes(month, types, entries);

    final updatedExpenses = _syncLeaveExpenses(entries, state.fixedExpenses);
    _set(state.copyWith(leaveEntries: entries, fixedExpenses: updatedExpenses));
  }

  // ── Applique une distribution sur un mois (efface et remplace les poses) ──
  List<LeaveEntry> _applyDistribution(
      Ym month, double totalDays, List<LeaveType> types, List<LeaveEntry> entries) {
    var updated = entries
        .where((e) => !(types.any((t) => t.id == e.leaveTypeId) && e.month == month && e.note != '__solde__'))
        .toList();
    final dist = _distribute(totalDays, types, month, updated);
    for (final e in dist.entries) {
      if (e.value > 0) {
        updated.add(LeaveEntry(id: _id(), leaveTypeId: e.key, month: month, days: e.value));
      }
    }
    return updated;
  }

  // ── Comme _applyDistribution mais cap à ce qui est disponible ─────────────
  List<LeaveEntry> _applyDistributionCapped(
      Ym month, double totalDays, List<LeaveType> types, List<LeaveEntry> entries) {
    var updated = entries
        .where((e) => !(types.any((t) => t.id == e.leaveTypeId) && e.month == month && e.note != '__solde__'))
        .toList();
    final totalDispo = types.fold(0.0, (s, lt) =>
        s + (_soldeDebut(lt, month, updated) + lt.accrualPerMonth).floorToDouble().clamp(0.0, double.infinity));
    final effectif = totalDays.clamp(0.0, totalDispo);
    final dist = _distribute(effectif, types, month, updated);
    for (final e in dist.entries) {
      if (e.value > 0) {
        updated.add(LeaveEntry(id: _id(), leaveTypeId: e.key, month: month, days: e.value));
      }
    }
    return updated;
  }

  // ── Redistribue uniquement les TYPES des mois futurs, sans changer le total
  List<LeaveEntry> _rebalanceFutureTypes(
      Ym fromMonth, List<LeaveType> types, List<LeaveEntry> entries) {
    final futurePosedMonths = entries
        .where((e) =>
            types.any((t) => t.id == e.leaveTypeId) &&
            e.month.index > fromMonth.index &&
            e.note != '__solde__')
        .map((e) => e.month)
        .toSet()
        .toList()
      ..sort((a, b) => a.index.compareTo(b.index));

    var current = entries;
    for (final ym in futurePosedMonths) {
      final totalDemande = types.fold(0.0, (s, lt) => s + _posesIn(lt, ym, current));
      if (totalDemande <= 0) continue;
      // Redistribuer les types avec le solde réel — cap si insuffisant
      // mais NE PAS modifier le total (si cap → le mois garde des jours "flottants")
      current = _applyDistributionCapped(ym, totalDemande, types, current);
    }
    return current;
  }

  // ── Sync charges fixes liées aux congés ───────────────────────────────────
  List<FixedExpense> _syncLeaveExpenses(List<LeaveEntry> entries, List<FixedExpense> expenses) {
    return expenses.map((f) {
      if (f.leaveTypeId == null) return f;
      final list = [...f.checkedMonths];
      // Trouver tous les mois où ce type a des poses
      final posedMonths = entries
          .where((e) => e.leaveTypeId == f.leaveTypeId && e.note != '__solde__' && e.days > 0)
          .map((e) => e.month.key)
          .toSet();
      list.clear();
      list.addAll(posedMonths);
      return f.copyWith(checkedMonths: list);
    }).toList();
  }

  /// [Mode dev] Définit la règle de débit par défaut d'un budget.
  void setBudgetDebitDay(String budgetId, ReceiptDayRule rule) => _set(state.copyWith(
      budgets: state.budgets
          .map((b) => b.id == budgetId ? b.copyWith(debitDay: rule) : b)
          .toList()));

  /// Nouvelle catégorie : un budget par personne en mode couple.
  void addCategoryWithBudget(String name, String emoji, double amount,
      {int? colorValue, bool separate = false}) {
    final color = AppColors.palette[state.categories.length % AppColors.palette.length];
    final cid = _id();
    final cat = Category(
        id: cid,
        name: name,
        emoji: emoji.isEmpty ? '💰' : emoji,
        colorValue: colorValue ?? color.value);
    final persons = (state.isCouple && separate) ? [1, 2] : [0];
    _set(state.copyWith(
      categories: [...state.categories, cat],
      budgets: [
        ...state.budgets,
        for (final p in persons)
          Budget(id: '${cid}_b$p', categoryId: cid, amount: amount, person: p),
      ],
    ));
  }

  /// Supprime les budgets d'une catégorie (les deux conjoints en mode couple).
  /// La catégorie disparaît aussi si aucune dépense n'y est rattachée.
  void setCategoryStyle(String categoryId, String emoji, int colorValue) {
    final c = state.category(categoryId);
    if (c == null || (c.emoji == emoji && c.colorValue == colorValue)) return;
    _set(state.copyWith(
      categories: state.categories
          .map((x) => x.id == categoryId
              ? Category(id: x.id, name: x.name, emoji: emoji, colorValue: colorValue)
              : x)
          .toList(),
    ));
  }

  void removeBudget(String categoryId) => _set(state.copyWith(
        budgets: state.budgets.where((b) => b.categoryId != categoryId).toList(),
        categories: state.categories
            .where((c) => c.id != categoryId || state.transactions.any((t) => t.categoryId == categoryId))
            .toList(),
      ));

  // ---- Revenus ----
  void addRecurringIncome(String label, double amount, Ym start, Ym? end,
      {int intervalMonths = 1, bool checked = false}) {
    final id = _id();
    _set(state.copyWith(recurringIncomes: [
      ...state.recurringIncomes,
      RecurringIncome(
          id: id,
          label: label.isEmpty ? 'Salaire' : label,
          amount: amount,
          start: start,
          end: end,
          intervalMonths: intervalMonths,
          checkedMonths: checked ? [start.key] : const []),
    ]));
  }

  void removeRecurringIncome(String id) => _set(state.copyWith(
      recurringIncomes: state.recurringIncomes.where((r) => r.id != id).toList()));

  /// Modifie l'ensemble d'un revenu récurrent (nom, montant, fréquence, début, fin).
  void updateRecurringIncome(String id,
      {required String label,
      required double amount,
      required Ym start,
      Ym? end,
      required int intervalMonths,
      ReceiptDayRule? receiptDay,
      bool? isShiftSalary,
      double? baseSalary}) {
    _set(state.copyWith(
      recurringIncomes: state.recurringIncomes
          .map((r) => r.id != id
              ? r
              : r.copyWith(
                  label: label,
                  amount: amount,
                  start: start,
                  end: end,
                  clearEnd: end == null,
                  intervalMonths: intervalMonths,
                  receiptDay: receiptDay,
                  isShiftSalary: isShiftSalary,
                  baseSalary: baseSalary))
          .toList(),
    ));
  }

  /// [Mode dev] Crée un revenu récurrent de type salaire 3×8.
  void addShiftSalaryIncome(String label, double baseSalary, Ym start) {
    _set(state.copyWith(
      recurringIncomes: [
        ...state.recurringIncomes,
        RecurringIncome(
          id: _id(),
          label: label,
          amount: baseSalary,
          start: start,
          isShiftSalary: true,
          baseSalary: baseSalary,
        ),
      ],
    ));
  }

  /// Supprime seulement l'occurrence d'un mois précis (les autres mois ne changent pas).
  void excludeRecurringMonth(String id, Ym ym) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          return r.copyWith(excludedMonths: [...r.excludedMonths, ym.key]);
        }).toList(),
      ));

  /// Supprime ce mois-ci et tous les suivants (le revenu s'arrête juste avant).
  /// S'il n'y a aucun mois avant, le revenu est supprimé entièrement.
  void endRecurringFrom(String id, Ym ym) {
    final r = state.recurring(id);
    if (r == null) return;
    if (!ym.isAfter(r.start)) {
      removeRecurringIncome(id);
      return;
    }
    _set(state.copyWith(
      recurringIncomes:
          state.recurringIncomes.map((x) => x.id == id ? x.copyWith(end: ym.add(-1)) : x).toList(),
    ));
  }

  /// Change le montant habituel (tous les mois sans modification propre).
  void setRecurringAmount(String id, double amount) => _set(state.copyWith(
      recurringIncomes: state.recurringIncomes
          .map((r) => r.id == id ? r.copyWith(amount: amount) : r)
          .toList()));

  /// Modifie le montant d'un seul mois (null = retour au montant habituel).
  void setRecurringOverride(String id, Ym ym, double? amount) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          final o = Map<String, double>.from(r.overrides);
          if (amount == null) {
            o.remove(ym.key);
          } else {
            o[ym.key] = amount;
          }
          return r.copyWith(overrides: o);
        }).toList(),
      ));

  void addExtraIncome(IncomeKind kind, String label, double amount, Ym ym,
          {String note = '', bool checked = false}) =>
      _set(state.copyWith(incomes: [
        ...state.incomes,
        Income(id: _id(), kind: kind, label: label, amount: amount, ym: ym, note: note, checked: checked),
      ]));

  void updateIncomeAmount(String id, double amount) => _set(state.copyWith(
      incomes: state.incomes
          .map((i) => i.id == id
              ? Income(id: i.id, kind: i.kind, label: i.label, amount: amount, ym: i.ym, note: i.note)
              : i)
          .toList()));

  /// Modifie le nom (et éventuellement le montant) d'un revenu ponctuel.
  void updateIncome(String id, {String? label, double? amount, String? note}) => _set(state.copyWith(
      incomes: state.incomes
          .map((i) => i.id == id
              ? Income(
                  id: i.id,
                  kind: i.kind,
                  label: label ?? i.label,
                  amount: amount ?? i.amount,
                  ym: i.ym,
                  note: note ?? i.note)
              : i)
          .toList()));

  void removeIncome(String id) =>
      _set(state.copyWith(incomes: state.incomes.where((i) => i.id != id).toList()));

  // ---- Charges fixes ----
  void addFixedExpense(String name, double amount, Ym start, Ym? end,
      {String emoji = '', int? colorValue, int intervalMonths = 1, String? leaveTypeId, String? categoryId, String note = '',
      bool checked = false}) {
    final newId = _id();
    final d = state.copyWith(fixedExpenses: [
      ...state.fixedExpenses,
      FixedExpense(
          id: newId,
          name: name,
          amount: amount,
          start: start,
          end: end,
          emoji: emoji,
          colorValue: colorValue,
          categoryId: categoryId,
          intervalMonths: intervalMonths,
          leaveTypeId: leaveTypeId,
          note: note),
    ]);
    _log(d, 'Charge ajoutée : $name · ${amount.toStringAsFixed(2)} €/mois');
    // Déjà prélevée : on la pointe tout de suite (synchronise aussi les congés liés).
    if (checked) toggleFixedChecked(newId, start);
  }

  /// Pointer / dépointer une charge fixe pour un mois donné (prélèvement constaté).
  /// Si la charge est liée à un type de congé, synchronise les poses de congés.
  void toggleFixedChecked(String id, Ym ym) {
    final f = state.fixedExpenses.where((e) => e.id == id).firstOrNull;
    if (f == null) return;
    final nowChecked = !f.checkedMonths.contains(ym.key);
    final updatedExpenses = state.fixedExpenses.map((e) {
      if (e.id != id) return e;
      final list = [...e.checkedMonths];
      if (!list.remove(ym.key)) list.add(ym.key);
      return e.copyWith(checkedMonths: list);
    }).toList();
    // Synchroniser avec les congés si la charge est liée
    List<LeaveEntry> updatedLeaves = state.leaveEntries;
    if (f.leaveTypeId != null) {
      final existing = state.leaveEntries
          .where((e) => e.leaveTypeId == f.leaveTypeId && e.month == ym && e.note != '__solde__')
          .firstOrNull;
      if (nowChecked) {
        // Coché → ajouter une pose (jours = amount de la charge, ex. 1 j)
        // On stocke le nombre de jours dans LeaveEntry.days
        // Par convention : amount de la charge = jours posés
        final days = f.amount;
        if (existing != null) {
          updatedLeaves = state.leaveEntries
              .map((e) => e.id == existing.id
                  ? LeaveEntry(id: e.id, leaveTypeId: f.leaveTypeId!, month: ym, days: days)
                  : e)
              .toList();
        } else {
          updatedLeaves = [
            ...state.leaveEntries,
            LeaveEntry(id: _id(), leaveTypeId: f.leaveTypeId!, month: ym, days: days),
          ];
        }
      } else {
        // Décoché → supprimer la pose
        if (existing != null) {
          updatedLeaves = state.leaveEntries.where((e) => e.id != existing.id).toList();
        }
      }
    }
    _set(state.copyWith(fixedExpenses: updatedExpenses, leaveEntries: updatedLeaves));
  }

  /// Supprime le report d'une charge fixe (retire [prevYm] de carriedMonths).
  /// Utilisé depuis l'onglet Mensuel pour annuler un report non souhaité.
  void removeFixedCarried(String id, Ym prevYm) {
    final f = state.fixedExpenses.where((e) => e.id == id).firstOrNull;
    if (f == null) return;
    _set(state.copyWith(
      fixedExpenses: state.fixedExpenses.map((e) {
        if (e.id != id) return e;
        return e.copyWith(
          carriedMonths: e.carriedMonths.where((m) => m != prevYm.key).toList(),
        );
      }).toList(),
    ));
  }

  void updateFixedExpense(FixedExpense f) {
    final d = state.copyWith(fixedExpenses: state.fixedExpenses.map((e) => e.id == f.id ? f : e).toList());
    _log(d, 'Charge modifiée : ${f.name} · ${f.amount.toStringAsFixed(2)} €/mois');
  }

  void removeFixedExpense(String id) {
    final f = state.fixedExpenses.firstWhere((e) => e.id == id, orElse: () => state.fixedExpenses.first);
    final d = state.copyWith(fixedExpenses: state.fixedExpenses.where((e) => e.id != id).toList());
    _log(d, 'Charge supprimée : ${f.name}');
  }

  /// Retire uniquement les mois indiqués (un seul mois, ou une période) sans supprimer
  /// la charge : elle continue normalement en dehors de ces mois.
  void excludeFixedMonths(String id, List<Ym> months) => _set(state.copyWith(
        fixedExpenses: state.fixedExpenses.map((f) {
          if (f.id != id) return f;
          final keys = {...f.excludedMonths, ...months.map((m) => m.key)};
          return f.copyWith(excludedMonths: keys.toList());
        }).toList(),
      ));

  // ---- Projets ----
  void addProject(String name, double target, Ym targetYm, ProjectMode mode,
      {DateTime? tripStart,
      DateTime? tripEnd,
      int who = 0,
      bool isTrip = true,
      Map<String, ClientTripPlan> clientPlans = const {}}) {
    final start = now.isBefore(state.startYm) ? state.startYm : now;
    final d = state.copyWith(projects: [
      ...state.projects,
      Project(
          id: _id(),
          name: name,
          target: target,
          startYm: start,
          targetYm: targetYm,
          mode: mode,
          tripStart: tripStart,
          tripEnd: tripEnd,
          who: who,
          isTrip: isTrip,
          clientPlans: clientPlans),
    ]);
    _log(d, '${isTrip ? 'Voyage' : 'Projet'} ajouté : $name · ${target.toStringAsFixed(2)} €');
  }

  /// Modifie un voyage (nom, budget, mois, mode) en gardant ses versements et ses dépenses.
  void updateProject(String id,
      {required String name,
      required double target,
      required Ym targetYm,
      required ProjectMode mode,
      DateTime? tripStart,
      DateTime? tripEnd,
      int who = 0,
      bool isTrip = true,
      Map<String, ClientTripPlan>? clientPlans}) {
    final d = state.copyWith(
      projects: state.projects.map((p) {
        if (p.id != id) return p;
        final start = p.startYm.isBefore(targetYm) ? p.startYm : targetYm.add(-1);
        return Project(
            id: p.id,
            name: name,
            target: target,
            startYm: start,
            targetYm: targetYm,
            contributions: p.contributions,
            mode: mode,
            tripStart: tripStart,
            tripEnd: tripEnd,
            who: who,
            isTrip: isTrip,
            clientPlans: clientPlans ?? p.clientPlans);
      }).toList(),
    );
    _log(d, '${isTrip ? 'Voyage' : 'Projet'} modifié : $name · ${target.toStringAsFixed(2)} €');
  }

  /// Clients et mois dont les factures dépendent d'un voyage (pour proposer de les remettre à l'état de base).
  List<({Client client, Ym ym})> _tripInvoices(Project p) {
    final out = <({Client client, Ym ym})>[];
    final s = p.tripStart, e = p.tripEnd;
    if (s == null || e == null) return out;
    for (final c in state.clients) {
      if (!state.aeActive(c.owner) || c.isOneOff) continue;
      for (var ym = Ym.of(s); !ym.isAfter(Ym.of(e)); ym = ym.add(1)) {
        if (state.lostInMonth(c, p, ym) > 0.01) out.add((client: c, ym: ym));
      }
    }
    return out;
  }

  /// Des clients ont-ils des factures liées à ce voyage ?
  bool projectTouchesInvoices(String id) {
    final p = state.projects.where((x) => x.id == id).firstOrNull;
    return p != null && _tripInvoices(p).isNotEmpty;
  }

  /// Supprime un voyage. [restoreInvoices] : true = les factures reviennent à leur état de base
  /// (modifications manuelles effacées) ; false = on garde les factures telles qu'elles sont aujourd'hui.
  void removeProjectWithInvoices(String id, {required bool restoreInvoices}) {
    final p = state.projects.where((x) => x.id == id).firstOrNull;
    if (p != null) {
      for (final t in _tripInvoices(p)) {
        if (restoreInvoices) {
          setInvoiceOverride(t.client.id, t.ym);
        } else if (state.clients.any((c) => c.id == t.client.id) && t.client.forfait == null) {
          final plan = p.clientPlans[t.client.id];
          final removed = plan == null || plan.mode == ClientTripPlan.remove;
          final rec = state.invoiceRecord(t.client.id, t.ym);
          if (removed && rec?.overrideVisits == null && rec?.overrideAmount == null) {
            setInvoiceOverride(t.client.id, t.ym, visits: state.invoiceView(t.client, t.ym).visits);
          }
        }
      }
    }
    removeProject(id);
  }

  /// Supprime un voyage et ses dépenses.
  void removeProject(String id) {
    final p = state.projects.firstWhere((p) => p.id == id, orElse: () => state.projects.first);
    final d = state.copyWith(
      projects: state.projects.where((p) => p.id != id).toList(),
      transactions: state.transactions.where((t) => t.tripId != id).toList(),
    );
    _log(d, '${p.isTrip ? 'Voyage' : 'Projet'} supprimé : ${p.name}');
  }

  /// Marque (ou annule) le versement du mois courant pour un projet.
  void toggleContribution(String projectId) {
    _set(state.copyWith(
      projects: state.projects.map((p) {
        if (p.id != projectId) return p;
        final c = Map<String, double>.from(p.contributions);
        if (c.containsKey(now.key)) {
          c.remove(now.key);
        } else {
          c[now.key] = p.monthlyPlan;
        }
        return p.copyWith(contributions: c);
      }).toList(),
    ));
  }

  // ---- Clôture ----
  /// [deferFixedIds] : charges fixes actives ce mois-ci, non cochées, que l'utilisateur
  /// a choisi de reporter au mois suivant (elles n'ont pas été débitées ce mois).
  /// [deferFixedIds] : charges fixes actives ce mois-ci, non cochées, reportées au mois suivant.
  /// [deferRecurringIds] : revenus récurrents actifs, non pointés, reportés au mois suivant.
  /// [deferOneOffIncomeIds] / [deferTransactionIds] : revenus ponctuels et dépenses non pointés
  /// ce mois-ci, déplacés directement au mois suivant.
  void closeMonth(
    Ym ym, {
    List<String> deferFixedIds = const [],
    List<String> deferRecurringIds = const [],
    List<String> deferOneOffIncomeIds = const [],
    List<String> deferTransactionIds = const [],
  }) {
    final planned = state.plannedIn(ym);
    final spent = state.spentIn(ym);
    final byBudget = {
      for (final b in state.budgets) b.id: b.amountIn(ym) - state.spentForBudget(b, ym),
    };
    // Factures non payées : reportées au mois suivant (retard de paiement)
    final recs = [...state.invoices];
    for (final v in (kInvoicesEnabled ? state.unpaidReceivedIn(ym) : <InvoiceView>[])) {
      final i = recs.indexWhere((r) => r.clientId == v.client.id && r.ym == v.ym);
      final base = i >= 0 ? recs[i] : InvoiceRecord(clientId: v.client.id, ym: v.ym);
      final upd = base.copyWith(receivedYm: ym.add(1), carryLog: [...base.carryLog, ym.key]);
      if (i >= 0) {
        recs[i] = upd;
      } else {
        recs.add(upd);
      }
    }
    // Charges fixes non cochées et reportées : le montant se rajoute au mois suivant.
    final fixed = state.fixedExpenses.map((f) {
      if (deferFixedIds.contains(f.id) && !f.carriedMonths.contains(ym.key)) {
        return f.copyWith(carriedMonths: [...f.carriedMonths, ym.key]);
      }
      return f;
    }).toList();
    // Revenus récurrents non pointés : reportés au mois suivant.
    final recurring = state.recurringIncomes.map((r) {
      if (deferRecurringIds.contains(r.id) && !r.carriedMonths.contains(ym.key)) {
        return r.copyWith(carriedMonths: [...r.carriedMonths, ym.key]);
      }
      return r;
    }).toList();
    // Revenus ponctuels non pointés : déplacés directement au mois suivant.
    final incomes = state.incomes.map((i) {
      if (deferOneOffIncomeIds.contains(i.id) && i.ym == ym) {
        return i.copyWith(ym: ym.add(1), movedFrom: ym);
      }
      return i;
    }).toList();
    // Dépenses non pointées (courses, charges, voyages...) : déplacées au mois suivant.
    final txs = state.transactions.map((t) {
      if (deferTransactionIds.contains(t.id)) {
        return t.copyWith(date: ym.add(1).firstDay, movedFrom: t.date);
      }
      return t;
    }).toList();
    final newData = state.copyWith(
      invoices: recs,
      fixedExpenses: fixed,
      recurringIncomes: recurring,
      incomes: incomes,
      transactions: txs,
      snapshots: {
        ...state.snapshots,
        ym.key: MonthSnapshot(
            ym: ym,
            planned: planned,
            spent: spent,
            savingsByCategory: byBudget,
            closedAt: DateTime.now()),
      },
    );
    _log(newData, 'Mois clôturé : ${ym.longName}');
  }

  void reopenMonth(Ym ym) {
    final s = Map<String, MonthSnapshot>.from(state.snapshots)..remove(ym.key);
    // Annule les reports de factures faits à la clôture de ce mois
    final recs = state.invoices.map((r) {
      if (r.carryLog.isNotEmpty && r.carryLog.last == ym.key) {
        final log = [...r.carryLog]..removeLast();
        return r.ym == ym
            ? r.copyWith(clearReceived: true, carryLog: log)
            : r.copyWith(receivedYm: ym, carryLog: log);
      }
      return r;
    }).toList();
    // Annule les reports de charges fixes faits à la clôture de ce mois
    final fixed = state.fixedExpenses.map((f) {
      if (f.carriedMonths.isNotEmpty && f.carriedMonths.last == ym.key) {
        return f.copyWith(carriedMonths: [...f.carriedMonths]..removeLast());
      }
      return f;
    }).toList();
    // Annule les reports de revenus récurrents faits à la clôture de ce mois
    final recurring = state.recurringIncomes.map((r) {
      if (r.carriedMonths.isNotEmpty && r.carriedMonths.last == ym.key) {
        return r.copyWith(carriedMonths: [...r.carriedMonths]..removeLast());
      }
      return r;
    }).toList();
    // Ramène les revenus ponctuels déplacés lors de cette clôture
    final incomes = state.incomes.map((i) {
      if (i.movedFrom == ym) return i.copyWith(ym: ym, clearMovedFrom: true);
      return i;
    }).toList();
    // Ramène les dépenses déplacées lors de cette clôture
    final txs = state.transactions.map((t) {
      if (t.movedFrom != null && Ym.of(t.movedFrom!) == ym) {
        return t.copyWith(date: t.movedFrom!, clearMovedFrom: true);
      }
      return t;
    }).toList();
    final d = state.copyWith(
        snapshots: s,
        invoices: recs,
        fixedExpenses: fixed,
        recurringIncomes: recurring,
        incomes: incomes,
        transactions: txs);
    _log(d, 'Mois rouvert : ${ym.longName}');
  }

  // ---- Clients & factures (auto-entrepreneur) ----
  void addClient(Client c) => _set(state.copyWith(clients: [...state.clients, c]));

  void updateClient(Client c) =>
      _set(state.copyWith(clients: state.clients.map((e) => e.id == c.id ? c : e).toList()));

  void removeClient(String id) => _set(state.copyWith(
        clients: state.clients.where((c) => c.id != id).toList(),
        invoices: state.invoices.where((r) => r.clientId != id).toList(),
      ));

  // ── Paiements en plusieurs fois ──────────────────────────────
  void addInstallment(InstallmentPlan p) => _set(state.copyWith(installments: [...state.installments, p]));

  void updateInstallment(InstallmentPlan p) => _set(
      state.copyWith(installments: state.installments.map((e) => e.id == p.id ? p : e).toList()));

  void removeInstallment(String id) =>
      _set(state.copyWith(installments: state.installments.where((e) => e.id != id).toList()));

  /// Marque l'échéance [i] comme ajoutée au budget ([done]) ou ignorée.
  void resolveInstallment(String id, int i, {required bool done}) {
    final p = state.installments.where((e) => e.id == id).firstOrNull;
    if (p == null) return;
    final key = p.ymAt(i).key;
    _set(state.copyWith(
      installments: state.installments
          .map((e) => e.id != id
              ? e
              : e.copyWith(
                  done: done ? [...e.done.where((k) => k != key), key] : e.done,
                  skipped: done ? e.skipped.where((k) => k != key).toList() : [...e.skipped.where((k) => k != key), key]))
          .toList(),
    ));
  }

  String newId() => _id();

  void _upsertInvoice(String clientId, Ym ym, InvoiceRecord Function(InvoiceRecord) f) {
    final recs = [...state.invoices];
    final i = recs.indexWhere((r) => r.clientId == clientId && r.ym == ym);
    if (i >= 0) {
      recs[i] = f(recs[i]);
    } else {
      recs.add(f(InvoiceRecord(clientId: clientId, ym: ym)));
    }
    _set(state.copyWith(invoices: recs));
  }

  /// Modifie la facture à la main : soit le nombre de passages, soit le montant
  /// (l'autre est recalculé). Sans argument : retour au calcul automatique.
  void setInvoiceOverride(String clientId, Ym ym, {double? visits, double? amount}) {
    _upsertInvoice(clientId, ym, (r) {
      final base = r.copyWith(clearOverrides: true);
      if (visits != null) {
        return InvoiceRecord(
            clientId: base.clientId,
            ym: base.ym,
            overrideVisits: visits,
            sent: base.sent,
            paid: base.paid,
            receivedYm: base.receivedYm,
            carryLog: base.carryLog,
            missedVisits: base.missedVisits);
      }
      if (amount != null) {
        return InvoiceRecord(
            clientId: base.clientId,
            ym: base.ym,
            overrideAmount: amount,
            sent: base.sent,
            paid: base.paid,
            receivedYm: base.receivedYm,
            carryLog: base.carryLog,
            missedVisits: base.missedVisits);
      }
      return base;
    });
  }

  /// Client au forfait : nombre de passages manqués ce mois-là (null = aucun saisi).
  void setInvoiceMissed(String clientId, Ym ym, double? missed) => _upsertInvoice(
      clientId,
      ym,
      (r) => (missed == null || missed <= 0)
          ? r.copyWith(clearMissed: true)
          : r.copyWith(missedVisits: missed));

  void toggleInvoiceSent(String clientId, Ym ym) =>
      _upsertInvoice(clientId, ym, (r) => r.copyWith(sent: !r.sent));

  /// Marque la facture payée / non payée. Payée plus tard que prévu : l'argent est
  /// compté dans le mois où il arrive.
  void toggleInvoicePaid(String clientId, Ym ym) {
    final current = now;
    _upsertInvoice(clientId, ym, (r) {
      final nowPaid = !r.paid;
      Ym? recv;
      if (nowPaid) {
        final base = r.receivedYm ?? ym;
        if (current.isAfter(base)) recv = current;
      }
      return r.copyWith(paid: nowPaid, receivedYm: recv);
    });
  }

  // ---- Auto-entrepreneur ----
  void setAutoEntrepreneur({bool? me, bool? partner}) =>
      _set(state.copyWith(user: state.user.copyWith(ae1: me, ae2: partner)));

  void setUrssafRate(double rate) =>
      _set(state.copyWith(user: state.user.copyWith(urssafRate: rate)));

  /// Enregistre les noms des couleurs d'un type (« fixed » ou « client »).
  void setColorNames(String scope, Map<int, String> names) {
    final map = Map<String, String>.from(state.colorNames)..removeWhere((k, _) => k.startsWith('$scope:'));
    names.forEach((color, name) {
      if (name.trim().isNotEmpty) map['$scope:$color'] = name.trim();
    });
    _set(state.copyWith(colorNames: map));
  }

  // ---- Mode privé ----
  void setPrivateMode(bool on) =>
      _set(state.copyWith(user: state.user.copyWith(privateMode: on)));

  void setUniproRate(double rate) =>
      _set(state.copyWith(user: state.user.copyWith(uniproRate: rate)));

  // ---- Réglages ----
  /// Modifier le solde de départ en gardant l'historique (annule un éventuel « repartir de zéro »).
  void setStartBalanceKeepHistory(double v) {
    final rounded = double.parse(v.toStringAsFixed(2));
    _set(state.copyWith(startBalance: rounded, clearReset: true));
  }

  /// « Repartir de zéro » : [balance] est le solde au 1er de [ym], les mois précédents sont ignorés.
  void resetBalanceFrom(Ym ym, double balance) {
    final rounded = double.parse(balance.toStringAsFixed(2));
    _set(state.copyWith(resetYm: ym, resetBalance: rounded));
  }

  void setStartBalance(double v) {
    // Arrondi à 2 décimales max pour éviter les imprécisions flottantes (ex. 1200.9999999).
    final rounded = double.parse(v.toStringAsFixed(2));
    _set(state.copyWith(startBalance: rounded));
  }

  void setReduceMotion(bool v) => _set(state.copyWith(user: state.user.copyWith(reduceMotion: v)));

  /// Fin de l'assistant de configuration : remplace les données par celles saisies.
  void completeOnboarding(AppData d) => _set(d);

  /// « Passer » : on garde les données d'exemple.
  void skipOnboarding() =>
      _set(state.copyWith(user: state.user.copyWith(onboarded: true, tourSeen: false)));

  void markTourSeen() {
    if (state.user.tourSeen) return;
    _set(state.copyWith(user: state.user.copyWith(tourSeen: true)));
  }

  void setUiScale(double v) => _set(state.copyWith(user: state.user.copyWith(uiScale: v)));

  /// Active/désactive le mode couple.
  /// Activation : chaque budget existant devient celui de la personne 1 et est
  /// dupliqué pour la personne 2 ; les dépenses existantes passent à la personne 1.
  /// Désactivation : on garde les budgets de la personne 1 (budget "seul"), ceux
  /// de la personne 2 sont supprimés, et toutes les dépenses restent comptées.
  void setCouple(bool couple, {String? person1, String? person2}) {
    final u = state.user;
    final names = u.copyWith(
      person1: (person1 ?? u.person1).trim().isEmpty ? u.person1 : (person1 ?? u.person1).trim(),
      person2: (person2 ?? u.person2).trim().isEmpty ? u.person2 : (person2 ?? u.person2).trim(),
    );
    if (couple == u.isCouple) {
      _set(state.copyWith(user: names));
      return;
    }
    if (couple) {
      _set(state.copyWith(
        user: names.copyWith(isCouple: true),
        transactions: [for (final t in state.transactions) t.copyWith(person: 1)],
      ));
    } else {
      _set(state.copyWith(
        user: names.copyWith(isCouple: false),
        budgets: _mergedBudgets(),
        transactions: [for (final t in state.transactions) t.copyWith(person: 0)],
      ));
    }
  }

  /// Fusionne les budgets séparés (un par conjoint) en un budget commun (somme).
  List<Budget> _mergedBudgets([String? onlyCategory]) {
    final out = <Budget>[];
    for (final c in state.budgets.map((b) => b.categoryId).toSet()) {
      final bs = state.budgets.where((b) => b.categoryId == c).toList();
      if ((onlyCategory != null && c != onlyCategory) || bs.length == 1) {
        out.addAll(bs.length == 1 ? [bs.first.copyWith(person: 0)] : bs);
        continue;
      }
      final a = bs.firstWhere((b) => b.person != 2, orElse: () => bs.first);
      final keys = <String>{for (final b in bs) ...b.overrides.keys};
      out.add(a.copyWith(
        person: 0,
        amount: bs.fold<double>(0.0, (s, b) => s + b.amount),
        overrides: {
          for (final k in keys) k: bs.fold<double>(0.0, (s, b) => s + (b.overrides[k] ?? b.amount)),
        },
      ));
    }
    return out;
  }

  /// Couple : un budget commun, ou un budget par personne, pour une catégorie.
  void setBudgetSeparate(String categoryId, bool separate) {
    if (!state.isCouple) return;
    final bs = state.budgets.where((b) => b.categoryId == categoryId).toList();
    if (bs.isEmpty || separate == bs.any((b) => b.person != 0)) return;
    if (separate) {
      final b = bs.first;
      final ov = {for (final e in b.overrides.entries) e.key: e.value / 2};
      _set(state.copyWith(budgets: [
        ...state.budgets.where((x) => x.categoryId != categoryId),
        for (final p in [1, 2]) b.copyWith(id: '${b.id}_p$p', person: p, amount: b.amount / 2, overrides: ov),
      ]));
    } else {
      _set(state.copyWith(budgets: _mergedBudgets(categoryId)));
    }
  }

  /// Photo de profil d'une personne (null = retirer).
  void setPhoto(int person, String? base64) => _set(state.copyWith(
      user: person == 2
          ? state.user.copyWith(photo2: base64, clearPhoto2: base64 == null)
          : state.user.copyWith(photo1: base64, clearPhoto1: base64 == null)));

  Future<void> resetDemo({bool onboarded = true}) async {
    state = SeedData.create(realNow, onboarded: onboarded);
    await repo.save(state);
    onChanged?.call();
  }
  void toggleLeaveEnabled() => _set(state.copyWith(
      user: state.user.copyWith(leaveEnabled: !state.user.leaveEnabled)));

  void setTheme(int index) {
    state = state.copyWith(user: state.user.copyWith(themeIndex: index));
    repo.save(state);
  }

  /// Apparence : 0 = automatique (suit le téléphone), 1 = clair, 2 = nuit.
  void setThemeMode(int mode) {
    state = state.copyWith(user: state.user.copyWith(themeMode: mode));
    repo.save(state);
  }

  void resetToEmpty(Ym now) {
    // Repart d'une ardoise vierge, sans données demo
    final empty = AppData(
      user: state.user.copyWith(isDemo: false, onboarded: false, tourSeen: false),
      startYm: now,
      startBalance: 0,
      categories: const [],
      budgets: const [],
      transactions: const [],
      recurringIncomes: const [],
      incomes: const [],
      fixedExpenses: const [],
      projects: const [],
      snapshots: const {},
    );
    _set(empty);
  }

}

/// Tick pour déclencher l'animation de succès après clôture du mois.
final closeSuccessTickProvider = StateProvider<int>((ref) => 0);
