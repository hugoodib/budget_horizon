import 'dart:math';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/theme.dart';
import '../core/ym.dart';
import '../data/seed.dart';
import '../domain/business.dart';
import '../domain/forecast.dart';
import '../domain/models.dart';
import '../domain/repository.dart';
import 'auth_controller.dart';

final repositoryProvider =
    Provider<AppRepository>((ref) => throw UnimplementedError('Override in main()'));

/// Mois réel (date du téléphone).
final realNowProvider = Provider<Ym>((ref) => Ym.now());

final appProvider = StateNotifierProvider<AppNotifier, AppData>((ref) => AppNotifier(
      ref.read(repositoryProvider),
      ref.read(realNowProvider),
      // Chaque modification déclenche (si connecté) une synchronisation différée.
      onChanged: () => ref.read(authProvider.notifier).markChanged(),
    ));

/// Mois courant de l'app : le mois réel, décalé au mois suivant
/// tant que le mois est clôturé (« Clôturer le mois » fait basculer).
final nowProvider = Provider<Ym>((ref) {
  final d = ref.watch(appProvider);
  var y = ref.watch(realNowProvider);
  while (d.isClosed(y)) {
    y = y.add(1);
  }
  return y;
});

/// Prévisions du premier mois suivi jusqu'à 24 mois dans le futur.
final forecastProvider = Provider<List<MonthForecast>>((ref) {
  final d = ref.watch(appProvider);
  final now = ref.watch(nowProvider);
  final to = Ym.fromIndex(max(now.index, d.startYm.index) + 24);
  return Forecaster.compute(d, now: now, to: to);
});

/// Onglets de l'app. « clients » et « invoices » n'apparaissent que pour un auto-entrepreneur.
enum AppTab { home, forecast, budgets, charges, incomes, clients, invoices, trips, analysis }

final tabProvider = StateProvider<AppTab>((ref) => AppTab.home);

/// Mois affiché dans l'onglet Factures.
final invoiceMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));

/// Mois affiché dans l'onglet Revenus.
final incomeMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));

final budgetMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));
final chargeMonthProvider = StateProvider<Ym>((ref) => ref.read(nowProvider));

String _id() => DateTime.now().microsecondsSinceEpoch.toString();

class AppNotifier extends StateNotifier<AppData> {
  final AppRepository repo;
  final Ym realNow;
  final void Function()? onChanged;
  final List<AppData> _history = [];
  final List<AppData> _future = [];
  static const _maxHistory = 30;

  AppNotifier(this.repo, this.realNow, {this.onChanged})
      : super(SeedData.upgradeStyles(repo.load() ?? SeedData.create(realNow))) {
    repo.save(state);
  }

  /// Mois courant (après clôture, le mois suivant).
  Ym get now {
    var y = realNow;
    while (state.isClosed(y)) {
      y = y.add(1);
    }
    return y;
  }

  bool get canUndo => _history.isNotEmpty;
  bool get canRedo => _future.isNotEmpty;

  /// Revient à l'état juste avant la dernière modification.
  void undo() {
    if (_history.isEmpty) return;
    _future.add(state);
    state = _history.removeLast();
    repo.save(state);
    onChanged?.call();
  }

  /// Rétablit la modification annulée.
  void redo() {
    if (_future.isEmpty) return;
    _history.add(state);
    state = _future.removeLast();
    repo.save(state);
    onChanged?.call();
  }

  void _set(AppData d) {
    _history.add(state);
    if (_history.length > _maxHistory) _history.removeAt(0);
    _future.clear();
    state = d;
    repo.save(d);
    onChanged?.call();
  }

  /// Remplace toutes les données (ex. données du compte reçues du cloud).
  /// Ne déclenche pas de nouvelle synchronisation, et ne s'ajoute pas à l'historique.
  void replace(AppData d) {
    state = SeedData.upgradeStyles(d);
    repo.save(state);
  }

  // ---- Dépenses ----
  void addTransaction(String categoryId, String description, double amount, DateTime date,
      {int person = 0, String? tripId}) {
    _set(state.copyWith(transactions: [
      ...state.transactions,
      Transaction(
          id: _id(),
          categoryId: categoryId,
          description: description.isEmpty ? 'Dépense' : description,
          amount: amount,
          date: date,
          person: person,
          tripId: tripId),
    ]));
  }

  /// Pointer / dépointer une dépense (comme dans une application bancaire).
  void toggleTransactionChecked(String id) => _set(state.copyWith(
      transactions: state.transactions
          .map((t) => t.id == id ? t.copyWith(checked: !t.checked) : t)
          .toList()));

  /// Pointer / dépointer un revenu ponctuel (versement bien reçu).
  void toggleIncomeChecked(String id) => _set(state.copyWith(
      incomes:
          state.incomes.map((i) => i.id == id ? i.copyWith(checked: !i.checked) : i).toList()));

  /// Pointer / dépointer un revenu récurrent pour un mois donné.
  void toggleRecurringChecked(String id, Ym ym) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          final list = [...r.checkedMonths];
          if (!list.remove(ym.key)) list.add(ym.key);
          return r.copyWith(checkedMonths: list);
        }).toList(),
      ));

  void deleteTransaction(String id) =>
      _set(state.copyWith(transactions: state.transactions.where((t) => t.id != id).toList()));

  // ---- Budgets & catégories ----
  /// Change le budget habituel (tous les mois).
  void setBudgetAmount(String budgetId, double amount) => _set(state.copyWith(
      budgets: state.budgets.map((b) => b.id == budgetId ? b.copyWith(amount: amount) : b).toList()));

  /// Change le budget d'un seul mois (null = retour au budget habituel).
  void setBudgetOverride(String budgetId, Ym ym, double? amount) => _set(state.copyWith(
        budgets: state.budgets.map((b) {
          if (b.id != budgetId) return b;
          final o = Map<String, double>.from(b.overrides);
          if (amount == null) {
            o.remove(ym.key);
          } else {
            o[ym.key] = amount;
          }
          return b.copyWith(overrides: o);
        }).toList(),
      ));

  /// Nouvelle catégorie : un budget par personne en mode couple.
  void addCategoryWithBudget(String name, String emoji, double amount,
      {int? colorValue, bool separate = false}) {
    final color = AppColors.palette[state.categories.length % AppColors.palette.length];
    final cid = _id();
    final cat = Category(
        id: cid,
        name: name,
        emoji: emoji.isEmpty ? '💰' : emoji,
        colorValue: colorValue ?? color.value);
    final persons = (state.isCouple && separate) ? [1, 2] : [0];
    _set(state.copyWith(
      categories: [...state.categories, cat],
      budgets: [
        ...state.budgets,
        for (final p in persons)
          Budget(id: '${cid}_b$p', categoryId: cid, amount: amount, person: p),
      ],
    ));
  }

  /// Supprime les budgets d'une catégorie (les deux conjoints en mode couple).
  /// La catégorie disparaît aussi si aucune dépense n'y est rattachée.
  void setCategoryStyle(String categoryId, String emoji, int colorValue) {
    final c = state.category(categoryId);
    if (c == null || (c.emoji == emoji && c.colorValue == colorValue)) return;
    _set(state.copyWith(
      categories: state.categories
          .map((x) => x.id == categoryId
              ? Category(id: x.id, name: x.name, emoji: emoji, colorValue: colorValue)
              : x)
          .toList(),
    ));
  }

  void removeBudget(String categoryId) => _set(state.copyWith(
        budgets: state.budgets.where((b) => b.categoryId != categoryId).toList(),
        categories: state.categories
            .where((c) => c.id != categoryId || state.transactions.any((t) => t.categoryId == categoryId))
            .toList(),
      ));

  // ---- Revenus ----
  void addRecurringIncome(String label, double amount, Ym start, Ym? end, {int intervalMonths = 1}) =>
      _set(state.copyWith(recurringIncomes: [
        ...state.recurringIncomes,
        RecurringIncome(
            id: _id(),
            label: label.isEmpty ? 'Salaire' : label,
            amount: amount,
            start: start,
            end: end,
            intervalMonths: intervalMonths),
      ]));

  void removeRecurringIncome(String id) => _set(state.copyWith(
      recurringIncomes: state.recurringIncomes.where((r) => r.id != id).toList()));

  /// Modifie l'ensemble d'un revenu récurrent (nom, montant, fréquence, début, fin).
  void updateRecurringIncome(String id,
      {required String label,
      required double amount,
      required Ym start,
      Ym? end,
      required int intervalMonths}) {
    _set(state.copyWith(
      recurringIncomes: state.recurringIncomes
          .map((r) => r.id != id
              ? r
              : r.copyWith(
                  label: label,
                  amount: amount,
                  start: start,
                  end: end,
                  clearEnd: end == null,
                  intervalMonths: intervalMonths))
          .toList(),
    ));
  }

  /// Supprime seulement l'occurrence d'un mois précis (les autres mois ne changent pas).
  void excludeRecurringMonth(String id, Ym ym) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          return r.copyWith(excludedMonths: [...r.excludedMonths, ym.key]);
        }).toList(),
      ));

  /// Supprime ce mois-ci et tous les suivants (le revenu s'arrête juste avant).
  /// S'il n'y a aucun mois avant, le revenu est supprimé entièrement.
  void endRecurringFrom(String id, Ym ym) {
    final r = state.recurring(id);
    if (r == null) return;
    if (!ym.isAfter(r.start)) {
      removeRecurringIncome(id);
      return;
    }
    _set(state.copyWith(
      recurringIncomes:
          state.recurringIncomes.map((x) => x.id == id ? x.copyWith(end: ym.add(-1)) : x).toList(),
    ));
  }

  /// Change le montant habituel (tous les mois sans modification propre).
  void setRecurringAmount(String id, double amount) => _set(state.copyWith(
      recurringIncomes: state.recurringIncomes
          .map((r) => r.id == id ? r.copyWith(amount: amount) : r)
          .toList()));

  /// Modifie le montant d'un seul mois (null = retour au montant habituel).
  void setRecurringOverride(String id, Ym ym, double? amount) => _set(state.copyWith(
        recurringIncomes: state.recurringIncomes.map((r) {
          if (r.id != id) return r;
          final o = Map<String, double>.from(r.overrides);
          if (amount == null) {
            o.remove(ym.key);
          } else {
            o[ym.key] = amount;
          }
          return r.copyWith(overrides: o);
        }).toList(),
      ));

  void addExtraIncome(IncomeKind kind, String label, double amount, Ym ym) =>
      _set(state.copyWith(incomes: [
        ...state.incomes,
        Income(id: _id(), kind: kind, label: label, amount: amount, ym: ym),
      ]));

  void updateIncomeAmount(String id, double amount) => _set(state.copyWith(
      incomes: state.incomes
          .map((i) => i.id == id
              ? Income(id: i.id, kind: i.kind, label: i.label, amount: amount, ym: i.ym)
              : i)
          .toList()));

  /// Modifie le nom (et éventuellement le montant) d'un revenu ponctuel.
  void updateIncome(String id, {String? label, double? amount}) => _set(state.copyWith(
      incomes: state.incomes
          .map((i) => i.id == id
              ? Income(
                  id: i.id,
                  kind: i.kind,
                  label: label ?? i.label,
                  amount: amount ?? i.amount,
                  ym: i.ym)
              : i)
          .toList()));

  void removeIncome(String id) =>
      _set(state.copyWith(incomes: state.incomes.where((i) => i.id != id).toList()));

  // ---- Charges fixes ----
  void addFixedExpense(String name, double amount, Ym start, Ym? end,
          {String emoji = '', int? colorValue, int intervalMonths = 1}) =>
      _set(state.copyWith(fixedExpenses: [
        ...state.fixedExpenses,
        FixedExpense(
            id: _id(),
            name: name,
            amount: amount,
            start: start,
            end: end,
            emoji: emoji,
            colorValue: colorValue,
            intervalMonths: intervalMonths),
      ]));

  /// Pointer / dépointer une charge fixe pour un mois donné (prélèvement constaté).
  void toggleFixedChecked(String id, Ym ym) => _set(state.copyWith(
        fixedExpenses: state.fixedExpenses.map((f) {
          if (f.id != id) return f;
          final list = [...f.checkedMonths];
          if (!list.remove(ym.key)) list.add(ym.key);
          return f.copyWith(checkedMonths: list);
        }).toList(),
      ));

  void updateFixedExpense(FixedExpense f) => _set(state.copyWith(
      fixedExpenses: state.fixedExpenses.map((e) => e.id == f.id ? f : e).toList()));

  void removeFixedExpense(String id) => _set(
      state.copyWith(fixedExpenses: state.fixedExpenses.where((f) => f.id != id).toList()));

  /// Retire uniquement les mois indiqués (un seul mois, ou une période) sans supprimer
  /// la charge : elle continue normalement en dehors de ces mois.
  void excludeFixedMonths(String id, List<Ym> months) => _set(state.copyWith(
        fixedExpenses: state.fixedExpenses.map((f) {
          if (f.id != id) return f;
          final keys = {...f.excludedMonths, ...months.map((m) => m.key)};
          return f.copyWith(excludedMonths: keys.toList());
        }).toList(),
      ));

  // ---- Projets ----
  void addProject(String name, double target, Ym targetYm, ProjectMode mode,
      {DateTime? tripStart, DateTime? tripEnd, int who = 0}) {
    final start = now.isBefore(state.startYm) ? state.startYm : now;
    _set(state.copyWith(projects: [
      ...state.projects,
      Project(
          id: _id(),
          name: name,
          target: target,
          startYm: start,
          targetYm: targetYm,
          mode: mode,
          tripStart: tripStart,
          tripEnd: tripEnd,
          who: who),
    ]));
  }

  /// Modifie un voyage (nom, budget, mois, mode) en gardant ses versements et ses dépenses.
  void updateProject(String id,
      {required String name,
      required double target,
      required Ym targetYm,
      required ProjectMode mode,
      DateTime? tripStart,
      DateTime? tripEnd,
      int who = 0}) {
    _set(state.copyWith(
      projects: state.projects.map((p) {
        if (p.id != id) return p;
        // Début de l'épargne : on le garde s'il précède encore le mois du voyage.
        final start = p.startYm.isBefore(targetYm) ? p.startYm : targetYm.add(-1);
        return Project(
            id: p.id,
            name: name,
            target: target,
            startYm: start,
            targetYm: targetYm,
            contributions: p.contributions,
            mode: mode,
            tripStart: tripStart,
            tripEnd: tripEnd,
            who: who);
      }).toList(),
    ));
  }

  /// Supprime un voyage et ses dépenses.
  void removeProject(String id) => _set(state.copyWith(
        projects: state.projects.where((p) => p.id != id).toList(),
        transactions: state.transactions.where((t) => t.tripId != id).toList(),
      ));

  /// Marque (ou annule) le versement du mois courant pour un projet.
  void toggleContribution(String projectId) {
    _set(state.copyWith(
      projects: state.projects.map((p) {
        if (p.id != projectId) return p;
        final c = Map<String, double>.from(p.contributions);
        if (c.containsKey(now.key)) {
          c.remove(now.key);
        } else {
          c[now.key] = p.monthlyPlan;
        }
        return p.copyWith(contributions: c);
      }).toList(),
    ));
  }

  // ---- Clôture ----
  /// [deferFixedIds] : charges fixes actives ce mois-ci, non cochées, que l'utilisateur
  /// a choisi de reporter au mois suivant (elles n'ont pas été débitées ce mois).
  /// [deferFixedIds] : charges fixes actives ce mois-ci, non cochées, reportées au mois suivant.
  /// [deferRecurringIds] : revenus récurrents actifs, non pointés, reportés au mois suivant.
  /// [deferOneOffIncomeIds] / [deferTransactionIds] : revenus ponctuels et dépenses non pointés
  /// ce mois-ci, déplacés directement au mois suivant.
  void closeMonth(
    Ym ym, {
    List<String> deferFixedIds = const [],
    List<String> deferRecurringIds = const [],
    List<String> deferOneOffIncomeIds = const [],
    List<String> deferTransactionIds = const [],
  }) {
    final planned = state.plannedIn(ym);
    final spent = state.spentIn(ym);
    final byBudget = {
      for (final b in state.budgets) b.id: b.amountIn(ym) - state.spentForBudget(b, ym),
    };
    // Factures non payées : reportées au mois suivant (retard de paiement)
    final recs = [...state.invoices];
    for (final v in (kInvoicesEnabled ? state.unpaidReceivedIn(ym) : <InvoiceView>[])) {
      final i = recs.indexWhere((r) => r.clientId == v.client.id && r.ym == v.ym);
      final base = i >= 0 ? recs[i] : InvoiceRecord(clientId: v.client.id, ym: v.ym);
      final upd = base.copyWith(receivedYm: ym.add(1), carryLog: [...base.carryLog, ym.key]);
      if (i >= 0) {
        recs[i] = upd;
      } else {
        recs.add(upd);
      }
    }
    // Charges fixes non cochées et reportées : le montant se rajoute au mois suivant.
    final fixed = state.fixedExpenses.map((f) {
      if (deferFixedIds.contains(f.id) && !f.carriedMonths.contains(ym.key)) {
        return f.copyWith(carriedMonths: [...f.carriedMonths, ym.key]);
      }
      return f;
    }).toList();
    // Revenus récurrents non pointés : reportés au mois suivant.
    final recurring = state.recurringIncomes.map((r) {
      if (deferRecurringIds.contains(r.id) && !r.carriedMonths.contains(ym.key)) {
        return r.copyWith(carriedMonths: [...r.carriedMonths, ym.key]);
      }
      return r;
    }).toList();
    // Revenus ponctuels non pointés : déplacés directement au mois suivant.
    final incomes = state.incomes.map((i) {
      if (deferOneOffIncomeIds.contains(i.id) && i.ym == ym) {
        return i.copyWith(ym: ym.add(1), movedFrom: ym);
      }
      return i;
    }).toList();
    // Dépenses non pointées (courses, charges, voyages...) : déplacées au mois suivant.
    final txs = state.transactions.map((t) {
      if (deferTransactionIds.contains(t.id)) {
        return t.copyWith(date: ym.add(1).firstDay, movedFrom: t.date);
      }
      return t;
    }).toList();
    _set(state.copyWith(
      invoices: recs,
      fixedExpenses: fixed,
      recurringIncomes: recurring,
      incomes: incomes,
      transactions: txs,
      snapshots: {
        ...state.snapshots,
        ym.key: MonthSnapshot(
            ym: ym,
            planned: planned,
            spent: spent,
            savingsByCategory: byBudget,
            closedAt: DateTime.now()),
      },
    ));
  }

  void reopenMonth(Ym ym) {
    final s = Map<String, MonthSnapshot>.from(state.snapshots)..remove(ym.key);
    // Annule les reports de factures faits à la clôture de ce mois
    final recs = state.invoices.map((r) {
      if (r.carryLog.isNotEmpty && r.carryLog.last == ym.key) {
        final log = [...r.carryLog]..removeLast();
        return r.ym == ym
            ? r.copyWith(clearReceived: true, carryLog: log)
            : r.copyWith(receivedYm: ym, carryLog: log);
      }
      return r;
    }).toList();
    // Annule les reports de charges fixes faits à la clôture de ce mois
    final fixed = state.fixedExpenses.map((f) {
      if (f.carriedMonths.isNotEmpty && f.carriedMonths.last == ym.key) {
        return f.copyWith(carriedMonths: [...f.carriedMonths]..removeLast());
      }
      return f;
    }).toList();
    // Annule les reports de revenus récurrents faits à la clôture de ce mois
    final recurring = state.recurringIncomes.map((r) {
      if (r.carriedMonths.isNotEmpty && r.carriedMonths.last == ym.key) {
        return r.copyWith(carriedMonths: [...r.carriedMonths]..removeLast());
      }
      return r;
    }).toList();
    // Ramène les revenus ponctuels déplacés lors de cette clôture
    final incomes = state.incomes.map((i) {
      if (i.movedFrom == ym) return i.copyWith(ym: ym, clearMovedFrom: true);
      return i;
    }).toList();
    // Ramène les dépenses déplacées lors de cette clôture
    final txs = state.transactions.map((t) {
      if (t.movedFrom != null && Ym.of(t.movedFrom!) == ym) {
        return t.copyWith(date: t.movedFrom!, clearMovedFrom: true);
      }
      return t;
    }).toList();
    _set(state.copyWith(
        snapshots: s,
        invoices: recs,
        fixedExpenses: fixed,
        recurringIncomes: recurring,
        incomes: incomes,
        transactions: txs));
  }

  // ---- Clients & factures (auto-entrepreneur) ----
  void addClient(Client c) => _set(state.copyWith(clients: [...state.clients, c]));

  void updateClient(Client c) =>
      _set(state.copyWith(clients: state.clients.map((e) => e.id == c.id ? c : e).toList()));

  void removeClient(String id) => _set(state.copyWith(
        clients: state.clients.where((c) => c.id != id).toList(),
        invoices: state.invoices.where((r) => r.clientId != id).toList(),
      ));

  String newId() => _id();

  void _upsertInvoice(String clientId, Ym ym, InvoiceRecord Function(InvoiceRecord) f) {
    final recs = [...state.invoices];
    final i = recs.indexWhere((r) => r.clientId == clientId && r.ym == ym);
    if (i >= 0) {
      recs[i] = f(recs[i]);
    } else {
      recs.add(f(InvoiceRecord(clientId: clientId, ym: ym)));
    }
    _set(state.copyWith(invoices: recs));
  }

  /// Modifie la facture à la main : soit le nombre de passages, soit le montant
  /// (l'autre est recalculé). Sans argument : retour au calcul automatique.
  void setInvoiceOverride(String clientId, Ym ym, {double? visits, double? amount}) {
    _upsertInvoice(clientId, ym, (r) {
      final base = r.copyWith(clearOverrides: true);
      if (visits != null) {
        return InvoiceRecord(
            clientId: base.clientId,
            ym: base.ym,
            overrideVisits: visits,
            sent: base.sent,
            paid: base.paid,
            receivedYm: base.receivedYm,
            carryLog: base.carryLog);
      }
      if (amount != null) {
        return InvoiceRecord(
            clientId: base.clientId,
            ym: base.ym,
            overrideAmount: amount,
            sent: base.sent,
            paid: base.paid,
            receivedYm: base.receivedYm,
            carryLog: base.carryLog);
      }
      return base;
    });
  }

  void toggleInvoiceSent(String clientId, Ym ym) =>
      _upsertInvoice(clientId, ym, (r) => r.copyWith(sent: !r.sent));

  /// Marque la facture payée / non payée. Payée plus tard que prévu : l'argent est
  /// compté dans le mois où il arrive.
  void toggleInvoicePaid(String clientId, Ym ym) {
    final current = now;
    _upsertInvoice(clientId, ym, (r) {
      final nowPaid = !r.paid;
      Ym? recv;
      if (nowPaid) {
        final base = r.receivedYm ?? ym;
        if (current.isAfter(base)) recv = current;
      }
      return r.copyWith(paid: nowPaid, receivedYm: recv);
    });
  }

  // ---- Auto-entrepreneur ----
  void setAutoEntrepreneur({bool? me, bool? partner}) =>
      _set(state.copyWith(user: state.user.copyWith(ae1: me, ae2: partner)));

  void setUrssafRate(double rate) =>
      _set(state.copyWith(user: state.user.copyWith(urssafRate: rate)));

  // ---- Réglages ----
  void setStartBalance(double v) => _set(state.copyWith(startBalance: v));

  void setReduceMotion(bool v) => _set(state.copyWith(user: state.user.copyWith(reduceMotion: v)));

  /// Fin de l'assistant de configuration : remplace les données par celles saisies.
  void completeOnboarding(AppData d) => _set(d);

  /// « Passer » : on garde les données d'exemple.
  void skipOnboarding() =>
      _set(state.copyWith(user: state.user.copyWith(onboarded: true, tourSeen: false)));

  void markTourSeen() {
    if (state.user.tourSeen) return;
    _set(state.copyWith(user: state.user.copyWith(tourSeen: true)));
  }

  void setUiScale(double v) => _set(state.copyWith(user: state.user.copyWith(uiScale: v)));

  /// Active/désactive le mode couple.
  /// Activation : chaque budget existant devient celui de la personne 1 et est
  /// dupliqué pour la personne 2 ; les dépenses existantes passent à la personne 1.
  /// Désactivation : on garde les budgets de la personne 1 (budget "seul"), ceux
  /// de la personne 2 sont supprimés, et toutes les dépenses restent comptées.
  void setCouple(bool couple, {String? person1, String? person2}) {
    final u = state.user;
    final names = u.copyWith(
      person1: (person1 ?? u.person1).trim().isEmpty ? u.person1 : (person1 ?? u.person1).trim(),
      person2: (person2 ?? u.person2).trim().isEmpty ? u.person2 : (person2 ?? u.person2).trim(),
    );
    if (couple == u.isCouple) {
      _set(state.copyWith(user: names));
      return;
    }
    if (couple) {
      _set(state.copyWith(
        user: names.copyWith(isCouple: true),
        transactions: [for (final t in state.transactions) t.copyWith(person: 1)],
      ));
    } else {
      _set(state.copyWith(
        user: names.copyWith(isCouple: false),
        budgets: _mergedBudgets(),
        transactions: [for (final t in state.transactions) t.copyWith(person: 0)],
      ));
    }
  }

  /// Fusionne les budgets séparés (un par conjoint) en un budget commun (somme).
  List<Budget> _mergedBudgets([String? onlyCategory]) {
    final out = <Budget>[];
    for (final c in state.budgets.map((b) => b.categoryId).toSet()) {
      final bs = state.budgets.where((b) => b.categoryId == c).toList();
      if ((onlyCategory != null && c != onlyCategory) || bs.length == 1) {
        out.addAll(bs.length == 1 ? [bs.first.copyWith(person: 0)] : bs);
        continue;
      }
      final a = bs.firstWhere((b) => b.person != 2, orElse: () => bs.first);
      final keys = <String>{for (final b in bs) ...b.overrides.keys};
      out.add(a.copyWith(
        person: 0,
        amount: bs.fold<double>(0.0, (s, b) => s + b.amount),
        overrides: {
          for (final k in keys) k: bs.fold<double>(0.0, (s, b) => s + (b.overrides[k] ?? b.amount)),
        },
      ));
    }
    return out;
  }

  /// Couple : un budget commun, ou un budget par personne, pour une catégorie.
  void setBudgetSeparate(String categoryId, bool separate) {
    if (!state.isCouple) return;
    final bs = state.budgets.where((b) => b.categoryId == categoryId).toList();
    if (bs.isEmpty || separate == bs.any((b) => b.person != 0)) return;
    if (separate) {
      final b = bs.first;
      final ov = {for (final e in b.overrides.entries) e.key: e.value / 2};
      _set(state.copyWith(budgets: [
        ...state.budgets.where((x) => x.categoryId != categoryId),
        for (final p in [1, 2]) b.copyWith(id: '${b.id}_p$p', person: p, amount: b.amount / 2, overrides: ov),
      ]));
    } else {
      _set(state.copyWith(budgets: _mergedBudgets(categoryId)));
    }
  }

  /// Photo de profil d'une personne (null = retirer).
  void setPhoto(int person, String? base64) => _set(state.copyWith(
      user: person == 2
          ? state.user.copyWith(photo2: base64, clearPhoto2: base64 == null)
          : state.user.copyWith(photo1: base64, clearPhoto1: base64 == null)));

  Future<void> resetDemo({bool onboarded = true}) async {
    state = SeedData.create(realNow, onboarded: onboarded);
    await repo.save(state);
    onChanged?.call();
  }
}
