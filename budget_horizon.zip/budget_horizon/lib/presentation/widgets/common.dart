import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../screens/settings_screen.dart';
import '../tour.dart';

/// Navigation instantanée (aucune animation de transition).
class QuickRoute<T> extends MaterialPageRoute<T> {
  QuickRoute({required super.builder});
  @override
  Duration get transitionDuration => Duration.zero;
  @override
  Duration get reverseTransitionDuration => Duration.zero;
}

/// Boîte de dialogue sans animation d'ouverture.
Future<T?> showQuickDialog<T>({required BuildContext context, required WidgetBuilder builder}) =>
    showDialog<T>(context: context, builder: builder, animationStyle: AnimationStyle.noAnimation);

/// Fond dégradé lavande → menthe, posé derrière toutes les pages.
class AppBackground extends ConsumerWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final idx = ref.watch(appProvider.select((d) => d.user.themeIndex));
    final palette = appThemes[idx.clamp(0, appThemes.length - 1)];
    return Container(
      decoration: BoxDecoration(gradient: dark ? palette.pageDark : palette.page),
      child: child,
    );
  }
}

/// Carte arrondie. Si [onTap] est fourni : la carte s'assombrit instantanément au toucher.
class AppCard extends StatefulWidget {
  final Widget child;
  final EdgeInsets padding;
  final Gradient? gradient;
  final VoidCallback? onTap;
  const AppCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.gradient,
    this.onTap,
  });

  @override
  State<AppCard> createState() => _AppCardState();
}

class _AppCardState extends State<AppCard> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    final card = Container(
      decoration: BoxDecoration(
        color: widget.gradient == null
            ? (Theme.of(context).brightness == Brightness.dark
                ? AppColors.cardDark.withAlpha(_down ? 180 : 255)
                : Colors.white.withAlpha(_down ? 150 : 215))
            : null,
        gradient: widget.gradient,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white.withAlpha(15)
              : Colors.white.withAlpha(200),
        ),
        boxShadow: Theme.of(context).brightness == Brightness.dark
            ? [BoxShadow(color: Colors.black.withAlpha(60), blurRadius: 14, offset: const Offset(0, 5))]
            : const [BoxShadow(color: Color(0x0D2A2F6B), blurRadius: 14, offset: Offset(0, 5))],
      ),
      // Material transparent : permet aux ListTile & co. de fonctionner dans la carte
      child: Material(
        type: MaterialType.transparency,
        child: Padding(padding: widget.padding, child: widget.child),
      ),
    );
    if (widget.onTap == null) return RepaintBoundary(child: card);
    return RepaintBoundary(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) => setState(() => _down = false),
        onTapCancel: () => setState(() => _down = false),
        onTap: widget.onTap,
        child: card,
      ),
    );
  }
}

/// Avatar d'une personne : sa photo si elle existe, sinon son initiale.
class PersonAvatar extends ConsumerWidget {
  final int person;
  final double size;
  const PersonAvatar({super.key, required this.person, this.size = 30});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final b64 = person == 2 ? d.user.photo2 : d.user.photo1;
    final name = d.personName(person == 2 ? 2 : 1);
    final initial = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: const BoxDecoration(gradient: brandGradient, shape: BoxShape.circle),
      child: Text(name.isEmpty ? '?' : name.characters.first.toUpperCase(),
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: size * .45)),
    );
    if (b64 == null || b64.isEmpty) return initial;
    try {
      return ClipOval(
        child: Image.memory(base64Decode(b64),
            width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, __, ___) => initial),
      );
    } catch (_) {
      return initial;
    }
  }
}

/// Bouton des réglages (en haut à droite de chaque page).
class SettingsButton extends StatelessWidget {
  const SettingsButton({super.key});

  @override
  Widget build(BuildContext context) => RoundIconButton(
        key: TourKeys.settings,
        icon: Icons.tune_rounded,
        size: 40,
        onTap: () => Navigator.push(context, QuickRoute(builder: (_) => const SettingsScreen())),
      );
}

class RoundIconButton extends StatelessWidget {
  final IconData icon;
  final double size;
  final VoidCallback? onTap;
  const RoundIconButton({super.key, required this.icon, this.size = 38, this.onTap});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: dark ? AppColors.fieldDark.withAlpha(200) : Colors.white.withAlpha(150),
      shape: CircleBorder(side: BorderSide(color: dark ? AppColors.trackDark : Colors.white.withAlpha(220))),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(width: size, height: size, child: Icon(icon, size: size * .47, color: context.textColor)),
      ),
    );
  }
}

/// Page : grand titre + boutons + contenu. Aucune animation.
/// Flèches « annuler / rétablir » pour les dernières modifications de données.
class UndoRedoButtons extends ConsumerWidget {
  const UndoRedoButtons({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(appProvider); // se reconstruit à chaque modification
    final n = ref.read(appProvider.notifier);
    return Row(children: [
      Opacity(
        opacity: n.canUndo ? 1 : .35,
        child: RoundIconButton(icon: Icons.undo_rounded, size: 40, onTap: n.canUndo ? n.undo : null),
      ),
      const SizedBox(width: 8),
      Opacity(
        opacity: n.canRedo ? 1 : .35,
        child: RoundIconButton(icon: Icons.redo_rounded, size: 40, onTap: n.canRedo ? n.redo : null),
      ),
    ]);
  }
}

class ScreenScaffold extends ConsumerStatefulWidget {
  final String title;
  final List<Widget> actions;
  final List<Widget> children;
  /// Élément toujours visible en haut de la page, même en faisant défiler (ex. le mois).
  final Widget? pinned;
  const ScreenScaffold({
    super.key,
    required this.title,
    required this.children,
    this.actions = const [],
    this.pinned,
  });

  @override
  ConsumerState<ScreenScaffold> createState() => _ScreenScaffoldState();
}

class _ScreenScaffoldState extends ConsumerState<ScreenScaffold> {
  final _ctl = ScrollController();

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Toucher l'onglet déjà affiché : retour en haut de la page.
    ref.listen<int>(scrollTopTickProvider, (_, __) {
      if (_ctl.hasClients) {
        _ctl.animateTo(0, duration: const Duration(milliseconds: 450), curve: Curves.easeOutCubic);
      }
    });
    final header = Row(children: [
      Expanded(
        child: widget.title.isEmpty
            ? const SizedBox(height: 40)
            : Text(widget.title,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
      ),
      const UndoRedoButtons(),
      const SizedBox(width: 8),
      for (final a in widget.actions) ...[a, const SizedBox(width: 8)],
      const SettingsButton(),
    ]);
    final list = ListView(
      key: PageStorageKey<String>('scroll_${widget.title.isEmpty ? 'home' : widget.title}'),
      controller: _ctl,
      cacheExtent: 5000, // tout est construit : la démonstration doit pouvoir atteindre chaque élément
      padding: EdgeInsets.fromLTRB(16, widget.pinned == null ? 10 : 6, 16, 96), // place pour le bouton +
      children: [
        if (widget.pinned == null) ...[header, const SizedBox(height: 12)],
        ...widget.children,
      ],
    );
    return SafeArea(
      bottom: false,
      child: widget.pinned == null
          ? list
          : Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: Column(children: [header, const SizedBox(height: 10), widget.pinned!]),
              ),
              Expanded(child: list),
            ]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  final Widget? trailing;
  const SectionTitle(this.text, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 8),
        child: Row(children: [
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
          if (trailing != null) trailing!,
        ]),
      );
}

/// Barre de progression fine.
class AppProgress extends StatelessWidget {
  final double value;
  final Color color;
  const AppProgress({super.key, required this.value, this.color = AppColors.teal});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Container(
          height: 6,
          color: dark ? AppColors.trackDark : AppColors.track,
          alignment: Alignment.centerLeft,
          child: FractionallySizedBox(
            widthFactor: value.clamp(0.0, 1.0),
            child: Container(color: color),
          ),
        ),
      );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  const GradientButton({super.key, required this.label, this.icon, this.onPressed});

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return Opacity(
      opacity: enabled ? 1 : .45,
      child: Container(
        decoration: BoxDecoration(
          gradient: brandGradient,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(color: tint(AppColors.violet, .22), blurRadius: 14, offset: const Offset(0, 6)),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: onPressed,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[Icon(icon, color: context.textColor, size: 20), const SizedBox(width: 8)],
                  Flexible(
                    child: Text(label,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: context.textColor, fontWeight: FontWeight.w700, fontSize: 15)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SoftButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  const SoftButton({super.key, required this.label, this.icon, this.onPressed});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        child: TextButton.icon(
          onPressed: onPressed,
          icon: icon == null ? const SizedBox.shrink() : Icon(icon, size: 17),
          label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          style: TextButton.styleFrom(
            foregroundColor: context.textColor,
            disabledForegroundColor: context.mutedColor,
            backgroundColor: context.fieldColor,
            padding: const EdgeInsets.symmetric(vertical: 13),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
      );
}

class BudgetRow extends StatelessWidget {
  final String emoji;
  final String name;
  final double spent;
  final double planned;
  final Color? tileColor;
  final VoidCallback? onTap;
  const BudgetRow(
      {super.key,
      required this.emoji,
      required this.name,
      required this.spent,
      required this.planned,
      this.tileColor,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = ratio >= 1
        ? AppColors.danger
        : ratio >= .8
            ? AppColors.warning
            : AppColors.teal;
    final baseColor = tileColor ?? AppColors.violet;
    return GestureDetector(
      onTap: onTap,
      child: Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: tint(baseColor, .08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          if (emoji.isNotEmpty) ...[
            CircleEmoji(emoji, baseColor, size: 36),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Text(name,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(_e(spent),
                style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                    color: color)),
            Text('sur ${_e(planned)}',
                style: const TextStyle(
                    color: AppColors.muted,
                    fontWeight: FontWeight.w500,
                    fontSize: 12)),
          ]),
        ]),
        const SizedBox(height: 10),
        AppProgress(value: ratio, color: color),
        const SizedBox(height: 4),
        Text(
          ratio >= 1
              ? 'Budget dépassé'
              : '${_e(planned - spent)} restant · ${(ratio * 100).round()}%',
          style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: ratio >= 1 ? AppColors.danger : AppColors.muted),
        ),
      ]),
    ),  // Container
    ); // GestureDetector
  }
}

/// Cercle de progression qui remplit vraiment tout son SizedBox.
/// [value] entre 0.0 et 1.0, [strokeWidth] en pixels logiques.
class ArcProgress extends StatelessWidget {
  final double value;
  final Color color;
  final Color trackColor;
  final double strokeWidth;
  final Widget? child;
  const ArcProgress({
    super.key,
    required this.value,
    required this.color,
    required this.trackColor,
    this.strokeWidth = 10,
    this.child,
  });

  @override
  Widget build(BuildContext context) => CustomPaint(
        painter: _ArcPainter(
          value: value.clamp(0.0, 1.0),
          color: color,
          trackColor: trackColor,
          strokeWidth: strokeWidth,
        ),
        child: child != null ? Center(child: child) : null,
      );
}

class _ArcPainter extends CustomPainter {
  final double value;
  final Color color;
  final Color trackColor;
  final double strokeWidth;
  const _ArcPainter({
    required this.value,
    required this.color,
    required this.trackColor,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;
    final radius = (size.shortestSide - strokeWidth) / 2;
    final rect = Rect.fromCircle(center: Offset(cx, cy), radius: radius);
    const start = -90 * 3.14159265 / 180; // 12h

    // Fond
    canvas.drawArc(rect, 0, 2 * 3.14159265, false,
        Paint()
          ..color = trackColor
          ..style = PaintingStyle.stroke
          ..strokeWidth = strokeWidth
          ..strokeCap = StrokeCap.round);

    if (value > 0) {
      // Arc coloré
      canvas.drawArc(rect, start, value * 2 * 3.14159265, false,
          Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = strokeWidth
            ..strokeCap = StrokeCap.round);
    }
  }

  @override
  bool shouldRepaint(_ArcPainter old) =>
      old.value != value || old.color != color;
}

String _e(double v) => eur(v);


/// Bulle verticale pour les budgets séparés d'une personne.
/// Affiche avatar + prénom en en-tête, puis une ligne par catégorie.
class PersonBudgetBubble extends ConsumerWidget {
  final int person;
  final List<({Category cat, String? budgetId, double spent, double planned})> items;
  final Ym? month;
  final void Function(String budgetId, Category cat, int person, Ym month)? onItemTap;
  const PersonBudgetBubble({
    super.key,
    required this.person,
    required this.items,
    this.month,
    this.onItemTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Couleur dominante : première catégorie (pour le fond de la bulle)
    final bubbleColor = items.isNotEmpty ? Color(items.first.cat.colorValue) : AppColors.violet;

    return Container(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: tint(bubbleColor, .06),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          PersonAvatar(person: person, size: 22),
          const SizedBox(width: 7),
          Expanded(
            child: Text(ref.read(appProvider).personName(person),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          ),
        ]),
        const SizedBox(height: 8),
        const Divider(height: 1),
        for (final e in items) ...[
          const SizedBox(height: 10),
          Builder(builder: (ctx) {
            final catColor = Color(e.cat.colorValue);
            final ratio = e.planned <= 0 ? (e.spent > 0 ? 1.0 : 0.0) : e.spent / e.planned;
            final statusColor = ratio >= 1 ? AppColors.danger : ratio >= .8 ? AppColors.warning : AppColors.teal;
            final tile = Container(
              padding: const EdgeInsets.fromLTRB(10, 9, 10, 9),
              decoration: BoxDecoration(
                color: tint(catColor, .10),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(e.cat.emoji, style: const TextStyle(fontSize: 14)),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(e.cat.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  ),
                ]),
                const SizedBox(height: 4),
                Text(eur(e.spent),
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: statusColor)),
                Text('sur ${eur(e.planned)}',
                    style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w500, fontSize: 12)),
                const SizedBox(height: 6),
                AppProgress(value: ratio, color: statusColor),
                const SizedBox(height: 3),
                Text(
                  ratio >= 1 ? 'Budget dépassé' : '${eur(e.planned - e.spent)} restant · ${(ratio * 100).round()}%',
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600,
                      color: ratio >= 1 ? AppColors.danger : AppColors.muted),
                ),
              ]),
            );
            if (e.budgetId != null && month != null && onItemTap != null) {
              return GestureDetector(
                onTap: () => onItemTap!(e.budgetId!, e.cat, person, month!),
                child: tile,
              );
            }
            return tile;
          }),
        ],
      ]),
    );
  }
}

class MonthSwitcher extends StatelessWidget {
  final Ym value;
  final Ym min;
  final ValueChanged<Ym> onChanged;
  final Ym? now;
  final bool showCalendar;
  const MonthSwitcher(
      {super.key,
      required this.value,
      required this.min,
      required this.onChanged,
      this.now,
      this.showCalendar = true});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          IconButton(
            onPressed: value.index <= min.index ? null : () => onChanged(value.add(-1)),
            icon: const Icon(Icons.chevron_left_rounded),
          ),
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () async {
                final y = await pickYm(context, value);
                if (y != null) onChanged(y);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: context.fieldColor,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.calendar_month_rounded, size: 16, color: AppColors.violet),
                  const SizedBox(width: 6),
                  Text(value.label,
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                          color: context.textColor)),
                  const Icon(Icons.arrow_drop_down_rounded, size: 18, color: AppColors.muted),
                ]),
              ),
            ),
          ),
          // ── Retour au mois actuel (remplace le > quand on est en avance/retard) ──
          if (now != null && value != now)
            IconButton(
              onPressed: () => onChanged(now!),
              tooltip: 'Mois actuel',
              icon: const Icon(Icons.replay_rounded, size: 22, color: AppColors.violet),
            )
          else
            IconButton(
              onPressed: () => onChanged(value.add(1)),
              icon: const Icon(Icons.chevron_right_rounded),
            ),
        ],
      );
}

/// Pastille d'icône vive : dégradé de la couleur choisie, avec un emoji
/// ou (si [letter]) une lettre blanche.
class CircleEmoji extends StatelessWidget {
  final String emoji;
  final Color color;
  final double size;
  final bool letter;
  const CircleEmoji(this.emoji, this.color, {super.key, this.size = 44, this.letter = false});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [color, Color.lerp(color, Colors.white, .38)!],
          ),
          borderRadius: BorderRadius.circular(size * .32),
          boxShadow: [BoxShadow(color: tint(color, .35), blurRadius: 8, offset: const Offset(0, 3))],
        ),
        child: letter
            ? Text(emoji,
                style: TextStyle(fontSize: size * .48, fontWeight: FontWeight.w800, color: Colors.white))
            : Text(emoji, style: TextStyle(fontSize: size * .54)),
      );
}

/// Case à cocher ronde façon application bancaire (opération pointée).
class CheckCircle extends StatelessWidget {
  final bool checked;
  final VoidCallback? onTap;
  const CheckCircle({super.key, required this.checked, this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap == null ? null : () {
          HapticFeedback.mediumImpact();
          onTap!();
        },
        child: Padding(
          padding: const EdgeInsets.all(6),
          child: Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: checked ? AppColors.success : Colors.transparent,
              border: Border.all(color: checked ? AppColors.success : const Color(0xFFC5C9D6).withAlpha(Theme.of(context).brightness == Brightness.dark ? 80 : 255), width: 2),
            ),
            child: checked ? const Icon(Icons.check_rounded, size: 17, color: Colors.white) : null,
          ),
        ),
      );
}

Future<T?> showSheet<T>(BuildContext context, {
  required String title,
  required Widget child,
  Widget? stickyHeader, // widget affiché sous le titre, non scrollable
}) {
  final bg = Theme.of(context).brightness == Brightness.dark
      ? AppColors.fieldDark
      : Colors.white;
  final handleColor = const Color(0xFFD9DCE8).withAlpha(
      Theme.of(context).brightness == Brightness.dark ? 60 : 255);

  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    enableDrag: true,
    backgroundColor: bg,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) {
      final bottom = MediaQuery.of(ctx).viewInsets.bottom;
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Poignée + titre (non scrollables, draggables) ──────
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onVerticalDragUpdate: (d) {
              if ((d.primaryDelta ?? 0) > 6) Navigator.of(ctx).pop();
            },
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 38, height: 4,
                      decoration: BoxDecoration(
                          color: handleColor,
                          borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(title,
                      style: const TextStyle(
                          fontSize: 19, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 14),
                ],
              ),
            ),
          ),
          // ── Header sticky (tri, etc.) ───────────────────────────
          if (stickyHeader != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
              child: stickyHeader,
            ),
          // ── Contenu scrollable ─────────────────────────────────
          Flexible(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(18, 0, 18, bottom + 20),
              child: child,
            ),
          ),
        ],
      );
    },
  );
}

const _calWeekdays = ['Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa', 'Di'];

/// Calendrier compact, utilisé partout dans l'app pour choisir une date ou une période :
/// touchez un jour (et, en mode période, un second jour pour l'intervalle). Le bouton
/// « Aujourd'hui » dans l'en-tête permet de revenir vite au mois actuel, et les doubles
/// flèches changent d'année rapidement.
class RangeCalendarSheet extends StatefulWidget {
  final DateTime initialMonth;
  final DateTime? initialStart;
  final DateTime? initialEnd;
  final bool rangeMode; // faux : un seul jour, validé dès qu'on le touche
  const RangeCalendarSheet(
      {super.key, required this.initialMonth, this.initialStart, this.initialEnd, this.rangeMode = true});

  @override
  State<RangeCalendarSheet> createState() => _RangeCalendarSheetState();
}

class _RangeCalendarSheetState extends State<RangeCalendarSheet> {
  late DateTime _month = DateTime(widget.initialMonth.year, widget.initialMonth.month, 1);
  late DateTime? _start = widget.initialStart;
  late DateTime? _end = widget.initialEnd;
  bool _picker = false; // vrai : choix rapide de l'année et du mois
  final _yearsCtl = ScrollController();

  @override
  void dispose() {
    _yearsCtl.dispose();
    super.dispose();
  }

  bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  void _tapDay(DateTime d) {
    if (!widget.rangeMode) {
      Navigator.pop(context, DateTimeRange(start: d, end: d));
      return;
    }
    setState(() {
      if (_start == null || _end != null) {
        _start = d;
        _end = null;
      } else if (d.isBefore(_start!)) {
        _start = d;
      } else {
        _end = d;
      }
    });
  }

  /// Choix rapide : bande d'années qui défile + les 12 mois.
  Widget _quickPicker(DateTime now) {
    final first = now.year - 3;
    const months = ['Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'];
    return Column(children: [
      SizedBox(
        height: 44,
        child: ListView.builder(
          controller: _yearsCtl,
          scrollDirection: Axis.horizontal,
          itemCount: 25,
          itemBuilder: (_, i) {
            final y = first + i;
            final sel = y == _month.year;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: SizedBox(
                width: 64,
                child: ChoiceChip(
                  showCheckmark: false,
                  label: SizedBox(width: double.infinity, child: Text('$y', textAlign: TextAlign.center)),
                  selected: sel,
                  onSelected: (_) => setState(() => _month = DateTime(y, _month.month, 1)),
                ),
              ),
            );
          },
        ),
      ),
      const SizedBox(height: 10),
      Expanded(
        child: GridView.count(
          crossAxisCount: 3,
          childAspectRatio: 2.2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            for (var m = 1; m <= 12; m++)
              GestureDetector(
                onTap: () => setState(() {
                  _month = DateTime(_month.year, m, 1);
                  _picker = false;
                }),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: m == _month.month ? AppColors.violet : context.fieldColor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(months[m - 1],
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: m == _month.month ? Colors.white : context.textColor)),
                ),
              ),
          ],
        ),
      ),
    ]);
  }

  void _goToMonth(int delta) => setState(() => _month = DateTime(_month.year, _month.month + delta, 1));
  void _goToYear(int delta) => setState(() => _month = DateTime(_month.year + delta, _month.month, 1));

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final onCurrentMonth = _month.year == today.year && _month.month == today.month;
    final daysInMonth = DateTime(_month.year, _month.month + 1, 0).day;
    final leading = _month.weekday - 1; // lundi = 0 espace vide

    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        IconButton(
            tooltip: 'Année précédente',
            onPressed: () => _goToYear(-1),
            icon: const Icon(Icons.keyboard_double_arrow_left_rounded, size: 20)),
        IconButton(onPressed: () => _goToMonth(-1), icon: const Icon(Icons.chevron_left_rounded)),
        // Toucher le mois : choix rapide de l'année et du mois
        Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              setState(() => _picker = !_picker);
              if (_picker) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (_yearsCtl.hasClients) {
                    final i = _month.year - (now.year - 3);
                    _yearsCtl.jumpTo(((i - 1) * 72.0).clamp(0.0, _yearsCtl.position.maxScrollExtent));
                  }
                });
              }
            },
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Flexible(
                child: Text(Ym.of(_month).label,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              ),
              Icon(_picker ? Icons.arrow_drop_up_rounded : Icons.arrow_drop_down_rounded, color: AppColors.muted),
            ]),
          ),
        ),
        IconButton(onPressed: () => _goToMonth(1), icon: const Icon(Icons.chevron_right_rounded)),
        IconButton(
            tooltip: 'Année suivante',
            onPressed: () => _goToYear(1),
            icon: const Icon(Icons.keyboard_double_arrow_right_rounded, size: 20)),
        IconButton.filledTonal(
          tooltip: 'Aujourd\'hui',
          onPressed: onCurrentMonth ? null : () => setState(() => _month = DateTime(today.year, today.month, 1)),
          icon: const Icon(Icons.today_rounded, size: 20),
        ),
      ]),
      const SizedBox(height: 6),
      // Hauteur toujours identique (6 semaines) : les flèches ne bougent plus d'un mois à l'autre
      AspectRatio(
        aspectRatio: 7 / 6.8,
        child: _picker ? _quickPicker(now) : Column(children: [
      Row(children: [
        for (final n in _calWeekdays)
          Expanded(
            child: Center(
              child: Text(n, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12)),
            ),
          ),
      ]),
      const SizedBox(height: 6),
      GridView.count(
        crossAxisCount: 7,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          for (var i = 0; i < leading; i++) const SizedBox.shrink(),
          for (var day = 1; day <= daysInMonth; day++)
            Builder(builder: (_) {
              final d = DateTime(_month.year, _month.month, day);
              final isStart = _start != null && _sameDay(d, _start!);
              final isEnd = _end != null && _sameDay(d, _end!);
              final inRange = widget.rangeMode &&
                  _start != null &&
                  _end != null &&
                  !d.isBefore(_start!) &&
                  !d.isAfter(_end!);
              final isToday = _sameDay(d, today);
              final selected = isStart || isEnd;
              return GestureDetector(
                onTap: () => _tapDay(d),
                child: Container(
                  margin: const EdgeInsets.all(2),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected
                        ? AppColors.violet
                        : (inRange ? tint(AppColors.violet, .18) : Colors.transparent),
                    shape: BoxShape.circle,
                    border: isToday && !selected ? Border.all(color: AppColors.violet, width: 1.4) : null,
                  ),
                  child: Text('$day',
                      style: TextStyle(
                          fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                          color: selected ? Colors.white : context.textColor)),
                ),
              );
            }),
          // cases vides pour compléter 6 semaines
          for (var i = leading + daysInMonth; i < 42; i++) const SizedBox.shrink(),
        ],
      ),
        ]),
      ),
      if (widget.rangeMode) ...[
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler'))),
          const SizedBox(width: 8),
          Expanded(
            child: GradientButton(
              label: 'Valider',
              onPressed: _start == null
                  ? null
                  : () => Navigator.pop(context, DateTimeRange(start: _start!, end: _end ?? _start!)),
            ),
          ),
        ]),
      ],
    ]);
  }
}

/// Un seul jour, avec la même présentation que le calendrier des voyages.
Future<DateTime?> pickDay(BuildContext context, DateTime initial) async {
  final r = await showSheet<DateTimeRange>(
    context,
    title: 'Choisir une date',
    child: RangeCalendarSheet(initialMonth: initial, initialStart: initial, rangeMode: false),
  );
  return r?.start;
}

/// Grille des 12 mois d'une année, même présentation (doubles flèches, « Aujourd'hui »).
class MonthGridSheet extends StatefulWidget {
  final int initialYear;
  final int? initialMonth; // mois déjà choisi, mis en évidence
  const MonthGridSheet({super.key, required this.initialYear, this.initialMonth});

  @override
  State<MonthGridSheet> createState() => _MonthGridSheetState();
}

class _MonthGridSheetState extends State<MonthGridSheet> {
  late int _year = widget.initialYear;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        IconButton(
            tooltip: 'Année précédente',
            onPressed: () => setState(() => _year--),
            icon: const Icon(Icons.chevron_left_rounded)),
        Expanded(
          child: Text('$_year',
              textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ),
        IconButton(
            tooltip: 'Année suivante',
            onPressed: () => setState(() => _year++),
            icon: const Icon(Icons.chevron_right_rounded)),
        IconButton.filledTonal(
          tooltip: 'Année actuelle',
          onPressed: _year == now.year ? null : () => setState(() => _year = now.year),
          icon: const Icon(Icons.today_rounded, size: 20),
        ),
      ]),
      const SizedBox(height: 10),
      GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 2.1,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        children: [
          for (var m = 1; m <= 12; m++)
            Builder(builder: (_) {
              final selected = widget.initialMonth == m && widget.initialYear == _year;
              final isCurrent = m == now.month && _year == now.year;
              return GestureDetector(
                onTap: () => Navigator.pop(context, Ym(_year, m)),
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: selected ? AppColors.violet : context.fieldColor,
                    borderRadius: BorderRadius.circular(14),
                    border: isCurrent && !selected ? Border.all(color: AppColors.violet, width: 1.4) : null,
                  ),
                  child: Text(Ym(_year, m).short,
                      style: TextStyle(
                          fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                          color: selected ? Colors.white : context.textColor)),
                ),
              );
            }),
        ],
      ),
    ]);
  }
}

Future<Ym?> pickYm(BuildContext context, Ym initial) =>
    showSheet<Ym>(context, title: 'Choisir un mois', child: MonthGridSheet(initialYear: initial.year, initialMonth: initial.month));

/// Bouton calendrier cohérent en haut des pages avec un sélecteur de mois : ouvre le
/// même calendrier partout pour choisir directement n'importe quel mois.
class MonthCalendarButton extends StatelessWidget {
  final Ym value;
  final ValueChanged<Ym> onChanged;
  const MonthCalendarButton({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => RoundIconButton(
        icon: Icons.calendar_month_rounded,
        size: 40,
        onTap: () async {
          final y = await pickYm(context, value);
          if (y != null) onChanged(y);
        },
      );
}


void snack(BuildContext context, String text, {String? actionLabel, VoidCallback? onAction}) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(text),
    behavior: SnackBarBehavior.floating,
    duration: Duration(seconds: onAction == null ? 3 : 6),
    action: onAction == null ? null : SnackBarAction(label: actionLabel ?? 'Annuler', onPressed: onAction),
  ));
}


/// Haut de l'onglet « Récurrent » : bascule entre Charges et Revenus.
class FixesSwitch extends ConsumerWidget {
  const FixesSwitch({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cur = ref.watch(tabProvider);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: SizedBox(
        width: double.infinity,
        child: SegmentedButton<AppTab>(
          segments: const [
            ButtonSegment(
                value: AppTab.charges,
                label: Text('Charges'),
                icon: Icon(Icons.repeat_rounded)),
            ButtonSegment(
                value: AppTab.incomes,
                label: Text('Revenus'),
                icon: Icon(Icons.trending_up_rounded)),
          ],
          selected: {cur},
          showSelectedIcon: false,
          onSelectionChanged: (s) => ref.read(tabProvider.notifier).state = s.first,
          style: SegmentedButton.styleFrom(
            selectedBackgroundColor: AppColors.violet,
            selectedForegroundColor: Colors.white,
            textStyle: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
      ),
    );
  }
}
