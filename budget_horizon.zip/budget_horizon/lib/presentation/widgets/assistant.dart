import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';

/// Assistant vocal 100 % local (gratuit, sans clé, sans connexion) :
/// la dictée du clavier de l'iPhone transcrit la phrase (le module de reconnaissance
/// vocale du navigateur faisait planter l'app installée sur l'écran d'accueil), l'app la comprend avec des règles simples,
/// pose une question s'il manque un détail, puis enregistre.

/// Bouton rond ✨ en bas à gauche de l'écran : ouvre l'assistant.
class AssistantFab extends StatelessWidget {
  const AssistantFab({super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 56,
        height: 56,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          border: Border.all(color: Colors.white),
          boxShadow: [BoxShadow(color: tint(AppColors.violet, .35), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Material(
          color: Colors.transparent,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => showSheet(context, title: 'Assistant', child: const AssistantSheet()),
            child: ShaderMask(
              shaderCallback: (r) => brandGradient.createShader(r),
              child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 26),
            ),
          ),
        ),
      );
}

// ------------------------------------------------------------------ Analyse

enum _Kind { expense, income, recurringIncome, fixed, budget }

enum _Ask { none, amount, category, person, name, kind, confirm }

/// Ce que l'assistant a compris jusqu'ici.
class _Draft {
  _Kind? kind;
  double? amount;
  String? categoryId; // catégorie, kUnexpectedId ou kTripCatId
  String? tripId;
  int? person;
  String? label;
  DateTime date = DateTime.now();
  Ym? month;
  int interval = 1;
  IncomeKind incomeKind = IncomeKind.bonus;
}

/// Minuscules sans accents, pour comparer facilement.
String _norm(String s) {
  const from = 'àâäáãéèêëíìîïóòôöõúùûüçœ’';
  const to = 'aaaaaeeeeiiiiooooouuuuco\'';
  final b = StringBuffer();
  for (final ch in s.toLowerCase().split('')) {
    final i = from.indexOf(ch);
    b.write(i >= 0 ? to[i] : ch);
  }
  return b.toString();
}

bool _has(String t, List<String> words) =>
    words.any((w) => RegExp('(^|[^a-z])${RegExp.escape(w)}([^a-z]|\$)').hasMatch(t));

const _months = [
  'janvier', 'fevrier', 'mars', 'avril', 'mai', 'juin',
  'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre'
];

/// Mots-clés → famille de catégorie (comparée au nom des catégories de l'utilisateur).
const _catKeywords = <String, List<String>>{
  'courses': ['courses', 'supermarche', 'carrefour', 'leclerc', 'lidl', 'auchan', 'intermarche', 'monoprix', 'franprix', 'aldi', 'casino', 'epicerie', 'marche', 'boulangerie', 'pain'],
  'restaurant': ['restaurant', 'resto', 'mcdo', 'mcdonald', 'mc do', 'macdo', 'burger', 'kfc', 'pizza', 'sushi', 'kebab', 'cafe', 'bar', 'brasserie', 'uber eats', 'deliveroo'],
  'essence': ['essence', 'carburant', 'plein', 'gasoil', 'gazole', 'diesel', 'station', 'peage', 'recharge'],
  'loisirs': ['loisir', 'loisirs', 'cinema', 'cine', 'concert', 'jeu', 'jeux', 'sortie', 'bowling', 'livre', 'musee', 'sport', 'piscine'],
  'sante': ['pharmacie', 'medecin', 'docteur', 'dentiste', 'sante'],
  'vetements': ['vetement', 'vetements', 'habits', 'zara', 'chaussures', 'shopping'],
};

/// Montant : « 23 », « 23,50 », « 23 euros 50 », « 1 200 € ».
double? _amountIn(String t) {
  final m = RegExp(r'(\d{1,3}(?:[ \u202f\u00a0]\d{3})+|\d+)(?:[.,](\d{1,2}))?\s*(?:€|euros?|e\b)?(?:\s*(\d{1,2})\b)?')
      .allMatches(t)
      .where((m) {
    // on ignore les nombres qui sont des dates (« le 12 », « 12 septembre ») et les fréquences
    final after = t.substring(m.end).trimLeft();
    final before = t.substring(0, m.start).trimRight();
    if (_months.any((mo) => after.startsWith(mo))) return false;
    if (before.endsWith(' le') || before == 'le') return false;
    if (after.startsWith('mois') || after.startsWith('ans') || after.startsWith('fois')) return false;
    // « septembre 2029 », « en 2029 » : c'est une année, pas un montant
    if (_months.any((mo) => before.endsWith(mo)) || before.endsWith(' en') || before.endsWith(' pour')) {
      if (RegExp(r'^20\d{2}$').hasMatch(m.group(1)!)) return false;
    }
    return true;
  }).toList();
  if (m.isEmpty) return null;
  final x = m.first;
  final whole = int.parse(x.group(1)!.replaceAll(RegExp(r'[ \u202f\u00a0]'), ''));
  var cents = x.group(2) ?? '';
  final spoken = x.group(3); // « 23 euros 50 »
  if (cents.isEmpty && spoken != null && x.group(0)!.contains('euro')) cents = spoken;
  final c = cents.isEmpty ? 0 : int.parse(cents.padRight(2, '0'));
  return whole + c / 100;
}

DateTime _dateIn(String t) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  if (t.contains('avant-hier') || t.contains('avant hier')) return today.subtract(const Duration(days: 2));
  if (_has(t, ['hier'])) return today.subtract(const Duration(days: 1));
  final m = RegExp(r'\ble (\d{1,2})(?:er)?(?:\s+(' + _months.join('|') + r')(?:\s+(20\d{2}))?)?').firstMatch(t);
  if (m != null) {
    final day = int.parse(m.group(1)!);
    final month = m.group(2) == null ? now.month : _months.indexOf(m.group(2)!) + 1;
    final year = m.group(3) == null ? now.year : int.parse(m.group(3)!);
    if (day >= 1 && day <= 31) return DateTime(year, month, day);
  }
  return today;
}

/// Année écrite juste après le mois (« septembre 2029 »), ou seule (« en 2029 »).
int? _yearIn(String t, [String? afterMonth]) {
  if (afterMonth != null) {
    final m = RegExp('$afterMonth\\s+(20\\d{2})').firstMatch(t);
    if (m != null) return int.parse(m.group(1)!);
  }
  final m = RegExp(r'\b(?:en|pour|d\x27ici)\s+(20\d{2})\b').firstMatch(t);
  return m == null ? null : int.parse(m.group(1)!);
}

Ym? _monthIn(String t, Ym now) {
  if (t.contains('mois prochain')) return now.add(1);
  if (t.contains('mois dernier')) return now.add(-1);
  if (t.contains('annee prochaine')) return Ym(now.year + 1, now.month);
  for (var i = 0; i < 12; i++) {
    if (_has(t, [_months[i]])) {
      final y = _yearIn(t, _months[i]);
      if (y != null) return Ym(y, i + 1);
      var ym = Ym(now.year, i + 1);
      if (ym.isBefore(now.add(-6))) ym = Ym(now.year + 1, i + 1);
      return ym;
    }
  }
  final y = _yearIn(t);
  if (y != null) return Ym(y, now.month);
  return null;
}

/// Mot(s) après « au / chez / à la / pour » : sert de description ou de nom.
String? _labelIn(String original) {
  final m = RegExp(r"\b(?:au|aux|chez|a la|à la|à l'|a l'|pour|de|d')\s*([A-Za-zÀ-ÿ'\-]+(?:\s+[A-Za-zÀ-ÿ'\-]+)?)",
          caseSensitive: false)
      .allMatches(original)
      .map((m) => m.group(1)!.trim())
      .where((w) {
    final n = _norm(w);
    return !RegExp(r'^\d').hasMatch(w) &&
        !_months.any((mo) => n.startsWith(mo)) &&
        !['euros', 'euro', 'mois', 'chaque', 'tous', 'budget', 'hier'].contains(n.split(' ').first);
  }).toList();
  if (m.isEmpty) return null;
  var w = m.last.split(' ').where((x) => !['chaque', 'tous', 'par', 'le', 'la', 'les', 'hier'].contains(_norm(x))).join(' ');
  if (w.isEmpty) return null;
  return w[0].toUpperCase() + w.substring(1);
}

// ------------------------------------------------------------------ Interface

class _Msg {
  final bool user;
  final String text;
  const _Msg(this.user, this.text);
}

class AssistantSheet extends ConsumerStatefulWidget {
  const AssistantSheet({super.key});
  @override
  ConsumerState<AssistantSheet> createState() => _AssistantSheetState();
}

class _AssistantSheetState extends ConsumerState<AssistantSheet> {
  final _input = TextEditingController();
  final _focus = FocusNode();
  final _msgs = <_Msg>[];
  bool _dictationHint = false;

  _Draft? _draft;
  _Ask _ask = _Ask.none;
  List<(String, VoidCallback)> _choices = const [];
  bool _handled = false; // vrai quand _understand a déjà répondu (projet, etc.)

  @override
  void initState() {
    super.initState();
    // Ouvre le clavier dès que la sheet est visible (l'utilisateur peut dicter tout de suite).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) FocusScope.of(context).requestFocus(_focus);
    });
  }

  @override
  void dispose() {
    _input.dispose();
    _focus.dispose();
    super.dispose();
  }

  /// Micro : remet le focus sur le champ (le clavier iOS a sa propre touche dictée 🎤).
  void _mic() {
    FocusScope.of(context).requestFocus(_focus);
  }

  void _say(String text, {List<(String, VoidCallback)> choices = const []}) =>
      setState(() {
        _msgs.add(_Msg(false, text));
        _choices = choices;
      });

  void _send([String? forced]) {
    final text = (forced ?? _input.text).trim();
    if (text.isEmpty) return;
    setState(() {
      _msgs.add(_Msg(true, text));
      _input.clear();
      _choices = const [];
    });
    final t = _norm(text);
    if (_has(t, ['annule', 'annuler', 'stop', 'laisse tomber'])) {
      _draft = null;
      _ask = _Ask.none;
      _say('D\'accord, j\'annule.');
      return;
    }
    if (_draft != null && _ask == _Ask.confirm) {
      if (_has(t, ['oui', 'ok', 'confirme', 'confirmer', 'vas-y', 'vas y', 'valide', 'go', 'daccord', 'd\'accord'])) {
        _save(_draft!);
      } else {
        _draft = null;
        _ask = _Ask.none;
        _say('D\'accord, je n\'enregistre rien. Reformulez votre demande si besoin.');
      }
      return;
    }
    if (_draft != null && _ask != _Ask.none) {
      _handled = false;
      _answer(text, t);
    } else {
      _handled = false;
      final result = _understand(text, t);
      if (result != null) _draft = result;
    }
    if (!_handled) _next();
  }

  /// Première phrase : on devine l'action et les détails. Retourne null si déjà traité.
  _Draft? _understand(String original, String t) {
    final d = ref.read(appProvider);
    final now = ref.read(nowProvider);
    final x = _Draft()
      ..amount = _amountIn(t)
      ..date = _dateIn(t)
      ..month = _monthIn(t, now);
    if (x.month != null && !RegExp(r'\ble \d').hasMatch(t) && !_has(t, ['hier', 'avant-hier'])) {
      x.date = x.month == now ? x.date : x.month!.firstDay;
    }

    // Fréquence
    final every = RegExp(r'tous les (\d+) mois').firstMatch(t);
    final recurring = every != null ||
        _has(t, ['chaque mois', 'tous les mois', 'par mois', 'mensuel', 'mensuelle', 'chaque annee', 'par an', 'tous les ans', 'annuel']);
    if (every != null) x.interval = int.parse(every.group(1)!).clamp(1, 12);
    if (_has(t, ['chaque annee', 'par an', 'tous les ans', 'annuel'])) x.interval = 12;

    final isIncome = _has(t, ['recu', 'recois', 'recevoir', 'recevrai', 'toucher', 'toucherai', 'encaisser', 'gagner', 'gagne', 'touche', 'salaire', 'prime', 'remboursement', 'rembourse', 'vendu', 'vente', 'revenu', 'paie', 'paye le']);
    if (_has(t, ['salaire', 'paie'])) x.incomeKind = IncomeKind.salary;
    if (_has(t, ['remboursement', 'rembourse'])) x.incomeKind = IncomeKind.refund;
    if (_has(t, ['vendu', 'vente'])) x.incomeKind = IncomeKind.sale;

    // Projet / voyage à créer (sans montant = pas une dépense) → guide vers l'onglet Projets
    final looksLikeProjectCreation = x.amount == null && (
        _has(t, ['projet', 'creer un voyage', 'nouveau voyage', 'je pars en voyage',
            'je fais un voyage', 'epargner pour', 'mettre de cote', 'mettre de côté',
            'apport', 'acheter une voiture']) ||
        // "voyage" + mois ou année future sans montant = création de projet
        (_has(t, ['voyage', 'partir', 'pars']) && x.month != null)
    );
    if (looksLikeProjectCreation) {
      _handled = true;
      _say('Je vois que vous planifiez un voyage 🎯\n'
          'Rendez-vous dans l\'onglet Projets → touchez + → choisissez Voyage.\n'
          'Vous pourrez y noter la date, le budget et l\'app calculera l\'épargne mensuelle automatiquement.');
      return null;
    }

    if (_has(t, ['budget', 'enveloppe'])) {
      x.kind = _Kind.budget;
    } else if (isIncome) {
      x.kind = recurring ? _Kind.recurringIncome : _Kind.income;
    } else if (recurring || _has(t, ['loyer', 'abonnement', 'assurance', 'credit', 'charge fixe', 'mutuelle'])) {
      x.kind = recurring ? _Kind.fixed : null; // « abonnement » seul : on demandera
      if (x.kind == null && _has(t, ['loyer'])) x.kind = _Kind.fixed;
    } else if (x.amount != null) {
      x.kind = _Kind.expense;
    }

    // Nom / description
    x.label = _labelIn(original);
    for (final w in ['loyer', 'netflix', 'spotify', 'assurance', 'mutuelle', 'electricite', 'internet', 'telephone', 'salaire', 'prime', 'credit']) {
      if (_has(t, [w])) {
        x.label ??= w[0].toUpperCase() + w.substring(1);
      }
    }
    if (x.kind == _Kind.income && x.label == null) x.label = x.incomeKind.label;
    if (x.kind == _Kind.recurringIncome && x.label == null && x.incomeKind == IncomeKind.salary) x.label = 'Salaire';

    // Catégorie (dépense) ou nom de budget
    if (x.kind == _Kind.budget) {
      final m = RegExp(r'budget\s+(?:de\s+|d\x27|pour\s+(?:les\s+|la\s+|le\s+)?)?([a-z\-]+)').firstMatch(t);
      if (m != null && !RegExp(r'^\d').hasMatch(m.group(1)!)) {
        final w = m.group(1)!;
        x.label = w[0].toUpperCase() + w.substring(1);
      }
    }
    if (_has(t, ['imprevu'])) x.categoryId = kUnexpectedId;
    for (final p in d.projects) {
      if (t.contains(_norm(p.name)) || (_has(t, ['voyage']) && d.projects.where((q) => q.tripIn(Ym.of(x.date))).length == 1 && p.tripIn(Ym.of(x.date)))) {
        x.categoryId = kTripCatId;
        x.tripId = p.id;
      }
    }
    if (x.categoryId == null) {
      for (final c in d.categories) {
        if (t.contains(_norm(c.name))) x.categoryId = c.id;
      }
    }
    if (x.categoryId == null) {
      for (final e in _catKeywords.entries) {
        if (_has(t, e.value)) {
          final c = d.categories.where((c) => _norm(c.name).contains(e.key) || e.key.contains(_norm(c.name))).firstOrNull;
          if (c != null) x.categoryId = c.id;
          x.label ??= _labelIn(original);
        }
      }
    }

    // Mois déjà clôturé (ex. on est le 30 septembre mais septembre est clôturé) :
    // la dépense ou le revenu va sur le mois de l'app (octobre).
    if (d.isClosed(Ym.of(x.date))) x.date = now.firstDay;
    if (x.month != null && d.isClosed(x.month!)) x.month = now;

    // Personne (couple)
    if (d.isCouple) {
      for (final p in [1, 2]) {
        if (d.personName(p).isNotEmpty && t.contains(_norm(d.personName(p)))) x.person = p;
      }
    }
    return x;
  }

  /// Réponse à la question posée.
  void _answer(String original, String t) {
    final x = _draft!;
    final d = ref.read(appProvider);
    switch (_ask) {
      case _Ask.amount:
        final a = _amountIn(t);
        if (a == null) {
          _say('Je n\'ai pas compris le montant. Combien ?');
          return;
        }
        x.amount = a;
      case _Ask.name:
        x.label = original[0].toUpperCase() + original.substring(1);
      case _Ask.category:
        if (_has(t, ['imprevu'])) {
          x.categoryId = kUnexpectedId;
        } else {
          final c = d.categories.where((c) => t.contains(_norm(c.name))).firstOrNull;
          final p = d.projects.where((p) => t.contains(_norm(p.name))).firstOrNull;
          if (p != null) {
            x.categoryId = kTripCatId;
            x.tripId = p.id;
          } else if (c != null) {
            x.categoryId = c.id;
          }
        }
      case _Ask.person:
        for (final p in [1, 2]) {
          if (t.contains(_norm(d.personName(p)))) x.person = p;
        }
      case _Ask.kind:
        if (_has(t, ['depense', 'achat'])) x.kind = _Kind.expense;
        if (_has(t, ['charge', 'fixe', 'abonnement', 'chaque mois'])) x.kind = _Kind.fixed;
        if (_has(t, ['revenu', 'recu', 'entree'])) x.kind = _Kind.income;
        if (x.amount == null) x.amount = _amountIn(t);
      case _Ask.none:
      case _Ask.confirm:
        break;
    }
  }

  /// Pose la prochaine question, ou enregistre si tout est complet.
  void _next() {
    final x = _draft;
    if (x == null) return;
    final d = ref.read(appProvider);

    if (x.kind == null) {
      _ask = _Ask.kind;
      _say('C\'est une dépense, une charge fixe ou un revenu ?', choices: [
        ('Dépense', () => _send('Dépense')),
        ('Charge fixe', () => _send('Charge fixe')),
        ('Revenu', () => _send('Revenu')),
      ]);
      return;
    }
    if (x.amount == null || x.amount! <= 0) {
      _ask = _Ask.amount;
      _say(switch (x.kind!) {
        _Kind.budget => 'Quel montant par mois pour ce budget ?',
        _Kind.income || _Kind.recurringIncome => 'Quel montant ?',
        _ => 'Combien ?',
      });
      return;
    }
    if (x.kind == _Kind.expense && x.categoryId == null) {
      _ask = _Ask.category;
      final trips = d.projects.where((p) => p.tripIn(Ym.of(x.date)));
      _say('Dans quelle catégorie ?', choices: [
        for (final c in d.categories) ('${c.emoji} ${c.name}', () => _send(c.name)),
        ('⚡ Imprévu', () => _send('Imprévu')),
        for (final p in trips) ('✈️ ${p.name}', () => _send(p.name)),
      ]);
      return;
    }
    if (x.kind == _Kind.expense && d.isCouple && x.person == null) {
      _ask = _Ask.person;
      _say('Qui a payé ?', choices: [for (final p in [1, 2]) (d.personName(p), () => _send(d.personName(p)))]);
      return;
    }
    if ((x.kind == _Kind.fixed || x.kind == _Kind.recurringIncome || x.kind == _Kind.budget) && x.label == null) {
      _ask = _Ask.name;
      _say(x.kind == _Kind.budget ? 'Quel nom pour ce budget ? (ex. Courses)' : 'Quel nom ? (ex. ${x.kind == _Kind.fixed ? 'Loyer' : 'Salaire'})');
      return;
    }
    _ask = _Ask.confirm;
    _say('J\'ai compris :\n${_summary(x)}\n\nJe l\'enregistre ?', choices: [
      ('✓ Confirmer', () => _send('Oui')),
      ('✕ Annuler', () => _send('Non')),
    ]);
  }

  /// Ce que l'assistant a compris, en clair.
  String _summary(_Draft x) {
    final d = ref.read(appProvider);
    final now = ref.read(nowProvider);
    final amt = eur(x.amount!);
    final every = x.interval == 1 ? 'chaque mois' : (x.interval == 12 ? 'chaque année' : 'tous les ${x.interval} mois');
    final from = (x.month ?? now).label.toLowerCase();
    switch (x.kind!) {
      case _Kind.expense:
        final where = x.categoryId == kUnexpectedId
            ? 'Imprévus'
            : (x.tripId != null
                ? 'voyage ${d.projects.firstWhere((p) => p.id == x.tripId).name}'
                : 'catégorie ${d.category(x.categoryId!)?.name ?? ''}');
        return '• Dépense de $amt${x.label != null ? ' (${x.label})' : ''}\n'
            '• Dans : $where\n'
            '• Le ${x.date.day.toString().padLeft(2, '0')}/${x.date.month.toString().padLeft(2, '0')}/${x.date.year}'
            '${d.isCouple ? '\n• Payée par ${d.personName(x.person ?? 1)}' : ''}';
      case _Kind.income:
        return '• Revenu ponctuel « ${x.label ?? x.incomeKind.label} » de $amt\n• En ${(x.month ?? now).label.toLowerCase()}';
      case _Kind.recurringIncome:
        return '• Revenu régulier « ${x.label} » de $amt\n• $every, à partir de $from';
      case _Kind.fixed:
        return '• Charge fixe « ${x.label} » de $amt\n• $every, à partir de $from';
      case _Kind.budget:
        return '• Nouveau budget « ${x.label} »\n• $amt par mois';
    }
  }

  void _save(_Draft x) {
    final n = ref.read(appProvider.notifier);
    final d = ref.read(appProvider);
    final now = ref.read(nowProvider);
    final amt = double.parse(x.amount!.toStringAsFixed(2));
    final every = x.interval == 1 ? 'chaque mois' : (x.interval == 12 ? 'chaque année' : 'tous les ${x.interval} mois');
    String done;
    switch (x.kind!) {
      case _Kind.expense:
        n.addTransaction(x.categoryId!, x.label ?? '', amt, x.date,
            person: d.isCouple ? (x.person ?? 1) : 0, tripId: x.tripId);
        final where = x.categoryId == kUnexpectedId
            ? 'Imprévus'
            : (x.tripId != null
                ? d.projects.firstWhere((p) => p.id == x.tripId).name
                : d.category(x.categoryId!)?.name ?? '');
        done = 'Dépense de ${eur(amt)}${x.label != null ? ' (${x.label})' : ''} ajoutée dans $where'
            '${_sameDay(x.date, DateTime.now()) ? '' : ', le ${x.date.day}/${x.date.month}'}.';
      case _Kind.income:
        final ym = x.month ?? now;
        n.addExtraIncome(x.incomeKind, x.label ?? x.incomeKind.label, amt, ym);
        done = 'Revenu de ${eur(amt)} ajouté en ${ym.label.toLowerCase()}.';
      case _Kind.recurringIncome:
        n.addRecurringIncome(x.label!, amt, x.month ?? now, null, intervalMonths: x.interval);
        done = 'Revenu « ${x.label} » de ${eur(amt)} ajouté, $every.';
      case _Kind.fixed:
        n.addFixedExpense(x.label!, amt, x.month ?? now, null, intervalMonths: x.interval);
        done = 'Charge fixe « ${x.label} » de ${eur(amt)} ajoutée, $every.';
      case _Kind.budget:
        n.addCategoryWithBudget(x.label!, '💰', amt);
        done = 'Budget « ${x.label} » de ${eur(amt)} par mois créé.';
    }
    _draft = null;
    _ask = _Ask.none;
    _say('✓ $done');
    _goTo(x);
  }

  /// Ferme l'assistant et affiche l'onglet (et le mois) où l'ajout a eu lieu.
  void _goTo(_Draft x) {
    final now = ref.read(nowProvider);
    final tab = ref.read(tabProvider.notifier);
    StateController<Ym>? monthCtl;
    Ym? month;
    switch (x.kind!) {
      case _Kind.expense:
        if (x.tripId != null) {
          tab.state = AppTab.trips;
        } else {
          tab.state = AppTab.budgets;
          monthCtl = ref.read(budgetMonthProvider.notifier);
          month = Ym.of(x.date);
        }
      case _Kind.income:
      case _Kind.recurringIncome:
        tab.state = AppTab.incomes;
        monthCtl = ref.read(incomeMonthProvider.notifier);
        month = x.month ?? now;
      case _Kind.fixed:
        tab.state = AppTab.charges;
        monthCtl = ref.read(chargeMonthProvider.notifier);
        month = x.month ?? now;
      case _Kind.budget:
        tab.state = AppTab.budgets;
    }
    final messenger = ScaffoldMessenger.maybeOf(context);
    Future.delayed(const Duration(milliseconds: 700), () {
      if (!mounted) return;
      Navigator.of(context).pop();
      // L'onglet se remet sur le mois actuel à son ouverture : on choisit le bon mois juste après.
      if (monthCtl != null && month != null) {
        final c = monthCtl, m = month;
        Future.delayed(const Duration(milliseconds: 250), () => c.state = m);
      }
      messenger?.showSnackBar(const SnackBar(content: Text('Ajouté. Touchez ↶ en haut pour annuler.')));
    });
  }

  bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (_msgs.isEmpty)
        const Text(
            'Dites ce que vous voulez faire, par exemple :\n'
            '« J\'ai dépensé 23 euros au McDo »\n'
            '« 45 euros d\'essence hier »\n'
            '« Mon loyer de 650 euros chaque mois »\n'
            '« J\'ai reçu une prime de 300 euros »\n'
            '« Crée un budget courses de 350 euros »\n'
            'S\'il manque un détail, je vous pose la question.',
            style: TextStyle(color: AppColors.muted, height: 1.45)),
      for (final m in _msgs)
        Align(
          alignment: m.user ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            constraints: const BoxConstraints(maxWidth: 300),
            decoration: BoxDecoration(
              color: m.user ? tint(AppColors.violet, .22) : context.fieldColor,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Text(m.text, style: const TextStyle(height: 1.35)),
          ),
        ),
      if (_choices.isNotEmpty) ...[
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final c in _choices) ActionChip(label: Text(c.$1), onPressed: c.$2),
        ]),
      ],
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          child: TextField(
            controller: _input,
            focusNode: _focus,
            minLines: 1,
            maxLines: 4,
            textCapitalization: TextCapitalization.sentences,
            // Sur iOS : keyboardType.text + enableSuggestions fait apparaître
            // la touche 🎤 dictée native en bas à droite du clavier.
            keyboardType: TextInputType.text,
            enableSuggestions: true,
            decoration: const InputDecoration(
              hintText: 'Écrivez ou dictez (touche 🎤 du clavier)',
            ),
            onSubmitted: (_) => _send(),
          ),
        ),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () => _send(),
          child: Container(
            width: 52,
            height: 52,
            decoration: const BoxDecoration(shape: BoxShape.circle, gradient: brandGradient),
            child: const Icon(Icons.send_rounded, color: Colors.white),
          ),
        ),
      ]),
    ]);
  }
}
