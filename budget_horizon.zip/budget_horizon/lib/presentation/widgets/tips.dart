import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme.dart';

const _amber = Color(0xFFF5A524);

class _Tip {
  final String id;
  final String emoji;
  final String title;
  final String text;
  const _Tip(this.id, this.emoji, this.title, this.text);
}

const _tips = <_Tip>[
  _Tip('home1', '🔮', 'Regarde la fin du mois',
      'Le solde du jour ne dit pas tout. Ce qui compte, c\'est ce qu\'il te restera une fois les charges et les projets passés.'),
  _Tip('home2', '✅', 'Pointe tes lignes',
      'Quand une dépense ou un revenu est vraiment passé sur ton compte, coche-le : ton solde reste juste.'),
  _Tip('forecast1', '🧪', 'Teste avant d\'acheter',
      'Pour un gros achat, regarde le mois concerné. Si la courbe reste positive, tu peux y aller.'),
  _Tip('forecast2', '🛟', 'Garde une marge',
      'Vise toujours un peu d\'avance sur la courbe : une panne ou une facture surprise ne doit pas te mettre dans le rouge.'),
  _Tip('forecastYear', '🔭', 'Vois les gros mois venir',
      'La vue annuelle montre les mois chargés (impôts, assurances, vacances) bien à l\'avance, pour les préparer.'),
  _Tip('budgets1', '🗂️', 'Peu d\'enveloppes, c\'est mieux',
      'Quelques grandes enveloppes (courses, sorties, transport…) sont plus faciles à suivre que beaucoup de petites.'),
  _Tip('budgets2', '💰', 'Épargne en premier',
      'Mets ton épargne de côté dès le début du mois et vis avec le reste.'),
  _Tip('monthly1', '🧹', 'Trie tes abonnements',
      'Une fois par trimestre, vérifie ta liste et supprime ce que tu n\'utilises plus.'),
  _Tip('monthly2', '📅', 'N\'oublie pas les charges annuelles',
      'Une assurance payée une fois par an ? Ajoute-la avec une fréquence annuelle pour ne pas être surpris.'),
  _Tip('income1', '🌱', 'Note tous tes revenus',
      'Salaire, prime, remboursement… plus la liste est complète, plus tes prévisions sont justes.'),
  _Tip('clients1', '🎯', 'Regarde le net, pas le brut',
      'Ce que tu factures n\'est pas ce que tu gardes. Hever déduit les charges pour te montrer ton vrai revenu.'),
  _Tip('clients2', '🏦', 'Mets l\'URSSAF de côté',
      'À chaque facture encaissée, vire tout de suite la part d\'URSSAF sur ton compte pro.'),
  _Tip('invoices1', '⚡', 'Facture vite',
      'Plus tu factures tôt après le passage, plus tu es payé tôt.'),
  _Tip('analysis1', '⏱️', 'Calcule ton taux horaire',
      'Divise ce que tu gagnes par les heures réellement travaillées pour savoir ce qui vaut vraiment la peine.'),
  _Tip('analysis2', '🔍', 'Commence par les grosses dépenses',
      'Réduire une grosse ligne change plus ton budget que plusieurs petites économies.'),
  _Tip('analysis3', '🌦️', 'Garde de la marge les bons mois',
      'Les mois pleins peuvent compenser les mois creux, si tu en mets un peu de côté.'),
  _Tip('projects1', '🏝️', 'Un projet = un montant + une date',
      'Avec les deux, Hever calcule combien mettre de côté chaque mois.'),
  _Tip('leave1', '🌉', 'Pense aux jours fériés',
      'Un congé collé à un jour férié te donne plus de jours de repos pour le même nombre de jours posés.'),
];

int _indexOf(String id) {
  final i = _tips.indexWhere((t) => t.id == id);
  return i < 0 ? 0 : i;
}

void _showTip(BuildContext context, String id) {
  final dark = context.isDark;
  var i = _indexOf(id);
  showModalBottomSheet<void>(
    context: context,
    useSafeArea: true,
    backgroundColor: dark ? AppColors.bgDark : AppColors.bg,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => StatefulBuilder(builder: (ctx, setState) {
      final t = _tips[i];
      return Padding(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(
            child: Container(
              width: 38, height: 4,
              decoration: BoxDecoration(color: context.mutedColor.withAlpha(90), borderRadius: BorderRadius.circular(4)),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            const Icon(Icons.lightbulb_rounded, color: _amber, size: 20),
            const SizedBox(width: 6),
            const Expanded(child: Text('Astuce', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
            GestureDetector(
              onTap: () => Navigator.of(ctx).pop(),
              child: Container(
                width: 32, height: 32,
                decoration: BoxDecoration(color: context.mutedColor.withAlpha(40), shape: BoxShape.circle),
                child: const Icon(Icons.close_rounded, size: 18),
              ),
            ),
          ]),
          const SizedBox(height: 14),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 220),
            child: Container(
              key: ValueKey(t.id),
              width: double.infinity,
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: context.cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _amber.withAlpha(80)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t.emoji, style: const TextStyle(fontSize: 34)),
                const SizedBox(height: 8),
                Text(t.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                const SizedBox(height: 6),
                Text(t.text, style: TextStyle(color: context.mutedColor, fontSize: 14.5, height: 1.45)),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: TextButton.icon(
              onPressed: () {
                HapticFeedback.selectionClick();
                setState(() => i = (i + 1) % _tips.length);
              },
              icon: const Icon(Icons.casino_rounded, size: 18),
              label: const Text('Une autre astuce'),
            ),
          ),
        ]),
      );
    }),
  );
}

/// Petite ampoule à poser à côté d'un titre : ouvre une astuce fun.
class TipBulb extends StatelessWidget {
  final String id;
  const TipBulb(this.id, {super.key});

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          HapticFeedback.selectionClick();
          _showTip(context, id);
        },
        child: const SizedBox(
          width: 30,
          height: 30,
          child: Center(child: Icon(Icons.lightbulb_rounded, size: 18, color: _amber)),
        ),
      );
}

/// Bandeau d'astuce cliquable, pour les pages sans titre de section.
class TipChip extends StatelessWidget {
  final String id;
  const TipChip(this.id, {super.key});

  @override
  Widget build(BuildContext context) {
    final t = _tips[_indexOf(id)];
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        _showTip(context, id);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _amber.withAlpha(26),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          const Icon(Icons.lightbulb_rounded, size: 18, color: _amber),
          const SizedBox(width: 8),
          Expanded(
            child: Text('${t.emoji}  ${t.title}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          ),
          Icon(Icons.chevron_right_rounded, size: 18, color: context.mutedColor),
        ]),
      ),
    );
  }
}
