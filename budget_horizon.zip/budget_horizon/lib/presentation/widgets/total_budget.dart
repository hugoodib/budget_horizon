import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../providers.dart';
import 'common.dart';

/// Vue d'ensemble du budget total du mois : ce qui compte vraiment pour la prévision.
/// (Les catégories ne sont que des enveloppes.)
class TotalBudgetCard extends ConsumerWidget {
  final Ym month;
  const TotalBudgetCard({super.key, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final planned = d.plannedIn(month);
    final spent = d.spentIn(month);
    final remaining = planned - spent;
    final over = spent > planned;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final envelopeOver = d.budgets.any((b) => d.spentForBudget(b, month) > b.amountIn(month));
    final color = over ? AppColors.danger : (ratio >= .85 ? AppColors.warning : AppColors.teal);

    // Rythme (uniquement pour le mois réel en cours, non clôturé)
    final today = DateTime.now();
    final isRealMonth = month == Ym.of(today) && !d.isClosed(month);
    final daysInMonth = DateTime(today.year, today.month + 1, 0).day;
    final daysLeftInc = daysInMonth - today.day + 1; // aujourd'hui compris
    final perDay = (isRealMonth && remaining > 0 && daysLeftInc > 0) ? remaining / daysLeftInc : null;
    final projected = isRealMonth && today.day > 0 ? spent / today.day * daysInMonth : null;
    final paceWarning = projected != null && !over && planned > 0 && projected > planned;

    // Anneau : dépensé (couleur) / restant (gris)
    final used = planned <= 0 ? 0.0 : min(spent, planned);
    final rest = max(0.0, planned - spent);
    final sections = <PieChartSectionData>[
      if (used > 0) PieChartSectionData(value: used, color: color, radius: 13, showTitle: false),
      if (rest > 0) PieChartSectionData(value: rest, color: AppColors.track, radius: 13, showTitle: false),
      if (used <= 0 && rest <= 0) PieChartSectionData(value: 1, color: AppColors.track, radius: 13, showTitle: false),
    ];

    final Color hintColor;
    final String hint;
    if (over) {
      hintColor = AppColors.danger;
      hint = 'Budget dépassé de ${eur(spent - planned)}.';
    } else if (envelopeOver) {
      hintColor = AppColors.warning;
      hint = 'Une catégorie est dépassée, mais pas le total. Tout va bien.';
    } else {
      hintColor = AppColors.success;
      hint = 'Vous êtes dans votre budget.';
    }

    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('BUDGET TOTAL · ${month.longName.toUpperCase()}',
            style: const TextStyle(
                color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 2.2)),
        const SizedBox(height: 10),
        Row(children: [
          SizedBox(
            width: 118,
            height: 118,
            child: Stack(alignment: Alignment.center, children: [
              PieChart(PieChartData(
                startDegreeOffset: -90,
                sectionsSpace: 0,
                centerSpaceRadius: 40,
                sections: sections,
              )),
              Column(mainAxisSize: MainAxisSize.min, children: [
                Text('${(ratio * 100).round()} %',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: over ? AppColors.danger : AppColors.text)),
                const Text('utilisé', style: TextStyle(color: AppColors.muted, fontSize: 11.5)),
              ]),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(over ? 'Dépassement' : 'Reste sur le budget',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(eur(over ? spent - planned : remaining),
                    style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.8,
                        color: over ? AppColors.danger : AppColors.text)),
              ),
              const SizedBox(height: 4),
              Text('${eur(spent)} dépensés sur ${eur(planned)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ]),
          ),
        ]),
        const SizedBox(height: 12),
        Text(hint, style: TextStyle(color: hintColor, fontSize: 13, fontWeight: FontWeight.w600, height: 1.3)),
        if (perDay != null) ...[
          const SizedBox(height: 6),
          Text('Vous pouvez dépenser environ ${eur(perDay)} par jour.',
              style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        ],
        if (paceWarning) ...[
          const SizedBox(height: 6),
          Text('À ce rythme, vous dépasserez votre budget de ${eur(projected - planned)}.',
              style: const TextStyle(color: AppColors.warning, fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ]),
    );
  }
}
