import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';
import 'forms.dart';

/// Compteur d'imprévus du mois — même style visuel que les budgets.
class UnexpectedCard extends ConsumerWidget {
  final Ym month;
  const UnexpectedCard({super.key, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final total = d.unexpectedIn(month); // montant dépensé en imprévus (positif)
    const planned = 0.0; // pas de budget prévu : tout imprévu est un dépassement
    final count = d.transactionsIn(month, categoryId: kUnexpectedId).length;
    const catColor = Color(0xFFFF9F0A); // orange

    final hasItems = total > 0;

    return GestureDetector(
      onTap: () => showSheet(context,
          title: 'Nouvel imprévu',
          child: AddExpenseSheet(month: month, initialUnexpected: true)),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: tint(catColor, .08),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const CircleEmoji('⚡', catColor, size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Text('Imprévus',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(hasItems ? eur(-total) : eur(0),
                  style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                      color: hasItems ? AppColors.warning : AppColors.muted)),
              Text(count == 0 ? 'aucune' : '$count dépense${count > 1 ? 's' : ''}',
                  style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w500, fontSize: 12)),
            ]),
            const SizedBox(width: 4),
            GestureDetector(
              onTap: () => showSheet(context,
                  title: 'Nouvel imprévu',
                  child: AddExpenseSheet(month: month, initialUnexpected: true)),
              child: const Padding(
                padding: EdgeInsets.all(6),
                child: Icon(Icons.add_rounded, color: AppColors.muted, size: 18),
              ),
            ),
          ]),
          const SizedBox(height: 10),
          AppProgress(
            value: hasItems ? 1.0 : 0.0,
            color: hasItems ? AppColors.warning : AppColors.muted.withAlpha(60),
          ),
          const SizedBox(height: 4),
          Text(
            hasItems
                ? '${eur(-total)} retirés de votre fin de mois'
                : 'Aucun imprévu ce mois-ci',
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: hasItems ? AppColors.warning : AppColors.muted),
          ),
        ]),
      ),
    );
  }
}

/// Budget d'un voyage pendant son mois : les dépenses du voyage y sont saisies.
/// Au-delà du budget, l'estimation de fin de mois baisse ; en dessous, la différence est
/// remise dans le solde à la clôture du mois.
class TripBudgetCard extends ConsumerWidget {
  final Project project;
  final Ym month;
  const TripBudgetCard({super.key, required this.project, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final spent = d.tripSpentIn(month, project.id);
    final planned = project.budgetIn(month); // au prorata des jours du voyage dans ce mois
    final over = spent > planned;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final closed = d.isClosed(month);
    final color = over ? AppColors.danger : (ratio >= .85 ? AppColors.warning : AppColors.teal);
    final isTrip = project.isTrip;
    final hint = closed
        ? (isTrip
            ? 'Voyage clôturé : ${eur(spent)} dépensés sur ${eur(planned)} de budget.'
            : '${project.name} clôturé : ${eur(planned)} déduit de votre solde.')
        : over
            ? 'Budget dépassé de ${eur(spent - planned)} : retiré de votre fin de mois.'
            : (isTrip
                ? 'Si vous dépensez moins, le reste revient dans votre solde à la clôture.'
                : '${eur(planned)} sera déduit de votre solde ce mois-ci.');
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleEmoji(project.emoji, isTrip ? const Color(0xFF0A84FF) : const Color(0xFF34C759)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(project.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              Text(isTrip ? 'Budget voyage · ${month.label}' : 'Projet · ${month.label}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ]),
          ),
          Text(over ? eur(spent - planned) : eur(planned - spent),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: over ? AppColors.danger : AppColors.teal)),
        ]),
        const SizedBox(height: 12),
        AppProgress(value: ratio, color: color),
        const SizedBox(height: 8),
        Text(isTrip ? '${eur(spent)} dépensés sur ${eur(planned)}' : 'Budget prévu : ${eur(planned)}',
            style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        const SizedBox(height: 6),
        Text(hint,
            style: TextStyle(
                color: over ? AppColors.danger : AppColors.muted,
                fontSize: 12.5,
                height: 1.3,
                fontWeight: over ? FontWeight.w600 : FontWeight.w400)),
        // Le bouton dépenses n'apparaît que pour les voyages
        if (isTrip) ...[
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: GradientButton(
              label: 'Ajouter une dépense de voyage',
              icon: Icons.add_rounded,
              onPressed: () => showSheet(context,
                  title: 'Dépense · ${project.name}',
                  child: AddExpenseSheet(month: ref.read(nowProvider), initialTripId: project.id)),
            ),
          ),
        ],
      ]),
    );
  }
}
