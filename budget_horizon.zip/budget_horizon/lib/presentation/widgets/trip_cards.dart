import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';
import 'forms.dart';

/// Compteur d'imprévus du mois — même style visuel que les budgets.
class UnexpectedCard extends ConsumerWidget {
  final Ym month;
  const UnexpectedCard({super.key, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final total = d.unexpectedIn(month); // montant dépensé en imprévus (positif)
    final count = d.transactionsIn(month, categoryId: kUnexpectedId).length;
    const catColor = Color(0xFFFF9F0A); // orange
    final hasItems = total > 0;

    return GestureDetector(
      onTap: () => showUnexpectedDetailSheet(context, month: month),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: tint(catColor, .08),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const CircleEmoji('⚡', catColor, size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Text('Imprévus',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(hasItems ? eur(-total) : eur(0),
                  style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 17,
                      color: hasItems ? AppColors.warning : AppColors.muted)),
              Text(count == 0 ? 'aucune' : '$count dépense${count > 1 ? 's' : ''}',
                  style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w500, fontSize: 12)),
            ]),
            const SizedBox(width: 4),
            GestureDetector(
              onTap: () => showSheet(context,
                  title: 'Nouvel imprévu',
                  child: AddExpenseSheet(month: month, initialUnexpected: true)),
              child: const Padding(
                padding: EdgeInsets.all(6),
                child: Icon(Icons.add_rounded, color: AppColors.muted, size: 18),
              ),
            ),
          ]),
          const SizedBox(height: 10),
          AppProgress(
            value: hasItems ? 1.0 : 0.0,
            color: hasItems ? AppColors.warning : AppColors.muted.withAlpha(60),
          ),
          const SizedBox(height: 4),
          Text(
            hasItems
                ? '${eur(-total)} retirés de votre fin de mois'
                : 'Aucun imprévu ce mois-ci',
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: hasItems ? AppColors.warning : AppColors.muted),
          ),
        ]),
      ),
    );
  }
}

/// Sheet de détail des imprévus — même design que BudgetDetailSheet.
void showUnexpectedDetailSheet(BuildContext context, {required Ym month}) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    enableDrag: true,
    backgroundColor: Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF1C1C1E)
        : Colors.white,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) {
      final handleColor = const Color(0xFFD9DCE8).withAlpha(
          Theme.of(ctx).brightness == Brightness.dark ? 60 : 255);
      return StatefulBuilder(
        builder: (ctx, setState) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onVerticalDragUpdate: (d) {
                if ((d.primaryDelta ?? 0) > 6) Navigator.of(ctx).pop();
              },
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Center(
                    child: Container(
                      width: 38, height: 4,
                      decoration: BoxDecoration(
                          color: handleColor,
                          borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  const Text('⚡ Imprévus',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                ]),
              ),
            ),
            Flexible(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(18, 0, 18,
                    MediaQuery.of(ctx).viewInsets.bottom + 20),
                child: _UnexpectedDetailSheet(month: month),
              ),
            ),
          ],
        ),
      );
    },
  );
}

class _UnexpectedDetailSheet extends ConsumerWidget {
  final Ym month;
  const _UnexpectedDetailSheet({required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const catColor = Color(0xFFFF9F0A);
    final d = ref.watch(appProvider);
    final total = d.unexpectedIn(month);
    final txs = d.transactionsIn(month, categoryId: kUnexpectedId)
      ..sort((a, b) => b.date.compareTo(a.date));
    final hasItems = total > 0;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Résumé visuel ──────────────────────────────────────────
      AppCard(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const CircleEmoji('⚡', catColor, size: 36),
            const SizedBox(width: 12),
            const Expanded(
              child: Text('Imprévus',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
            ),
          ]),
          const SizedBox(height: 16),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(eur(-total),
                style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    color: hasItems ? catColor : AppColors.muted,
                    letterSpacing: -0.5)),
            const SizedBox(width: 8),
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('dépensés ce mois-ci',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13,
                      fontWeight: FontWeight.w500)),
            ),
          ]),
          const SizedBox(height: 10),
          AppProgress(
            value: hasItems ? 1.0 : 0.0,
            color: hasItems ? catColor : AppColors.muted.withAlpha(60),
          ),
          const SizedBox(height: 8),
          Text(
            hasItems
                ? '${txs.length} imprévu${txs.length > 1 ? 's' : ''} · ${eur(-total)} retirés de votre fin de mois'
                : 'Aucun imprévu ce mois-ci',
            style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
        ]),
      ),
      const SizedBox(height: 20),

      // ── Liste + bouton ajouter ─────────────────────────────────
      Row(children: [
        Expanded(
          child: Text(
            txs.isEmpty ? 'Aucun imprévu ce mois-ci' : '${txs.length} dépense${txs.length > 1 ? 's' : ''}',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
        ),
        FilledButton.icon(
          onPressed: () => showSheet(context,
              title: 'Nouvel imprévu',
              child: AddExpenseSheet(month: month, initialUnexpected: true)),
          icon: const Icon(Icons.add_rounded, size: 18),
          label: const Text('+ Ajouter'),
          style: FilledButton.styleFrom(
            backgroundColor: catColor,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          ),
        ),
      ]),

      if (txs.isEmpty) ...[
        const SizedBox(height: 12),
        const Text('Touchez « Ajouter » pour saisir un imprévu.',
            style: TextStyle(color: AppColors.muted, fontSize: 13, height: 1.4)),
      ] else ...[
        const SizedBox(height: 10),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: [
            for (final t in txs)
              Dismissible(
                key: ValueKey('unexp_${t.id}'),
                direction: DismissDirection.horizontal,
                background: Container(
                  color: t.checked ? AppColors.muted : AppColors.teal,
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(left: 20),
                  child: Icon(t.checked ? Icons.remove_done_rounded : Icons.check_circle_rounded,
                      color: Colors.white),
                ),
                secondaryBackground: Container(
                  color: AppColors.danger,
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  child: const Icon(Icons.delete_rounded, color: Colors.white),
                ),
                confirmDismiss: (dir) async {
                  if (dir == DismissDirection.startToEnd) {
                    ref.read(appProvider.notifier).toggleTransactionChecked(t.id);
                    return false;
                  }
                  return await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Supprimer cet imprévu ?'),
                      content: Text('${t.description} · ${eur(t.amount)}'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
                      ],
                    ),
                  ) ?? false;
                },
                onDismissed: (_) => ref.read(appProvider.notifier).deleteTransaction(t.id),
                child: InkWell(
                  onTap: () => showSheet(context,
                      title: 'Modifier l\'imprévu',
                      child: AddExpenseSheet(month: Ym.of(t.date), existing: t)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(children: [
                      SizedBox(
                        width: 36,
                        child: Text(
                          '${t.date.day.toString().padLeft(2, '0')}/${t.date.month.toString().padLeft(2, '0')}',
                          style: const TextStyle(color: AppColors.muted, fontSize: 12,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(
                            t.description.isEmpty ? 'Imprévu' : t.description,
                            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            t.checked ? 'Débité sur votre compte' : 'En attente de débit',
                            style: TextStyle(
                              fontSize: 11,
                              color: t.checked ? AppColors.success : AppColors.muted,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          if (t.note.isNotEmpty)
                            Text(
                              t.note,
                              style: const TextStyle(fontSize: 11, color: AppColors.muted, height: 1.3),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                        ]),
                      ),
                      Text('−${eur(t.amount)}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      const SizedBox(width: 4),
                      Consumer(builder: (_, ref, __) => CheckCircle(
                        checked: t.checked,
                        onTap: () => ref.read(appProvider.notifier).toggleTransactionChecked(t.id),
                      )),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      ],
      const SizedBox(height: 8),
    ]);
  }
}

/// Budget d'un voyage pendant son mois : les dépenses du voyage y sont saisies.
/// Au-delà du budget, l'estimation de fin de mois baisse ; en dessous, la différence est
/// remise dans le solde à la clôture du mois.
class TripBudgetCard extends ConsumerWidget {
  final Project project;
  final Ym month;
  const TripBudgetCard({super.key, required this.project, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final spent = d.tripSpentIn(month, project.id);
    final planned = project.budgetIn(month); // au prorata des jours du voyage dans ce mois
    final over = spent > planned;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final closed = d.isClosed(month);
    final color = over ? AppColors.danger : (ratio >= .85 ? AppColors.warning : AppColors.teal);
    final isTrip = project.isTrip;
    final hint = closed
        ? (isTrip
            ? 'Voyage clôturé : ${eur(spent)} dépensés sur ${eur(planned)} de budget.'
            : '${project.name} clôturé : ${eur(planned)} déduit de votre solde.')
        : over
            ? 'Budget dépassé de ${eur(spent - planned)} : retiré de votre fin de mois.'
            : (isTrip
                ? 'Le reste revient dans votre solde à la clôture.'
                : '${eur(planned)} sera déduit de votre solde ce mois-ci.');
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleEmoji(project.emoji, isTrip ? const Color(0xFF0A84FF) : const Color(0xFF34C759)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(project.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              Text(isTrip ? 'Budget voyage · ${month.label}' : 'Projet · ${month.label}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ]),
          ),
          Text(over ? eur(spent - planned) : eur(planned - spent),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: over ? AppColors.danger : AppColors.teal)),
        ]),
        const SizedBox(height: 12),
        AppProgress(value: ratio, color: color),
        const SizedBox(height: 8),
        Text(isTrip ? '${eur(spent)} dépensés sur ${eur(planned)}' : 'Budget prévu : ${eur(planned)}',
            style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        const SizedBox(height: 6),
        Text(hint,
            style: TextStyle(
                color: over ? AppColors.danger : AppColors.muted,
                fontSize: 12.5,
                height: 1.3,
                fontWeight: over ? FontWeight.w600 : FontWeight.w400)),
        // Le bouton dépenses n'apparaît que pour les voyages
        if (isTrip) ...[
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: GradientButton(
              label: 'Ajouter une dépense de voyage',
              icon: Icons.add_rounded,
              onPressed: () => showSheet(context,
                  title: 'Dépense · ${project.name}',
                  child: AddExpenseSheet(month: ref.read(nowProvider), initialTripId: project.id)),
            ),
          ),
        ],
      ]),
    );
  }
}
