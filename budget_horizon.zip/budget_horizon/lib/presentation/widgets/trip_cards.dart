import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';
import 'forms.dart';

/// Compteur d'imprévus du mois : pas un budget, chaque dépense est déduite directement
/// de l'estimation de fin de mois.
class UnexpectedCard extends ConsumerWidget {
  final Ym month;
  const UnexpectedCard({super.key, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final total = d.unexpectedIn(month);
    final count = d.transactionsIn(month, categoryId: kUnexpectedId).length;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const CircleEmoji('⚡', Color(0xFFFF9F0A)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Imprévus', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 2),
            Text(count == 0 ? 'Aucun imprévu ce mois-ci' : '$count dépense${count > 1 ? 's' : ''}',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            const SizedBox(height: 4),
            const Text('Dépenses hors budget, retirées directement de votre fin de mois.',
                style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.3)),
          ]),
        ),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(total > 0 ? eur(-total) : eur(0),
              style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                  color: total > 0 ? AppColors.warning : AppColors.muted)),
          const SizedBox(height: 8),
          RoundIconButton(
            icon: Icons.add_rounded,
            size: 36,
            onTap: () => showSheet(context,
                title: 'Nouvel imprévu', child: AddExpenseSheet(month: month, initialUnexpected: true)),
          ),
        ]),
      ]),
    );
  }
}

/// Budget d'un voyage pendant son mois : les dépenses du voyage y sont saisies.
/// Au-delà du budget, l'estimation de fin de mois baisse ; en dessous, la différence est
/// remise dans le solde à la clôture du mois.
class TripBudgetCard extends ConsumerWidget {
  final Project project;
  final Ym month;
  const TripBudgetCard({super.key, required this.project, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final spent = d.tripSpentIn(month, project.id);
    final planned = project.target;
    final over = spent > planned;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final closed = d.isClosed(month);
    final color = over ? AppColors.danger : (ratio >= .85 ? AppColors.warning : AppColors.teal);
    final hint = closed
        ? 'Voyage clôturé : ${eur(spent)} dépensés sur ${eur(planned)} de budget.'
        : over
            ? 'Budget dépassé de ${eur(spent - planned)} : retiré de votre fin de mois.'
            : 'Si vous dépensez moins, le reste revient dans votre solde à la clôture.';
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleEmoji('✈️', Color(0xFF0A84FF)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(project.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              Text('Budget voyage · ${month.label}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ]),
          ),
          Text(over ? eur(spent - planned) : eur(planned - spent),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: over ? AppColors.danger : AppColors.teal)),
        ]),
        const SizedBox(height: 12),
        AppProgress(value: ratio, color: color),
        const SizedBox(height: 8),
        Text('${eur(spent)} dépensés sur ${eur(planned)}',
            style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        const SizedBox(height: 6),
        Text(hint,
            style: TextStyle(
                color: over ? AppColors.danger : AppColors.muted,
                fontSize: 12.5,
                height: 1.3,
                fontWeight: over ? FontWeight.w600 : FontWeight.w400)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: GradientButton(
            label: 'Ajouter une dépense de voyage',
            icon: Icons.add_rounded,
            onPressed: () => showSheet(context,
                title: 'Dépense · ${project.name}',
                child: AddExpenseSheet(month: month, initialTripId: project.id)),
          ),
        ),
      ]),
    );
  }
}
