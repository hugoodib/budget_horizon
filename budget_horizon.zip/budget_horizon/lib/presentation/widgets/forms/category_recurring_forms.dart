part of '../forms.dart';

// ---------------- Nouvelle catégorie + budget ----------------
class AddCategorySheet extends ConsumerStatefulWidget {
  const AddCategorySheet({super.key});
  @override
  ConsumerState<AddCategorySheet> createState() => _AddCategoryState();
}

class _AddCategoryState extends ConsumerState<AddCategorySheet> {
  final _name = TextEditingController();
  final _amt = TextEditingController();
  String _emoji = '🍕';
  int _color = AppColors.palette[2].value;
  bool _separate = false;

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseAmount(_amt.text);
    if (_name.text.trim().isEmpty || a == null || a < 0) {
      snack(context, 'Nom et budget requis');
      return;
    }
    ref.read(appProvider.notifier).addCategoryWithBudget(_name.text.trim(), _emoji, a,
        colorValue: _color, separate: _separate);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isCouple = ref.watch(appProvider).isCouple;
    final accent = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _name,
          hint: 'Nom (ex. Courses, Loisirs)',
          icon: Icons.label_outline_rounded,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: accent)),
      ]),
      const SizedBox(height: 10),
      // ── Style (emoji + couleur) ──────────────────────────────
      StylePicker(
        emoji: _emoji,
        color: _color,
        onEmoji: (e) => setState(() => _emoji = e),
        onColor: (c) => setState(() => _color = c),
      ),
      // ── Mode couple ──────────────────────────────────────────
      if (isCouple) ...[
        const SizedBox(height: 10),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: labelWithInfo('Un budget par personne', Hint.fieldPerPerson, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(_separate ? 'Chaque personne a son propre budget indépendant.' : 'Un seul budget commun pour les deux.'),
          value: _separate,
          onChanged: (v) => setState(() => _separate = v),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(saveLabel: 'Créer', onSave: _save),
    ]);
  }
}

// ---------------- Saisie d'un montant simple ----------------
Future<double?> askAmount(BuildContext context, String title, double initial,
    {String? hint, String suffix = '€'}) {
  return showSheet<double>(
    context,
    title: title,
    child: _AskAmountBody(initial: initial, hint: hint, suffix: suffix),
  );
}

class _AskAmountBody extends StatefulWidget {
  final double initial;
  final String? hint;
  final String suffix;
  const _AskAmountBody({required this.initial, this.hint, required this.suffix});
  @override
  State<_AskAmountBody> createState() => _AskAmountBodyState();
}

class _AskAmountBodyState extends State<_AskAmountBody> {
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    final i = widget.initial;
    _c = TextEditingController(
        text: i == 0 ? '' : (i == i.roundToDouble() ? i.round().toString() : i.toString()));
    _c.selection = TextSelection(baseOffset: 0, extentOffset: _c.text.length);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _save() {
    // Champ vide = 0 : on peut simplement tout effacer.
    final v = _c.text.trim().isEmpty ? 0.0 : parseAmount(_c.text);
    if (v == null) {
      snack(context, 'Montant invalide');
      return;
    }
    Navigator.pop(context, v);
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (widget.hint != null)
        Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(widget.hint!)),
      TextField(
        controller: _c,
        autofocus: true,
        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
        decoration: InputDecoration(suffixText: widget.suffix),
        onSubmitted: (_) => _save(),
      ),
      const SizedBox(height: 16),
      _CancelSaveRow(saveLabel: 'Enregistrer', onSave: _save),
    ]);
  }
}

// ---------------- Revenu récurrent : modifier un seul mois ----------------
class RecurringOverrideSheet extends ConsumerStatefulWidget {
  final Ym month;
  final String recurringId;
  const RecurringOverrideSheet({super.key, required this.month, required this.recurringId});
  @override
  ConsumerState<RecurringOverrideSheet> createState() => _RecurringOverrideState();
}

class _RecurringOverrideState extends ConsumerState<RecurringOverrideSheet> {
  late final TextEditingController _amt;
  @override
  void initState() {
    super.initState();
    final r = ref.read(appProvider).recurring(widget.recurringId);
    _amt = TextEditingController(text: (r?.amountIn(widget.month) ?? 0).round().toString());
  }

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = ref.watch(appProvider).recurring(widget.recurringId);
    if (r == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: AppColors.violet.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Info ─────────────────────────────────────────────────
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.violet.withAlpha(15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(children: [
          const Icon(Icons.info_outline_rounded, size: 15, color: AppColors.violet),
          const SizedBox(width: 8),
          Expanded(child: Text(
            'Montant habituel : ${eur(r.amount)}. Ce changement ne s\'applique qu\'au mois de ${widget.month.label} — les autres mois restent inchangés.',
            style: const TextStyle(color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600),
          )),
        ]),
      ),
      const SizedBox(height: 14),
      _AmountFieldCompact(controller: _amt, accentColor: AppColors.violet),
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer pour ${widget.month.label} seulement',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (v == null || v < 0) return;
          ref.read(appProvider.notifier).setRecurringOverride(r.id, widget.month, v);
          Navigator.pop(context);
        },
      ),
      if (r.hasOverride(widget.month)) ...[
        const SizedBox(height: 10),
        SoftButton(
          label: 'Annuler la modification — revenir à ${eur(r.amount)}',
          onPressed: () {
            ref.read(appProvider.notifier).setRecurringOverride(r.id, widget.month, null);
            Navigator.pop(context);
          },
        ),
      ],
      const SizedBox(height: 10),
      SoftButton(
        icon: Icons.delete_outline_rounded,
        label: 'Supprimer ce revenu',
        onPressed: () async {
          final choice = await showQuickDialog<String>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Text('Supprimer ${r.label} ?'),
              content: Text(
                  'Voulez-vous retirer ce revenu uniquement en ${widget.month.label}, ou l\'arrêter définitivement à partir de ce mois ? Les mois déjà passés ne seront jamais modifiés.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                TextButton(
                    onPressed: () => Navigator.pop(ctx, 'one'), child: const Text('Ce mois uniquement')),
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, 'future'),
                    child: const Text('Arrêter définitivement')),
              ],
            ),
          );
          if (choice == null || !context.mounted) return;
          final n = ref.read(appProvider.notifier);
          if (choice == 'one') {
            n.excludeRecurringMonth(r.id, widget.month);
          } else {
            n.endRecurringFrom(r.id, widget.month);
          }
          Navigator.pop(context);
        },
      ),
    ]);
  }
}

// ---------------- Modifier un revenu récurrent (tout : nom, montant, fréquence...) ----------------
class EditRecurringIncomeSheet extends ConsumerStatefulWidget {
  final String recurringId;
  const EditRecurringIncomeSheet({super.key, required this.recurringId});
  @override
  ConsumerState<EditRecurringIncomeSheet> createState() => _EditRecurringIncomeState();
}

class _EditRecurringIncomeState extends ConsumerState<EditRecurringIncomeSheet> {
  late RecurringIncome _r = ref.read(appProvider).recurring(widget.recurringId)!;
  late final TextEditingController _label = TextEditingController(text: _r.label);
  late final TextEditingController _amt = TextEditingController(
      text: _r.amount == _r.amount.roundToDouble() ? _r.amount.round().toString() : _r.amount.toString());
  late Ym _start = _r.start;
  late Ym? _end = _r.end;
  late int _interval = _r.intervalMonths;
  late ReceiptDayRule _receiptDay = _r.receiptDay;

  @override
  void dispose() {
    _label.dispose();
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final still = ref.watch(appProvider).recurring(widget.recurringId);
    if (still == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: AppColors.violet.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _label,
          hint: 'Nom du revenu',
          icon: Icons.edit_note_rounded,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: AppColors.violet)),
      ]),
      const SizedBox(height: 14),
      labelWithInfo('Fréquence', Hint.fieldFrequency, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      PillSelector<int>.scroll(
        items: const [
          PillItem(1,  'Mensuel'),
          PillItem(2,  '2 mois'),
          PillItem(3,  '3 mois'),
          PillItem(4,  '4 mois'),
          PillItem(6,  '6 mois'),
          PillItem(12, 'Annuel'),
        ],
        selected: _interval,
        onChanged: (n) => setState(() => _interval = n),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: SoftButton(
            icon: Icons.play_arrow_rounded,
            label: 'Commence en ${_start.label}',
            onPressed: () async {
              final y = await pickYm(context, _start);
              if (y != null) setState(() => _start = y);
            },
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: SoftButton(
            icon: Icons.stop_rounded,
            label: _end == null ? 'Sans date de fin' : 'Se termine en ${_end!.label}',
            onPressed: () async {
              final y = await pickYm(context, _end ?? _start.add(12));
              if (y != null) setState(() => _end = y);
            },
          ),
        ),
      ]),
      if (_end != null)
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(onPressed: () => setState(() => _end = null), child: const Text('Sans date de fin')),
        ),
      // ── [Mode dev] Date de réception ─────────────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 12),
        _ReceiptDayPicker(
          receiptDay: _receiptDay,
          onChanged: (r) => setState(() => _receiptDay = r),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (_label.text.trim().isEmpty || v == null || v <= 0) {
            snack(context, 'Nom et montant requis');
            return;
          }
          if (_end != null && _end!.isBefore(_start)) {
            snack(context, 'La date de fin doit être après la date de début.');
            return;
          }
          final devMode = ref.read(devModeProvider);
          ref.read(appProvider.notifier).updateRecurringIncome(widget.recurringId,
              label: _label.text.trim(), amount: v, start: _start, end: _end,
              intervalMonths: _interval,
              receiptDay: devMode ? _receiptDay : null);
          Navigator.pop(context);
        },
      ),
    ]);
  }
}
