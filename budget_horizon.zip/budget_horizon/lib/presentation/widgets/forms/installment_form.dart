part of '../forms.dart';

/// Création / modification d'un paiement en plusieurs fois.
class AddInstallmentSheet extends ConsumerStatefulWidget {
  final InstallmentPlan? existing;
  const AddInstallmentSheet({super.key, this.existing});
  @override
  ConsumerState<AddInstallmentSheet> createState() => _AddInstallmentState();
}

class _AddInstallmentState extends ConsumerState<AddInstallmentSheet> {
  final _name = TextEditingController();
  final _total = TextEditingController();
  int _count = 3;
  late Ym _start;
  int _day = 1;
  String? _cat;
  int _person = 1;

  @override
  void initState() {
    super.initState();
    final now = ref.read(nowProvider);
    _start = now;
    _day = DateTime.now().day.clamp(1, 28).toInt();
    _total.addListener(() {
      if (mounted) setState(() {});
    });
    final e = widget.existing;
    if (e != null) {
      _name.text = e.name;
      _total.text = e.total == e.total.roundToDouble() ? e.total.round().toString() : e.total.toString();
      _count = e.count;
      _start = e.start;
      _day = e.day;
      _cat = e.categoryId;
      _person = e.person == 0 ? 1 : e.person;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _total.dispose();
    super.dispose();
  }

  void _save() {
    final total = parseAmount(_total.text);
    if (_name.text.trim().isEmpty || total == null || total <= 0) {
      snack(context, 'Nom et montant total requis');
      return;
    }
    if (_cat == null) {
      snack(context, 'Choisis le budget concerné');
      return;
    }
    final d = ref.read(appProvider);
    final n = ref.read(appProvider.notifier);
    final e = widget.existing;
    final person = d.isCouple ? _person : 0;
    if (e != null) {
      n.updateInstallment(e.copyWith(
          name: _name.text.trim(),
          categoryId: _cat,
          person: person,
          total: total,
          count: _count,
          start: _start,
          day: _day));
    } else {
      n.addInstallment(InstallmentPlan(
          id: n.newId(),
          name: _name.text.trim(),
          categoryId: _cat!,
          person: person,
          total: total,
          count: _count,
          start: _start,
          day: _day));
    }
    Navigator.pop(context, true);
  }

  Widget _stepper(String label, String value, VoidCallback minus, VoidCallback plus) {
    return Row(children: [
      Expanded(
          child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
      RoundIconButton(icon: Icons.remove_rounded, size: 36, onTap: minus),
      SizedBox(
        width: 110,
        child: Text(value,
            textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
      RoundIconButton(icon: Icons.add_rounded, size: 36, onTap: plus),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final total = parseAmount(_total.text) ?? 0;
    final each = total > 0 ? total / _count : 0.0;
    final end = _start.add(_count - 1);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
            flex: 3,
            child: _CompactField(
              controller: _name,
              hint: 'Achat (ex. Canapé)',
              icon: Icons.shopping_bag_outlined,
              textCapitalization: TextCapitalization.sentences,
              onChanged: (_) {},
            )),
        const SizedBox(width: 8),
        Expanded(
            flex: 2,
            child: _AmountFieldCompact(controller: _total, accentColor: AppColors.violet)),
      ]),
      const SizedBox(height: 4),
      labelWithInfo('Montant total à payer', Hint.fieldInstallTotal,
          style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
      const SizedBox(height: 14),
      Align(alignment: Alignment.centerLeft, child: labelWithInfo('Échéances', Hint.fieldInstallCount, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
      _stepper('Nombre de fois', '$_count fois', () {
        if (_count > 2) setState(() => _count--);
      }, () {
        if (_count < 36) setState(() => _count++);
      }),
      const SizedBox(height: 8),
      _stepper('Première échéance', '${_start.short} ${_start.year}',
          () => setState(() => _start = _start.add(-1)), () => setState(() => _start = _start.add(1))),
      const SizedBox(height: 8),
      _stepper('Jour du mois', 'le $_day', () {
        if (_day > 1) setState(() => _day--);
      }, () {
        if (_day < 31) setState(() => _day++);
      }),
      const SizedBox(height: 14),
      labelWithInfo('Dans quel budget ?', Hint.fieldInstallBudget, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final c in d.categories)
          ChoiceChip(
            label: Text('${c.emoji} ${c.name}'),
            selected: _cat == c.id,
            onSelected: (_) => setState(() => _cat = c.id),
          ),
        ChoiceChip(
          label: const Text('⚡ Imprévu'),
          selected: _cat == kUnexpectedId,
          onSelected: (_) => setState(() => _cat = kUnexpectedId),
        ),
      ]),
      if (d.isCouple) ...[
        const SizedBox(height: 14),
        PillSelector<int>.row(
          items: [PillItem(1, d.personName(1)), PillItem(2, d.personName(2))],
          selected: _person,
          onChanged: (v) => setState(() => _person = v),
        ),
      ],
      const SizedBox(height: 14),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: tint(AppColors.violet, .12),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(
          total > 0
              ? '$_count × ${eur(each)} · de ${_start.short} ${_start.year} à ${end.short} ${end.year}.\n'
                  'Chaque mois, je te demanderai de confirmer l\'échéance avant de l\'ajouter au budget.'
              : 'Chaque mois, je te demanderai de confirmer l\'échéance avant de l\'ajouter au budget.',
          style: const TextStyle(fontSize: 12.5, height: 1.35),
        ),
      ),
      const SizedBox(height: 16),
      _CancelSaveRow(saveLabel: widget.existing == null ? 'Créer' : 'Enregistrer', onSave: _save),
    ]);
  }
}
