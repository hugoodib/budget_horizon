part of '../forms.dart';

class AddIncomeSheet extends ConsumerStatefulWidget {
  final Ym month;
  final bool startRecurring;
  const AddIncomeSheet({super.key, required this.month, this.startRecurring = false});
  @override
  ConsumerState<AddIncomeSheet> createState() => _AddIncomeState();
}

class _AddIncomeState extends ConsumerState<AddIncomeSheet> {
  late bool _recurring = widget.startRecurring;
  IncomeKind _kind = IncomeKind.salary;
  late Ym _start = widget.month;
  late Ym _month = widget.month; // mois d'un revenu ponctuel
  Ym? _end;
  int _interval = 1;
  final _label = TextEditingController();
  final _amt = TextEditingController();
  final _note = TextEditingController();
  bool _received = false; // déjà reçu : pointé dès la création
  late final _hours = TextEditingController(
      text: ref.read(repositoryProvider).readMeta('salary_hours_week') ?? '');

  @override
  void dispose() {
    _label.dispose();
    _amt.dispose();
    _note.dispose();
    _hours.dispose();
    super.dispose();
  }

  void _save() {
    final v = parseAmount(_amt.text);
    if (v == null || v <= 0) {
      snack(context, 'Montant requis');
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (_recurring) {
      if (_end != null && _end!.isBefore(_start)) {
        snack(context, 'La date de fin doit être après la date de début.');
        return;
      }
      final h = parseAmount(_hours.text);
      if (h != null && h > 0) {
        ref.read(repositoryProvider).writeMeta('salary_hours_week', h.toString().replaceAll(RegExp(r'\.0$'), ''));
      }
      n.addRecurringIncome(_label.text.trim(), v, _start, _end,
          intervalMonths: _interval, checked: _received);
    } else {
      n.addExtraIncome(_kind, _label.text.trim(), v, _month,
          note: _note.text.trim(), checked: _received);
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Drag handle ────────────────────────────────────────
        Center(child: Container(
          width: 36, height: 4,
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(color: AppColors.success.withAlpha(80), borderRadius: BorderRadius.circular(2)),
        )),
        // ── Ponctuel / Récurrent ───────────────────────────────
        withInfo(TabSwitcher<bool>(
          tabs: const [
            (value: false, label: 'Ponctuel',   icon: Icons.bolt_rounded),
            (value: true,  label: 'Récurrent',  icon: Icons.repeat_rounded),
          ],
          selected: _recurring,
          onChanged: (v) => setState(() => _recurring = v),
        ), Hint.fieldRecurring),
        const SizedBox(height: 8),
        Row(children: [
          const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
          const SizedBox(width: 5),
          Expanded(child: Text(
            _recurring
                ? 'Ce revenu sera compté chaque mois automatiquement. Vous pourrez l\'ajuster mois par mois.'
                : 'Ce revenu ne sera compté qu\'une seule fois, en ${_month.label}.',
            style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
          )),
        ]),
        const SizedBox(height: 14),
        if (!_recurring) ...[
          PillSelector<IncomeKind>(
            items: [for (final k in IncomeKind.values) PillItem(k, k.label)],
            selected: _kind,
            onChanged: (k) => setState(() => _kind = k),
          ),
          const SizedBox(height: 12),
          SoftButton(
            icon: Icons.calendar_month_rounded,
            label: 'Reçu en ${_month.longName}',
            onPressed: () async {
              final y = await pickYm(context, _month);
              if (y != null) setState(() => _month = y);
            },
          ),
          const SizedBox(height: 12),
        ],
        // ── Libellé + Montant côte à côte ──────────────────────
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 3, child: _CompactField(
            controller: _label,
            hint: _recurring ? 'Nom (ex. Salaire, Loyer perçu)' : 'Description (optionnel)',
            icon: Icons.edit_note_rounded,
            textCapitalization: TextCapitalization.sentences,
            onChanged: (_) {},
          )),
          const SizedBox(width: 8),
          Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: AppColors.success)),
        ]),
        if (_recurring) ...[
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
              child: SoftButton(
                icon: Icons.play_arrow_rounded,
                label: 'Commence en ${_start.label}',
                onPressed: () async {
                  final y = await pickYm(context, _start);
                  if (y != null) setState(() => _start = y);
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: SoftButton(
                icon: Icons.stop_rounded,
                label: _end == null ? 'Sans date de fin' : 'Se termine en ${_end!.label}',
                onPressed: () async {
                  final y = await pickYm(context, _end ?? _start.add(12));
                  if (y != null) setState(() => _end = y);
                },
              ),
            ),
          ]),
          if (_end != null)
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: () => setState(() => _end = null), child: const Text('Supprimer la date de fin')),
            ),
          const SizedBox(height: 12),
          labelWithInfo('Fréquence', Hint.fieldFrequency, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          PillSelector<int>.scroll(
            items: const [
              PillItem(1,  'Mensuel'),
              PillItem(2,  '2 mois'),
              PillItem(3,  '3 mois'),
              PillItem(4,  '4 mois'),
              PillItem(6,  '6 mois'),
              PillItem(12, 'Annuel'),
            ],
            selected: _interval,
            onChanged: (n) => setState(() => _interval = n),
          ),
        ],
        if (!_recurring) ...[
          const SizedBox(height: 14),
          TextField(
            controller: _note,
            maxLines: 2,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(
              hintText: 'Note (optionnel)',
              prefixIcon: Icon(Icons.sticky_note_2_outlined, size: 20),
            ),
          ),
        ],
        if (_recurring) ...[
          const SizedBox(height: 14),
          TextField(
            controller: _hours,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Heures par semaine pour ce travail (optionnel)',
              suffixText: 'h',
              prefixIcon: Icon(Icons.schedule_rounded, size: 20),
            ),
          ),
        ],
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: labelWithInfo('Déjà reçu', Hint.fieldReceived, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(_recurring
              ? 'Pointé dès maintenant pour ${_start.label}.'
              : 'Pointé dès maintenant : il compte déjà dans ton solde actuel.'),
          value: _received,
          onChanged: (v) => setState(() => _received = v),
        ),
        const SizedBox(height: 8),
        _CancelSaveRow(saveLabel: 'Enregistrer', onSave: _save),
      ]);
}

// ---------------- Charge fixe (création ou modification) ----------------
class AddFixedExpenseSheet extends ConsumerStatefulWidget {
  final FixedExpense? existing;
  const AddFixedExpenseSheet({super.key, this.existing});
  @override
  ConsumerState<AddFixedExpenseSheet> createState() => _AddFixedState();
}

class _AddFixedState extends ConsumerState<AddFixedExpenseSheet> {
  bool _paid = false; // déjà prélevée : pointée dès la création
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _amt = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.amount == widget.existing!.amount.roundToDouble()
              ? widget.existing!.amount.round().toString()
              : widget.existing!.amount.toStringAsFixed(2)));
  late final TextEditingController _note = TextEditingController(text: widget.existing?.note ?? '');
  late Ym _start = widget.existing?.start ?? ref.read(nowProvider);
  late Ym? _end = widget.existing?.end;
  late String _emoji = widget.existing?.emoji ?? '';
  late bool _useEmoji = (widget.existing?.emoji ?? '').isNotEmpty;
  late int _color = widget.existing?.colorValue ?? 0xFF9E9E9E;
  late int _interval = widget.existing?.intervalMonths ?? 1;
  late String? _leaveTypeId = widget.existing?.leaveTypeId;
  late String? _linkedCategoryId = widget.existing?.categoryId;
  // 0 = sans couleur, 1 = catégorie existante, 2 = nouvelle couleur personnalisée
  late int _colorMode =
      (widget.existing?.colorValue != null && widget.existing?.colorValue != 0xFF9E9E9E) ? 2 : 0;
  bool _onlyThisMonth = false; // raccourci "seulement ce mois-ci"
  // Noms donnés aux couleurs des charges (ex. Maison, Crédit)
  late final Map<int, String> _names = {
    for (final e in ref.read(appProvider).colorNames.entries)
      if (e.key.startsWith('fixed:')) int.parse(e.key.substring(6)): e.value,
  };

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    final letter = _name.text.trim().isEmpty ? '?' : _name.text.trim().characters.first.toUpperCase();
    final accent = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _name,
          hint: 'Nom (ex. Loyer, Netflix, Assurance)',
          icon: Icons.edit_note_rounded,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) => setState(() {}),
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: accent)),
      ]),
      const SizedBox(height: 12),
      // Raccourci : juste ce mois-ci (une seule occurrence)
      if (widget.existing == null)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () {
              final now = ref.read(nowProvider);
              setState(() {
                _onlyThisMonth = !_onlyThisMonth;
                if (_onlyThisMonth) {
                  _start = now;
                  _end = now;
                  _interval = 1;
                } else {
                  _end = null;
                }
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: _onlyThisMonth ? AppColors.teal.withAlpha(20) : context.fieldColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _onlyThisMonth ? AppColors.teal : Colors.transparent,
                  width: 1.5,
                ),
              ),
              child: Row(children: [
                Icon(_onlyThisMonth ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: _onlyThisMonth ? AppColors.teal : AppColors.muted, size: 20),
                const SizedBox(width: 10),
                const Text('Juste ce mois',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              ]),
            ),
          ),
        ),
      if (!_onlyThisMonth) ...[
        Row(children: [
          Expanded(
            child: SoftButton(
              icon: Icons.play_arrow_rounded,
              label: 'Commence en ${_start.label}',
              onPressed: () async {
                final y = await pickYm(context, _start);
                if (y != null) setState(() => _start = y);
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: SoftButton(
              icon: Icons.stop_rounded,
              label: _end == null ? 'Sans date de fin' : 'Se termine en ${_end!.label}',
              onPressed: () async {
                final y = await pickYm(context, _end ?? _start.add(12));
                if (y != null) setState(() => _end = y);
              },
            ),
          ),
        ]),
        if (_end != null)
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(onPressed: () => setState(() => _end = null), child: const Text('Supprimer la date de fin')),
          ),
      ],
      const SizedBox(height: 14),
      labelWithInfo('Fréquence', Hint.fieldFrequency, style: const TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      PillSelector<int>.scroll(
        items: const [
          PillItem(1,  'Mensuel'),
          PillItem(2,  '2 mois'),
          PillItem(3,  '3 mois'),
          PillItem(4,  '4 mois'),
          PillItem(6,  '6 mois'),
          PillItem(12, 'Annuel'),
        ],
        selected: _interval,
        onChanged: (n) => setState(() => _interval = n),
      ),
      const SizedBox(height: 14),
      // ── Catégorie / Couleur ───────────────────────────────────
      const Text('Couleur', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
      const SizedBox(height: 8),
      PillSelector<int>.row(
        items: const [
          PillItem(0, 'Gris neutre', icon: Icons.circle_outlined),
          PillItem(2, 'Couleur',  icon: Icons.palette_outlined),
        ],
        selected: _colorMode,
        onChanged: (v) => setState(() {
          _colorMode = v;
          if (v == 0) { _linkedCategoryId = null; _color = 0xFF9E9E9E; }
          if (v == 2 && _color == 0xFF9E9E9E) _color = AppColors.palette.first.value;
        }),
      ),
      const SizedBox(height: 10),
      // Couleur personnalisée
      if (_colorMode == 2) StylePicker(
        emoji: _emoji,
        color: _color,
        showEmoji: true,
        previewLetter: letter,
        onEmoji: (e) => setState(() {
          _emoji = e;
          _useEmoji = e.isNotEmpty;
        }),
        onColor: (c) => setState(() => _color = c),
        colorNames: _names,
        onRenameColor: (c, t) => setState(() => _names[c] = t),
      ),
      // ── [Mode dev] Lier à un type de congé ───────────────────
      if (ref.watch(devModeProvider) && ref.watch(appProvider).leaveTypes.isNotEmpty) ...[
        const SizedBox(height: 14),
        const Text('Lier à un type de congé (optionnel)',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 8),
        Builder(builder: (ctx) {
          final leaveTypes = ref.watch(appProvider).leaveTypes;
          return PillSelector<String?>(
            items: [
              const PillItem(null, 'Aucun'),
              for (final lt in leaveTypes)
                PillItem(lt.id, lt.name),
            ],
            selected: _leaveTypeId,
            onChanged: (v) => setState(() => _leaveTypeId = v),
          );
        }),
      ],
      const SizedBox(height: 14),
      // ── Note libre ────────────────────────────────────────────
      TextField(
        controller: _note,
        maxLines: 2,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(
          hintText: 'Note (optionnel)',
          prefixIcon: Icon(Icons.sticky_note_2_outlined, size: 20),
        ),
      ),
      if (!editing) ...[
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: labelWithInfo('Déjà prélevée', Hint.fieldDebited, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('Pointée dès maintenant pour ${_start.label}.'),
          value: _paid,
          onChanged: (v) => setState(() => _paid = v),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (_name.text.trim().isEmpty || v == null || v <= 0) {
            snack(context, 'Nom et montant requis');
            return;
          }
          if (_end != null && _end!.isBefore(_start)) {
            snack(context, 'La date de fin doit être après la date de début.');
            return;
          }
          final n = ref.read(appProvider.notifier);
          if (_colorMode == 2) n.setColorNames('fixed', _names);
          final emoji = _useEmoji ? _emoji : '';
          // Couleur effective : depuis catégorie liée, personnalisée, ou gris neutre
          final effectiveColor = _colorMode == 0 ? 0xFF9E9E9E : _color;
          if (editing) {
            n.updateFixedExpense(FixedExpense(
                id: widget.existing!.id,
                name: _name.text.trim(),
                amount: v,
                start: _start,
                end: _end,
                emoji: emoji,
                colorValue: effectiveColor,
                categoryId: _colorMode == 0 ? null : _linkedCategoryId,
                intervalMonths: _interval,
                checkedMonths: widget.existing!.checkedMonths,
                leaveTypeId: _leaveTypeId,
                note: _note.text.trim()));
          } else {
            n.addFixedExpense(_name.text.trim(), v, _start, _end,
                emoji: emoji, colorValue: effectiveColor, intervalMonths: _interval,
                leaveTypeId: _leaveTypeId,
                categoryId: _colorMode == 0 ? null : _linkedCategoryId,
                note: _note.text.trim(),
                checked: _paid);
          }
          Navigator.pop(context);
        },
      ),
      if (editing) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer...',
          onPressed: () async {
            final choice = await showQuickDialog<String>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('Supprimer ${widget.existing!.name} ?'),
                content: const Text('Pour toujours, seulement un mois, ou une période précise ?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                  TextButton(onPressed: () => Navigator.pop(ctx, 'one'), child: const Text('Un seul mois')),
                  TextButton(onPressed: () => Navigator.pop(ctx, 'range'), child: const Text('Une période')),
                  FilledButton(
                      onPressed: () => Navigator.pop(ctx, 'all'), child: const Text('Pour toujours')),
                ],
              ),
            );
            if (choice == null || !context.mounted) return;
            final n = ref.read(appProvider.notifier);
            if (choice == 'all') {
              n.removeFixedExpense(widget.existing!.id);
              Navigator.pop(context);
              return;
            }
            if (choice == 'one') {
              final y = await pickYm(context, ref.read(chargeMonthProvider));
              if (y != null) n.excludeFixedMonths(widget.existing!.id, [y]);
            } else if (choice == 'range') {
              final from = await pickYm(context, ref.read(chargeMonthProvider));
              if (from == null || !context.mounted) return;
              final to = await pickYm(context, from);
              if (to == null) return;
              final a = from.index <= to.index ? from : to;
              final b = from.index <= to.index ? to : from;
              final months = [for (var i = a.index; i <= b.index; i++) Ym.fromIndex(i)];
              n.excludeFixedMonths(widget.existing!.id, months);
            }
            if (context.mounted) Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}
