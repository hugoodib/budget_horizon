part of '../forms.dart';

// ---------------- Réduction de budgets pour financer un projet ----------------
class _BudgetReduceSheet extends ConsumerStatefulWidget {
  final String projectName;
  final double monthlyNeeded;
  final double disponible;
  final double shortage;
  final int months;
  const _BudgetReduceSheet({
    required this.projectName,
    required this.monthlyNeeded,
    required this.disponible,
    required this.shortage,
    required this.months,
  });
  @override
  ConsumerState<_BudgetReduceSheet> createState() => _BudgetReduceSheetState();
}

class _BudgetReduceSheetState extends ConsumerState<_BudgetReduceSheet> {
  // réductions choisies par l'utilisateur : budgetId -> montant réduit
  late Map<String, double> _reductions;

  @override
  void initState() {
    super.initState();
    _reductions = {
      for (final b in ref.read(appProvider).budgets) b.id: 0.0,
    };
  }

  double get _totalReduced => _reductions.values.fold(0.0, (a, b) => a + b);
  double get _remaining => widget.shortage - _totalReduced;

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final budgets = d.budgets.where((b) => b.amount > 0).toList();
    final covered = _remaining <= 0.5;

    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.75,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // ── Résumé ────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.warning.withAlpha(18),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.warning.withAlpha(60)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Text('⚠️', style: TextStyle(fontSize: 18)),
                const SizedBox(width: 8),
                Expanded(child: Text(
                  '${eur(widget.monthlyNeeded)}/mois nécessaires pour "${widget.projectName}"',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
                )),
              ]),
              const SizedBox(height: 6),
              Text(
                'Il manque ${eur(widget.shortage)}/mois sur votre marge actuelle (${eur(widget.disponible)}/mois disponibles).',
                style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
              ),
              const SizedBox(height: 4),
              Text(
                'Choisissez les budgets à réduire pour dégager cette marge :',
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
              ),
            ]),
          ),
          const SizedBox(height: 14),

          // ── Barre de progression ──────────────────────────────
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(
                covered ? '✅ Objectif atteint !' : 'Marge dégagée',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13.5,
                  color: covered ? AppColors.success : context.textColor,
                ),
              ),
              Text(
                '${eur(_totalReduced)} / ${eur(widget.shortage)}',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                  color: covered ? AppColors.success : AppColors.warning,
                ),
              ),
            ]),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                height: 14,
                child: Stack(children: [
                  // fond
                  Container(color: context.fieldColor),
                  // remplissage animé
                  AnimatedFractionallySizedBox(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOut,
                    widthFactor: (_totalReduced / widget.shortage).clamp(0.0, 1.0),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: covered
                          ? [AppColors.success, AppColors.success]
                          : [AppColors.warning, AppColors.warning.withGreen(200)]),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 6),
            if (!covered)
              Text('Encore ${eur(_remaining)}/mois à dégager',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          ]),
          const SizedBox(height: 14),

          // ── Liste des budgets avec slider ─────────────────────
          for (final b in budgets) ...[
            _BudgetSliderTile(
              budget: b,
              reduction: _reductions[b.id] ?? 0,
              onChanged: (v) => setState(() => _reductions[b.id] = v),
              categoryName: d.category(b.categoryId)?.name ?? b.id,
              categoryColor: d.category(b.categoryId) != null
                  ? Color(d.category(b.categoryId)!.colorValue)
                  : AppColors.violet,
            ),
            const SizedBox(height: 8),
          ],

          const SizedBox(height: 8),

          // ── Boutons ───────────────────────────────────────────
          if (covered) ...[
            FilledButton(
              onPressed: () {
                // Appliquer les réductions
                final n = ref.read(appProvider.notifier);
                for (final b in budgets) {
                  final r = _reductions[b.id] ?? 0;
                  if (r > 0.5) n.setBudgetAmount(b.id, b.amount - r);
                }
                Navigator.pop(context, true);
              },
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
              child: const Text('Appliquer les réductions et créer le voyage',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ] else ...[
            OutlinedButton(
              onPressed: () => Navigator.pop(context, true),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Créer quand même sans modifier les budgets',
                  style: TextStyle(fontWeight: FontWeight.w600)),
            ),
          ],
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
        ],
      ),
    );
  }
}

class _BudgetSliderTile extends StatelessWidget {
  final Budget budget;
  final double reduction;
  final ValueChanged<double> onChanged;
  final String categoryName;
  final Color categoryColor;
  const _BudgetSliderTile({
    required this.budget,
    required this.reduction,
    required this.onChanged,
    required this.categoryName,
    required this.categoryColor,
  });

  @override
  Widget build(BuildContext context) {
    final newAmount = budget.amount - reduction;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(color: categoryColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(categoryName,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
          Text(
            reduction > 0
                ? '${eur(budget.amount)} → ${eur(newAmount)}'
                : eur(budget.amount),
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 13,
              color: reduction > 0 ? AppColors.warning : AppColors.muted,
            ),
          ),
        ]),
        if (reduction > 0) ...[
          const SizedBox(height: 2),
          Text('Réduction : −${eur(reduction)}/mois',
              style: const TextStyle(color: AppColors.warning, fontSize: 11.5, fontWeight: FontWeight.w600)),
        ],
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 3,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
            activeTrackColor: categoryColor,
            thumbColor: categoryColor,
            inactiveTrackColor: categoryColor.withAlpha(40),
          ),
          child: Slider(
            value: reduction,
            min: 0,
            max: budget.amount,
            divisions: budget.amount > 10 ? (budget.amount / 5).round() : null,
            onChanged: (v) => onChanged((v * 2).round() / 2), // arrondi au 0.5 €
          ),
        ),
      ]),
    );
  }
}

// ---------------- Modifier un budget (tous les mois ou un seul mois) ----------------
class EditBudgetSheet extends ConsumerStatefulWidget {
  final String budgetId;
  final Ym month;
  const EditBudgetSheet({super.key, required this.budgetId, required this.month});
  @override
  ConsumerState<EditBudgetSheet> createState() => _EditBudgetState();
}

class _EditBudgetState extends ConsumerState<EditBudgetSheet> {
  bool _onlyThisMonth = false;
  late final TextEditingController _amt;
  late String _emojiSel;
  late int _colorSel;
  late ReceiptDayRule _debitDay;

  Budget? _find() {
    for (final b in ref.read(appProvider).budgets) {
      if (b.id == widget.budgetId) return b;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    final b = _find();
    _amt = TextEditingController(text: (b?.amount ?? 0).round().toString());
    final cat = b == null ? null : ref.read(appProvider).category(b.categoryId);
    _emojiSel = cat?.emoji ?? '💰';
    _colorSel = cat?.colorValue ?? AppColors.palette[2].value;
    _debitDay = b?.debitDay ?? ReceiptDayRule.none;
  }

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  void _setMode(bool only) {
    final b = _find();
    if (b == null) return;
    setState(() {
      _onlyThisMonth = only;
      _amt.text = (only ? b.amountIn(widget.month) : b.amount).round().toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    final b = ref.watch(appProvider).budgets.where((x) => x.id == widget.budgetId).firstOrNull;
    if (b == null) return const SizedBox.shrink();
    final n = ref.read(appProvider.notifier);
    final overridden = b.hasOverride(widget.month);
    final accent = Color(_colorSel);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Montant ───────────────────────────────────────────────
      _AmountFieldCompact(controller: _amt, accentColor: accent),
      const SizedBox(height: 12),
      // ── Portée ────────────────────────────────────────────────
      withInfo(TabSwitcher<bool>(
        tabs: <({bool value, String label, IconData? icon})>[
          (value: false, label: 'Pour toujours', icon: Icons.all_inclusive_rounded),
          (value: true,  label: 'En ${widget.month.label} seulement', icon: Icons.event_rounded),
        ],
        selected: _onlyThisMonth,
        onChanged: _setMode,
      ), Hint.fieldScope),
      const SizedBox(height: 6),
      Row(children: [
        const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
        const SizedBox(width: 5),
        Expanded(child: Text(
          _onlyThisMonth
              ? 'Tous les autres mois gardent leur budget habituel — seul ${widget.month.longName.toLowerCase()} sera différent.'
              : 'Ce nouveau montant s\'appliquera à tous les mois à venir'
                  '${overridden ? ' (sauf ${widget.month.longName.toLowerCase()} qui a déjà été modifié)' : ''}.',
          style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
        )),
      ]),
      if (ref.watch(appProvider).isCouple) ...[
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: labelWithInfo('Un budget par personne', Hint.fieldPerPerson, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(b.person != 0 ? 'Chaque personne gère son budget séparément.' : 'Un seul budget partagé entre les deux.'),
          value: b.person != 0,
          onChanged: (v) {
            n.setBudgetSeparate(b.categoryId, v);
            Navigator.pop(context);
          },
        ),
      ],
      const SizedBox(height: 16),
      const Text('Icône et couleur', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      StylePicker(
        emoji: _emojiSel,
        color: _colorSel,
        onEmoji: (e) => setState(() => _emojiSel = e),
        onColor: (c) => setState(() => _colorSel = c),
      ),
      // ── [Mode dev] Règle de débit du budget ──────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 16),
        const Text('Date de débit par défaut',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 4),
        const Text(
          'S\'applique à toutes les dépenses de ce budget. '
          'Une dépense avec sa propre date de débit la garde.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
        ),
        const SizedBox(height: 10),
        _BudgetDebitDayPicker(
          debitDay: _debitDay,
          onChanged: (r) => setState(() => _debitDay = r),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (v == null || v < 0) return;
          if (_onlyThisMonth) {
            n.setBudgetOverride(b.id, widget.month, v);
          } else {
            n.setBudgetAmount(b.id, v);
          }
          n.setCategoryStyle(b.categoryId, _emojiSel, _colorSel);
          if (ref.read(devModeProvider)) {
            n.setBudgetDebitDay(b.id, _debitDay);
          }
          Navigator.pop(context);
        },
      ),
      if (overridden) ...[
        const SizedBox(height: 10),
        SoftButton(
          label: 'Annuler la modification de ${widget.month.label} — revenir au montant habituel',
          onPressed: () {
            n.setBudgetOverride(b.id, widget.month, null);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}
