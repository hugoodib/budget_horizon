part of '../forms.dart';

// ---------------- Couple : noms des deux conjoints ----------------
class CoupleSheet extends ConsumerStatefulWidget {
  const CoupleSheet({super.key});
  @override
  ConsumerState<CoupleSheet> createState() => _CoupleState();
}

class _CoupleState extends ConsumerState<CoupleSheet> {
  late final TextEditingController _p1;
  late final TextEditingController _p2;

  @override
  void initState() {
    super.initState();
    final u = ref.read(appProvider).user;
    _p1 = TextEditingController(text: u.isCouple ? u.person1 : '');
    _p2 = TextEditingController(text: u.isCouple ? u.person2 : '');
  }

  @override
  void dispose() {
    _p1.dispose();
    _p2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCouple = ref.watch(appProvider).isCouple;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: AppColors.violet.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Info ─────────────────────────────────────────────────
      Row(children: [
        const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
        const SizedBox(width: 5),
        Expanded(child: Text(
          isCouple
              ? 'Modifiez les prénoms affichés sur les budgets et les dépenses.'
              : 'Vous pourrez séparer certains budgets (un par personne) et garder les autres en commun.',
          style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
        )),
      ]),
      const SizedBox(height: 14),
      // ── Prénom 1 + Prénom 2 côte à côte ─────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: _CompactField(
          controller: _p1,
          hint: 'Vous',
          icon: Icons.person_outline_rounded,
          textCapitalization: TextCapitalization.words,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(child: _CompactField(
          controller: _p2,
          hint: 'Conjoint(e)',
          icon: Icons.person_outline_rounded,
          textCapitalization: TextCapitalization.words,
          onChanged: (_) {},
        )),
      ]),
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: isCouple ? 'Enregistrer' : 'Activer le mode couple',
        onSave: () {
          final a = _p1.text.trim();
          final b = _p2.text.trim();
          if (a.isEmpty || b.isEmpty) {
            snack(context, 'Les deux prénoms sont requis');
            return;
          }
          if (a.toLowerCase() == b.toLowerCase()) {
            snack(context, 'Les deux prénoms doivent être différents');
            return;
          }
          ref.read(appProvider.notifier).setCouple(true, person1: a, person2: b);
          Navigator.pop(context);
        },
      ),
    ]);
  }
}


// ── [Mode dev] Sélecteur de date de débit ────────────────────────────────────
/// Permet de choisir la date à laquelle une dépense sera débitée.
/// Raccourcis : "5 du mois prochain", "dernier jour ouvré", calendrier libre.
class _DebitDatePicker extends StatelessWidget {
  final DateTime expenseDate; // date de la dépense (référence pour les raccourcis)
  final DateTime? debitDate;
  final ValueChanged<DateTime?> onChanged;
  const _DebitDatePicker({required this.expenseDate, required this.debitDate, required this.onChanged});

  DateTime _fifthNextMonth() {
    final next = DateTime(expenseDate.year, expenseDate.month + 1, 5);
    return next;
  }

  DateTime _lastWorkingDayOfMonth() {
    final lastDay = DateTime(expenseDate.year, expenseDate.month + 1, 0).day;
    var d = DateTime(expenseDate.year, expenseDate.month, lastDay);
    while (d.weekday == DateTime.saturday || d.weekday == DateTime.sunday) {
      d = d.subtract(const Duration(days: 1));
    }
    return d;
  }

  String _fmt(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    final fifth = _fifthNextMonth();
    final lastWorking = _lastWorkingDayOfMonth();
    final hasFifth = debitDate != null && _isSameDay(debitDate!, fifth);
    final hasLast = debitDate != null && _isSameDay(debitDate!, lastWorking);
    final hasNow = debitDate != null && _isSameDay(debitDate!, expenseDate);
    final hasCustom = debitDate != null && !hasFifth && !hasLast && !hasNow;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: debitDate != null
            ? tint(AppColors.violet, .08)
            : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: debitDate != null ? AppColors.violet.withAlpha(80) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_outlined, size: 15,
              color: debitDate != null ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            debitDate != null ? 'Débit le ${_fmt(debitDate!)}' : 'Date de débit (selon le budget)',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: debitDate != null ? AppColors.violet : AppColors.muted,
            ),
          ),
          if (debitDate != null) ...[
            const Spacer(),
            GestureDetector(
              onTap: () => onChanged(null),
              child: const Icon(Icons.close_rounded, size: 18, color: AppColors.muted),
            ),
          ],
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          // Pas différée : débitée le jour même (compte ce mois-ci dès qu'elle est cochée)
          _DebitChip(
            label: 'Débité ce mois-ci',
            selected: hasNow,
            icon: Icons.bolt_rounded,
            onTap: () => onChanged(hasNow
                ? null
                : DateTime(expenseDate.year, expenseDate.month, expenseDate.day)),
          ),
          // Raccourci 1 : le 5 du mois prochain
          _DebitChip(
            label: '5 du mois prochain',
            selected: hasFifth,
            onTap: () => onChanged(hasFifth ? null : fifth),
          ),
          // Raccourci 2 : dernier jour ouvré du mois
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: hasLast,
            onTap: () => onChanged(hasLast ? null : lastWorking),
          ),
          // Raccourci 3 : calendrier libre
          _DebitChip(
            label: hasCustom ? _fmt(debitDate!) : 'Autre date…',
            selected: hasCustom,
            icon: Icons.calendar_today_rounded,
            onTap: () async {
              final now = DateTime.now();
              final picked = await showDatePicker(
                context: context,
                initialDate: debitDate ?? expenseDate.add(const Duration(days: 3)),
                firstDate: DateTime(now.year - 1),
                lastDate: DateTime(now.year + 2),
              );
              if (picked != null) onChanged(picked);
            },
          ),
        ]),
      ]),
    );
  }
}

class _DebitChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;
  const _DebitChip({required this.label, required this.selected, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppColors.violet.withAlpha(25) : context.fieldColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.violet : context.trackColor,
            width: 1.5,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: selected ? AppColors.violet : AppColors.muted),
            const SizedBox(width: 5),
          ],
          Text(label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? AppColors.violet : context.textColor,
              )),
        ]),
      ),
    );
  }
}


// ── [Mode dev] Sélecteur de date de réception (revenus récurrents) ────────────
class _ReceiptDayPicker extends StatefulWidget {
  final ReceiptDayRule receiptDay;
  final ValueChanged<ReceiptDayRule> onChanged;
  const _ReceiptDayPicker({required this.receiptDay, required this.onChanged});

  @override
  State<_ReceiptDayPicker> createState() => _ReceiptDayPickerState();
}

class _ReceiptDayPickerState extends State<_ReceiptDayPicker> {
  late TextEditingController _dayCtrl;

  @override
  void initState() {
    super.initState();
    _dayCtrl = TextEditingController(
      text: widget.receiptDay.kind == ReceiptDayKind.fixedDay
          ? widget.receiptDay.day.toString()
          : '',
    );
  }

  @override
  void dispose() {
    _dayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rule = widget.receiptDay;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: rule.kind != ReceiptDayKind.none
            ? tint(AppColors.teal, .08)
            : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: rule.kind != ReceiptDayKind.none
              ? AppColors.teal.withAlpha(80)
              : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_rounded, size: 15,
              color: rule.kind != ReceiptDayKind.none ? AppColors.teal : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            _ruleLabel(rule),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: rule.kind != ReceiptDayKind.none ? AppColors.teal : AppColors.muted,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _DebitChip(
            label: 'Aucune règle',
            selected: rule.kind == ReceiptDayKind.none,
            onTap: () {
              widget.onChanged(ReceiptDayRule.none);
              setState(() => _dayCtrl.text = '');
            },
          ),
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: rule.kind == ReceiptDayKind.lastWorkingDay,
            onTap: () => widget.onChanged(
                const ReceiptDayRule(kind: ReceiptDayKind.lastWorkingDay)),
          ),
        ]),
        const SizedBox(height: 10),
        // Saisie d'un jour fixe
        Row(children: [
          Expanded(
            child: TextField(
              controller: _dayCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Jour fixe du mois (ex. 26)',
                suffixText: 'du mois',
                filled: true,
                fillColor: rule.kind == ReceiptDayKind.fixedDay
                    ? AppColors.teal.withAlpha(15)
                    : null,
              ),
              onChanged: (v) {
                final d = int.tryParse(v);
                if (d != null && d >= 1 && d <= 31) {
                  widget.onChanged(ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: d));
                }
              },
            ),
          ),
        ]),
        if (rule.kind == ReceiptDayKind.fixedDay)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Le salaire sera reçu le ${rule.day} de chaque mois.',
              style: const TextStyle(color: AppColors.teal, fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
      ]),
    );
  }

  String _ruleLabel(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => 'Date de réception (optionnel)',
        ReceiptDayKind.fixedDay => 'Reçu le ${r.day} du mois',
        ReceiptDayKind.lastWorkingDay => 'Reçu le dernier jour ouvré',
      };
}


// ── [Mode dev] Sélecteur de règle de débit pour un budget ────────────────────
class _BudgetDebitDayPicker extends StatefulWidget {
  final ReceiptDayRule debitDay;
  final ValueChanged<ReceiptDayRule> onChanged;
  const _BudgetDebitDayPicker({required this.debitDay, required this.onChanged});

  @override
  State<_BudgetDebitDayPicker> createState() => _BudgetDebitDayPickerState();
}

class _BudgetDebitDayPickerState extends State<_BudgetDebitDayPicker> {
  late TextEditingController _dayCtrl;

  @override
  void initState() {
    super.initState();
    _dayCtrl = TextEditingController(
      text: widget.debitDay.kind == ReceiptDayKind.fixedDay
          ? widget.debitDay.day.toString()
          : '',
    );
  }

  @override
  void dispose() {
    _dayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rule = widget.debitDay;
    final active = rule.kind != ReceiptDayKind.none;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: active ? tint(AppColors.violet, .08) : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: active ? AppColors.violet.withAlpha(80) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_outlined, size: 15,
              color: active ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            _ruleLabel(rule),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: active ? AppColors.violet : AppColors.muted,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _DebitChip(
            label: 'Aucune règle',
            selected: rule.kind == ReceiptDayKind.none,
            onTap: () {
              widget.onChanged(ReceiptDayRule.none);
              setState(() => _dayCtrl.text = '');
            },
          ),
          _DebitChip(
            label: '5 du mois prochain',
            selected: rule.kind == ReceiptDayKind.fixedDay && rule.day == 5,
            onTap: () {
              widget.onChanged(const ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: 5));
              setState(() => _dayCtrl.text = '5');
            },
          ),
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: rule.kind == ReceiptDayKind.lastWorkingDay,
            onTap: () => widget.onChanged(
                const ReceiptDayRule(kind: ReceiptDayKind.lastWorkingDay)),
          ),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _dayCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Autre jour fixe (ex. 10)',
                suffixText: 'du mois',
                filled: true,
                fillColor: rule.kind == ReceiptDayKind.fixedDay
                    ? AppColors.violet.withAlpha(15)
                    : null,
              ),
              onChanged: (v) {
                final d = int.tryParse(v);
                if (d != null && d >= 1 && d <= 31) {
                  widget.onChanged(ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: d));
                }
              },
            ),
          ),
        ]),
        if (active)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              _ruleExplain(rule),
              style: const TextStyle(
                  color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
            ),
          ),
      ]),
    );
  }

  String _ruleLabel(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => 'Pas de règle (débit immédiat)',
        ReceiptDayKind.fixedDay => r.day == 5
            ? 'Débité le 5 du mois prochain'
            : 'Débité le ${r.day} du mois',
        ReceiptDayKind.lastWorkingDay => 'Débité le dernier jour ouvré',
      };

  String _ruleExplain(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => '',
        ReceiptDayKind.fixedDay => r.day == 5
            ? 'Toutes les dépenses de ce budget seront comptées dans le mois suivant (débit le 5).'
            : 'Toutes les dépenses de ce budget seront débitées le ${r.day} du mois.',
        ReceiptDayKind.lastWorkingDay =>
            'Toutes les dépenses de ce budget seront débitées le dernier jour ouvré du mois.',
      };
}
