part of '../forms.dart';

class AddExpenseSheet extends ConsumerStatefulWidget {
  final Ym month;
  final String? initialTripId;
  final String? initialCategoryId; // pré-sélectionne une catégorie
  final int? initialPerson;        // pré-sélectionne une personne (mode couple)
  final bool initialUnexpected;
  final Transaction? existing; // dépense à modifier (null = nouvelle dépense)
  final double? initialAmount; // montant déjà tapé (saisie rapide)
  final String? initialDescription; // description pré-remplie (paiement en plusieurs fois)
  final DateTime? initialDate; // date pré-remplie
  const AddExpenseSheet(
      {super.key, required this.month, this.initialTripId, this.initialCategoryId,
       this.initialPerson, this.initialUnexpected = false, this.existing, this.initialAmount,
       this.initialDescription, this.initialDate});
  @override
  ConsumerState<AddExpenseSheet> createState() => _AddExpenseState();
}

class _AddExpenseState extends ConsumerState<AddExpenseSheet> {
  String? _cat; // id de catégorie, kUnexpectedId ou kTripCatId
  String? _tripId;
  int _person = 1;
  final _desc = TextEditingController();
  final _amt = TextEditingController();
  final _note = TextEditingController();
  late DateTime _date;
  DateTime? _debitDate; // [Mode dev] date de débit bancaire
  List<Transaction> _suggestions = [];  // dernières dépenses similaires
  bool _showSuggestions = false;
  bool _checked = false; // déjà prélevée / pointée
  int _tripWhen = 0; // 0 = débitée maintenant, 1 = pendant le projet

  @override
  void initState() {
    super.initState();
    _date = widget.month == Ym.now() ? DateTime.now() : widget.month.firstDay;
    if (widget.initialUnexpected) _cat = kUnexpectedId;
    if (widget.initialTripId != null) {
      _cat = kTripCatId;
      _tripId = widget.initialTripId;
    }
    if (widget.initialCategoryId != null) _cat = widget.initialCategoryId;
    if (widget.initialPerson != null) _person = widget.initialPerson!;
    if (widget.initialAmount != null) _amt.text = widget.initialAmount!.toStringAsFixed(2).replaceAll('.', ',');
    if (widget.initialDate != null) _date = widget.initialDate!;
    if (widget.initialDescription != null) _desc.text = widget.initialDescription!;
    _desc.addListener(_onDescChanged);
    final e = widget.existing;
    if (e != null) {
      _date = e.date;
      _debitDate = e.debitDate;
      _desc.text = e.description == 'Dépense' ? '' : e.description;
      _amt.text = e.amount == e.amount.roundToDouble() ? e.amount.round().toString() : e.amount.toString();
      _person = e.person == 0 ? 1 : e.person;
      _checked = e.checked;
      _note.text = e.note;
      if (e.tripId != null) {
        _cat = kTripCatId;
        _tripId = e.tripId;
        final pr = ref.read(appProvider).projects.where((x) => x.id == e.tripId).firstOrNull;
        _tripWhen = pr != null && pr.tripIn(Ym.of(e.date)) ? 1 : 0;
      } else {
        _cat = e.categoryId;
      }
    }
  }

  void _onDescChanged() {
    final query = _desc.text.trim().toLowerCase();
    if (query.length < 2) {
      if (_showSuggestions) setState(() { _suggestions = []; _showSuggestions = false; });
      return;
    }
    final d = ref.read(appProvider);
    // ── Catégorie intelligente ──────────────────────────────────
    // Chercher si la description correspond à un mot-clé connu
    final qNorm = _normCat(query);
    String? autocat;
    outer:
    for (final entry in _smartCategoryKeywords.entries) {
      for (final kw in entry.value) {
        if (qNorm.contains(_normCat(kw)) || _normCat(kw).contains(qNorm)) {
          // Trouver la catégorie de l'utilisateur dont le slug correspond
          final match = d.categories.where((c) =>
              _normCat(c.name).contains(entry.key) || entry.key.contains(_normCat(c.name))).firstOrNull;
          if (match != null) { autocat = match.id; break outer; }
          break;
        }
      }
    }
    // Auto-sélection de catégorie désactivée intentionnellement :
    // l'utilisateur choisit lui-même sa catégorie.
    // if (autocat != null && _cat != autocat) {
    //   setState(() { _cat = autocat; _tripId = null; });
    // }
    // Chercher dans toutes les transactions passées (hors mois actuel)
    final now = ref.read(nowProvider);
    final all = d.transactions
        .where((t) =>
            Ym.of(t.date) != now &&       // pas du mois en cours
            t.description.toLowerCase().contains(query))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    // Dédupliquer par description+catégorie, garder les 4 plus récentes
    final seen = <String>{};
    final unique = <Transaction>[];
    for (final t in all) {
      final key = '${t.description.toLowerCase()}_${t.categoryId}';
      if (seen.add(key)) unique.add(t);
      if (unique.length >= 4) break;
    }
    setState(() {
      _suggestions = unique;
      _showSuggestions = unique.isNotEmpty;
    });
  }

  void _applySuggestion(Transaction t) {
    setState(() {
      _desc.text = t.description;
      _amt.text = t.amount == t.amount.roundToDouble()
          ? t.amount.round().toString()
          : t.amount.toStringAsFixed(2);
      if (t.tripId != null) {
        _cat = kTripCatId;
        _tripId = t.tripId;
      } else {
        _cat = t.categoryId;
        _tripId = null;
      }
      if (t.person != 0) _person = t.person;
      _showSuggestions = false;
    });
  }

  bool _isToday(DateTime x) {
    final n = DateTime.now();
    return x.year == n.year && x.month == n.month && x.day == n.day;
  }

  @override
  void dispose() {
    _desc.removeListener(_onDescChanged);
    _desc.dispose();
    _amt.dispose();
    _note.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseAmount(_amt.text);
    if (a == null || a <= 0 || _cat == null) {
      snack(context, 'Catégorie et montant requis');
      return;
    }
    if (_cat == kTripCatId && _tripId == null) {
      snack(context, 'Sélectionnez le voyage associé');
      return;
    }
    final d = ref.read(appProvider);
    final couple = d.isCouple;
    final amount = double.parse(a.toStringAsFixed(2));
    final e = widget.existing;

    // ── Détection des doublons ────────────────────────────────────
    // On cherche une dépense du même montant dans le même mois,
    // sauf si on est en train de modifier une dépense existante.
    if (e == null) {
      final ym = Ym.of(_date);
      final duplicates = d.transactionsIn(ym).where((t) =>
          (t.amount - amount).abs() < 0.01 &&
          t.categoryId == _cat &&
          (t.person == 0 || !couple || t.person == _person)).toList();
      if (duplicates.isNotEmpty) {
        final dup = duplicates.first;
        final dupDesc = dup.description.isEmpty ? '' : ' (${dup.description})';
        final dupDate = '${dup.date.day.toString().padLeft(2, '0')}/${dup.date.month.toString().padLeft(2, '0')}';
        // Afficher un avertissement — l'utilisateur peut confirmer ou annuler
        showQuickDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Row(children: [
              Text('⚠️', style: TextStyle(fontSize: 22)),
              SizedBox(width: 8),
              Text('Doublon possible', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            ]),
            content: Text(
              'Tu as déjà une dépense de ${eur(amount)}$dupDesc le $dupDate ce mois-ci.\n\nTu veux quand même l\'enregistrer ?',
              style: const TextStyle(fontSize: 14, height: 1.45),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer quand même')),
            ],
          ),
        ).then((confirmed) {
          if (confirmed == true && mounted) _doSave(amount, couple);
        });
        return;
      }
    }
    _doSave(amount, couple);
  }

  void _doSave(double amount, bool couple) {
    final e = widget.existing;
    final devMode = ref.read(devModeProvider);
    final debitDate = devMode ? _debitDate : null;
    final noteText = _note.text.trim();
    var date = _date;
    if (_cat == kTripCatId && _tripId != null && _tripWhen == 1) {
      final pr = ref.read(appProvider).projects.where((x) => x.id == _tripId).firstOrNull;
      if (pr != null && !pr.tripIn(Ym.of(date))) {
        date = pr.tripStart ?? pr.targetYm.firstDay;
      }
    }
    if (e != null) {
      ref.read(appProvider.notifier).updateTransaction(e.id, _cat!, _desc.text.trim(), amount, date,
          person: couple ? _person : 0, tripId: _cat == kTripCatId ? _tripId : null,
          debitDate: debitDate, checked: _checked, note: noteText);
    } else {
      ref.read(appProvider.notifier).addTransaction(_cat!, _desc.text.trim(), amount, date,
          person: couple ? _person : 0, tripId: _cat == kTripCatId ? _tripId : null,
          debitDate: debitDate, checked: _checked, note: noteText);
    }
    if (mounted) Navigator.pop(context, true);
  }

  /// [Mode dev] Le budget de la catégorie choisie est à débit différé : propose, en un bouton,
  /// de débiter CETTE dépense ce mois-ci (elle comptera dès qu'elle est cochée).
  Widget _deferredBudgetHint(AppData d) {
    final person = d.isCouple ? _person : 0;
    final budget = d.budgets
        .where((b) => b.categoryId == _cat && (b.person == 0 || b.person == person))
        .firstOrNull;
    final rule = budget?.debitDay;
    if (rule == null || rule.kind == ReceiptDayKind.none) return const SizedBox.shrink();
    final what = rule.kind == ReceiptDayKind.fixedDay
        ? (rule.day == 5 ? 'débité le 5 du mois prochain' : 'débité le ${rule.day}')
        : 'débité le dernier jour ouvré';
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
        decoration: BoxDecoration(
          color: tint(AppColors.violet, .08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.violet.withAlpha(60), width: 1.2),
        ),
        child: Row(children: [
          const Icon(Icons.schedule_rounded, size: 16, color: AppColors.violet),
          const SizedBox(width: 8),
          Expanded(
            child: Text('Ce budget est à débit différé ($what).',
                style: const TextStyle(
                    color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
          ),
          const SizedBox(width: 8),
          _DebitChip(
            label: 'Débiter ce mois-ci',
            selected: false,
            icon: Icons.bolt_rounded,
            onTap: () => setState(() => _debitDate = DateTime(_date.year, _date.month, _date.day)),
          ),
        ]),
      ),
    );
  }

  // Couleur de la catégorie sélectionnée (pour teinter montant et bouton)
  Color _accentColor(AppData d) {
    if (_cat == kUnexpectedId) return AppColors.warning;
    if (_cat == kTripCatId) return const Color(0xFF0A84FF);
    final cat = d.categories.where((c) => c.id == _cat).firstOrNull;
    return cat != null ? Color(cat.colorValue) : AppColors.violet;
  }

  Widget _tripWhenCard(String title, String sub, int value, Color accent) {
    final sel = _tripWhen == value;
    return GestureDetector(
      onTap: () => setState(() => _tripWhen = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: sel ? accent.withAlpha(20) : context.fieldColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: sel ? accent : Colors.transparent, width: 1.5),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Flexible(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))),
            InfoButton(value == 0 ? Hint.fieldTripNow : Hint.fieldTripLater, size: 14),
          ]),
          const SizedBox(height: 2),
          Text(sub, style: TextStyle(color: AppColors.muted, fontSize: 11.5)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final cats = d.categories;
    final trips = d.projects.toList();
    if (_cat == kTripCatId && !trips.any((t) => t.id == _tripId)) {
      _cat = null;
      _tripId = null;
    }
    _cat ??= cats.isEmpty ? kUnexpectedId : cats.first.id;
    final accent = _accentColor(d);

    // Toutes les options de catégorie (liste plate pour le scroll horizontal)
    final allCats = <_CatOption>[
      for (final c in cats)
        _CatOption(
          id: c.id,
          emoji: c.emoji,
          name: c.name,
          color: Color(c.colorValue),
        ),
      const _CatOption(id: kUnexpectedId, emoji: '⚡', name: 'Imprévu', color: AppColors.warning),
      for (final t in trips)
        _CatOption(
          id: kTripCatId,
          tripId: t.id,
          emoji: t.emoji,
          name: t.name,
          color: Color(0xFF0A84FF),
        ),
    ];

    // Label info sous les catégories (seulement si imprévu ou voyage)
    String? infoLabel;
    Color? infoColor;
    if (_cat == kUnexpectedId) {
      infoLabel = 'Hors budget — retiré directement de votre fin de mois';
      infoColor = AppColors.warning;
    } else if (_cat == kTripCatId) {
      infoLabel = null;
      infoColor = const Color(0xFF0A84FF);
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── En-tête titre + drag handle ──────────────────────────
      Center(
        child: Container(
          width: 36, height: 4,
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: accent.withAlpha(80),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),

      // ── Catégories : scroll horizontal (1 seule ligne) ───────
      SizedBox(
        height: 76,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(bottom: 4),
          itemCount: allCats.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final opt = allCats[i];
            final isSel = opt.id == kTripCatId
                ? (_cat == kTripCatId && _tripId == opt.tripId)
                : _cat == opt.id;
            return _CatChipCompact(
              option: opt,
              selected: isSel,
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() {
                  _cat = opt.id;
                  _tripId = opt.tripId;
                });
              },
            );
          },
        ),
      ),

      // ── Info rapide (imprévu / voyage) ────────────────────────
      AnimatedSize(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeInOut,
        child: infoLabel != null
            ? Padding(
                padding: const EdgeInsets.only(top: 4, bottom: 4),
                child: Row(children: [
                  Icon(Icons.info_outline_rounded, size: 13, color: infoColor),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(infoLabel,
                        style: TextStyle(
                          color: infoColor, fontSize: 12,
                          fontWeight: FontWeight.w600,
                        )),
                  ),
                ]),
              )
            : const SizedBox(height: 6),
      ),

      if (_cat == kTripCatId && _tripId != null) ...[
        Row(children: [
          Expanded(child: _tripWhenCard('Débitée maintenant', 'Sort de ton compte ce mois-ci', 0, accent)),
          const SizedBox(width: 8),
          Expanded(child: _tripWhenCard('Pendant le projet', 'Comptée au mois du projet', 1, accent)),
        ]),
        const SizedBox(height: 4),
        Text(
          _tripWhen == 0
              ? 'Retirée de ton solde ce mois-ci, et le budget restant du projet baisse d\'autant.'
              : 'Pas touchée ce mois-ci : elle sera comptée dans le budget du projet, à sa date.',
          style: TextStyle(color: AppColors.muted, fontSize: 12, height: 1.35),
        ),
        const SizedBox(height: 10),
      ],

      // ── Personne (mode couple) ────────────────────────────────
      if (d.isCouple) ...[
        _PersonToggleRow(
          names: [d.personName(1), d.personName(2)],
          selectedIndex: _person - 1,
          onSelect: (i) => setState(() => _person = i + 1),
        ),
        const SizedBox(height: 10),
      ],

      // ── Description + Montant côte à côte ────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Description (prend les 3/5)
        Expanded(
          flex: 3,
          child: _CompactField(
            controller: _desc,
            hint: 'Description (ex. Carrefour, Essence A6)',
            icon: Icons.edit_note_rounded,
            textCapitalization: TextCapitalization.sentences,
            onChanged: (_) {}, // _onDescChanged est déjà branché via addListener
          ),
        ),
        const SizedBox(width: 8),
        // Montant (prend les 2/5), teinté de la couleur catégorie
        Expanded(
          flex: 2,
          child: _AmountFieldCompact(
            controller: _amt,
            accentColor: accent,
          ),
        ),
      ]),

      // ── Suggestions de dépenses similaires ───────────────────
      AnimatedSize(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        child: _showSuggestions
            ? Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  decoration: BoxDecoration(
                    color: context.fieldColor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Padding(
                      padding: EdgeInsets.fromLTRB(12, 8, 12, 2),
                      child: Text('Dépenses similaires',
                          style: TextStyle(color: AppColors.muted, fontSize: 11.5,
                              fontWeight: FontWeight.w600)),
                    ),
                    for (final s in _suggestions)
                      InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => _applySuggestion(s),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          child: Row(children: [
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(s.description,
                                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                                    maxLines: 1, overflow: TextOverflow.ellipsis),
                                Text(
                                  '${d.category(s.categoryId)?.name ?? ''} · '
                                  '${s.date.day.toString().padLeft(2, '0')}/${s.date.month.toString().padLeft(2, '0')}',
                                  style: const TextStyle(color: AppColors.muted, fontSize: 11),
                                ),
                              ]),
                            ),
                            Text(eur(s.amount),
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                            const SizedBox(width: 4),
                            const Icon(Icons.north_west_rounded, size: 14, color: AppColors.muted),
                          ]),
                        ),
                      ),
                    const SizedBox(height: 4),
                  ]),
                ),
              )
            : const SizedBox.shrink(),
      ),

      const SizedBox(height: 10),

      // ── Date + toggle débit différé sur une ligne ─────────────
      Row(children: [
        // Date de la dépense
        GestureDetector(
          onTap: () async {
            final picked = await pickDay(context, _date);
            if (picked != null) setState(() => _date = picked);
          },
          child: Container(
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: context.fieldColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.calendar_today_rounded, size: 14, color: AppColors.muted),
              const SizedBox(width: 6),
              Text(
                '${_date.day.toString().padLeft(2, '0')}/${_date.month.toString().padLeft(2, '0')}/${_date.year}',
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: context.textColor,
                ),
              ),
            ]),
          ),
        ),
        if (!_isToday(_date)) ...[
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () => setState(() => _date = DateTime.now()),
            child: Container(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: context.fieldColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.today_rounded, size: 18, color: AppColors.muted),
            ),
          ),
        ],
        // [Mode dev] Toggle débit différé
        if (ref.watch(devModeProvider)) ...[
          const SizedBox(width: 6),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() {
                if (_debitDate != null) {
                  _debitDate = null;
                }
                // On affiche/cache le picker débit via _debitDate == null
              }),
              child: _DebitToggleChip(
                debitDate: _debitDate,
                expenseDate: _date,
                onToggle: () => setState(() {
                  _debitDate = _debitDate == null
                      ? DateTime(_date.year, _date.month + 1, 5)
                      : null;
                }),
              ),
            ),
          ),
        ],
      ]),

      // ── [Mode dev] Options débit différé (s'ouvre si activé) ──
      if (ref.watch(devModeProvider))
        AnimatedSize(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
          child: _debitDate != null
              ? Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: _DebitDatePicker(
                    expenseDate: _date,
                    debitDate: _debitDate,
                    onChanged: (d) => setState(() => _debitDate = d),
                  ),
                )
              : _deferredBudgetHint(d),
        ),

      const SizedBox(height: 10),

      // ── Déjà prélevée ─────────────────────────────────────────
      GestureDetector(
        onTap: () => setState(() => _checked = !_checked),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: _checked ? accent.withAlpha(20) : context.fieldColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _checked ? accent : Colors.transparent,
              width: 1.5,
            ),
          ),
          child: Row(children: [
            Icon(
              _checked ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
              color: _checked ? accent : AppColors.muted,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisSize: MainAxisSize.min, children: [
                const Text('Vu sur mon compte', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                const InfoButton(Hint.fieldChecked, size: 15),
              ]),
              Text('Déjà sortie de mon compte', style: TextStyle(color: AppColors.muted, fontSize: 12)),
            ])),
          ]),
        ),
      ),

      const SizedBox(height: 14),

      // ── Note libre ────────────────────────────────────────────
      TextField(
        controller: _note,
        maxLines: 2,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(
          hintText: 'Note (optionnel)',
          prefixIcon: Icon(Icons.sticky_note_2_outlined, size: 20),
        ),
      ),

      const SizedBox(height: 14),

      // ── Bouton Annuler + Enregistrer côte à côte ──────────────
      _CancelSaveRow(saveLabel: 'Enregistrer', onSave: _save),
    ]);
  }
}

// ── Option de catégorie (modèle interne) ──────────────────────────────────────
class _CatOption {
  final String id;
  final String? tripId;
  final String emoji;
  final String name;
  final Color color;
  const _CatOption({
    required this.id,
    this.tripId,
    required this.emoji,
    required this.name,
    required this.color,
  });
}

// ── Chip catégorie compact (scroll horizontal) ────────────────────────────────
class _CatChipCompact extends StatelessWidget {
  const _CatChipCompact({
    required this.option,
    required this.selected,
    required this.onTap,
  });
  final _CatOption option;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = option.color;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: 72,
        decoration: BoxDecoration(
          color: selected ? c.withAlpha(28) : c.withAlpha(10),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? c : c.withAlpha(50),
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(option.emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 3),
          Text(
            option.name,
            style: TextStyle(
              fontSize: 10,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? c : AppColors.muted,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ]),
      ),
    );
  }
}

// ── Toggle personne compact ───────────────────────────────────────────────────
class _PersonToggleRow extends StatelessWidget {
  const _PersonToggleRow({
    required this.names,
    required this.selectedIndex,
    required this.onSelect,
  });
  final List<String> names;
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Text('Pour', style: TextStyle(
        fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.muted)),
      const InfoButton(Hint.fieldPerson, size: 15),
      const SizedBox(width: 4),
      Container(
        height: 34,
        decoration: BoxDecoration(
          color: context.fieldColor,
          borderRadius: BorderRadius.circular(17),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          for (var i = 0; i < names.length; i++)
            GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                onSelect(i);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: selectedIndex == i ? AppColors.violet : Colors.transparent,
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Text(
                  names[i],
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: selectedIndex == i ? Colors.white : AppColors.muted,
                  ),
                ),
              ),
            ),
        ]),
      ),
    ]);
  }
}

// ── Champ texte compact ───────────────────────────────────────────────────────
class _CompactField extends StatelessWidget {
  const _CompactField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.textCapitalization = TextCapitalization.none,
    this.onChanged,
  });
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final TextCapitalization textCapitalization;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: context.isDark ? const Color(0xFF1E2440) : Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: context.isDark ? const Color(0xFF3A4163) : const Color(0xFFCDD1E2), width: 1.2),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        Icon(icon, size: 15, color: AppColors.muted),
        const SizedBox(width: 7),
        Expanded(
          child: TextField(
            controller: controller,
            textCapitalization: textCapitalization,
            onChanged: onChanged,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
            decoration: InputDecoration(
              filled: false,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              hintText: hint,
              hintStyle: const TextStyle(color: AppColors.muted, fontSize: 14),
              isDense: true,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ),
      ]),
    );
  }
}

// ── Champ montant coloré ──────────────────────────────────────────────────────
class _AmountFieldCompact extends StatelessWidget {
  const _AmountFieldCompact({
    required this.controller,
    required this.accentColor,
  });
  final TextEditingController controller;
  final Color accentColor;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: 48,
      decoration: BoxDecoration(
        color: accentColor.withAlpha(22),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accentColor.withAlpha(80), width: 1.5),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        Text('€',
            style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w800, color: accentColor)),
        const SizedBox(width: 4),
        Expanded(
          child: TextField(
            controller: controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*[.,]?\d{0,2}')),
            ],
            style: TextStyle(
              fontSize: 17, fontWeight: FontWeight.w800, color: accentColor),
            decoration: InputDecoration(
              filled: false,
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              hintText: '0',
              hintStyle: TextStyle(
                color: accentColor.withAlpha(80),
                fontSize: 17, fontWeight: FontWeight.w800),
              isDense: true,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ),
      ]),
    );
  }
}

// ── Chip toggle débit différé (compact) ──────────────────────────────────────
class _DebitToggleChip extends StatelessWidget {
  const _DebitToggleChip({
    required this.debitDate,
    required this.expenseDate,
    required this.onToggle,
  });
  final DateTime? debitDate;
  final DateTime expenseDate;
  final VoidCallback onToggle;

  String _fmt(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final active = debitDate != null;
    return GestureDetector(
      onTap: onToggle,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: active ? AppColors.violet.withAlpha(20) : context.fieldColor,
          borderRadius: BorderRadius.circular(12),
          border: active
              ? Border.all(color: AppColors.violet.withAlpha(80), width: 1.2)
              : null,
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.account_balance_rounded,
              size: 14,
              color: active ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 5),
          Text(
            active ? 'Débit ${_fmt(debitDate!)}' : 'Débit différé',
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              color: active ? AppColors.violet : AppColors.muted,
            ),
          ),
        ]),
      ),
    );
  }
}
