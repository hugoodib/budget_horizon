part of '../forms.dart';

/// Saisie ultra rapide d'une dépense : on tape le montant, puis on touche l'enveloppe.
/// C'est enregistré tout de suite (date du jour). Les enveloppes les plus récemment
/// utilisées sont proposées en premier. Retourne 'saved' ou 'full' (ouvrir le formulaire complet).
class QuickExpenseSheet extends ConsumerStatefulWidget {
  final Ym month;
  const QuickExpenseSheet({super.key, required this.month});
  @override
  ConsumerState<QuickExpenseSheet> createState() => _QuickExpenseState();
}

class _QuickExpenseState extends ConsumerState<QuickExpenseSheet> {
  final _amt = TextEditingController();
  int _person = 1;

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  /// Montant saisi, ou null (avec message) s'il est invalide.
  double? _amount() {
    final a = parseAmount(_amt.text);
    if (a == null || a <= 0) {
      snack(context, 'Tape d\'abord le montant');
      return null;
    }
    return double.parse(a.toStringAsFixed(2));
  }

  void _saveIn(String categoryId) {
    final a = _amount();
    if (a == null) return;
    final d = ref.read(appProvider);
    final date = widget.month == Ym.now() ? DateTime.now() : widget.month.firstDay;
    ref.read(appProvider.notifier).addTransaction(categoryId, '', a, date,
        person: d.isCouple ? _person : 0);
    FocusManager.instance.primaryFocus?.unfocus();
    Navigator.pop(context, 'saved');
  }

  void _openFull() {
    final a = parseAmount(_amt.text);
    Navigator.pop(context, a != null && a > 0 ? 'full:${a.toStringAsFixed(2)}' : 'full');
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    // Enveloppes triées : les plus récemment utilisées d'abord.
    final cats = d.categories;
    final sorted = [...d.transactions]..sort((a, b) => b.date.compareTo(a.date));
    final order = <String>[];
    for (final t in sorted) {
      if (t.tripId == null && cats.any((c) => c.id == t.categoryId) && !order.contains(t.categoryId)) {
        order.add(t.categoryId);
      }
    }
    for (final c in cats) {
      if (!order.contains(c.id)) order.add(c.id);
    }
    final chips = <Widget>[
      for (final id in order)
        () {
          final c = cats.firstWhere((x) => x.id == id);
          return _QuickChip(
              emoji: c.emoji, name: c.name, color: Color(c.colorValue), onTap: () => _saveIn(c.id));
        }(),
      _QuickChip(
          emoji: '⚡', name: 'Imprévu', color: AppColors.warning, onTap: () => _saveIn(kUnexpectedId)),
    ];

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(
        controller: _amt,
        autofocus: true,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d*[.,]?\d{0,2}'))],
        style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800),
        decoration: const InputDecoration(
          suffixText: ' €',
          contentPadding: EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        ),
      ),
      if (d.isCouple) ...[
        const SizedBox(height: 12),
        Row(children: [
          for (final p in [1, 2]) ...[
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _person = p),
                child: Container(
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: _person == p ? AppColors.violet : context.fieldColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(p == 1 ? d.user.person1 : d.user.person2,
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: _person == p ? Colors.white : context.textColor)),
                ),
              ),
            ),
            if (p == 1) const SizedBox(width: 8),
          ],
        ]),
      ],
      const SizedBox(height: 16),
      Text('Touche l\'enveloppe pour enregistrer',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: context.mutedColor)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: chips),
      const SizedBox(height: 8),
      Align(
        alignment: Alignment.centerRight,
        child: TextButton.icon(
          onPressed: _openFull,
          icon: const Icon(Icons.tune_rounded, size: 18),
          label: const Text('Plus de détails'),
        ),
      ),
    ]);
  }
}

class _QuickChip extends StatelessWidget {
  final String emoji;
  final String name;
  final Color color;
  final VoidCallback onTap;
  const _QuickChip({required this.emoji, required this.name, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 46),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: color.withAlpha(30),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withAlpha(110), width: 1.2),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(emoji, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 8),
            Text(name,
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: context.textColor)),
          ]),
        ),
      );
}
