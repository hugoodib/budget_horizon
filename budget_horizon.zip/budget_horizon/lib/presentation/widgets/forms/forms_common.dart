part of '../forms.dart';

// ---------------- Ligne Annuler + Enregistrer (réutilisable) ----------------
class _CancelSaveRow extends StatefulWidget {
  final String saveLabel;
  final VoidCallback onSave;
  const _CancelSaveRow({required this.saveLabel, required this.onSave});

  @override
  State<_CancelSaveRow> createState() => _CancelSaveRowState();
}

class _CancelSaveRowState extends State<_CancelSaveRow> {
  ValueNotifier<SheetActions?>? _scope;

  @override
  void initState() {
    super.initState();
    _scope = context.getInheritedWidgetOfExactType<SheetScope>()?.actions;
    _publish();
  }

  @override
  void didUpdateWidget(covariant _CancelSaveRow old) {
    super.didUpdateWidget(old);
    _publish();
  }

  void _publish() {
    final scope = _scope;
    if (scope == null) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) scope.value = SheetActions(widget.saveLabel, widget.onSave);
    });
  }

  @override
  Widget build(BuildContext context) {
    // Dans une feuille : les boutons sont affichés par la feuille, collés au clavier.
    if (_scope != null) return const SizedBox.shrink();
    return Row(children: [
      Expanded(
        flex: 2,
        child: TextButton(
          onPressed: () => Navigator.pop(context),
          style: TextButton.styleFrom(
            minimumSize: const Size.fromHeight(50),
            backgroundColor: context.fieldColor,
            foregroundColor: context.textColor,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ),
      const SizedBox(width: 10),
      Expanded(
        flex: 3,
        child: GradientButton(label: widget.saveLabel, onPressed: widget.onSave),
      ),
    ]);
  }
}

// ---------------- Icône + couleur d'une catégorie ----------------
const kEmojiChoices = [
  '🥕', '🛒', '🍕', '🍔', '☕', '🍷', '⛽', '🚗', '🚌', '✈️',
  '🏠', '💡', '📱', '🎮', '🎬', '🎉', '🏋️', '💊', '🧴', '👗',
  '🛍️', '🎁', '🐶', '🐱', '👶', '📚', '🎓', '💇', '💄', '🧾',
  '🏖️', '🍿', '🎵', '🧹', '🔧', '🌿', '💰', '🥂', '🚴', '🎨',
];

/// Garde uniquement le dernier emoji saisi (un seul caractère « visuel »).
class _OneEmojiFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final chars = newValue.text.characters;
    if (chars.isEmpty) return newValue;
    final last = chars.last;
    return TextEditingValue(text: last, selection: TextSelection.collapsed(offset: last.length));
  }
}

/// Un rond de couleur avec son label de catégorie en dessous.
class _PaletteItem extends StatelessWidget {
  final Color color;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _PaletteItem({required this.color, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: selected ? context.textColor : Colors.transparent, width: 2.5),
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: 46,
            child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 9,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? context.textColor : context.mutedColor,
            ),
            textAlign: TextAlign.center,
          )),
        ]),
      );
}

/// Choix d'un emoji (grille + clavier emoji complet de l'iPhone) et d'une couleur vive.
class StylePicker extends StatelessWidget {
  final String emoji;
  final int color;
  final ValueChanged<String> onEmoji;
  final ValueChanged<int> onColor;
  final bool showEmoji; // faux : couleur seule (logo « première lettre »)
  final String previewLetter;
  /// Noms donnés aux couleurs (couleur -> nom). Si [onRenameColor] est fourni, un champ permet de nommer la couleur choisie.
  final Map<int, String>? colorNames;
  final void Function(int color, String name)? onRenameColor;
  const StylePicker({
    super.key,
    required this.emoji,
    required this.color,
    required this.onEmoji,
    required this.onColor,
    this.showEmoji = true,
    this.previewLetter = '?',
    this.colorNames,
    this.onRenameColor,
  });

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          showEmoji
              ? CircleEmoji(emoji.isEmpty ? '💰' : emoji, Color(color), size: 48)
              : CircleEmoji(previewLetter, Color(color), size: 48, letter: true),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
                showEmoji
                    ? 'Choisissez une icône et une couleur bien distinctes.'
                    : 'Choisissez une couleur.',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          ),
        ]),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (var i = 0; i < AppColors.palette.length; i++)
              _PaletteItem(
                color: AppColors.palette[i],
                label: (colorNames?[AppColors.palette[i].value] ?? '').trim().isNotEmpty
                    ? colorNames![AppColors.palette[i].value]!.trim()
                    : AppColors.paletteLabels[i],
                selected: AppColors.palette[i].value == color,
                onTap: () => onColor(AppColors.palette[i].value),
              ),
          ],
        ),
        if (onRenameColor != null) ...[
          const SizedBox(height: 12),
          _ColorNameField(
            key: ValueKey('colorname_$color'),
            initial: colorNames?[color] ?? '',
            color: Color(color),
            onChanged: (t) => onRenameColor!(color, t),
          ),
        ],
        if (showEmoji) ...[
        const SizedBox(height: 12),
        TextField(
          inputFormatters: [_OneEmojiFormatter()],
          decoration: const InputDecoration(
            labelText: 'Emoji',
            hintText: 'Touchez 🌐 pour changer de clavier',
          ),
          onChanged: (v) {
            final t = v.trim();
            if (t.isNotEmpty) onEmoji(t.characters.last);
          },
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final e in kEmojiChoices)
            GestureDetector(
              onTap: () => onEmoji(e),
              child: Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: e == emoji ? tint(Color(color), .22) : context.fieldColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: e == emoji ? Color(color) : Colors.transparent, width: 2),
                ),
                child: Text(e, style: const TextStyle(fontSize: 22)),
              ),
            ),
        ]),
        ],
      ]);
}

// ---------------- Ajouter une dépense ----------------
/// Une dépense va dans une enveloppe (catégorie), dans les « imprévus » (compteur qui baisse
/// directement l'estimation) ou dans le budget d'un voyage.

/// Mots-clés → nom de catégorie (insensible à la casse, normalisé).
/// Si le nom de catégorie de l'utilisateur contient le slug, on pré-sélectionne.
const _smartCategoryKeywords = <String, List<String>>{
  'courses': ['carrefour','leclerc','lidl','auchan','intermarche','monoprix','franprix',
               'aldi','casino','biocoop','marche','epicerie','boulangerie','supermarche',
               'spar','picard','naturalia','grand frais','netto','super u','simply market'],
  'restaurant': ['mcdo','mcdonald','macdo','burger king','kfc','subway','pizza','sushi',
                  'kebab','resto','restaurant','brasserie','bistrot','uber eats','deliveroo',
                  'just eat','tablapizza','dominos','quick','five guys','popeyes','chipotle',
                  'noodles','poke','wok','thai','indien','libanais','japonais','buffet'],
  'essence': ['total','bp','shell','esso','leclerc carb','intermarche carb','carrefour carb',
               'essence','gasoil','diesel','gazole','station','plein','carburant','e10','sp95',
               'sp98','gnv','peage','autoroute','vinci','sanef','cofiroute'],
  'loisirs': ['cinema','cine','pathé','ugc','mk2','fnac','micromania','steam','playstation',
               'xbox','netflix','disney','canal','spotify','deezer','amazon prime','apple tv',
               'hulu','twitch','youtube','concert','spectacle','theatre','musee','zoo','parc',
               'laser game','bowling','karting','accrobranche','escape game','billeterie'],
  'sante': ['pharmacie','medecin','docteur','dentiste','opticien','kiné','osteo','psy',
             'laboratoire','optique','krys','atol','afflelou','généraliste','urgences',
             'hopital','clinique','mutuelle','cpam','maternite','sage femme','podologue'],
  'vetements': ['zara','h&m','primark','bershka','pull bear','mango','uniqlo','asos','shein',
                 'zalando','kiabi','la redoute','camaieu','promod','jennyfer','sandro','maje',
                 'decathlon','nike','adidas','new balance','courir','foot locker','chaussures'],
  'maison': ['leroy merlin','castorama','brico depot','ikea','conforama','but','maisons du monde',
              'bricorama','mr bricolage','bricomarche','lapeyre','saint maclou','gedimat',
              'jardiland','truffaut','botanic','gamm vert','weldom'],
  'transport': ['sncf','ratp','transilien','ter','ouigo','thalys','eurostar','blablacar',
                 'uber','lyft','bolt','heetch','taxi','vtc','metro','bus','tramway','navigo',
                 'velib','lime','tier','bird','trottinette','stationnement','parking','horodateur'],
  'abonnement': ['sfr','orange','bouygues','free','sosh','b&you','red','prixtel','youprice',
                  'coriolis','auchan telecom','nrj mobile','fnac mobile','lebara','lycamobile',
                  'netflix','spotify','deezer','disney','canal','youtube premium','apple one',
                  'icloud','google one','dropbox','adobe','microsoft','office 365'],
  'alimentation': ['franprix','naturalia','bio c bon','day by day','metro','promocash',
                    'cuisine','repas','dejeuner','diner','snack','sandwicherie','traiteur'],
};

/// Normalise un texte : minuscules, accents retirés.
String _normCat(String s) {
  const from = 'àâäáãéèêëíìîïóòôöõúùûüçœ';
  const to   = 'aaaaaeeeeiiiiooooouuuuco';
  final b = StringBuffer();
  for (final ch in s.toLowerCase().split('')) {
    final i = from.indexOf(ch);
    b.write(i >= 0 ? to[i] : ch);
  }
  return b.toString();
}

/// Champ « nom de la couleur » (ex. Maison, Crédit, Particuliers, Vitres).
class _ColorNameField extends StatefulWidget {
  final String initial;
  final Color color;
  final ValueChanged<String> onChanged;
  const _ColorNameField({super.key, required this.initial, required this.color, required this.onChanged});
  @override
  State<_ColorNameField> createState() => _ColorNameFieldState();
}

class _ColorNameFieldState extends State<_ColorNameField> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TextField(
        controller: _c,
        textCapitalization: TextCapitalization.sentences,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
          labelText: 'Nom de cette couleur (optionnel)',
          hintText: 'ex. Maison, Crédit, Particuliers…',
          prefixIcon: Icon(Icons.label_rounded, size: 20, color: widget.color),
        ),
      );
}
