part of '../forms.dart';

class AddProjectSheet extends ConsumerStatefulWidget {
  final Project? existing; // non nul : modification d'un voyage
  const AddProjectSheet({super.key, this.existing});
  @override
  ConsumerState<AddProjectSheet> createState() => _AddProjectState();
}

class _AddProjectState extends ConsumerState<AddProjectSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _amt = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.target == widget.existing!.target.roundToDouble()
              ? widget.existing!.target.round().toString()
              : widget.existing!.target.toStringAsFixed(2)));
  late ProjectMode _mode = widget.existing?.mode ?? ProjectMode.expense;
  late Ym _target = widget.existing?.targetYm ?? Ym.now().add(6);
  late DateTime? _start = widget.existing?.tripStart;
  late DateTime? _end = widget.existing?.tripEnd;
  late int _who = widget.existing?.who ?? 0;
  late bool _trip = widget.existing?.isTrip ?? true;

  String _fd(DateTime x) =>
      '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}/${x.year}';

  /// Un seul calendrier : on touche un jour (départ), puis un autre (retour),
  /// et l'intervalle se sélectionne automatiquement. Il s'ouvre sur le mois actuel,
  /// avec un bouton « Aujourd'hui » directement dans le calendrier.
  Future<void> _pickDates() async {
    final range = await showSheet<DateTimeRange>(
      context,
      title: 'Dates du voyage',
      child: RangeCalendarSheet(
        initialMonth: _start ?? ref.read(nowProvider).firstDay,
        initialStart: _start,
        initialEnd: _end,
      ),
    );
    if (range == null) return;
    setState(() {
      _start = range.start;
      _end = range.end;
      _target = Ym.of(range.start); // le mois du voyage est déduit de la date de départ
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  Map<String, ClientTripPlan>? _plans; // choix pour les clients (auto-entrepreneur)

  void _doSaveProject(double v) {
    final n = ref.read(appProvider.notifier);
    if (widget.existing == null) {
      n.addProject(_name.text.trim(), v, _target, _mode,
          tripStart: _start, tripEnd: _end, who: _who, isTrip: _trip, clientPlans: _plans ?? const {});
    } else {
      n.updateProject(widget.existing!.id,
          name: _name.text.trim(), target: v, targetYm: _target, mode: _mode,
          tripStart: _start, tripEnd: _end, who: _who, isTrip: _trip, clientPlans: _plans);
    }
    Navigator.pop(context);
  }

  Future<void> _trySave(BuildContext context) async {
    final v = parseAmount(_amt.text);
    if (_name.text.trim().isEmpty || v == null || v <= 0) {
      snack(context, 'Nom et budget requis');
      return;
    }
    final now = ref.read(nowProvider);
    if (_start != null && _end != null && _end!.isBefore(_start!)) {
      snack(context, 'La date de retour doit être après la date de départ.');
      return;
    }
    if (widget.existing == null) {
      if (_mode == ProjectMode.expense ? _target.isBefore(now) : !_target.isAfter(now)) {
        snack(context, _mode == ProjectMode.expense
            ? 'Choisissez le mois du voyage — le mois actuel ou un mois futur.'
            : 'Pour épargner, l\'objectif doit être dans un mois futur.');
        return;
      }
    }

    // ── Vérification de faisabilité (mode épargne uniquement) ──
    if (_mode == ProjectMode.savings && widget.existing == null) {
      final d = ref.read(appProvider);
      final months = max(1, _target.index - now.index);
      final monthlyNeeded = v / months;

      // Revenu moyen - charges fixes - budgets actuels
      final avgIncome = d.recurringIncomes.fold(0.0, (s, r) => s + r.amount);
      final avgFixed = d.fixedExpenses.where((f) => f.activeIn(now)).fold(0.0, (s, f) => s + f.amount);
      final currentBudgets = d.budgets.fold(0.0, (s, b) => s + b.amount);
      final disponible = avgIncome - avgFixed - currentBudgets;

      if (monthlyNeeded > disponible) {
        // Pas assez de marge → proposer de réduire des budgets
        final shortage = monthlyNeeded - disponible;
        final ok = await showSheet<bool>(
          context,
          title: 'Solde insuffisant pour épargner',
          child: _BudgetReduceSheet(
            projectName: _name.text.trim(),
            monthlyNeeded: monthlyNeeded,
            disponible: disponible,
            shortage: shortage,
            months: months,
          ),
        );
        if (ok != true) return; // l'utilisateur a annulé ou refusé
      }
    }

    // ── Auto-entrepreneur : que faire des clients qu'on ne pourra pas voir ? ──
    if (_trip && _start != null && _end != null) {
      final d = ref.read(appProvider);
      final draft = Project(
          id: widget.existing?.id ?? 'draft',
          name: _name.text.trim(),
          target: v,
          startYm: now,
          targetYm: _target,
          tripStart: _start,
          tripEnd: _end,
          who: _who,
          clientPlans: widget.existing?.clientPlans ?? const {});
      final impact = d.tripImpact(draft);
      if (impact.isNotEmpty) {
        final plans = await showTripClientsDialog(context, d, draft, impact);
        if (plans == null || !context.mounted) return;
        _plans = plans;
      } else {
        if (widget.existing != null) _plans = const {};
        if (d.hasAE) {
          snack(context, d.clients.where((c) => !c.isOneOff).isEmpty
              ? 'Aucun client enregistré : rien à ajuster pour ce voyage.'
              : 'Aucun passage client n\'est touché par ces dates.');
        }
      }
    }

    _doSaveProject(v);

    // ── Calcul des jours de congés à poser pour ce voyage ──────
    if (_trip && _start != null && _end != null) {
      await _proposeLeaveForTrip(context, v);
    }
  }

  /// Calcule les jours de travail tombant pendant le voyage selon la tournante,
  /// et propose de les poser en congés.
  Future<void> _proposeLeaveForTrip(BuildContext context, double budget) async {
    final d = ref.read(appProvider);
    final schedule = d.shiftSchedule;
    final leaveTypes = d.leaveTypes;
    if (!d.user.leaveEnabled || leaveTypes.isEmpty) return;
    if (schedule == null && d.shiftSchedule == null) return;

    // Compter les jours de travail pendant le voyage
    final tripDays = <DateTime>[];
    if (schedule != null && _start != null && _end != null) {
      var cur = DateTime(_start!.year, _start!.month, _start!.day);
      final endDate = DateTime(_end!.year, _end!.month, _end!.day);
      while (!cur.isAfter(endDate)) {
        if (schedule.shiftOn(cur).isWorking) tripDays.add(cur);
        cur = cur.add(const Duration(days: 1));
      }
    }
    if (tripDays.isEmpty) return;

    // Regrouper par mois
    final Map<Ym, int> joursParMois = {};
    for (final d in tripDays) {
      final ym = Ym(d.year, d.month);
      joursParMois[ym] = (joursParMois[ym] ?? 0) + 1;
    }

    // Afficher la proposition
    if (!context.mounted) return;
    await showSheet(
      context,
      title: 'Congés pour ${_name.text.trim()}',
      child: _TripLeaveSheet(
        tripName: _name.text.trim(),
        joursParMois: joursParMois,
        leaveTypes: leaveTypes,
        tripStart: _start!,
        tripEnd: _end!,
      ),
    );
  }

  Widget _financeOption({
    required bool selected,
    required IconData icon,
    required String title,
    required String subtitle,
    required Hint info,
    required VoidCallback onTap,
  }) {
    final color = selected ? AppColors.violet : AppColors.muted;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.fromLTRB(14, 10, 4, 10),
        decoration: BoxDecoration(
          color: selected ? AppColors.violet.withAlpha(22) : context.fieldColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? AppColors.violet : Colors.transparent, width: 1.6),
        ),
        child: Row(children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5, color: selected ? AppColors.violet : null)),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 12, height: 1.3)),
            ]),
          ),
          InfoButton(info, size: 17),
          Icon(selected ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, size: 20, color: color),
          const SizedBox(width: 6),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final expense = _mode == ProjectMode.expense;
    final days = (_start != null && _end != null) ? _end!.difference(_start!).inDays + 1 : 0;
    final accent = _trip ? const Color(0xFF0A84FF) : AppColors.violet;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Voyage / Autre projet ─────────────────────────────────
      withInfo(SizedBox(
        width: double.infinity,
        child: TabSwitcher<bool>(
          tabs: const [
            (value: true,  label: 'Voyage',       icon: Icons.flight_rounded),
            (value: false, label: 'Autre projet',  icon: Icons.flag_rounded),
          ],
          selected: _trip,
          onChanged: (v) => setState(() {
            _trip = v;
            if (!v) {
              _start = null;
              _end = null;
              if (widget.existing == null) _mode = ProjectMode.savings;
            }
          }),
        ),
      ), Hint.fieldProjectType),
      const SizedBox(height: 12),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _name,
          hint: _trip ? 'Nom du voyage (ex. Thaïlande, Japon)' : 'Nom du projet (ex. Voiture, Apport)',
          icon: _trip ? Icons.flight_rounded : Icons.flag_outlined,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: accent)),
      ]),
      const SizedBox(height: 12),
      if (!_trip)
        SoftButton(
          icon: Icons.flag_rounded,
          label: 'Mois cible : ${_target.label}',
          onPressed: () async {
            final y = await pickYm(context, _target);
            if (y != null) setState(() => _target = y);
          },
        ),
      if (_trip) ...[
      if (_start == null) ...[
        SoftButton(
          icon: Icons.date_range_rounded,
          label: 'Choisir les dates du voyage',
          onPressed: _pickDates,
        ),
        const SizedBox(height: 6),
        SoftButton(
          icon: Icons.calendar_month_rounded,
          label: 'Dates inconnues — mois : ${_target.label}',
          onPressed: () async {
            final y = await pickYm(context, _target);
            if (y != null) setState(() => _target = y);
          },
        ),
      ] else ...[
        Row(children: [
          Expanded(
            child: SoftButton(
              icon: Icons.flight_takeoff_rounded,
              label: 'Départ ${_fd(_start!)}',
              onPressed: _pickDates,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: SoftButton(
              icon: Icons.flight_land_rounded,
              label: 'Retour ${_fd(_end!)}',
              onPressed: _pickDates,
            ),
          ),
        ]),
        const SizedBox(height: 6),
        Text(
            '$days jour${days > 1 ? 's' : ''} · ${_target.longName} ${_target.year}'
            '${d.hasAE ? ' · passages clients retirés' : ''}',
            style: const TextStyle(color: AppColors.muted, fontSize: 12, height: 1.3)),
      ],
      ],
      if (_trip && d.isCouple && d.hasAE) ...[
        const SizedBox(height: 12),
        labelWithInfo('Qui part ?', Hint.fieldWho, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        PillSelector<int>.row(
          items: [
            const PillItem(0, 'Les deux', icon: Icons.people_rounded),
            for (final p in [1, 2])
              PillItem(p, d.personName(p), icon: Icons.person_rounded),
          ],
          selected: _who,
          onChanged: (p) => setState(() => _who = p),
        ),
      ],
      const SizedBox(height: 12),
      // ── Financement : deux options bien distinctes, chacune avec son explication ─
      const Text('Comment veux-tu le financer ?', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      const SizedBox(height: 8),
      _financeOption(
        selected: expense,
        icon: Icons.credit_card_rounded,
        title: _trip ? 'Payer sur place' : "Payer d'un coup",
        subtitle: _trip
            ? 'Rien avant : le budget est réservé le mois du voyage.'
            : 'Rien avant : déduit de ton solde le mois cible.',
        info: _trip ? Hint.fieldPayOnSite : Hint.fieldPayCash,
        onTap: () => setState(() => _mode = ProjectMode.expense),
      ),
      const SizedBox(height: 8),
      _financeOption(
        selected: !expense,
        icon: Icons.savings_rounded,
        title: 'Épargner avant',
        subtitle: _trip
            ? 'Une somme est mise de côté chaque mois jusqu\'au voyage.'
            : 'Une somme est mise de côté chaque mois jusqu\'à la date cible.',
        info: Hint.fieldSave,
        onTap: () => setState(() => _mode = ProjectMode.savings),
      ),
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: widget.existing == null ? (_trip ? 'Créer le voyage' : 'Créer le projet') : 'Enregistrer',
        onSave: () => _trySave(context),
      ),
    ]);
  }
}

// ---------------- Proposition de congés pour un voyage ----------------
class _TripLeaveSheet extends ConsumerStatefulWidget {
  final String tripName;
  final Map<Ym, int> joursParMois; // jours travaillés par mois pendant le voyage
  final List<LeaveType> leaveTypes;
  final DateTime tripStart;
  final DateTime tripEnd;
  const _TripLeaveSheet({
    required this.tripName,
    required this.joursParMois,
    required this.leaveTypes,
    required this.tripStart,
    required this.tripEnd,
  });
  @override
  ConsumerState<_TripLeaveSheet> createState() => _TripLeaveSheetState();
}

class _TripLeaveSheetState extends ConsumerState<_TripLeaveSheet> {
  // Pour chaque mois : répartition par type de congé (typeId -> jours)
  late Map<Ym, Map<String, int>> _repartition;
  late Map<Ym, int> _totalParMois;

  @override
  void initState() {
    super.initState();
    _totalParMois = Map.from(widget.joursParMois);
    _computeRepartition();
  }

  void _computeRepartition() {
    final d = ref.read(appProvider);
    final types = [...widget.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    _repartition = {};

    for (final entry in _totalParMois.entries) {
      final ym = entry.key;
      int remaining = entry.value;
      _repartition[ym] = {};

      for (final lt in types) {
        if (remaining <= 0) break;
        // Solde disponible ce mois
        double bal = lt.initialBalance;
        var cur = d.startYm;
        while (cur.index < ym.index) {
          bal += lt.accrualPerMonth;
          final posed = d.leaveEntries
              .where((e) => e.leaveTypeId == lt.id && e.month == cur && e.note != '__solde__')
              .fold(0.0, (s, e) => s + e.days);
          bal -= posed;
          cur = cur.add(1);
        }
        bal += lt.accrualPerMonth;
        final dispo = bal.floor().clamp(0, remaining);
        if (dispo > 0) {
          _repartition[ym]![lt.id] = dispo;
          remaining -= dispo;
        }
      }
      // Si remaining > 0 : pas assez de solde
      if (remaining > 0 && types.isNotEmpty) {
        _repartition[ym]![types.first.id] = (_repartition[ym]![types.first.id] ?? 0) + remaining;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final types = [...widget.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    final totalJours = _totalParMois.values.fold(0, (a, b) => a + b);
    final n = ref.read(appProvider.notifier);

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Résumé ───────────────────────────────────────────────
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.violet.withAlpha(15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          const Text('✈️', style: TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.tripName,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            Text(
              '${_fmtDate(widget.tripStart)} → ${_fmtDate(widget.tripEnd)} · $totalJours jour${totalJours > 1 ? 's' : ''} travaillé${totalJours > 1 ? 's' : ''} à couvrir',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
            ),
          ])),
        ]),
      ),
      const SizedBox(height: 14),
      // ── Répartition par mois ──────────────────────────────────
      for (final entry in _totalParMois.entries) ...[
        Text(
          entry.key.longName,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.muted),
        ),
        const SizedBox(height: 6),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
          child: Column(children: [
            for (final lt in types) ...[
              Builder(builder: (_) {
                final posed = _repartition[entry.key]?[lt.id] ?? 0;
                final d = ref.read(appProvider);
                // Calculer le dispo
                double bal = lt.initialBalance;
                var cur = d.startYm;
                while (cur.index < entry.key.index) {
                  bal += lt.accrualPerMonth;
                  final p = d.leaveEntries
                      .where((e) => e.leaveTypeId == lt.id && e.month == cur && e.note != '__solde__')
                      .fold(0.0, (s, e) => s + e.days);
                  bal -= p;
                  cur = cur.add(1);
                }
                bal += lt.accrualPerMonth;
                final dispo = bal.floor().clamp(0, 999);
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(children: [
                    CircleAvatar(radius: 7, backgroundColor: Color(lt.colorValue)),
                    const SizedBox(width: 10),
                    Expanded(child: Text(lt.name,
                        style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text('dispo : $dispo j', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    const SizedBox(width: 10),
                    // Sélecteur de jours
                    Row(children: [
                      GestureDetector(
                        onTap: posed > 0 ? () => setState(() {
                          _repartition[entry.key]![lt.id] = posed - 1;
                        }) : null,
                        child: Container(
                          width: 28, height: 28,
                          decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(8)),
                          child: const Icon(Icons.remove_rounded, size: 14),
                        ),
                      ),
                      SizedBox(width: 32, child: Center(
                        child: Text('$posed j', style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: posed > dispo ? AppColors.danger : Color(lt.colorValue))),
                      )),
                      GestureDetector(
                        onTap: () => setState(() {
                          _repartition[entry.key]![lt.id] = posed + 1;
                        }),
                        child: Container(
                          width: 28, height: 28,
                          decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(8)),
                          child: const Icon(Icons.add_rounded, size: 14),
                        ),
                      ),
                    ]),
                  ]),
                );
              }),
            ],
          ]),
        ),
        const SizedBox(height: 10),
      ],
      const SizedBox(height: 6),
      // ── Boutons ───────────────────────────────────────────────
      GradientButton(
        label: 'Poser ces congés',
        onPressed: () {
          for (final moisEntry in _repartition.entries) {
            for (final typeEntry in moisEntry.value.entries) {
              if (typeEntry.value > 0) {
                n.setLeaveEntry(typeEntry.key, moisEntry.key, typeEntry.value.toDouble());
              }
            }
          }
          Navigator.pop(context);
          snack(context, '✅ Congés posés pour ${widget.tripName}');
        },
      ),
      const SizedBox(height: 8),
      SoftButton(
        icon: Icons.skip_next_rounded,
        label: 'Ne pas poser de congés maintenant',
        onPressed: () => Navigator.pop(context),
      ),
    ]);
  }

  String _fmtDate(DateTime d) => '${d.day}/${d.month}/${d.year}';
}

/// Voyage avec dates pour un auto-entrepreneur : que faire des clients qu'on ne pourra pas voir ?
/// Retourne les choix par client (null = annulé).
Future<Map<String, ClientTripPlan>?> showTripClientsDialog(
  BuildContext context,
  AppData d,
  Project draft,
  List<({Client client, double lost})> impact,
) =>
    Navigator.of(context).push<Map<String, ClientTripPlan>>(PageRouteBuilder(
      opaque: true,
      transitionDuration: const Duration(milliseconds: 260),
      reverseTransitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (_, __, ___) => _TripClientsPage(data: d, draft: draft, impact: impact),
      transitionsBuilder: (_, anim, __, child) => FadeTransition(
        opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
        child: SlideTransition(
          position: Tween(begin: const Offset(0, 0.04), end: Offset.zero)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: child,
        ),
      ),
    ));

class _TripClientsPage extends StatefulWidget {
  final AppData data;
  final Project draft;
  final List<({Client client, double lost})> impact;
  const _TripClientsPage({required this.data, required this.draft, required this.impact});
  @override
  State<_TripClientsPage> createState() => _TripClientsPageState();
}

class _TripClientsPageState extends State<_TripClientsPage> {
  final _modes = <String, int>{};
  final _lost = <String, double>{};
  final _pays = <String, TextEditingController>{};

  @override
  void initState() {
    super.initState();
    final d = widget.data;
    for (final i in widget.impact) {
      final id = i.client.id;
      final plan = widget.draft.clientPlans[id];
      _modes[id] = plan?.mode ?? ClientTripPlan.remove;
      if (d.isFlexible(i.client)) {
        _lost[id] = plan?.lost ?? min(d.tripCapacity(i.client, widget.draft), i.lost.ceilToDouble());
      }
      _pays[id] = TextEditingController(text: (plan?.subPay ?? 0) > 0 ? plan!.subPay.toStringAsFixed(0) : '');
    }
  }

  @override
  void dispose() {
    for (final c in _pays.values) {
      c.dispose();
    }
    super.dispose();
  }

  String _nb(double v) => v == v.roundToDouble() ? v.round().toString() : v.toStringAsFixed(1).replaceAll('.', ',');
  String _fd(DateTime x) => '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}';
  double _lostOf(({Client client, double lost}) i) => _lost[i.client.id] ?? i.lost;

  double _effect(({Client client, double lost}) i) {
    switch (_modes[i.client.id]) {
      case ClientTripPlan.keep:
        return 0;
      case ClientTripPlan.sub:
        return -(parseAmount(_pays[i.client.id]!.text) ?? 0);
      default:
        return -_lostOf(i) * i.client.amount;
    }
  }

  void _setAll(int mode) {
    HapticFeedback.selectionClick();
    setState(() {
      for (final i in widget.impact) {
        _modes[i.client.id] = mode;
      }
    });
  }

  void _done() => Navigator.pop(context, <String, ClientTripPlan>{
        for (final i in widget.impact)
          i.client.id: ClientTripPlan(
            mode: _modes[i.client.id] ?? ClientTripPlan.remove,
            subPay: _modes[i.client.id] == ClientTripPlan.sub ? (parseAmount(_pays[i.client.id]!.text) ?? 0) : 0,
            lost: _lost[i.client.id],
          ),
      });

  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    final p = widget.draft;
    final n = widget.impact.length;
    final total = widget.impact.fold(0.0, (t, i) => t + _effect(i));
    final loss = total < -0.5;
    final pageBg = Theme.of(context).brightness == Brightness.dark ? AppColors.bgDark : AppColors.bg;
    return Scaffold(
      backgroundColor: pageBg,
      body: SafeArea(
        child: Column(children: [
          // ── Barre du haut : fermer + titre ─────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: Row(children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(color: context.fieldColor, shape: BoxShape.circle),
                  child: Icon(Icons.close_rounded, size: 20, color: context.mutedColor),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Tes clients pendant le voyage',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, letterSpacing: -0.3)),
                  Text('${p.name.isEmpty ? 'Voyage' : p.name} · ${_fd(p.tripStart!)} → ${_fd(p.tripEnd!)}',
                      style: const TextStyle(color: AppColors.muted, fontSize: 12.5, fontWeight: FontWeight.w600)),
                ]),
              ),
            ]),
          ),
          // ── Liste ──────────────────────────────────────────────
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              children: [
                Text(
                    '$n client${n > 1 ? 's' : ''} ${n > 1 ? 'risquent' : 'risque'} d\'être touché${n > 1 ? 's' : ''}. '
                    'Choisis ce que tu veux faire pour chacun.',
                    style: const TextStyle(fontSize: 13.5, height: 1.4)),
                const SizedBox(height: 12),
                if (n > 1)
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      const Text('Pour tous :', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w700, fontSize: 12.5)),
                      const SizedBox(width: 8),
                      for (final o in const [
                        (ClientTripPlan.remove, 'Tout retirer'),
                        (ClientTripPlan.keep, 'Tout décaler'),
                        (ClientTripPlan.sub, 'Tout sous-traiter'),
                      ]) ...[
                        GestureDetector(
                          onTap: () => _setAll(o.$1),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                            decoration: BoxDecoration(
                              color: AppColors.violet.withAlpha(22),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(o.$2,
                                style: const TextStyle(color: AppColors.violet, fontWeight: FontWeight.w700, fontSize: 12.5)),
                          ),
                        ),
                        const SizedBox(width: 6),
                      ],
                    ]),
                  ),
                const SizedBox(height: 14),
                for (final i in widget.impact) _clientCard(context, d, i),
              ],
            ),
          ),
          // ── Pied : bilan + valider ─────────────────────────────
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            decoration: BoxDecoration(
              color: pageBg,
              border: Border(top: BorderSide(color: context.mutedColor.withAlpha(30))),
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                Expanded(
                    child: Text(loss ? 'Manque à gagner estimé' : 'Aucune perte de chiffre d\'affaires',
                        style: TextStyle(
                            color: context.mutedColor, fontWeight: FontWeight.w600, fontSize: 13))),
                Text(loss ? eur(total) : '0 €',
                    style: TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 20,
                        letterSpacing: -0.4,
                        color: loss ? AppColors.danger : AppColors.success)),
              ]),
              const SizedBox(height: 10),
              SizedBox(
                  width: double.infinity,
                  child: GradientButton(label: 'Valider mes choix', icon: Icons.check_rounded, onPressed: _done)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _segmented(BuildContext context, String id) {
    final mode = _modes[id] ?? ClientTripPlan.remove;
    const items = [
      (ClientTripPlan.remove, Icons.block_rounded, 'Retirer'),
      (ClientTripPlan.keep, Icons.event_repeat_rounded, 'Décaler'),
      (ClientTripPlan.sub, Icons.handshake_rounded, 'Sous-traiter'),
    ];
    return Container(
      height: 42,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(color: context.cardColor, borderRadius: BorderRadius.circular(14)),
      child: Stack(children: [
        AnimatedAlign(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          alignment: Alignment(mode == ClientTripPlan.remove ? -1.0 : (mode == ClientTripPlan.keep ? 0.0 : 1.0), 0),
          child: FractionallySizedBox(
            widthFactor: 1 / 3,
            heightFactor: 1,
            child: Container(
              decoration: BoxDecoration(gradient: brandGradient, borderRadius: BorderRadius.circular(11)),
            ),
          ),
        ),
        Row(children: [
          for (final o in items)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _modes[id] = o.$1);
                },
                child: Center(
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    TweenAnimationBuilder<Color?>(
                      tween: ColorTween(end: mode == o.$1 ? Colors.white : context.mutedColor),
                      duration: const Duration(milliseconds: 220),
                      builder: (_, col, __) => Icon(o.$2, size: 15, color: col),
                    ),
                    const SizedBox(width: 4),
                    Flexible(
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 220),
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: mode == o.$1 ? Colors.white : context.mutedColor),
                        child: Text(o.$3, maxLines: 1, overflow: TextOverflow.ellipsis),
                      ),
                    ),
                  ]),
                ),
              ),
            ),
        ]),
      ]),
    );
  }

  Widget _clientCard(BuildContext context, AppData d, ({Client client, double lost}) i) {
    final c = i.client;
    final mode = _modes[c.id] ?? ClientTripPlan.remove;
    final eff = _effect(i);
    final flexible = d.isFlexible(c);
    final unipro = d.user.privateMode && c.unipro;
    return Container(
      key: ValueKey('trip_client_${c.id}'),
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(22)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleEmoji(c.name.characters.first.toUpperCase(),
              clientColorOf(c),
              letter: true, size: 38),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Flexible(
                    child: Text(c.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5))),
                if (unipro) ...[const SizedBox(width: 8), const UniproBadge()],
              ]),
              Text(
                  flexible
                      ? c.frequencyLabel
                      : '${_nb(i.lost)} passage${i.lost > 1 ? 's' : ''} pendant ton absence',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
            ]),
          ),
          const SizedBox(width: 8),
          Text(eff < -0.5 ? eur(eff) : '0 €',
              style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                  color: eff < -0.5 ? AppColors.danger : AppColors.success)),
        ]),
        if (flexible) ...[
          const SizedBox(height: 12),
          Row(children: [
            const Expanded(
                child: Text('Passages que tu rates pendant ce voyage',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13))),
            Container(
              decoration: BoxDecoration(color: context.cardColor, borderRadius: BorderRadius.circular(20)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.remove_rounded, size: 20),
                  color: AppColors.violet,
                  onPressed: (_lost[c.id] ?? 0) > 0
                      ? () {
                          HapticFeedback.selectionClick();
                          setState(() => _lost[c.id] = _lost[c.id]! - 1);
                        }
                      : null,
                ),
                SizedBox(
                    width: 22,
                    child: Text(_nb(_lost[c.id] ?? 0),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  icon: const Icon(Icons.add_rounded, size: 20),
                  color: AppColors.violet,
                  onPressed: (_lost[c.id] ?? 0) < d.tripCapacity(c, widget.draft)
                      ? () {
                          HapticFeedback.selectionClick();
                          setState(() => _lost[c.id] = _lost[c.id]! + 1);
                        }
                      : null,
                ),
              ]),
            ),
          ]),
        ],
        const SizedBox(height: 12),
        _segmented(context, c.id),
        AnimatedSize(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          alignment: Alignment.topCenter,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (mode != ClientTripPlan.remove) ...[
              const SizedBox(height: 8),
              Text(
                  mode == ClientTripPlan.keep
                      ? 'Les passages restent sur sa facture : tu les rattrapes plus tard.'
                      : 'La facture est maintenue : quelqu\'un d\'autre fait les passages.',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.35)),
            ],
            if (mode == ClientTripPlan.sub) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _pays[c.id],
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Ce que tu paies le sous-traitant (total)',
                  suffixText: '€',
                ),
              ),
            ],
          ]),
        ),
      ]),
    );
  }
}

/// Suppression d'un voyage qui avait touché des factures : remettre les factures de base ?
/// true = remettre, false = garder telles quelles, null = annuler.
Future<bool?> showRestoreInvoicesDialog(BuildContext context, int clientCount) => showQuickDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Remettre les factures ?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        content: Text(
            'Ce voyage avait modifié les passages de $clientCount client${clientCount > 1 ? 's' : ''}. '
            'Veux-tu remettre leurs factures comme avant, ou les garder telles qu\'elles sont ?',
            style: const TextStyle(fontSize: 14, height: 1.45)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Garder telles quelles')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Remettre comme avant')),
        ],
      ),
    );
