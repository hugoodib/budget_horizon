import 'package:flutter/material.dart';
import '../../core/theme.dart';
import 'hints.dart';

/// Une page d'un mini-tutoriel : un texte + une scène animée (écran fictif).
class TutPage {
  final String title;
  final String text;
  final Widget Function(BuildContext context, double v) scene;
  const TutPage(this.title, this.text, this.scene);
}

double _seg(double v, double a, double b) => ((v - a) / (b - a)).clamp(0.0, 1.0).toDouble();

Widget _frame(BuildContext c, Widget child) => Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      decoration: BoxDecoration(color: c.fieldColor.withAlpha(170), borderRadius: BorderRadius.circular(16)),
      child: child,
    );

Widget _finger(BuildContext c, double tap) => Transform.scale(
      scale: 1 - 0.16 * tap,
      child: Icon(Icons.touch_app_rounded, size: 32, color: c.textColor.withAlpha(225)),
    );

Widget _header(BuildContext c, String title, {bool plus = false, double tap = 0, bool finger = false}) => Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(children: [
        Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
        if (plus)
          SizedBox(
            width: 52,
            height: 40,
            child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
              if (tap > 0)
                Container(
                  width: 34 + 14 * tap,
                  height: 34 + 14 * tap,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.violet.withAlpha((80 * tap).round())),
                ),
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(shape: BoxShape.circle, color: c.fieldColor, border: Border.all(color: AppColors.violet.withAlpha(140), width: 1.5)),
                child: Icon(Icons.add_rounded, size: 20, color: c.textColor),
              ),
              if (finger) Positioned(right: -12, bottom: -14 + 4 * tap, child: _finger(c, tap)),
            ]),
          ),
      ]),
    );

Widget _row(BuildContext c, String emoji, String label, String sub, String amount,
        {double opacity = 1, bool? checked, Color? color, bool highlight = false, double? progress}) =>
    Opacity(
      opacity: opacity,
      child: Container(
        margin: const EdgeInsets.only(bottom: 7),
        padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
        decoration: BoxDecoration(
          color: highlight ? AppColors.violet.withAlpha(26) : (c.isDark ? Colors.white.withAlpha(10) : Colors.white.withAlpha(180)),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: highlight ? AppColors.violet.withAlpha(120) : Colors.transparent, width: 1.3),
        ),
        child: Column(children: [
          Row(children: [
            Text(emoji, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 9),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                Text(sub, style: TextStyle(color: c.mutedColor, fontSize: 11.5)),
              ]),
            ),
            Text(amount, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: color ?? c.textColor)),
            if (checked != null) ...[
              const SizedBox(width: 8),
              AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: 24,
                height: 24,
                decoration: BoxDecoration(shape: BoxShape.circle, color: checked ? AppColors.success : c.fieldColor),
                child: checked ? const Icon(Icons.check_rounded, size: 16, color: Colors.white) : null,
              ),
            ],
          ]),
          if (progress != null) ...[
            const SizedBox(height: 7),
            ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: LinearProgressIndicator(
                  value: progress, minHeight: 6, backgroundColor: c.trackColor, valueColor: const AlwaysStoppedAnimation(AppColors.violet)),
            ),
          ],
        ]),
      ),
    );

/// Formulaire fictif qui se remplit champ par champ, puis le bouton est touché.
Widget _form(BuildContext c, double v, String title, List<(String, String)> fields, String submit) {
  final n = fields.length;
  final w = 0.62 / n;
  final press = _seg(v, 0.74, 0.80);
  final fingerIn = _seg(v, 0.66, 0.74);
  return _frame(
    c,
    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      const SizedBox(height: 10),
      for (var i = 0; i < n; i++)
        Builder(builder: (_) {
          final p = _seg(v, 0.04 + i * w, 0.04 + (i + 1) * w - 0.02);
          final active = p > 0 && p < 1;
          final text = fields[i].$2;
          final shown = text.substring(0, (text.length * p).round());
          return Container(
            margin: const EdgeInsets.only(bottom: 7),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: c.isDark ? const Color(0xFF1E2440) : Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: active ? AppColors.violet : c.mutedColor.withAlpha(60), width: active ? 1.8 : 1),
            ),
            child: Row(children: [
              Expanded(
                child: Text(fields[i].$1, style: TextStyle(color: c.mutedColor, fontSize: 12, fontWeight: FontWeight.w600)),
              ),
              Text('$shown${active ? '▏' : ''}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
            ]),
          );
        }),
      const SizedBox(height: 4),
      SizedBox(
        height: 46,
        child: Stack(clipBehavior: Clip.none, children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(gradient: brandGradient, borderRadius: BorderRadius.circular(16)),
              alignment: Alignment.center,
              child: Text(submit, style: TextStyle(fontWeight: FontWeight.w700, color: c.textColor)),
            ),
          ),
          if (v > 0.64 && v < 0.9)
            Positioned(right: 30 + 40 * (1 - fingerIn), bottom: -16 - 8 * (1 - fingerIn) + 4 * press, child: _finger(c, press)),
        ]),
      ),
    ]),
  );
}

// ═══ Tutoriels par geste ═══════════════════════════════════════════════════════
final Map<Hint, List<TutPage>> hintTutorials = {
  // ── Projets ──
  Hint.tabTrips: [
    TutPage('Un projet, c\'est un objectif',
        'Voyage, voiture, apport… Tu fixes une somme et une date, Hever calcule combien mettre de côté chaque mois. Pour en créer un, touche le + en haut à droite.',
        (c, v) => _frame(c, Column(children: [
              _header(c, 'Projets', plus: true, tap: _seg(v, 0.45, 0.55) * (1 - _seg(v, 0.6, 0.7)), finger: v > 0.25 && v < 0.75),
              _row(c, '🚗', 'Voiture', '2 500 € · 8 mois restants', '312 €/mois', progress: 0.3),
              _row(c, '🏠', 'Apport appartement', '10 000 € · 30 mois restants', '300 €/mois', progress: 0.12),
            ]))),
    TutPage('Ce qu\'on remplit',
        'Choisis « Voyage » ou « Autre projet », donne-lui un nom, le montant total à prévoir et le mois (ou les dates) où tu en auras besoin.',
        (c, v) => _form(c, v, 'Nouveau projet', const [
              ('Type', 'Voyage'),
              ('Nom', 'Voyage au Japon'),
              ('Montant à prévoir', '3 000 €'),
              ('Mois cible', 'Juin 2027'),
            ], 'Enregistrer')),
    TutPage('Et ensuite ?',
        'Le projet apparaît avec sa jauge. Chaque mois, la somme à mettre de côté est retirée de ta prévision. Quand tu as vraiment fait le virement, touche « Marquer le versement du mois ».',
        (c, v) => _frame(c, Column(children: [
              _header(c, 'Projets'),
              _row(c, '✈️', 'Voyage au Japon', '3 000 € · 12 mois restants', '250 €/mois', highlight: true, progress: 0.08 + 0.3 * _seg(v, 0.3, 0.7)),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: v > 0.7 ? AppColors.success.withAlpha(40) : c.fieldColor, borderRadius: BorderRadius.circular(14)),
                alignment: Alignment.center,
                child: Text(v > 0.7 ? 'Versement effectué ✓' : 'Marquer le versement du mois',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            ]))),
  ],
  // ── Budgets ──
  Hint.tabBudgets: [
    TutPage('Tes enveloppes du mois',
        'Chaque dépense est rangée dans une enveloppe (Courses, Essence…). Pour en noter une, touche le + en haut ou le gros + en bas.',
        (c, v) => _frame(c, Column(children: [
              _header(c, 'Budgets', plus: true, tap: _seg(v, 0.45, 0.55) * (1 - _seg(v, 0.6, 0.7)), finger: v > 0.25 && v < 0.75),
              _row(c, '🥕', 'Courses', 'reste 114 €', '186 / 300 €'),
              _row(c, '⛽', 'Essence', 'reste 24 €', '96 / 120 €'),
            ]))),
    TutPage('Noter une dépense',
        'Tape le montant, choisis l\'enveloppe, ajoute une note si tu veux. C\'est tout : 5 secondes.',
        (c, v) => _form(c, v, 'Nouvelle dépense', const [
              ('Montant', '54,20 €'),
              ('Enveloppe', 'Courses'),
              ('Note', 'Carrefour'),
              ('Date', 'Aujourd\'hui'),
            ], 'Ajouter')),
    TutPage('Pointe-la quand elle passe',
        'La dépense est comptée dans l\'enveloppe tout de suite. Quand tu la vois sur ton relevé bancaire, touche le rond : ton solde actuel baisse.',
        (c, v) => _frame(c, Column(children: [
              _row(c, '🥕', 'Courses · Carrefour', 'aujourd\'hui', '−54,20 €', color: AppColors.danger, checked: v > 0.5 && v < 0.92, highlight: true),
              Row(children: [
                Text('Solde actuel', style: TextStyle(color: c.mutedColor, fontSize: 12.5)),
                const Spacer(),
                Text(v > 0.5 && v < 0.92 ? '1 425,80 €' : '1 480 €', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
              ]),
            ]))),
  ],
  // ── Mensuel ──
  Hint.tabCharges: [
    TutPage('Ce qui revient chaque mois',
        'Loyer, assurances, abonnements… Ici, tout ce qui est prélevé régulièrement. Les revenus (salaire…) sont sous l\'onglet « Revenus » juste au-dessus. Le + ajoute une ligne.',
        (c, v) => _frame(c, Column(children: [
              _header(c, 'Mensuel', plus: true, tap: _seg(v, 0.45, 0.55) * (1 - _seg(v, 0.6, 0.7)), finger: v > 0.25 && v < 0.75),
              _row(c, '🏠', 'Loyer', 'chaque mois', '−650 €', color: AppColors.danger, checked: true),
              _row(c, '📶', 'Internet', 'chaque mois', '−29,99 €', color: AppColors.danger, checked: false),
            ]))),
    TutPage('Ce qu\'on remplit',
        'Le nom, le montant et le rythme. Une charge peut commencer plus tard et s\'arrêter à un mois précis (fin d\'un crédit par exemple).',
        (c, v) => _form(c, v, 'Nouvelle charge', const [
              ('Nom', 'Assurance auto'),
              ('Montant', '62 €'),
              ('Rythme', 'Chaque mois'),
              ('Commence', 'Ce mois-ci'),
              ('Se termine', 'Jamais'),
            ], 'Enregistrer')),
    TutPage('Coche à chaque prélèvement',
        'La charge est déduite de ta prévision tous les mois. Quand elle est prélevée sur ton compte, touche le rond : elle passe dans ton solde actuel.',
        (c, v) => _frame(c, Column(children: [
              _row(c, '🚗', 'Assurance auto', 'chaque mois', '−62 €', color: AppColors.danger, checked: v > 0.45 && v < 0.92, highlight: true),
            ]))),
  ],
  // ── Clients ──
  Hint.tabClients: [
    TutPage('Tes clients',
        'Ajoute chaque client avec son tarif et sa fréquence : Hever calcule ton salaire net tout seul, tu n\'as jamais à le saisir. Le + ajoute un client.',
        (c, v) => _frame(c, Column(children: [
              _header(c, 'Clients', plus: true, tap: _seg(v, 0.45, 0.55) * (1 - _seg(v, 0.6, 0.7)), finger: v > 0.25 && v < 0.75),
              _row(c, '👤', 'Studio Léa', '1 fois par mois · 220 €', '≈ 220 €'),
            ]))),
    TutPage('Ce qu\'on remplit',
        'Le nom, le prix d\'un passage, sa durée et le rythme : certains jours, X fois par semaine ou par mois, tous les N mois…',
        (c, v) => _form(c, v, 'Nouveau client', const [
              ('Nom', 'Mme Martin'),
              ('Montant d\'un passage', '40 €'),
              ('Durée', '60 min'),
              ('Fréquence', 'Lundi et jeudi'),
            ], 'Enregistrer')),
    TutPage('Le salaire se calcule seul',
        'Hever compte les passages du mois, retire les charges URSSAF et te donne ton net. Chaque mois, tu retrouves une facture par client dans « Factures ».',
        (c, v) => _frame(c, Column(children: [
              _row(c, '👤', 'Mme Martin', 'Lundi et jeudi · 40 €', '≈ 346 €', highlight: true),
              _row(c, '👤', 'Studio Léa', '1 fois par mois', '≈ 220 €'),
              Row(children: [
                const Text('Ton salaire net', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                const Spacer(),
                Text('${(566 * _seg(v, 0.2, 0.6)).round()} €',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: AppColors.success)),
              ]),
            ]))),
  ],
  // ── Prévisions ──
  Hint.tabForecast: [
    TutPage('Regarde dans l\'avenir',
        'Touche un mois (ou les flèches) : Hever te dit combien il te restera à la fin, en tenant compte de tes revenus, charges, projets et paiements à venir.',
        (c, v) {
          const months = ['Nov', 'Déc', 'Jan', 'Fév'];
          const vals = ['420 €', '610 €', '280 €', '760 €'];
          final sel = v < 0.35 ? 0 : (v < 0.6 ? 1 : (v < 0.8 ? 2 : 3));
          return _frame(c, Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              for (var i = 0; i < 4; i++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(color: i == sel ? AppColors.violet : c.fieldColor, borderRadius: BorderRadius.circular(18)),
                  child: Text(months[i], style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: i == sel ? Colors.white : c.textColor)),
                ),
            ]),
            const SizedBox(height: 14),
            Text('Il te restera', style: TextStyle(color: c.mutedColor, fontSize: 12.5)),
            Text(vals[sel], style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 28, color: AppColors.success)),
          ]));
        }),
    TutPage('Plus loin ?',
        'Choisis 1 an, 5 ans ou 10 ans : le graphique s\'adapte. Pratique pour savoir si tu peux te permettre un voyage ou un achat.',
        (c, v) => _frame(c, SizedBox(
              height: 90,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (var i = 0; i < 8; i++)
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      height: 12 + (20.0 + i * 8) * _seg(v, 0.05 + i * 0.06, 0.4 + i * 0.06),
                      decoration: BoxDecoration(color: AppColors.teal, borderRadius: BorderRadius.circular(6)),
                    ),
                  ),
              ]),
            ))),
  ],
  // ── Bouton + ──
  Hint.add: [
    TutPage('Tout ce que tu peux ajouter',
        'Le + est le bouton principal : une dépense, un revenu, une charge fixe, un paiement en plusieurs fois, un projet…',
        (c, v) => _frame(c, Column(children: [
              for (final e in const [('🛒', 'Une dépense'), ('💼', 'Un revenu'), ('🏠', 'Une charge fixe'), ('💳', 'Un paiement en plusieurs fois'), ('🏁', 'Un projet')])
                _row(c, e.$1, e.$2, '', '', highlight: e.$2 == 'Une dépense' && v > 0.4),
            ]))),
    TutPage('Exemple : une dépense',
        'Montant, enveloppe, note : c\'est noté. Tu peux aussi l\'écrire à l\'assistant ✨ : « 23 € au McDo ».',
        (c, v) => _form(c, v, 'Nouvelle dépense', const [
              ('Montant', '23 €'),
              ('Enveloppe', 'Restaurants'),
              ('Note', 'McDo'),
            ], 'Ajouter')),
  ],
};
