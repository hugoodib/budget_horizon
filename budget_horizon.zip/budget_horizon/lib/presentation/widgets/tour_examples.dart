import 'package:flutter/material.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../tour.dart';
import 'common.dart';

/// Exemples animés de la visite guidée : des données fictives, pour ne pas montrer des écrans vides.
class TourExample extends StatefulWidget {
  final TourDemo kind;
  const TourExample({super.key, required this.kind});
  @override
  State<TourExample> createState() => _TourExampleState();
}

class _TourExampleState extends State<TourExample> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 8000))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  /// Progression 0 → 1 entre [a] et [b] (fraction du cycle), avec ralentissement.
  double _p(double a, double b) =>
      Curves.easeOutCubic.transform(((_c.value - a) / (b - a)).clamp(0.0, 1.0).toDouble());

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.auto_awesome_rounded, size: 14, color: context.mutedColor),
          const SizedBox(width: 6),
          Text('Exemple fictif', style: TextStyle(color: context.mutedColor, fontSize: 11.5, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 8),
        AnimatedBuilder(
          animation: _c,
          builder: (context, _) => switch (widget.kind) {
            TourDemo.envelopes => _envelopes(context),
            TourDemo.clients => _clients(context),
            TourDemo.invoices => _invoices(context),
            TourDemo.project => _project(context),
            TourDemo.forecast => _forecast(context),
            _ => const SizedBox.shrink(),
          },
        ),
      ]),
    );
  }

  // ─── Enveloppes ────────────────────────────────────────────────────────────
  Widget _envelopes(BuildContext context) {
    const rows = [
      ('🥕', 'Courses', 186.0, 300.0),
      ('⛽', 'Essence', 96.0, 120.0),
      ('🍕', 'Restaurants', 95.0, 80.0),
      ('🎮', 'Loisirs', 30.0, 100.0),
    ];
    final k = _p(0.04, 0.45);
    return Column(children: [
      for (final r in rows)
        Padding(
          padding: const EdgeInsets.only(bottom: 9),
          child: _envelopeRow(context, r.$1, r.$2, r.$3 * k, r.$4),
        ),
    ]);
  }

  Widget _envelopeRow(BuildContext context, String emoji, String name, double spent, double limit) {
    final ratio = limit <= 0 ? 0.0 : spent / limit;
    final color = ratio > 1 ? AppColors.danger : (ratio >= 0.75 ? AppColors.warning : AppColors.success);
    final left = limit - spent;
    return Column(children: [
      Row(children: [
        Text(emoji, style: const TextStyle(fontSize: 18)),
        const SizedBox(width: 8),
        Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5))),
        Text(left >= 0 ? 'reste ${eur(left)}' : 'dépassé de ${eur(-left)}',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5, color: color)),
      ]),
      const SizedBox(height: 5),
      ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: LinearProgressIndicator(
          value: ratio.clamp(0.0, 1.0).toDouble(),
          minHeight: 7,
          backgroundColor: context.trackColor,
          valueColor: AlwaysStoppedAnimation(color),
        ),
      ),
    ]);
  }

  // ─── Clients ───────────────────────────────────────────────────────────────
  Widget _clients(BuildContext context) {
    const rows = [
      ('Mme Martin', 'Lundi et jeudi · 40 € · 1 h', 346.4),
      ('Studio Léa', '1 fois par mois · 220 €', 220.0),
      ('Cabinet Roy', 'Tous les 2 mois · 300 €', 150.0),
    ];
    final gross = rows.fold(0.0, (s, r) => s + r.$3);
    final net = gross * (1 - 0.2368);
    final sum = _p(0.45, 0.65);
    return Column(children: [
      for (var i = 0; i < rows.length; i++)
        Opacity(
          opacity: _p(0.04 + i * 0.1, 0.16 + i * 0.1),
          child: Transform.translate(
            offset: Offset(0, 10 * (1 - _p(0.04 + i * 0.1, 0.16 + i * 0.1))),
            child: Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(children: [
                const Icon(Icons.person_outline_rounded, size: 20, color: AppColors.teal),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(rows[i].$1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                    Text(rows[i].$2, style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
                  ]),
                ),
                Text('≈ ${eur(rows[i].$3)}/mois', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
              ]),
            ),
          ),
        ),
      const Divider(height: 14),
      Opacity(
        opacity: sum,
        child: Column(children: [
          Row(children: [
            Text('Facturé (brut)', style: TextStyle(color: context.mutedColor, fontSize: 12.5)),
            const Spacer(),
            Text(eur(gross * sum), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
          ]),
          const SizedBox(height: 3),
          Row(children: [
            const Text('Ton salaire net (URSSAF déduit)', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
            const Spacer(),
            Text(eur(net * sum),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppColors.success)),
          ]),
        ]),
      ),
    ]);
  }

  // ─── Factures ──────────────────────────────────────────────────────────────
  Widget _invoices(BuildContext context) {
    // La 1re facture passe de « À envoyer » à « Envoyée » puis « Payée ».
    final v = _c.value;
    final stage = v < 0.30 ? 0 : (v < 0.62 ? 1 : 2);
    const labels = ['À envoyer', 'Envoyée', 'Payée'];
    final colors = [AppColors.muted, AppColors.warning, AppColors.success];
    Widget row(String name, String amount, int st) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(children: [
            Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5))),
            Text(amount, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            const SizedBox(width: 8),
            AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: tint(colors[st], .18), borderRadius: BorderRadius.circular(12)),
              child: Text(labels[st], style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: colors[st])),
            ),
          ]),
        );
    return Column(children: [
      row('Mme Martin', eur(346.4), stage),
      row('Studio Léa', eur(220), 2),
      row('Cabinet Roy', eur(150), 1),
      Text(
          stage == 2 ? 'Payée : l\'argent compte dans ton solde.' : 'Tant qu\'elle n\'est pas payée, la facture reste à suivre.',
          style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
    ]);
  }

  // ─── Projet ────────────────────────────────────────────────────────────────
  Widget _project(BuildContext context) {
    final k = _p(0.05, 0.55);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const Text('✈️', style: TextStyle(fontSize: 22)),
        const SizedBox(width: 10),
        const Expanded(child: Text('Voyage au Japon', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
        Text(eur(3000), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
      ]),
      const SizedBox(height: 8),
      ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: LinearProgressIndicator(
          value: 0.4 * k,
          minHeight: 8,
          backgroundColor: context.trackColor,
          valueColor: const AlwaysStoppedAnimation(AppColors.violet),
        ),
      ),
      const SizedBox(height: 6),
      Row(children: [
        Text('${eur(1200 * k)} mis de côté', style: TextStyle(color: context.mutedColor, fontSize: 12)),
        const Spacer(),
        const Text('250 € / mois', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
      ]),
      const SizedBox(height: 4),
      Text('Chaque mois, 250 € sont retirés de ta prévision : le voyage est payé sans mauvaise surprise.',
          style: TextStyle(color: context.mutedColor, fontSize: 11.5, height: 1.3)),
    ]);
  }

  // ─── Prévisions ────────────────────────────────────────────────────────────
  Widget _forecast(BuildContext context) {
    const months = ['Nov', 'Déc', 'Jan', 'Fév', 'Mar', 'Avr'];
    const values = [420.0, 610.0, 280.0, 760.0, 940.0, 1180.0];
    const maxV = 1180.0;
    return SizedBox(
      height: 112,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (var i = 0; i < months.length; i++)
          Expanded(
            child: Builder(builder: (context) {
              final k = _p(0.04 + i * 0.07, 0.30 + i * 0.07);
              return Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Text(eur(values[i] * k), style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 3),
                Container(
                  height: 62 * (values[i] / maxV) * k + 3,
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  decoration: BoxDecoration(
                      color: i == 2 ? AppColors.warning : AppColors.teal, borderRadius: BorderRadius.circular(6)),
                ),
                const SizedBox(height: 4),
                Text(months[i], style: TextStyle(fontSize: 11, color: context.mutedColor)),
              ]);
            }),
          ),
      ]),
    );
  }
}
