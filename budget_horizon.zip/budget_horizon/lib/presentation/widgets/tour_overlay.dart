import 'dart:math';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../tour.dart';
import 'common.dart';
import 'tour_examples.dart';

const _kAnim = Duration(milliseconds: 750);
const _kCurve = Curves.easeInOutCubic;

/// Couche posée au-dessus de toute l'app. Ne s'affiche que quand la démonstration est active.
class TourLayer extends ConsumerWidget {
  const TourLayer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = ref.watch(tourProvider);
    if (!t.active) return const SizedBox.shrink();
    return const _TourOverlay();
  }
}

class _TourOverlay extends ConsumerStatefulWidget {
  const _TourOverlay();
  @override
  ConsumerState<_TourOverlay> createState() => _TourOverlayState();
}

class _TourOverlayState extends ConsumerState<_TourOverlay> {
  int _lastStep = -1;
  int _frames = 0; // nombre d'images pendant lesquelles on suit l'élément (défilement)
  Rect? _rect;

  Rect? _rectOf(GlobalKey? key) {
    final ctx = key?.currentContext;
    if (ctx == null) return null;
    final ro = ctx.findRenderObject();
    if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
    return ro.localToGlobal(Offset.zero) & ro.size; // épouse exactement l'élément
  }

  Rect? _seen; // dernière position mesurée (pour attendre qu'elle soit stable)
  bool _scrolled = false;

  /// Suit l'élément pendant le changement d'onglet et le défilement, mais n'avance le
  /// cadre et la bulle qu'une fois la position STABLE : une seule glissade, sans à-coups.
  void _track(GlobalKey? key, int step) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || step != _lastStep) return;
      final ctx = key?.currentContext;
      if (ctx != null && !_scrolled) {
        _scrolled = true; // l'élément existe enfin : on l'amène à l'écran (une seule fois)
        Scrollable.ensureVisible(ctx,
            alignment: 0.35, duration: const Duration(milliseconds: 300), curve: _kCurve);
      }
      final r = _rectOf(key);
      final stable = r != null && _seen != null && (r.topLeft - _seen!.topLeft).distance < 0.5 &&
          (r.size.width - _seen!.size.width).abs() < 0.5 && (r.size.height - _seen!.size.height).abs() < 0.5;
      _seen = r;
      if (stable && r != _rect) setState(() => _rect = r);
      if (++_frames < 90) _track(key, step);
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(tourProvider);
    final steps = ref.watch(tourStepsProvider);
    if (t.step >= steps.length) return const SizedBox.shrink();
    final step = steps[t.step];
    if (t.step != _lastStep) {
      _lastStep = t.step;
      _frames = 0;
      _seen = null;
      _scrolled = false;
      if (step.target == null) {
        _rect = null;
      } else {
        _track(step.target, t.step);
      }
    }

    final size = MediaQuery.of(context).size;
    final pad = MediaQuery.of(context).padding;
    final ctl = ref.read(tourProvider.notifier);
    final last = t.step == steps.length - 1;
    final rect = _rect;

    // Sans cible : un « trou » de taille nulle au centre → tout l'écran est flou.
        final holeTarget = rect ?? Rect.fromCenter(center: size.center(Offset.zero), width: 0, height: 0);

    // Position de la bulle : sous l'élément, au-dessus, ou — si l'élément est très grand
    // (une grosse carte qui occupe presque tout l'écran) — épinglée en bas par-dessus.
    double top, bottom;
    Alignment align;
    final need = step.demo == null ? 240.0 : (step.demo!.index >= TourDemo.envelopes.index ? 470.0 : 380.0); // hauteur à peu près nécessaire à la bulle
    if (rect == null) {
      top = pad.top + 16;
      bottom = pad.bottom + 16;
      align = Alignment.center;
    } else {
      final below = size.height - pad.bottom - rect.bottom - 14;
      final above = rect.top - pad.top - 56 - 14;
      if (below >= need) {
        top = rect.bottom + 14;
        bottom = pad.bottom + 16;
        align = Alignment.topCenter;
      } else if (above >= need) {
        top = pad.top + 16;
        bottom = size.height - rect.top + 14;
        align = Alignment.bottomCenter;
      } else {
        top = pad.top + 16;
        bottom = pad.bottom + 16;
        align = Alignment.bottomCenter;
      }
    }

    final buttons = Row(children: [
      if (!last) TextButton(onPressed: ctl.finish, child: Text('Passer', style: TextStyle(fontSize: 14, color: context.mutedColor))),
      const Spacer(),
      if (t.step > 0) TextButton(onPressed: ctl.back, child: const Text('Retour', style: TextStyle(fontSize: 15))),
      const SizedBox(width: 6),
      SizedBox(width: 160, child: CtaButton(label: last ? 'Terminer' : 'Suivant', height: 52, fontSize: 16.5, onPressed: ctl.next)),
    ]);

    final card = Container(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
      decoration: BoxDecoration(
        color: context.isDark ? const Color(0xFF232948) : Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: context.isDark ? Colors.white.withAlpha(40) : Colors.black.withAlpha(18)),
        boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 28, offset: Offset(0, 10))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
       AnimatedSize(
        duration: _kAnim,
        curve: _kCurve,
        alignment: Alignment.topCenter,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 400),
          child: Column(
            key: ValueKey(t.step),
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(
                  child: Text(step.title,
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: context.textColor)),
                ),
                Text('${t.step + 1} / ${steps.length}',
                    style: const TextStyle(color: AppColors.muted, fontSize: 12.5, fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 6),
              Text(step.text,
                  style: TextStyle(
                      fontSize: 14.5, height: 1.42, color: context.textColor, fontWeight: FontWeight.w400)),
              if (step.demo != null) ...[
                const SizedBox(height: 12),
                (step.demo == TourDemo.expense || step.demo == TourDemo.charge || step.demo == TourDemo.income)
                    ? _CheckDemo(kind: step.demo!)
                    : TourExample(kind: step.demo!),
              ],
            ],
          ),
        ),
       ),
       const SizedBox(height: 14),
       buttons,
      ]),
    );

    return Material(
      type: MaterialType.transparency,
      child: Stack(fit: StackFit.expand, children: [
        // Flou animé : il glisse d'un élément à l'autre au lieu de sauter.
        TweenAnimationBuilder<Rect?>(
          tween: RectTween(end: holeTarget),
          duration: _kAnim,
          curve: _kCurve,
          builder: (context, hole, _) => _BlurAround(hole: hole ?? holeTarget, size: size),
        ),
        // Absorbe tous les touchers pendant la démonstration
        Positioned.fill(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: () {})),
        // Bulle d'explication
        AnimatedPositioned(
          duration: _kAnim,
          curve: _kCurve,
          left: 16,
          right: 16,
          top: top,
          bottom: bottom,
          child: AnimatedAlign(
            duration: _kAnim,
            curve: _kCurve,
            alignment: align,
            child: card,
          ),
        ),
      ]),
    );
  }
}

/// Assombrit l'écran SAUF l'élément [hole], qui reste net et cerclé d'un anneau lumineux.
/// Sans élément visé (trou de taille nulle) : simple voile léger, sans flou, pour que
/// l'écran reste lisible derrière la bulle.
class _BlurAround extends StatelessWidget {
  final Rect hole;
  final Size size;
  const _BlurAround({required this.hole, required this.size});

  @override
  Widget build(BuildContext context) {
    final hasHole = hole.width > 1 && hole.height > 1;
    if (!hasHole) {
      return SizedBox.expand(child: ColoredBox(color: Colors.black.withAlpha(95)));
    }
    // Même arrondi que les cartes de l'app (24), réduit pour les petits éléments.
    // Élément rond (ex. bouton +) : le trou est un cercle au diamètre exact du bouton.
    final isRound = (hole.width - hole.height).abs() < 3 && hole.width < 90;
    final radius = isRound ? hole.width / 2 : min(24.0, min(hole.width, hole.height) / 2);
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Stack(fit: StackFit.expand, children: [
      ClipPath(
        clipper: _HoleClipper(hole, radius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 4, sigmaY: 4),
          child: ColoredBox(color: Colors.black.withAlpha(dark ? 120 : 100), child: const SizedBox.expand()),
        ),
      ),
      CustomPaint(painter: _RingPainter(hole, radius)),
    ]);
  }
}

class _RingPainter extends CustomPainter {
  final Rect hole;
  final double radius;
  const _RingPainter(this.hole, this.radius);

  @override
  void paint(Canvas canvas, Size size) {
    final r = RRect.fromRectAndRadius(hole.inflate(1.5), Radius.circular(radius + 1.5));
    canvas.drawRRect(
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = AppColors.teal);
  }

  @override
  bool shouldRepaint(_RingPainter old) => old.hole != hole || old.radius != radius;
}

class _HoleClipper extends CustomClipper<Path> {
  final Rect hole;
  final double radius;
  const _HoleClipper(this.hole, this.radius);

  @override
  Path getClip(Size size) {
    final p = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Offset.zero & size);
    if (hole.width > 1 && hole.height > 1) {
      p.addRRect(RRect.fromRectAndRadius(hole, Radius.circular(radius)));
    }
    return p;
  }

  @override
  bool shouldReclip(_HoleClipper old) => old.hole != hole || old.radius != radius;
}


/// Exemple animé : une ligne qui se coche, et le solde qui change en conséquence.
class _CheckDemo extends StatefulWidget {
  final TourDemo kind;
  const _CheckDemo({required this.kind});
  @override
  State<_CheckDemo> createState() => _CheckDemoState();
}

class _CheckDemoState extends State<_CheckDemo> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 5600))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final k = widget.kind;
    final (emoji, label, sub, amount, start, balLabel) = switch (k) {
      TourDemo.expense => ('🛒', 'Courses', 'Carrefour · à confirmer', -54.20, 1480.0, 'Solde actuel'),
      TourDemo.charge => ('🏠', 'Loyer', 'Prélèvement du mois · à confirmer', -650.0, 1900.0, 'Solde actuel'),
      TourDemo.income => ('💼', 'Salaire', 'Virement attendu · à confirmer', 2100.0, 800.0, 'Solde actuel'),
      _ => ('💶', 'Ligne', 'à confirmer', -50.0, 1000.0, 'Solde actuel'),
    };
    final color = amount < 0 ? AppColors.danger : AppColors.success;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final v = _c.value;
        final checked = v > 0.42 && v < 0.93;
        // doigt : s'approche, touche (0.36–0.46), repart
        final tap = (1 - ((v - 0.40).abs() / 0.10)).clamp(0.0, 1.0).toDouble();
        final approach = Curves.easeOut.transform((v / 0.36).clamp(0.0, 1.0).toDouble());
        final fingerVisible = v < 0.60;
        // solde : bascule entre 0.42 et 0.55 puis redescend à la fin
        final t = checked ? Curves.easeOut.transform(((v - 0.42) / 0.13).clamp(0.0, 1.0).toDouble()) : 0.0;
        final balance = start + amount * t;
        return Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
          decoration: BoxDecoration(
            color: context.fieldColor,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(children: [
            Row(children: [
              Text(emoji, style: const TextStyle(fontSize: 22)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  Text(checked ? sub.replaceAll('à confirmer', 'confirmé') : sub,
                      style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
                ]),
              ),
              Text('${amount < 0 ? '−' : '+'}${eur(amount.abs())}',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: color)),
              const SizedBox(width: 6),
              SizedBox(
                width: 46,
                height: 40,
                child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: checked ? AppColors.teal : Colors.transparent,
                      border: Border.all(color: checked ? AppColors.teal : context.mutedColor, width: 2),
                    ),
                    child: checked ? const Icon(Icons.check_rounded, size: 19, color: Colors.white) : null,
                  ),
                  if (fingerVisible)
                    Positioned(
                      right: -14 - 26 * (1 - approach),
                      bottom: -16 - 10 * (1 - approach) + 4 * tap,
                      child: Transform.scale(
                        scale: 1 - 0.18 * tap,
                        child: Icon(Icons.touch_app_rounded,
                            size: 30, color: context.textColor.withAlpha(220)),
                      ),
                    ),
                ]),
              ),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Text(balLabel, style: TextStyle(color: context.mutedColor, fontSize: 12.5)),
              const Spacer(),
              Text(eur(balance),
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                      color: checked ? color : context.textColor)),
            ]),
          ]),
        );
      },
    );
  }
}
