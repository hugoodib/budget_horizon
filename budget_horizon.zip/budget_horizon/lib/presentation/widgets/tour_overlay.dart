import 'dart:math';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../tour.dart';
import 'common.dart';

const _kAnim = Duration(milliseconds: 380);
const _kCurve = Curves.easeOutCubic;

/// Couche posée au-dessus de toute l'app. Ne s'affiche que quand la démonstration est active.
class TourLayer extends ConsumerWidget {
  const TourLayer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = ref.watch(tourProvider);
    if (!t.active) return const SizedBox.shrink();
    return const _TourOverlay();
  }
}

class _TourOverlay extends ConsumerStatefulWidget {
  const _TourOverlay();
  @override
  ConsumerState<_TourOverlay> createState() => _TourOverlayState();
}

class _TourOverlayState extends ConsumerState<_TourOverlay> {
  int _lastStep = -1;
  int _frames = 0; // nombre d'images pendant lesquelles on suit l'élément (défilement)
  Rect? _rect;

  Rect? _rectOf(GlobalKey? key) {
    final ctx = key?.currentContext;
    if (ctx == null) return null;
    final ro = ctx.findRenderObject();
    if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
    return ro.localToGlobal(Offset.zero) & ro.size; // épouse exactement l'élément
  }

  /// Suit l'élément pendant ~0,6 s (changement d'onglet + défilement animé).
  void _track(GlobalKey? key) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (_frames == 1) {
        final ctx = key?.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(ctx,
              alignment: 0.35, duration: const Duration(milliseconds: 300), curve: _kCurve);
        }
      }
      final r = _rectOf(key);
      if (r != _rect) setState(() => _rect = r);
      if (++_frames < 40) _track(key);
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(tourProvider);
    final steps = ref.watch(tourStepsProvider);
    if (t.step >= steps.length) return const SizedBox.shrink();
    final step = steps[t.step];
    if (t.step != _lastStep) {
      _lastStep = t.step;
      _frames = 0;
      if (step.target == null) {
        _rect = null;
      } else {
        _track(step.target);
      }
    }

    final size = MediaQuery.of(context).size;
    final pad = MediaQuery.of(context).padding;
    final ctl = ref.read(tourProvider.notifier);
    final last = t.step == steps.length - 1;
    final rect = _rect;

    // Sans cible : un « trou » de taille nulle au centre → tout l'écran est flou.
    final holeTarget = rect ?? Rect.fromCenter(center: size.center(Offset.zero), width: 0, height: 0);

    // Position de la bulle : sous l'élément, au-dessus, ou au centre.
    double top, bottom;
    Alignment align;
    if (rect == null) {
      top = pad.top + 16;
      bottom = pad.bottom + 16;
      align = Alignment.center;
    } else if (rect.center.dy < size.height * 0.5) {
      top = min(rect.bottom + 14, size.height - 260);
      bottom = pad.bottom + 16;
      align = Alignment.topCenter;
    } else {
      top = pad.top + 16;
      bottom = max(size.height - rect.top + 14, 0);
      align = Alignment.bottomCenter;
    }

    final buttons = Row(children: [
      if (!last) TextButton(onPressed: ctl.finish, child: const Text('Passer')),
      const Spacer(),
      if (t.step > 0) TextButton(onPressed: ctl.back, child: const Text('Retour')),
      const SizedBox(width: 6),
      SizedBox(width: 128, child: GradientButton(label: last ? 'Terminer' : 'Suivant', onPressed: ctl.next)),
    ]);

    final card = Container(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
      decoration: BoxDecoration(
        color: context.cardColor,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, 8))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
       AnimatedSize(
        duration: _kAnim,
        curve: _kCurve,
        alignment: Alignment.topCenter,
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 220),
          child: Column(
            key: ValueKey(t.step),
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(
                  child: Text(step.title,
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: context.textColor)),
                ),
                Text('${t.step + 1} / ${steps.length}',
                    style: const TextStyle(color: AppColors.muted, fontSize: 12.5, fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 6),
              Text(step.text,
                  style: TextStyle(
                      fontSize: 14.5, height: 1.35, color: context.textColor, fontWeight: FontWeight.w400)),
            ],
          ),
        ),
       ),
       const SizedBox(height: 14),
       buttons,
      ]),
    );

    return Material(
      type: MaterialType.transparency,
      child: Stack(fit: StackFit.expand, children: [
        // Flou animé : il glisse d'un élément à l'autre au lieu de sauter.
        TweenAnimationBuilder<Rect?>(
          tween: RectTween(end: holeTarget),
          duration: _kAnim,
          curve: _kCurve,
          builder: (context, hole, _) => _BlurAround(hole: hole ?? holeTarget, size: size),
        ),
        // Absorbe tous les touchers pendant la démonstration
        Positioned.fill(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: () {})),
        // Bulle d'explication
        AnimatedPositioned(
          duration: _kAnim,
          curve: _kCurve,
          left: 16,
          right: 16,
          top: top,
          bottom: bottom,
          child: AnimatedAlign(
            duration: _kAnim,
            curve: _kCurve,
            alignment: align,
            child: card,
          ),
        ),
      ]),
    );
  }
}

/// Floute et assombrit tout l'écran SAUF l'élément [hole], qui reste net.
/// Un seul flou pour tout l'écran, découpé à la forme exacte de l'encadré (coins arrondis
/// compris) : pas de bandes, donc aucune ligne ni différence de teinte sur les côtés.
class _BlurAround extends StatelessWidget {
  final Rect hole;
  final Size size;
  const _BlurAround({required this.hole, required this.size});

  @override
  Widget build(BuildContext context) {
    // Même arrondi que les cartes de l'app (24), réduit pour les petits éléments.
    final radius = min(24.0, min(hole.width, hole.height) / 2);
    return ClipPath(
      clipper: _HoleClipper(hole, radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 7, sigmaY: 7),
        child: ColoredBox(color: Colors.black.withAlpha(105), child: const SizedBox.expand()),
      ),
    );
  }
}

class _HoleClipper extends CustomClipper<Path> {
  final Rect hole;
  final double radius;
  const _HoleClipper(this.hole, this.radius);

  @override
  Path getClip(Size size) {
    final p = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Offset.zero & size);
    if (hole.width > 1 && hole.height > 1) {
      p.addRRect(RRect.fromRectAndRadius(hole, Radius.circular(radius)));
    }
    return p;
  }

  @override
  bool shouldReclip(_HoleClipper old) => old.hole != hole || old.radius != radius;
}
