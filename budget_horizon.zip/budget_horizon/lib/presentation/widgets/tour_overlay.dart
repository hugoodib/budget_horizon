import 'dart:math';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../tour.dart';
import 'common.dart';

/// Couche posée au-dessus de toute l'app : floute l'écran, met un élément en lumière
/// et affiche une bulle d'explication. Ne s'affiche que quand la démonstration est active.
class TourLayer extends ConsumerWidget {
  const TourLayer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = ref.watch(tourProvider);
    if (!t.active) return const SizedBox.shrink();
    return const _TourOverlay();
  }
}

class _HoleClipper extends CustomClipper<Path> {
  final Rect? hole;
  const _HoleClipper(this.hole);

  @override
  Path getClip(Size size) {
    final full = Path()..addRect(Offset.zero & size);
    if (hole == null) return full;
    final h = Path()..addRRect(RRect.fromRectAndRadius(hole!, const Radius.circular(20)));
    return Path.combine(PathOperation.difference, full, h);
  }

  @override
  bool shouldReclip(_HoleClipper old) => old.hole != hole;
}

class _TourOverlay extends ConsumerStatefulWidget {
  const _TourOverlay();
  @override
  ConsumerState<_TourOverlay> createState() => _TourOverlayState();
}

class _TourOverlayState extends ConsumerState<_TourOverlay> {
  int _lastStep = -1;
  int _tries = 0;

  Rect? _rectOf(GlobalKey? key) {
    final ctx = key?.currentContext;
    if (ctx == null) return null;
    final ro = ctx.findRenderObject();
    if (ro is! RenderBox || !ro.attached || !ro.hasSize) return null;
    return ro.localToGlobal(Offset.zero) & ro.size;
  }

  @override
  Widget build(BuildContext context) {
    final t = ref.watch(tourProvider);
    final steps = ref.watch(tourStepsProvider);
    if (t.step >= steps.length) return const SizedBox.shrink();
    final step = steps[t.step];
    if (t.step != _lastStep) {
      _lastStep = t.step;
      _tries = 0;
    }

    // L'élément visé peut apparaître après le changement d'onglet ou demander un
    // défilement : on réessaie quelques images de suite, puis on s'arrête.
    final key = step.target;
    if (key != null && _tries < 6) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _tries++;
        final ctx = key.currentContext;
        if (ctx != null) {
          Scrollable.ensureVisible(ctx, alignment: 0.35, duration: Duration.zero);
        }
        setState(() {});
      });
    }

    final rect = _rectOf(key)?.inflate(6);
    final size = MediaQuery.of(context).size;
    final ctl = ref.read(tourProvider.notifier);
    final last = t.step == steps.length - 1;

    final card = Container(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 24, offset: Offset(0, 8))],
      ),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Text(step.title,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.text)),
          ),
          Text('${t.step + 1} / ${steps.length}',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 6),
        Text(step.text,
            style: const TextStyle(fontSize: 14.5, height: 1.35, color: AppColors.text, fontWeight: FontWeight.w400)),
        const SizedBox(height: 14),
        Row(children: [
          if (!last)
            TextButton(onPressed: ctl.finish, child: const Text('Passer')),
          const Spacer(),
          if (t.step > 0) TextButton(onPressed: ctl.back, child: const Text('Retour')),
          const SizedBox(width: 6),
          SizedBox(
            width: 128,
            child: GradientButton(label: last ? 'Terminer' : 'Suivant', onPressed: ctl.next),
          ),
        ]),
      ]),
    );

    Widget positioned;
    if (rect == null) {
      positioned = Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: card));
    } else if (rect.center.dy < size.height * 0.5) {
      positioned = Positioned(
        left: 16,
        right: 16,
        top: min(rect.bottom + 14, size.height - 260),
        child: card,
      );
    } else {
      positioned = Positioned(
        left: 16,
        right: 16,
        bottom: min(size.height - rect.top + 14, size.height - 260),
        child: card,
      );
    }

    return Material(
      type: MaterialType.transparency,
      child: Stack(fit: StackFit.expand, children: [
        // Flou + assombrissement, avec un trou sur l'élément mis en lumière
        Positioned.fill(
          child: ClipPath(
            clipper: _HoleClipper(rect),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
              child: Container(color: Colors.black.withAlpha(115)),
            ),
          ),
        ),
        // Absorbe tous les toucher pendant la démonstration
        Positioned.fill(
          child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: () {}),
        ),
        if (rect != null)
          Positioned(
            left: rect.left,
            top: rect.top,
            width: rect.width,
            height: rect.height,
            child: IgnorePointer(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
          ),
        positioned,
      ]),
    );
  }
}
