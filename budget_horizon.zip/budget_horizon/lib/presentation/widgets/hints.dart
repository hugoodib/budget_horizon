import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../providers.dart';
import '../tour.dart';
import 'hint_tutorials.dart';

/// Les gestes expliqués la toute première fois qu'on les utilise (après la visite guidée).
enum Hint {
  // ── Partout ──
  undo('Retour en arrière', 'Tu as fait une erreur ? Cette flèche annule ta dernière modification (dépense, revenu, charge…). Tu peux l\'utiliser plusieurs fois de suite.', Icons.undo_rounded, ''),
  redo('Rétablir', 'Tu as annulé un peu trop ? Cette flèche remet la modification que tu viens d\'annuler.', Icons.redo_rounded, ''),
  check('Pointer une ligne', 'Ce rond sert à confirmer que l\'argent est vraiment passé sur ton compte. Une fois coché, ton solde actuel est mis à jour. Tu peux le décocher en retouchant.', Icons.check_rounded, ''),
  add('Le bouton +', 'Il ouvre la liste de tout ce que tu peux ajouter : dépense, revenu, charge fixe, paiement en plusieurs fois, projet…', Icons.add_rounded, ''),
  assistant('L\'assistant', 'Écris ou dicte une phrase comme « 23 € au McDo » : l\'assistant comprend et prépare la dépense. Tu peux aussi lui poser des questions sur ton budget.', Icons.auto_awesome_rounded, ''),
  settings('Les réglages', 'Ton profil, le mode couple, le solde de départ, les rappels, l\'assistant IA et la visite guidée sont ici.', Icons.tune_rounded, ''),
  month('Changer de mois', 'Touche le calendrier pour sauter directement à n\'importe quel mois, passé ou à venir.', Icons.calendar_month_rounded, ''),
  alerts('Les alertes', 'La cloche te prévient de ce qui demande ton attention : budget dépassé, mois à clôturer, facture à envoyer…', Icons.notifications_outlined, 'La liste des alertes s\'ouvre'),
  // ── Barre du bas ──
  tabForecast('Onglet Prévisions', 'Ici tu regardes l\'avenir : choisis un mois et vois combien il te restera, mois après mois.', Icons.query_stats_rounded, 'Tes prévisions s\'affichent'),
  tabBudgets('Onglet Budgets', 'Toutes tes dépenses du mois, rangées par enveloppe, avec ce qu\'il te reste à dépenser. Pointe-les quand elles passent sur ton compte.', Icons.account_balance_wallet_rounded, 'Tes enveloppes s\'affichent'),
  tabCharges('Onglet Mensuel', 'Tes charges fixes (loyer, abonnements…) et tes revenus qui reviennent chaque mois. Coche chaque ligne quand elle est prélevée ou reçue.', Icons.repeat_rounded, 'Tes charges et revenus s\'affichent'),
  tabClients('Onglet Clients', 'Tes clients avec leur tarif et leur rythme, et tes factures. Hever en déduit ton salaire net chaque mois : tu ne le saisis jamais.', Icons.groups_rounded, 'Tes clients s\'affichent'),
  tabTrips('Onglet Projets', 'Voyage, voiture, apport… indique un montant et une date : Hever calcule combien mettre de côté chaque mois et le retire de ta prévision.', Icons.flag_rounded, 'Tes projets s\'affichent'),
  tabLeaves('Onglet Congés', 'Ton solde de jours, les jours posés et un calendrier pour repérer le mois le plus juste.', Icons.wb_sunny_rounded, 'Tes congés s\'affichent'),
  // ── Accueil ──
  homeBalance('Ton solde', 'Touche le solde pour voir le détail du calcul, ligne par ligne : de quoi il se compose et ce qui reste à passer.', Icons.account_balance_wallet_outlined, 'Le détail du calcul s\'ouvre'),
  homeEarn('Ce que tu gagnes', 'Cette carte résume les revenus du mois. En la touchant, tu ouvres la liste pour les modifier ou les pointer.', Icons.trending_up_rounded, 'La liste des revenus s\'ouvre'),
  homeFixed('Tes charges fixes', 'Cette carte résume ce qui sort chaque mois (loyer, abonnements…). En la touchant, tu ouvres la liste pour les modifier ou les pointer.', Icons.home_outlined, 'La liste des charges s\'ouvre'),
  homeBudgets('Tes enveloppes', 'Touche la carte pour aller dans Budgets et voir chaque dépense, enveloppe par enveloppe.', Icons.shopping_basket_outlined, 'L\'onglet Budgets s\'ouvre'),
  homeUnexpected('Les imprévus', 'Un coup dur (panne, amende…) est rangé ici, à part, pour ne pas fausser tes enveloppes habituelles. Touche pour voir le détail.', Icons.bolt_rounded, 'Le détail des imprévus s\'ouvre'),
  // ── Prévisions ──
  forecastMonth('Choisir un mois', 'Touche un mois, ou utilise les flèches, pour voir ce qu\'il te restera à ce moment-là. Pratique pour planifier un achat ou un voyage.', Icons.chevron_right_rounded, 'Le mois choisi s\'affiche'),
  forecastHorizon('Durée affichée', 'Choisis combien de mois afficher : quelques mois pour le court terme, ou plusieurs années pour voir loin.', Icons.date_range_rounded, 'Le graphique s\'adapte'),
  forecastTop('Épingler ce mois', 'Le mois choisi passe tout en haut de la page pour le garder sous les yeux pendant que tu fais défiler.', Icons.push_pin_outlined, 'Le mois monte en haut'),
  forecastIncome('Revenu à venir', 'Ajoute un revenu exceptionnel pour ce mois (prime, remboursement…) : la prévision se met à jour tout de suite.', Icons.add_card_rounded, 'La prévision se met à jour'),
  // ── Budgets ──
  budgetsAdd('Ajouter dans Budgets', 'Ce bouton ajoute une dépense, ou une nouvelle enveloppe, directement depuis cet onglet.', Icons.add_rounded, 'Le formulaire s\'ouvre'),
  budgetsSort('Trier les dépenses', 'Change l\'ordre de la liste : par date, par montant, par enveloppe…', Icons.sort_rounded, 'La liste est réordonnée'),
  budgetsTx('Ouvrir une dépense', 'Touche une ligne pour la modifier, la changer d\'enveloppe ou la supprimer. Le rond à droite sert à la pointer.', Icons.receipt_long_outlined, 'La dépense s\'ouvre'),
  closeMonth('Fin du mois', 'Hever liste ce qui n\'est pas pointé et te propose de le reporter au mois suivant. À faire quand le mois est terminé.', Icons.event_available_rounded, 'La liste à vérifier s\'affiche'),
  installment('Paiement en plusieurs fois', 'Quand une mensualité arrive, Hever te demande avant de l\'ajouter au budget du mois : tu peux la confirmer (et préciser le détail) ou la passer.', Icons.credit_score_rounded, 'La mensualité est ajoutée au budget'),
  // ── Mensuel ──
  chargesAdd('Ajouter une charge ou un revenu', 'Crée une ligne qui revient : montant, rythme (chaque mois, tous les 3 mois…), début et fin éventuels.', Icons.add_rounded, 'Le formulaire s\'ouvre'),
  chargesSort('Trier les charges', 'Change l\'ordre de la liste : par montant, par nom ou par date de prélèvement.', Icons.sort_rounded, 'La liste est réordonnée'),
  chargesRow('Ouvrir une ligne', 'Touche une charge ou un revenu pour le modifier, changer son rythme, ou l\'arrêter à une date précise.', Icons.edit_outlined, 'La fiche s\'ouvre'),
  // ── Clients / factures ──
  clientsSwitch('Clients ou Factures', 'Bascule entre la liste de tes clients et les factures du mois à envoyer et à encaisser.', Icons.swap_horiz_rounded, 'L\'affichage change'),
  clientsAdd('Ajouter un client', 'Nom, tarif d\'un passage, durée et fréquence (certains jours, par semaine, par mois…). Hever calcule le reste.', Icons.person_add_alt_rounded, 'Le formulaire s\'ouvre'),
  clientsRow('Ouvrir un client', 'Touche un client pour modifier son tarif, son rythme, ou arrêter la collaboration à une date.', Icons.person_outline_rounded, 'La fiche s\'ouvre'),
  invoiceRow('Une facture', 'Chaque mois, une facture par client. Touche-la pour la marquer « envoyée » puis « payée », ou corriger le montant (passage manqué…).', Icons.description_outlined, 'La facture s\'ouvre'),
  // ── Projets ──
  projectCard('Ouvrir un projet', 'Touche un projet pour voir où il en est, ajouter une dépense ou modifier le montant et la date.', Icons.flag_outlined, 'Le projet s\'ouvre'),
  projectDeposit('Versement du mois', 'Quand tu as réellement mis l\'argent de côté ce mois-ci, marque-le : le projet avance et ton solde est ajusté.', Icons.savings_outlined, 'Le versement est marqué'),
  projectExpense('Dépense du projet', 'Note ici ce que tu paies pour ce projet (billets, hôtel…) : elle est déduite de la somme prévue.', Icons.add_shopping_cart_rounded, 'La dépense est ajoutée'),
  // ── Analyses / congés ──
  analysisPills('Changer la période', 'Choisis la période (mois, année…) pour comparer tes dépenses et tes revenus.', Icons.insights_rounded, 'Les chiffres se mettent à jour'),
  leaveHorizon('Horizon des congés', 'Choisis sur combien de mois afficher le calendrier : 12 mois, 2 ans ou plus.', Icons.date_range_rounded, 'Le calendrier s\'adapte'),
  leaveAdd('Ajouter des congés', 'Pose des jours sur le calendrier : le solde de chaque type de congé est recalculé.', Icons.event_available_outlined, 'Le formulaire s\'ouvre'),
  // ── Infos « i » des formulaires (explication seule, sans animation) ──
  formExpense('Ajouter une dépense', 'Montant : ce que tu as payé.\n\nEnveloppe : la catégorie à laquelle ça se rattache (Courses, Essence…).\n\nNote : facultative, pour t\'en souvenir.\n\nVu sur mon compte : active-le si la dépense est déjà passée sur ton relevé bancaire.\n\nPour : en couple, à qui appartient la dépense.', Icons.info_outline_rounded, ''),
  formCategory('Une enveloppe de dépenses', 'Nom : par exemple Courses ou Loisirs.\n\nMontant : la somme maximale que tu veux dépenser par mois dans cette enveloppe. Le vert montre ce qu\'il te reste, le rouge un dépassement.\n\nChaque dépense que tu notes ensuite se range dans une enveloppe.', Icons.info_outline_rounded, ''),
  formUnexpected('Un imprévu', 'Un coup dur (panne, amende, réparation…). Il est compté dans ta prévision mais rangé à part, pour ne pas fausser tes enveloppes habituelles.', Icons.info_outline_rounded, ''),
  formIncome('Un revenu', 'Nom : salaire, prime, remboursement…\n\nMontant : ce que tu reçois.\n\nRythme : chaque mois, ou une seule fois pour un revenu exceptionnel.\n\nDéjà reçu : active-le si l\'argent est déjà sur ton compte.', Icons.info_outline_rounded, ''),
  formCharge('Une charge fixe', 'Nom : loyer, assurance, abonnement…\n\nMontant : ce qui est prélevé.\n\nRythme : chaque mois, tous les 3 mois, une fois par an…\n\nDébut / fin : une charge peut commencer plus tard et s\'arrêter à un mois précis (fin d\'un crédit).\n\nDéjà prélevée : active-le si c\'est déjà sorti de ton compte ce mois-ci.', Icons.info_outline_rounded, ''),
  formProject('Un projet', 'Type : Voyage (avec dates et dépenses) ou autre projet.\n\nNom : ce que tu prépares.\n\nMontant : la somme totale à prévoir.\n\nMois cible : quand tu en as besoin. Hever en déduit ce qu\'il faut mettre de côté chaque mois et le retire de ta prévision.', Icons.info_outline_rounded, ''),
  formClient('Un client', 'Nom : le client.\n\nMontant d\'un passage : ce que tu factures à chaque visite.\n\nDurée : le temps d\'un passage.\n\nFréquence : certains jours de la semaine, X fois par semaine ou par mois, ou tous les N mois.\n\nActif depuis : le premier mois où tu le factures.', Icons.info_outline_rounded, ''),
  formInvoice('Une facture', 'Chaque mois, une facture par client est calculée à partir de ses passages. Ici tu peux corriger le montant (passage manqué…), la marquer « envoyée » puis « payée ». Une facture payée compte dans ton solde.', Icons.info_outline_rounded, ''),
  formInstallment('Paiement en plusieurs fois', 'Nom et montant total, nombre d\'échéances, premier mois et enveloppe concernée. Quand une échéance arrive, Hever te demande avant de l\'ajouter au budget du mois : tu peux préciser le détail (débit différé…) ou la passer.', Icons.info_outline_rounded, ''),
  formTripDates('Dates du voyage', 'Choisis le départ et le retour. Hever en déduit le mois à prévoir et, si tu es auto-entrepreneur, les passages que tu n\'auras pas faits pendant ton absence.', Icons.info_outline_rounded, ''),
  formLeave('Poser des congés', 'Choisis le type de congé et les jours. Le solde de chaque catégorie est recalculé, et tu vois s\'il te reste assez de jours.', Icons.info_outline_rounded, ''),
  fieldChecked('Vu sur mon compte', 'À activer quand la dépense est déjà sortie de ton compte (tu la vois sur ton relevé). Elle est alors comptée dans ton solde actuel. Sinon elle reste « à confirmer » et tu la cocheras plus tard.', Icons.info_outline_rounded, ''),
  fieldPerson('Pour qui ?', 'En couple, choisis à qui appartient la dépense : à toi, à ton conjoint, ou aux deux (budget commun).', Icons.info_outline_rounded, ''),
  fieldProjectType('Voyage ou autre projet', 'Voyage : tu indiques les dates de départ et de retour, tu peux noter les dépenses du voyage, et si tu es auto-entrepreneur Hever retire les passages clients que tu n\'auras pas faits.\n\nAutre projet : un achat ou un objectif (voiture, apport…), avec seulement un montant et un mois cible.', Icons.info_outline_rounded, ''),
  fieldPayOnSite('Payer sur place', 'Tu ne mets rien de côté avant. Le budget du voyage est réservé d\'un coup le mois du voyage et déduit de ta prévision ce mois-là.\n\nLes mois d\'avant ne changent pas. Pratique si tu paies sur place pendant le séjour, ou si tu as déjà assez de marge ce mois-là.', Icons.info_outline_rounded, ''),
  fieldPayCash('Payer d\'un coup', 'Le montant total est déduit de ton solde en une seule fois, le mois cible. Les mois d\'avant ne changent pas.', Icons.info_outline_rounded, ''),
  fieldSave('Épargner avant', 'Hever répartit le montant sur les mois qui restent avant la date cible et retire cette somme chaque mois de ta prévision. Tu mets vraiment l\'argent de côté, et tu marques le versement chaque mois.\n\nL\'objectif doit être dans un mois futur.', Icons.info_outline_rounded, ''),
  fieldWho('Qui part ?', 'En couple avec une auto-entreprise : choisis qui part. Seuls les passages clients de cette personne sont retirés pendant le voyage ; « Les deux » retire ceux des deux.', Icons.info_outline_rounded, ''),
  fieldRecurring('Ponctuel ou récurrent', 'Ponctuel : un montant qui ne compte qu\'une fois, le mois choisi (prime, remboursement).\n\nRécurrent : il revient automatiquement selon le rythme choisi (chaque mois, tous les 3 mois…).', Icons.info_outline_rounded, ''),
  fieldFrequency('Fréquence', 'Chaque mois, ou un rythme plus espacé : tous les 2, 3, 6 mois ou une fois par an. Le premier mois sert de repère pour calculer les suivants.', Icons.info_outline_rounded, ''),
  fieldReceived('Déjà reçu', 'À activer si l\'argent est déjà arrivé sur ton compte : il est pointé tout de suite et compte dans ton solde actuel. Sinon il reste « attendu » jusqu\'à ce que tu le coches.', Icons.info_outline_rounded, ''),
  fieldDebited('Déjà prélevée', 'À activer si la charge est déjà sortie de ton compte ce mois-ci : elle est pointée tout de suite. Sinon elle reste « à venir » jusqu\'à ce que tu la coches.', Icons.info_outline_rounded, ''),
  fieldScope('Pour toujours ou ce mois seulement', 'Pour toujours : le montant change à partir de ce mois et pour tous les mois suivants.\n\nCe mois seulement : une exception pour un seul mois, les autres gardent le montant habituel.', Icons.info_outline_rounded, ''),
  fieldPerPerson('Un budget par personne', 'Désactivé : une seule enveloppe commune aux deux.\n\nActivé : chacun a sa propre enveloppe avec son montant (utile pour les loisirs, par exemple).', Icons.info_outline_rounded, ''),
  fieldDeferred('Date de débit', 'Certaines dépenses (carte à débit différé) ne sortent du compte que plus tard. Choisis la date réelle de débit : la dépense compte dans ton solde à ce moment-là, mais reste dans l\'enveloppe du mois où tu l\'as faite.', Icons.info_outline_rounded, ''),
  fieldVisitPrice('Montant d\'un passage', 'Ce que tu factures à chaque visite chez ce client (brut, avant charges URSSAF). Hever le multiplie par le nombre de passages du mois.', Icons.info_outline_rounded, ''),
  fieldDuration('Durée', 'Le temps d\'un passage, en minutes. Il sert à calculer tes heures travaillées.', Icons.info_outline_rounded, ''),
  fieldClientFreq('Fréquence des passages', 'Certains jours : par exemple tous les lundis et jeudis.\nPar semaine / par mois : un nombre de passages, sans jour fixe.\nTous les N mois : un client occasionnel.\n1 fois par an : une facture annuelle.', Icons.info_outline_rounded, ''),
  fieldMissed('Passages manqués', 'Si tu n\'as pas pu faire un passage (absence, annulation), indique-le : le montant d\'un passage est retiré de la facture du mois.', Icons.info_outline_rounded, ''),
  fieldVisitCount('Nombre de passages', 'Modifie le nombre de passages facturés : le montant se recalcule tout seul (et inversement).', Icons.info_outline_rounded, ''),
  fieldInvoiceAmount('Montant de la facture', 'Le montant brut facturé ce mois-ci. Tu peux le corriger à la main ; tu pourras revenir au calcul automatique.', Icons.info_outline_rounded, ''),
  fieldGross('Montant brut', 'Le montant facturé avant charges URSSAF. Hever en déduit ton net automatiquement.', Icons.info_outline_rounded, ''),
  fieldPaid('Déjà payée', 'À activer si le client a déjà payé : la facture est pointée et l\'argent compte dans ton solde actuel.', Icons.info_outline_rounded, ''),
  fieldInstallTotal('Montant total à payer', 'La somme totale de l\'achat. Hever la divise en échéances égales.', Icons.info_outline_rounded, ''),
  fieldInstallCount('Échéances', 'Nombre de fois, première échéance et jour du mois : à chaque échéance, Hever te demande avant d\'ajouter la mensualité au budget choisi.', Icons.info_outline_rounded, ''),
  fieldInstallBudget('Dans quel budget ?', 'L\'enveloppe dans laquelle chaque mensualité sera rangée. Choisis « Imprévu » si elle ne correspond à aucune enveloppe habituelle.', Icons.info_outline_rounded, ''),
  fieldDayRule('Règle de jour', 'Quand l\'argent arrive ou part : un jour fixe du mois, le dernier jour ouvré, ou aucune règle. Hever en tient compte pour savoir à quel moment du mois le solde bouge.', Icons.info_outline_rounded, ''),
  fieldStart('Début', 'Le premier mois concerné. Avant, rien n\'est compté ; à partir de ce mois, c\'est inclus dans la prévision.', Icons.info_outline_rounded, ''),
  screenInvoices('Onglet Factures', 'Chaque mois, une facture par client. Touche-la pour la marquer « envoyée » puis « payée ». Les impayés sont reportés au mois suivant et signalés en retard.', Icons.description_rounded, ''),
  screenAnalysis('Analyse', 'Compare tes revenus et tes dépenses sur la période de ton choix, enveloppe par enveloppe, pour voir où part ton argent.', Icons.insights_rounded, ''),
  screenFixes('Revenus du mois', 'Salaire, primes, aides… Les revenus réguliers reviennent chaque mois, les ponctuels ne comptent qu\'une fois. Coche chaque revenu quand il arrive sur ton compte.', Icons.payments_outlined, '');

  final String title;
  final String text;
  final IconData icon;
  final String effect; // résultat montré après le toucher (vide = scène dédiée)
  const Hint(this.title, this.text, this.icon, this.effect);
}

class HintsController extends StateNotifier<Set<String>> {
  final Ref _ref;
  HintsController(this._ref) : super(const {}) {
    final raw = _ref.read(repositoryProvider).readMeta('hints_seen') ?? '';
    state = raw.isEmpty ? <String>{} : raw.split(',').toSet();
  }

  /// « Revoir les explications » : tout redevient inédit.
  void reset() {
    state = <String>{};
    _ref.read(repositoryProvider).writeMeta('hints_seen', '');
  }

  void markSeen(Hint h) {
    if (state.contains(h.name)) return;
    state = {...state, h.name};
    _ref.read(repositoryProvider).writeMeta('hints_seen', state.join(','));
  }
}

/// Titre d'écran ou de formulaire → explication « i » correspondante (null = pas d'info).
Hint? infoForTitle(String t) {
  bool a(String p) => t.startsWith(p);
  if (t == 'Budgets') return Hint.tabBudgets;
  if (t == 'Mensuel') return Hint.tabCharges;
  if (t == 'Fixes') return Hint.screenFixes;
  if (t == 'Clients') return Hint.tabClients;
  if (t == 'Factures') return Hint.screenInvoices;
  if (t == 'Projets') return Hint.tabTrips;
  if (t == 'Prévisions') return Hint.tabForecast;
  if (t == 'Congés') return Hint.tabLeaves;
  if (t == 'Analyse') return Hint.screenAnalysis;
  if (a('Nouvelle dépense') || a('Modifier la dépense') || a('Dépense ·')) return Hint.formExpense;
  if (a('Nouvelle catégorie') || a('Modifier le budget') || a('Créer une enveloppe')) return Hint.formCategory;
  if (a('Nouvel imprévu')) return Hint.formUnexpected;
  if (a('Nouveau revenu')) return Hint.formIncome;
  if (a('Nouvelle charge')) return Hint.formCharge;
  if (a('Nouveau projet')) return Hint.formProject;
  if (a('Nouveau client')) return Hint.formClient;
  if (a('Nouvelle facture') || a('Émettre une facture') || a('Une facture')) return Hint.formInvoice;
  if (a('Paiement en plusieurs fois') || a('Modifier le paiement') || a('Échéance')) return Hint.formInstallment;
  if (a('Dates du voyage')) return Hint.formTripDates;
  if (a('Congés ·')) return Hint.formLeave;
  if (t == 'Assistant') return Hint.assistant;
  return null;
}

/// Petit « i » discret : touche pour lire l'explication (sans la marquer comme déjà vue).
class InfoButton extends StatelessWidget {
  final Hint hint;
  final double size;
  const InfoButton(this.hint, {super.key, this.size = 17});

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => showHintInfo(context, hint),
        child: Padding(
          padding: const EdgeInsets.all(7),
          child: Icon(Icons.info_outline_rounded, size: size, color: AppColors.violet.withAlpha(170)),
        ),
      );
}

/// Affiche l'explication à la demande (bouton « i »).
Future<void> showHintInfo(BuildContext context, Hint h) => _present(context, h);

/// Texte + petit « i » sur la même ligne.
Widget labelWithInfo(String text, Hint h, {TextStyle? style}) => Row(mainAxisSize: MainAxisSize.min, children: [
      Flexible(child: Text(text, style: style)),
      InfoButton(h, size: 15),
    ]);

/// Élément (sélecteur, bouton…) suivi d'un « i » à droite.
Widget withInfo(Widget child, Hint h) => Row(children: [Expanded(child: child), InfoButton(h, size: 15)]);

/// « i » posé dans le coin d'un champ de saisie.
class FieldInfo extends StatelessWidget {
  final Hint hint;
  final Widget child;
  const FieldInfo(this.hint, {super.key, required this.child});

  @override
  Widget build(BuildContext context) => Stack(clipBehavior: Clip.none, children: [
        child,
        Positioned(top: -3, right: -6, child: InfoButton(hint, size: 14)),
      ]);
}

final hintsProvider =
    StateNotifierProvider<HintsController, Set<String>>((ref) => HintsController(ref));

/// Exécute [action] ; si c'est la première fois que ce geste est utilisé (et que la visite
/// guidée est passée), une petite explication animée s'affiche d'abord.
Future<void> runWithHint(BuildContext context, Hint h, VoidCallback action) async {
  final c = ProviderScope.containerOf(context);
  final show = c.read(appProvider).user.tourSeen &&
      !c.read(tourProvider).active &&
      !c.read(hintsProvider).contains(h.name);
  if (!show) {
    action();
    return;
  }
  c.read(hintsProvider.notifier).markSeen(h);
  await _present(context, h);
  action();
}

Future<void> _present(BuildContext context, Hint h) {
  return showGeneralDialog<void>(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'Explication',
    barrierColor: Colors.black.withAlpha(90),
    transitionDuration: const Duration(milliseconds: 280),
    pageBuilder: (ctx, _, __) => _HintCard(hint: h),
    transitionBuilder: (ctx, anim, _, child) => BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 5 * anim.value, sigmaY: 5 * anim.value),
      child: FadeTransition(
        opacity: anim,
        child: ScaleTransition(
            scale: Tween(begin: .92, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutBack)),
            child: child),
      ),
    ),
  );
}

class _HintCard extends StatefulWidget {
  final Hint hint;
  const _HintCard({required this.hint});
  @override
  State<_HintCard> createState() => _HintCardState();
}

class _HintCardState extends State<_HintCard> with SingleTickerProviderStateMixin {
  int _page = 0;
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 6200))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hint = widget.hint;
    final pages = hintTutorials[hint];
    final last = pages == null || _page >= pages.length - 1;
    final title = pages == null ? hint.title : pages[_page].title;
    final text = pages == null ? hint.text : pages[_page].text;
    return Material(
      type: MaterialType.transparency,
      child: Center(
        child: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 22, vertical: 24),
            constraints: const BoxConstraints(maxWidth: 440),
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
            decoration: BoxDecoration(
              color: context.isDark ? const Color(0xFF232948) : Colors.white,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: context.isDark ? Colors.white.withAlpha(40) : Colors.black.withAlpha(18)),
              boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 28, offset: Offset(0, 10))],
            ),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(
                  child: Text(pages == null ? 'Explication' : '${hint.title} · explication',
                      style: TextStyle(color: context.mutedColor, fontSize: 12, fontWeight: FontWeight.w700)),
                ),
                if (pages != null)
                  Text('${_page + 1} / ${pages.length}',
                      style: TextStyle(color: context.mutedColor, fontSize: 12, fontWeight: FontWeight.w700)),
              ]),
              const SizedBox(height: 2),
              AnimatedSize(
                duration: const Duration(milliseconds: 220),
                alignment: Alignment.topCenter,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  child: Column(
                    key: ValueKey(_page),
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: context.textColor)),
                      const SizedBox(height: 6),
                      Text(text, style: TextStyle(fontSize: 14.5, height: 1.42, color: context.textColor)),
                      const SizedBox(height: 14),
                      if (pages == null)
                        (hint.name.startsWith('form') || hint.name.startsWith('field') || hint.name.startsWith('screen'))
                            ? const SizedBox.shrink()
                            : _HintAnim(hint: hint)
                      else
                        AnimatedBuilder(animation: _c, builder: (ctx, _) => pages[_page].scene(ctx, _c.value)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(children: [
                if (pages != null && !last)
                  TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Passer')),
                if (pages != null && _page > 0)
                  TextButton(onPressed: () => setState(() => _page--), child: const Text('Retour')),
                const Spacer(),
                FilledButton(
                  onPressed: () => last ? Navigator.of(context).pop() : setState(() => _page++),
                  style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  child: Text(last ? 'Compris' : 'Suivant', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5)),
                ),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Mini scène animée : le doigt touche le bouton, et on voit l'effet.
class _HintAnim extends StatefulWidget {
  final Hint hint;
  const _HintAnim({required this.hint});
  @override
  State<_HintAnim> createState() => _HintAnimState();
}

class _HintAnimState extends State<_HintAnim> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3400))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  IconData get _icon => widget.hint.icon;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final v = _c.value;
        // le doigt touche vers 0.35–0.45
        final tap = (1 - ((v - 0.40).abs() / 0.09)).clamp(0.0, 1.0).toDouble();
        final after = v > 0.42 && v < 0.92; // « effet » visible
        final approach = Curves.easeOut.transform((v / 0.36).clamp(0.0, 1.0).toDouble());
        final accent = AppColors.violet;

        final button = SizedBox(
          width: 64,
          height: 64,
          child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
            if (tap > 0)
              Container(
                width: 46 + 22 * tap,
                height: 46 + 22 * tap,
                decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withAlpha((70 * tap).round())),
              ),
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.hint == Hint.check
                    ? (after ? AppColors.success : context.fieldColor)
                    : context.fieldColor,
                border: Border.all(color: accent.withAlpha(120), width: 1.5),
              ),
              child: Icon(_icon,
                  size: 24,
                  color: widget.hint == Hint.check && after ? Colors.white : context.textColor),
            ),
            if (v < 0.62)
              Positioned(
                right: -8 - 22 * (1 - approach),
                bottom: -10 - 12 * (1 - approach) + 4 * tap,
                child: Transform.scale(
                  scale: 1 - 0.16 * tap,
                  child: Icon(Icons.touch_app_rounded, size: 30, color: context.textColor.withAlpha(220)),
                ),
              ),
          ]),
        );

        return Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: context.fieldColor.withAlpha(150), borderRadius: BorderRadius.circular(16)),
          child: Row(children: [
            button,
            const SizedBox(width: 12),
            Expanded(child: _effect(context, after, v)),
          ]),
        );
      },
    );
  }

  Widget _row(BuildContext context, String emoji, String label, String amount, {double opacity = 1, Color? color}) =>
      Opacity(
        opacity: opacity,
        child: Row(children: [
          Text(emoji, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 8),
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5))),
          Text(amount, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5, color: color ?? AppColors.danger)),
        ]),
      );

  Widget _effect(BuildContext context, bool after, double v) {
    switch (widget.hint) {
      case Hint.undo:
        return _row(context, '🛒', 'Courses', '−54,20 €', opacity: after ? 0.12 : 1);
      case Hint.redo:
        return _row(context, '🛒', 'Courses', '−54,20 €', opacity: after ? 1 : 0.12);
      case Hint.check:
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(after ? 'Loyer · confirmé' : 'Loyer · à confirmer',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
          const SizedBox(height: 2),
          Text(after ? 'Solde actuel : 1 250 €' : 'Solde actuel : 1 900 €',
              style: TextStyle(fontSize: 12.5, color: after ? AppColors.success : context.mutedColor, fontWeight: FontWeight.w600)),
        ]);
      case Hint.add:
        return Wrap(spacing: 6, runSpacing: 6, children: [
          for (var i = 0; i < 4; i++)
            Opacity(
              opacity: after ? ((v - 0.44 - i * 0.05) / 0.1).clamp(0.0, 1.0).toDouble() : 0.0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: AppColors.violet.withAlpha(30), borderRadius: BorderRadius.circular(12)),
                child: Text(const ['Dépense', 'Revenu', 'Charge fixe', 'Projet'][i],
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              ),
            ),
        ]);
      case Hint.assistant:
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(after ? '« 23 € au McDo »' : '…', style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 13)),
          const SizedBox(height: 4),
          _row(context, '🍕', 'Restaurants', '−23 €', opacity: v > 0.62 && v < 0.92 ? 1 : 0.0),
        ]);
      case Hint.settings:
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (var i = 0; i < 3; i++)
            Opacity(
              opacity: after ? ((v - 0.44 - i * 0.06) / 0.1).clamp(0.0, 1.0).toDouble() : 0.0,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Text(const ['Profil et couple', 'Rappels', 'Assistant IA'][i],
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              ),
            ),
        ]);
      case Hint.month:
        final months = const ['Octobre', 'Novembre', 'Décembre'];
        final i = !after ? 0 : (v < 0.65 ? 1 : 2);
        return Text(months[i], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800));
      default:
        return Opacity(
          opacity: after ? ((v - 0.44) / 0.1).clamp(0.0, 1.0).toDouble() : 0.0,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(color: AppColors.violet.withAlpha(30), borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              const Icon(Icons.arrow_forward_rounded, size: 16, color: AppColors.violet),
              const SizedBox(width: 8),
              Expanded(child: Text(widget.hint.effect, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700))),
            ]),
          ),
        );
    }
  }
}
