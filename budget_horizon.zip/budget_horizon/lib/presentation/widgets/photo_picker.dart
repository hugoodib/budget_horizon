import 'dart:convert';
import 'package:image_picker/image_picker.dart';

/// Choisit une photo dans la galerie, la réduit (256 px) et la renvoie en base64.
Future<String?> pickProfilePhoto() async {
  try {
    final f = await ImagePicker()
        .pickImage(source: ImageSource.gallery, maxWidth: 256, maxHeight: 256, imageQuality: 75);
    if (f == null) return null;
    return base64Encode(await f.readAsBytes());
  } catch (_) {
    return null;
  }
}
