import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:image_picker/image_picker.dart';
import '../../core/theme.dart';

/// Choisit une photo dans la galerie, laisse l'utilisateur la recadrer
/// (déplacer + zoomer dans un cercle), puis la renvoie en base64 (256 px).
Future<String?> pickProfilePhoto(BuildContext context) async {
  try {
    final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200, maxHeight: 1200, imageQuality: 90);
    if (f == null) return null;
    final bytes = await f.readAsBytes();
    if (!context.mounted) return null;
    return await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _CropDialog(bytes: bytes),
    );
  } catch (_) {
    return null;
  }
}

class _CropDialog extends StatefulWidget {
  final Uint8List bytes;
  const _CropDialog({required this.bytes});
  @override
  State<_CropDialog> createState() => _CropDialogState();
}

class _CropDialogState extends State<_CropDialog> {
  static const _box = 280.0; // taille de la zone de recadrage à l'écran
  final _key = GlobalKey();
  bool _saving = false;

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      final ro = _key.currentContext!.findRenderObject() as RenderRepaintBoundary;
      final img = await ro.toImage(pixelRatio: 256 / _box);
      final data = await img.toByteData(format: ui.ImageByteFormat.png);
      if (!mounted) return;
      Navigator.pop(context, data == null ? null : base64Encode(data.buffer.asUint8List()));
    } catch (_) {
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        title: const Text('Recadrer la photo'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Déplacez et pincez pour zoomer.',
              style: TextStyle(color: AppColors.muted, fontSize: 13)),
          const SizedBox(height: 12),
          SizedBox(
            width: _box,
            height: _box,
            child: Stack(children: [
              // Zone capturée : exactement ce qu'on voit dans le carré
              RepaintBoundary(
                key: _key,
                child: ClipRect(
                  child: SizedBox(
                    width: _box,
                    height: _box,
                    child: InteractiveViewer(
                      minScale: 1,
                      maxScale: 5,
                      boundaryMargin: const EdgeInsets.all(double.infinity),
                      constrained: false,
                      child: Image.memory(widget.bytes, fit: BoxFit.cover, width: _box, height: _box),
                    ),
                  ),
                ),
              ),
              // Masque rond (aperçu du rendu final)
              const IgnorePointer(child: CustomPaint(size: Size(_box, _box), painter: _CircleMask())),
            ]),
          ),
        ]),
        actions: [
          TextButton(onPressed: _saving ? null : () => Navigator.pop(context), child: const Text('Annuler')),
          FilledButton(onPressed: _saving ? null : _save, child: const Text('Valider')),
        ],
      );
}

class _CircleMask extends CustomPainter {
  const _CircleMask();
  @override
  void paint(Canvas canvas, Size size) {
    final r = Offset.zero & size;
    final path = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(r)
      ..addOval(r.deflate(2));
    canvas.drawPath(path, Paint()..color = Colors.white.withAlpha(170));
    canvas.drawOval(r.deflate(2), Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = Colors.white);
  }

  @override
  bool shouldRepaint(_CircleMask old) => false;
}
