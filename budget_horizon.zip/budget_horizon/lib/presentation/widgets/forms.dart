import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';

// ---------------- Ligne Annuler + Enregistrer (réutilisable) ----------------
class _CancelSaveRow extends StatelessWidget {
  final String saveLabel;
  final VoidCallback onSave;
  const _CancelSaveRow({required this.saveLabel, required this.onSave});

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
          flex: 2,
          child: SizedBox(
            height: 50,
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(
                foregroundColor: context.mutedColor,
                backgroundColor: context.fieldColor,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 3,
          child: GradientButton(label: saveLabel, onPressed: onSave),
        ),
      ]);
}

// ---------------- Icône + couleur d'une catégorie ----------------
const kEmojiChoices = [
  '🥕', '🛒', '🍕', '🍔', '☕', '🍷', '⛽', '🚗', '🚌', '✈️',
  '🏠', '💡', '📱', '🎮', '🎬', '🎉', '🏋️', '💊', '🧴', '👗',
  '🛍️', '🎁', '🐶', '🐱', '👶', '📚', '🎓', '💇', '💄', '🧾',
  '🏖️', '🍿', '🎵', '🧹', '🔧', '🌿', '💰', '🥂', '🚴', '🎨',
];

/// Garde uniquement le dernier emoji saisi (un seul caractère « visuel »).
class _OneEmojiFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final chars = newValue.text.characters;
    if (chars.isEmpty) return newValue;
    final last = chars.last;
    return TextEditingValue(text: last, selection: TextSelection.collapsed(offset: last.length));
  }
}

/// Un rond de couleur avec son label de catégorie en dessous.
class _PaletteItem extends StatelessWidget {
  final Color color;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _PaletteItem({required this.color, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: selected ? context.textColor : Colors.transparent, width: 2.5),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 9,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? context.textColor : context.mutedColor,
            ),
            textAlign: TextAlign.center,
          ),
        ]),
      );
}

/// Choix d'un emoji (grille + clavier emoji complet de l'iPhone) et d'une couleur vive.
class StylePicker extends StatelessWidget {
  final String emoji;
  final int color;
  final ValueChanged<String> onEmoji;
  final ValueChanged<int> onColor;
  final bool showEmoji; // faux : couleur seule (logo « première lettre »)
  final String previewLetter;
  const StylePicker({
    super.key,
    required this.emoji,
    required this.color,
    required this.onEmoji,
    required this.onColor,
    this.showEmoji = true,
    this.previewLetter = '?',
  });

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          showEmoji
              ? CircleEmoji(emoji.isEmpty ? '💰' : emoji, Color(color), size: 48)
              : CircleEmoji(previewLetter, Color(color), size: 48, letter: true),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
                showEmoji
                    ? 'Icône + couleur reconnaissables au premier coup d\'œil.'
                    : 'Choisissez une couleur.',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          ),
        ]),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (var i = 0; i < AppColors.palette.length; i++)
              _PaletteItem(
                color: AppColors.palette[i],
                label: AppColors.paletteLabels[i],
                selected: AppColors.palette[i].value == color,
                onTap: () => onColor(AppColors.palette[i].value),
              ),
          ],
        ),
        if (showEmoji) ...[
        const SizedBox(height: 12),
        TextField(
          inputFormatters: [_OneEmojiFormatter()],
          decoration: const InputDecoration(
            labelText: 'Autre emoji — touche 🌐 sur le clavier',
          ),
          onChanged: (v) {
            final t = v.trim();
            if (t.isNotEmpty) onEmoji(t.characters.last);
          },
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final e in kEmojiChoices)
            GestureDetector(
              onTap: () => onEmoji(e),
              child: Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: e == emoji ? tint(Color(color), .22) : context.fieldColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: e == emoji ? Color(color) : Colors.transparent, width: 2),
                ),
                child: Text(e, style: const TextStyle(fontSize: 22)),
              ),
            ),
        ]),
        ],
      ]);
}

// ---------------- Ajouter une dépense ----------------
/// Une dépense va dans une enveloppe (catégorie), dans les « imprévus » (compteur qui baisse
/// directement l'estimation) ou dans le budget d'un voyage.

/// Mots-clés → nom de catégorie (insensible à la casse, normalisé).
/// Si le nom de catégorie de l'utilisateur contient le slug, on pré-sélectionne.
const _smartCategoryKeywords = <String, List<String>>{
  'courses': ['carrefour','leclerc','lidl','auchan','intermarche','monoprix','franprix',
               'aldi','casino','biocoop','marche','epicerie','boulangerie','supermarche',
               'spar','picard','naturalia','grand frais','netto','super u','simply market'],
  'restaurant': ['mcdo','mcdonald','macdo','burger king','kfc','subway','pizza','sushi',
                  'kebab','resto','restaurant','brasserie','bistrot','uber eats','deliveroo',
                  'just eat','tablapizza','dominos','quick','five guys','popeyes','chipotle',
                  'noodles','poke','wok','thai','indien','libanais','japonais','buffet'],
  'essence': ['total','bp','shell','esso','leclerc carb','intermarche carb','carrefour carb',
               'essence','gasoil','diesel','gazole','station','plein','carburant','e10','sp95',
               'sp98','gnv','peage','autoroute','vinci','sanef','cofiroute'],
  'loisirs': ['cinema','cine','pathé','ugc','mk2','fnac','micromania','steam','playstation',
               'xbox','netflix','disney','canal','spotify','deezer','amazon prime','apple tv',
               'hulu','twitch','youtube','concert','spectacle','theatre','musee','zoo','parc',
               'laser game','bowling','karting','accrobranche','escape game','billeterie'],
  'sante': ['pharmacie','medecin','docteur','dentiste','opticien','kiné','osteo','psy',
             'laboratoire','optique','krys','atol','afflelou','généraliste','urgences',
             'hopital','clinique','mutuelle','cpam','maternite','sage femme','podologue'],
  'vetements': ['zara','h&m','primark','bershka','pull bear','mango','uniqlo','asos','shein',
                 'zalando','kiabi','la redoute','camaieu','promod','jennyfer','sandro','maje',
                 'decathlon','nike','adidas','new balance','courir','foot locker','chaussures'],
  'maison': ['leroy merlin','castorama','brico depot','ikea','conforama','but','maisons du monde',
              'bricorama','mr bricolage','bricomarche','lapeyre','saint maclou','gedimat',
              'jardiland','truffaut','botanic','gamm vert','weldom'],
  'transport': ['sncf','ratp','transilien','ter','ouigo','thalys','eurostar','blablacar',
                 'uber','lyft','bolt','heetch','taxi','vtc','metro','bus','tramway','navigo',
                 'velib','lime','tier','bird','trottinette','stationnement','parking','horodateur'],
  'abonnement': ['sfr','orange','bouygues','free','sosh','b&you','red','prixtel','youprice',
                  'coriolis','auchan telecom','nrj mobile','fnac mobile','lebara','lycamobile',
                  'netflix','spotify','deezer','disney','canal','youtube premium','apple one',
                  'icloud','google one','dropbox','adobe','microsoft','office 365'],
  'alimentation': ['franprix','naturalia','bio c bon','day by day','metro','promocash',
                    'cuisine','repas','dejeuner','diner','snack','sandwicherie','traiteur'],
};

/// Normalise un texte : minuscules, accents retirés.
String _normCat(String s) {
  const from = 'àâäáãéèêëíìîïóòôöõúùûüçœ';
  const to   = 'aaaaaeeeeiiiiooooouuuuco';
  final b = StringBuffer();
  for (final ch in s.toLowerCase().split('')) {
    final i = from.indexOf(ch);
    b.write(i >= 0 ? to[i] : ch);
  }
  return b.toString();
}
class AddExpenseSheet extends ConsumerStatefulWidget {
  final Ym month;
  final String? initialTripId;
  final String? initialCategoryId; // pré-sélectionne une catégorie
  final int? initialPerson;        // pré-sélectionne une personne (mode couple)
  final bool initialUnexpected;
  final Transaction? existing; // dépense à modifier (null = nouvelle dépense)
  const AddExpenseSheet(
      {super.key, required this.month, this.initialTripId, this.initialCategoryId,
       this.initialPerson, this.initialUnexpected = false, this.existing});
  @override
  ConsumerState<AddExpenseSheet> createState() => _AddExpenseState();
}

class _AddExpenseState extends ConsumerState<AddExpenseSheet> {
  String? _cat; // id de catégorie, kUnexpectedId ou kTripCatId
  String? _tripId;
  int _person = 1;
  final _desc = TextEditingController();
  final _amt = TextEditingController();
  late DateTime _date;
  DateTime? _debitDate; // [Mode dev] date de débit bancaire
  List<Transaction> _suggestions = [];  // dernières dépenses similaires
  bool _showSuggestions = false;
  bool _checked = false; // déjà prélevée / pointée

  @override
  void initState() {
    super.initState();
    _date = widget.month == Ym.now() ? DateTime.now() : widget.month.firstDay;
    if (widget.initialUnexpected) _cat = kUnexpectedId;
    if (widget.initialTripId != null) {
      _cat = kTripCatId;
      _tripId = widget.initialTripId;
    }
    if (widget.initialCategoryId != null) _cat = widget.initialCategoryId;
    if (widget.initialPerson != null) _person = widget.initialPerson!;
    _desc.addListener(_onDescChanged);
    final e = widget.existing;
    if (e != null) {
      _date = e.date;
      _debitDate = e.debitDate;
      _desc.text = e.description == 'Dépense' ? '' : e.description;
      _amt.text = e.amount == e.amount.roundToDouble() ? e.amount.round().toString() : e.amount.toString();
      _person = e.person == 0 ? 1 : e.person;
      _checked = e.checked;
      if (e.tripId != null) {
        _cat = kTripCatId;
        _tripId = e.tripId;
      } else {
        _cat = e.categoryId;
      }
    }
  }

  void _onDescChanged() {
    final query = _desc.text.trim().toLowerCase();
    if (query.length < 2) {
      if (_showSuggestions) setState(() { _suggestions = []; _showSuggestions = false; });
      return;
    }
    final d = ref.read(appProvider);
    // ── Catégorie intelligente ──────────────────────────────────
    // Chercher si la description correspond à un mot-clé connu
    final qNorm = _normCat(query);
    String? autocat;
    outer:
    for (final entry in _smartCategoryKeywords.entries) {
      for (final kw in entry.value) {
        if (qNorm.contains(_normCat(kw)) || _normCat(kw).contains(qNorm)) {
          // Trouver la catégorie de l'utilisateur dont le slug correspond
          final match = d.categories.where((c) =>
              _normCat(c.name).contains(entry.key) || entry.key.contains(_normCat(c.name))).firstOrNull;
          if (match != null) { autocat = match.id; break outer; }
          break;
        }
      }
    }
    // Auto-sélection de catégorie désactivée intentionnellement :
    // l'utilisateur choisit lui-même sa catégorie.
    // if (autocat != null && _cat != autocat) {
    //   setState(() { _cat = autocat; _tripId = null; });
    // }
    // Chercher dans toutes les transactions passées (hors mois actuel)
    final now = ref.read(nowProvider);
    final all = d.transactions
        .where((t) =>
            Ym.of(t.date) != now &&       // pas du mois en cours
            t.description.toLowerCase().contains(query))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    // Dédupliquer par description+catégorie, garder les 4 plus récentes
    final seen = <String>{};
    final unique = <Transaction>[];
    for (final t in all) {
      final key = '${t.description.toLowerCase()}_${t.categoryId}';
      if (seen.add(key)) unique.add(t);
      if (unique.length >= 4) break;
    }
    setState(() {
      _suggestions = unique;
      _showSuggestions = unique.isNotEmpty;
    });
  }

  void _applySuggestion(Transaction t) {
    setState(() {
      _desc.text = t.description;
      _amt.text = t.amount == t.amount.roundToDouble()
          ? t.amount.round().toString()
          : t.amount.toStringAsFixed(2);
      if (t.tripId != null) {
        _cat = kTripCatId;
        _tripId = t.tripId;
      } else {
        _cat = t.categoryId;
        _tripId = null;
      }
      if (t.person != 0) _person = t.person;
      _showSuggestions = false;
    });
  }

  bool _isToday(DateTime x) {
    final n = DateTime.now();
    return x.year == n.year && x.month == n.month && x.day == n.day;
  }

  @override
  void dispose() {
    _desc.removeListener(_onDescChanged);
    _desc.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseAmount(_amt.text);
    if (a == null || a <= 0 || _cat == null) {
      snack(context, 'Choisissez une catégorie et entrez un montant.');
      return;
    }
    if (_cat == kTripCatId && _tripId == null) {
      snack(context, 'Sélectionnez le voyage associé à cette dépense.');
      return;
    }
    final d = ref.read(appProvider);
    final couple = d.isCouple;
    final amount = double.parse(a.toStringAsFixed(2));
    final e = widget.existing;

    // ── Détection des doublons ────────────────────────────────────
    // On cherche une dépense du même montant dans le même mois,
    // sauf si on est en train de modifier une dépense existante.
    if (e == null) {
      final ym = Ym.of(_date);
      final duplicates = d.transactionsIn(ym).where((t) =>
          (t.amount - amount).abs() < 0.01 &&
          t.categoryId == _cat &&
          (t.person == 0 || !couple || t.person == _person)).toList();
      if (duplicates.isNotEmpty) {
        final dup = duplicates.first;
        final dupDesc = dup.description.isEmpty ? '' : ' (${dup.description})';
        final dupDate = '${dup.date.day.toString().padLeft(2, '0')}/${dup.date.month.toString().padLeft(2, '0')}';
        // Afficher un avertissement — l'utilisateur peut confirmer ou annuler
        showQuickDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Row(children: [
              Text('⚠️', style: TextStyle(fontSize: 22)),
              SizedBox(width: 8),
              Text('Doublon possible', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            ]),
            content: Text(
              'Tu as déjà une dépense de ${eur(amount)}$dupDesc le $dupDate ce mois-ci.\n\nTu veux quand même l\'enregistrer ?',
              style: const TextStyle(fontSize: 14, height: 1.45),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer quand même')),
            ],
          ),
        ).then((confirmed) {
          if (confirmed == true && mounted) _doSave(amount, couple);
        });
        return;
      }
    }
    _doSave(amount, couple);
  }

  void _doSave(double amount, bool couple) {
    final e = widget.existing;
    final devMode = ref.read(devModeProvider);
    final debitDate = devMode ? _debitDate : null;
    if (e != null) {
      ref.read(appProvider.notifier).updateTransaction(e.id, _cat!, _desc.text.trim(), amount, _date,
          person: couple ? _person : 0, tripId: _cat == kTripCatId ? _tripId : null,
          debitDate: debitDate, checked: _checked);
    } else {
      ref.read(appProvider.notifier).addTransaction(_cat!, _desc.text.trim(), amount, _date,
          person: couple ? _person : 0, tripId: _cat == kTripCatId ? _tripId : null,
          debitDate: debitDate, checked: _checked);
    }
    if (mounted) Navigator.pop(context, true);
  }

  // Couleur de la catégorie sélectionnée (pour teinter montant et bouton)
  Color _accentColor(AppData d) {
    if (_cat == kUnexpectedId) return AppColors.warning;
    if (_cat == kTripCatId) return const Color(0xFF0A84FF);
    final cat = d.categories.where((c) => c.id == _cat).firstOrNull;
    return cat != null ? Color(cat.colorValue) : AppColors.violet;
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final cats = d.categories;
    final dateYm = Ym.of(_date);
    // Tous les voyages dont le mois cible n'est pas encore passé
    final trips = d.projects.where((p) => p.isTrip && p.targetYm.index >= dateYm.index).toList();
    if (_cat == kTripCatId && !trips.any((t) => t.id == _tripId)) {
      _cat = null;
      _tripId = null;
    }
    _cat ??= cats.isEmpty ? kUnexpectedId : cats.first.id;
    final accent = _accentColor(d);

    // Catégories normales + Imprévu (sans les voyages individuels)
    final allCats = <_CatOption>[
      for (final c in cats)
        _CatOption(id: c.id, emoji: c.emoji, name: c.name, color: Color(c.colorValue)),
      const _CatOption(id: kUnexpectedId, emoji: '⚡', name: 'Imprévu', color: AppColors.warning),
    ];

    const tripColor = Color(0xFF0A84FF);
    final selectedTrip = _cat == kTripCatId
        ? trips.where((t) => t.id == _tripId).firstOrNull
        : null;

    // Label info sous les catégories
    String? infoLabel;
    Color? infoColor;
    if (_cat == kUnexpectedId) {
      infoLabel = '⚡ Hors enveloppe — impact direct sur le solde prévu';
      infoColor = AppColors.warning;
    } else if (_cat == kTripCatId) {
      infoLabel = selectedTrip != null
          ? '✈️ Sur le budget ${selectedTrip.name}'
          : '✈️ Sur le budget du voyage';
      infoColor = tripColor;
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── En-tête titre + drag handle ──────────────────────────
      Center(
        child: Container(
          width: 36, height: 4,
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(
            color: accent.withAlpha(80),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),

      // ── Catégories : scroll horizontal (1 seule ligne) ───────
      SizedBox(
        height: 76,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(bottom: 4),
          // +1 pour la chip Voyage si des voyages existent
          itemCount: allCats.length + (trips.isNotEmpty ? 1 : 0),
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            // Dernière position = chip Voyage unique
            if (trips.isNotEmpty && i == allCats.length) {
              return _CatChipCompact(
                option: _CatOption(
                  id: kTripCatId,
                  emoji: selectedTrip?.emoji ?? '✈️',
                  name: selectedTrip?.name ?? 'Voyage',
                  color: tripColor,
                ),
                selected: _cat == kTripCatId,
                onTap: () async {
                  HapticFeedback.selectionClick();
                  final picked = await showSheet<String>(
                    context,
                    title: 'Choisir un voyage',
                    child: _TripPickerSheet(trips: trips, selectedId: _tripId),
                  );
                  if (picked != null && mounted) {
                    setState(() { _cat = kTripCatId; _tripId = picked; });
                  }
                },
              );
            }
            final opt = allCats[i];
            return _CatChipCompact(
              option: opt,
              selected: _cat == opt.id,
              onTap: () {
                HapticFeedback.selectionClick();
                setState(() {
                  _cat = opt.id;
                  _tripId = null;
                });
              },
            );
          },
        ),
      ),

      // ── Info rapide (imprévu / voyage) ────────────────────────
      AnimatedSize(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeInOut,
        child: infoLabel != null
            ? Padding(
                padding: const EdgeInsets.only(top: 4, bottom: 4),
                child: Row(children: [
                  Icon(Icons.info_outline_rounded, size: 13, color: infoColor),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(infoLabel,
                        style: TextStyle(
                          color: infoColor, fontSize: 12,
                          fontWeight: FontWeight.w600,
                        )),
                  ),
                ]),
              )
            : const SizedBox(height: 6),
      ),

      // ── Personne (mode couple) ────────────────────────────────
      if (d.isCouple) ...[
        _PersonToggleRow(
          names: [d.personName(1), d.personName(2)],
          selectedIndex: _person - 1,
          onSelect: (i) => setState(() => _person = i + 1),
        ),
        const SizedBox(height: 10),
      ],

      // ── Description + Montant côte à côte ────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Description (prend les 3/5)
        Expanded(
          flex: 3,
          child: _CompactField(
            controller: _desc,
            hint: 'Description (ex. Carrefour, Essence A6)',
            icon: Icons.edit_note_rounded,
            textCapitalization: TextCapitalization.sentences,
            onChanged: (_) {}, // _onDescChanged est déjà branché via addListener
          ),
        ),
        const SizedBox(width: 8),
        // Montant (prend les 2/5), teinté de la couleur catégorie
        Expanded(
          flex: 2,
          child: _AmountFieldCompact(
            controller: _amt,
            accentColor: accent,
          ),
        ),
      ]),

      // ── Suggestions de dépenses similaires ───────────────────
      AnimatedSize(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        child: _showSuggestions
            ? Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  decoration: BoxDecoration(
                    color: context.fieldColor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Padding(
                      padding: EdgeInsets.fromLTRB(12, 8, 12, 2),
                      child: Text('Dépenses similaires',
                          style: TextStyle(color: AppColors.muted, fontSize: 11.5,
                              fontWeight: FontWeight.w600)),
                    ),
                    for (final s in _suggestions)
                      InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => _applySuggestion(s),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          child: Row(children: [
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(s.description,
                                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                                    maxLines: 1, overflow: TextOverflow.ellipsis),
                                Text(
                                  '${d.category(s.categoryId)?.name ?? ''} · '
                                  '${s.date.day.toString().padLeft(2, '0')}/${s.date.month.toString().padLeft(2, '0')}',
                                  style: const TextStyle(color: AppColors.muted, fontSize: 11),
                                ),
                              ]),
                            ),
                            Text(eur(s.amount),
                                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
                            const SizedBox(width: 4),
                            const Icon(Icons.north_west_rounded, size: 14, color: AppColors.muted),
                          ]),
                        ),
                      ),
                    const SizedBox(height: 4),
                  ]),
                ),
              )
            : const SizedBox.shrink(),
      ),

      const SizedBox(height: 10),

      // ── Date + toggle débit différé sur une ligne ─────────────
      Row(children: [
        // Date de la dépense
        GestureDetector(
          onTap: () async {
            final picked = await pickDay(context, _date);
            if (picked != null) setState(() => _date = picked);
          },
          child: Container(
            height: 40,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: context.fieldColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.calendar_today_rounded, size: 14, color: AppColors.muted),
              const SizedBox(width: 6),
              Text(
                '${_date.day.toString().padLeft(2, '0')}/${_date.month.toString().padLeft(2, '0')}/${_date.year}',
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: context.textColor,
                ),
              ),
            ]),
          ),
        ),
        if (!_isToday(_date)) ...[
          const SizedBox(width: 6),
          GestureDetector(
            onTap: () => setState(() => _date = DateTime.now()),
            child: Container(
              height: 40,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: context.fieldColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.today_rounded, size: 18, color: AppColors.muted),
            ),
          ),
        ],
        // [Mode dev] Toggle débit différé
        if (ref.watch(devModeProvider)) ...[
          const SizedBox(width: 6),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() {
                if (_debitDate != null) {
                  _debitDate = null;
                }
                // On affiche/cache le picker débit via _debitDate == null
              }),
              child: _DebitToggleChip(
                debitDate: _debitDate,
                expenseDate: _date,
                onToggle: () => setState(() {
                  _debitDate = _debitDate == null
                      ? DateTime(_date.year, _date.month + 1, 5)
                      : null;
                }),
              ),
            ),
          ),
        ],
      ]),

      // ── [Mode dev] Options débit différé (s'ouvre si activé) ──
      if (ref.watch(devModeProvider))
        AnimatedSize(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeInOut,
          child: _debitDate != null
              ? Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: _DebitDatePicker(
                    expenseDate: _date,
                    debitDate: _debitDate,
                    onChanged: (d) => setState(() => _debitDate = d),
                  ),
                )
              : const SizedBox.shrink(),
        ),

      const SizedBox(height: 10),

      // ── Vu sur mon compte ─────────────────────────────────────
      GestureDetector(
        onTap: () => setState(() => _checked = !_checked),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: _checked ? accent.withAlpha(20) : context.fieldColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: _checked ? accent : Colors.transparent,
              width: 1.5,
            ),
          ),
          child: Row(children: [
            Icon(
              _checked ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
              color: _checked ? accent : AppColors.muted,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Vu sur mon compte', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              Text('Pointer cette dépense maintenant', style: TextStyle(color: AppColors.muted, fontSize: 12)),
            ])),
          ]),
        ),
      ),

      const SizedBox(height: 14),

      // ── Boutons ───────────────────────────────────────────────
      _CancelSaveRow(saveLabel: 'Enregistrer', onSave: _save),
    ]);
  }
}

// ── Option de catégorie (modèle interne) ──────────────────────────────────────
class _CatOption {
  final String id;
  final String? tripId;
  final String emoji;
  final String name;
  final Color color;
  const _CatOption({
    required this.id,
    this.tripId,
    required this.emoji,
    required this.name,
    required this.color,
  });
}

// ── Chip catégorie compact (scroll horizontal) ────────────────────────────────
// ── Sélecteur de voyage (bottom sheet) ───────────────────────────────────────
// ── Grille emoji rapide + champ libre ────────────────────────────────────────
class _EmojiQuickPicker extends StatelessWidget {
  final String emoji;
  final ValueChanged<String> onEmoji;
  const _EmojiQuickPicker({required this.emoji, required this.onEmoji});

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Wrap(spacing: 6, runSpacing: 6, children: [
      for (final e in kEmojiChoices)
        GestureDetector(
          onTap: () => onEmoji(e),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            width: 40, height: 40,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: e == emoji ? AppColors.violet.withAlpha(30) : context.fieldColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: e == emoji ? AppColors.violet : Colors.transparent,
                width: 2,
              ),
            ),
            child: Text(e, style: const TextStyle(fontSize: 22)),
          ),
        ),
    ]),
    const SizedBox(height: 8),
    TextField(
      inputFormatters: [_OneEmojiFormatter()],
      decoration: const InputDecoration(
        labelText: 'Autre emoji — touche 🌐 sur le clavier',
        prefixIcon: Icon(Icons.emoji_emotions_outlined),
        isDense: true,
      ),
      onChanged: (v) {
        final t = v.trim();
        if (t.isNotEmpty) onEmoji(t.characters.last);
      },
    ),
  ]);
}

class _TripPickerSheet extends StatelessWidget {
  final List<Project> trips;
  final String? selectedId;
  const _TripPickerSheet({required this.trips, this.selectedId});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final t in trips)
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
            leading: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: const Color(0xFF0A84FF).withAlpha(18),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(child: Text(t.emoji, style: const TextStyle(fontSize: 22))),
            ),
            title: Text(t.name,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            subtitle: Text(
              '${t.targetYm.longName} ${t.targetYm.year} · ${eur(t.target)}',
              style: const TextStyle(fontSize: 12.5, color: AppColors.muted),
            ),
            trailing: selectedId == t.id
                ? const Icon(Icons.check_circle_rounded, color: Color(0xFF0A84FF))
                : const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
            onTap: () => Navigator.pop(context, t.id),
          ),
      ],
    );
  }
}

class _CatChipCompact extends StatelessWidget {
  const _CatChipCompact({
    required this.option,
    required this.selected,
    required this.onTap,
  });
  final _CatOption option;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = option.color;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        width: 72,
        decoration: BoxDecoration(
          color: selected ? c.withAlpha(28) : c.withAlpha(10),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? c : c.withAlpha(50),
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(option.emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(height: 3),
          Text(
            option.name,
            style: TextStyle(
              fontSize: 10,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? c : AppColors.muted,
            ),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ]),
      ),
    );
  }
}

// ── Toggle personne compact ───────────────────────────────────────────────────
class _PersonToggleRow extends StatelessWidget {
  const _PersonToggleRow({
    required this.names,
    required this.selectedIndex,
    required this.onSelect,
  });
  final List<String> names;
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Text('Pour', style: TextStyle(
        fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.muted)),
      const SizedBox(width: 10),
      Container(
        height: 34,
        decoration: BoxDecoration(
          color: context.fieldColor,
          borderRadius: BorderRadius.circular(17),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          for (var i = 0; i < names.length; i++)
            GestureDetector(
              onTap: () {
                HapticFeedback.selectionClick();
                onSelect(i);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  color: selectedIndex == i ? AppColors.violet : Colors.transparent,
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Text(
                  names[i],
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: selectedIndex == i ? Colors.white : AppColors.muted,
                  ),
                ),
              ),
            ),
        ]),
      ),
    ]);
  }
}

// ── Champ texte compact ───────────────────────────────────────────────────────
class _CompactField extends StatelessWidget {
  const _CompactField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.textCapitalization = TextCapitalization.none,
    this.onChanged,
  });
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final TextCapitalization textCapitalization;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        color: context.fieldColor,
        borderRadius: BorderRadius.circular(14),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        Icon(icon, size: 15, color: AppColors.muted),
        const SizedBox(width: 7),
        Expanded(
          child: TextField(
            controller: controller,
            textCapitalization: textCapitalization,
            onChanged: onChanged,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: hint,
              hintStyle: const TextStyle(color: AppColors.muted, fontSize: 14),
              isDense: true,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ),
      ]),
    );
  }
}

// ── Champ montant coloré ──────────────────────────────────────────────────────
class _AmountFieldCompact extends StatelessWidget {
  const _AmountFieldCompact({
    required this.controller,
    required this.accentColor,
  });
  final TextEditingController controller;
  final Color accentColor;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: 48,
      decoration: BoxDecoration(
        color: accentColor.withAlpha(22),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: accentColor.withAlpha(80), width: 1.5),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(children: [
        Text('€',
            style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.w800, color: accentColor)),
        const SizedBox(width: 4),
        Expanded(
          child: TextField(
            controller: controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*[.,]?\d{0,2}')),
            ],
            style: TextStyle(
              fontSize: 17, fontWeight: FontWeight.w800, color: accentColor),
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: '0',
              hintStyle: TextStyle(
                color: accentColor.withAlpha(80),
                fontSize: 17, fontWeight: FontWeight.w800),
              isDense: true,
              contentPadding: EdgeInsets.zero,
            ),
          ),
        ),
      ]),
    );
  }
}

// ── Chip toggle débit différé (compact) ──────────────────────────────────────
class _DebitToggleChip extends StatelessWidget {
  const _DebitToggleChip({
    required this.debitDate,
    required this.expenseDate,
    required this.onToggle,
  });
  final DateTime? debitDate;
  final DateTime expenseDate;
  final VoidCallback onToggle;

  String _fmt(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final active = debitDate != null;
    return GestureDetector(
      onTap: onToggle,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: active ? AppColors.violet.withAlpha(20) : context.fieldColor,
          borderRadius: BorderRadius.circular(12),
          border: active
              ? Border.all(color: AppColors.violet.withAlpha(80), width: 1.2)
              : null,
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.account_balance_rounded,
              size: 14,
              color: active ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 5),
          Text(
            active ? 'Débit ${_fmt(debitDate!)}' : 'Débit différé',
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w600,
              color: active ? AppColors.violet : AppColors.muted,
            ),
          ),
        ]),
      ),
    );
  }
}




// ---------------- Nouvelle catégorie + budget ----------------
class AddCategorySheet extends ConsumerStatefulWidget {
  const AddCategorySheet({super.key});
  @override
  ConsumerState<AddCategorySheet> createState() => _AddCategoryState();
}

class _AddCategoryState extends ConsumerState<AddCategorySheet> {
  final _name = TextEditingController();
  final _amt = TextEditingController();
  String _emoji = '🍕';
  int _color = AppColors.palette[2].value;
  bool _separate = false;

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseAmount(_amt.text);
    if (_name.text.trim().isEmpty || a == null || a < 0) {
      snack(context, 'Donnez un nom à cette catégorie et définissez un budget.');
      return;
    }
    ref.read(appProvider.notifier).addCategoryWithBudget(_name.text.trim(), _emoji, a,
        colorValue: _color, separate: _separate);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isCouple = ref.watch(appProvider).isCouple;
    final accent = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _name,
          hint: 'Nom (ex. Courses, Loisirs)',
          icon: Icons.label_outline_rounded,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: accent)),
      ]),
      const SizedBox(height: 10),
      // ── Style (emoji + couleur) ──────────────────────────────
      StylePicker(
        emoji: _emoji,
        color: _color,
        onEmoji: (e) => setState(() => _emoji = e),
        onColor: (c) => setState(() => _color = c),
      ),
      // ── Mode couple ──────────────────────────────────────────
      if (isCouple) ...[
        const SizedBox(height: 10),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Budget individuel', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(_separate ? 'Un budget chacun.' : 'Budget commun partagé.'),
          value: _separate,
          onChanged: (v) => setState(() => _separate = v),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(saveLabel: 'Créer', onSave: _save),
    ]);
  }
}

// ---------------- Saisie d'un montant simple ----------------
Future<double?> askAmount(BuildContext context, String title, double initial,
    {String? hint, String suffix = '€'}) {
  final c = TextEditingController(
      text: initial == 0 ? '' : (initial == initial.roundToDouble() ? initial.round().toString() : initial.toString()));
  return showQuickDialog<double>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        if (hint != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(hint)),
        TextField(
          controller: c,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
          decoration: InputDecoration(suffixText: suffix),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(
            onPressed: () {
              final v = parseAmount(c.text);
              if (v != null) Navigator.pop(ctx, v);
            },
            child: const Text('OK')),
      ],
    ),
  );
}

// ---------------- Revenu récurrent : modifier un seul mois ----------------
class RecurringOverrideSheet extends ConsumerStatefulWidget {
  final Ym month;
  final String recurringId;
  const RecurringOverrideSheet({super.key, required this.month, required this.recurringId});
  @override
  ConsumerState<RecurringOverrideSheet> createState() => _RecurringOverrideState();
}

class _RecurringOverrideState extends ConsumerState<RecurringOverrideSheet> {
  late final TextEditingController _amt;
  @override
  void initState() {
    super.initState();
    final r = ref.read(appProvider).recurring(widget.recurringId);
    _amt = TextEditingController(text: (r?.amountIn(widget.month) ?? 0).round().toString());
  }

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = ref.watch(appProvider).recurring(widget.recurringId);
    if (r == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: AppColors.violet.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Info ─────────────────────────────────────────────────
      Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.violet.withAlpha(15),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(children: [
          const Icon(Icons.info_outline_rounded, size: 15, color: AppColors.violet),
          const SizedBox(width: 8),
          Expanded(child: Text(
            'Montant habituel : ${eur(r.amount)}. Ce changement ne s\'applique qu\'au mois de ${widget.month.label} — les autres mois restent inchangés.',
            style: const TextStyle(color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600),
          )),
        ]),
      ),
      const SizedBox(height: 14),
      _AmountFieldCompact(controller: _amt, accentColor: AppColors.violet),
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer pour ${widget.month.label} seulement',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (v == null || v < 0) return;
          ref.read(appProvider.notifier).setRecurringOverride(r.id, widget.month, v);
          Navigator.pop(context);
        },
      ),
      if (r.hasOverride(widget.month)) ...[
        const SizedBox(height: 10),
        SoftButton(
          label: 'Annuler la modification — revenir à ${eur(r.amount)}',
          onPressed: () {
            ref.read(appProvider.notifier).setRecurringOverride(r.id, widget.month, null);
            Navigator.pop(context);
          },
        ),
      ],
      const SizedBox(height: 10),
      SoftButton(
        icon: Icons.delete_outline_rounded,
        label: 'Supprimer ce revenu',
        onPressed: () async {
          final choice = await showQuickDialog<String>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Text('Supprimer ${r.label} ?'),
              content: Text(
                  'Voulez-vous retirer ce revenu uniquement en ${widget.month.label}, ou l\'arrêter définitivement à partir de ce mois ? Les mois déjà passés ne seront jamais modifiés.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                TextButton(
                    onPressed: () => Navigator.pop(ctx, 'one'), child: const Text('Ce mois uniquement')),
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, 'future'),
                    child: const Text('Arrêter définitivement')),
              ],
            ),
          );
          if (choice == null || !context.mounted) return;
          final n = ref.read(appProvider.notifier);
          if (choice == 'one') {
            n.excludeRecurringMonth(r.id, widget.month);
          } else {
            n.endRecurringFrom(r.id, widget.month);
          }
          Navigator.pop(context);
        },
      ),
    ]);
  }
}

// ---------------- Modifier un revenu récurrent (tout : nom, montant, fréquence...) ----------------
class EditRecurringIncomeSheet extends ConsumerStatefulWidget {
  final String recurringId;
  const EditRecurringIncomeSheet({super.key, required this.recurringId});
  @override
  ConsumerState<EditRecurringIncomeSheet> createState() => _EditRecurringIncomeState();
}

class _EditRecurringIncomeState extends ConsumerState<EditRecurringIncomeSheet> {
  late RecurringIncome _r = ref.read(appProvider).recurring(widget.recurringId)!;
  late final TextEditingController _label = TextEditingController(text: _r.label);
  late final TextEditingController _amt = TextEditingController(
      text: _r.amount == _r.amount.roundToDouble() ? _r.amount.round().toString() : _r.amount.toString());
  late Ym _start = _r.start;
  late Ym? _end = _r.end;
  late int _interval = _r.intervalMonths;
  late ReceiptDayRule _receiptDay = _r.receiptDay;

  @override
  void dispose() {
    _label.dispose();
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final still = ref.watch(appProvider).recurring(widget.recurringId);
    if (still == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: AppColors.violet.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _label,
          hint: 'Nom du revenu',
          icon: Icons.edit_note_rounded,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: AppColors.violet)),
      ]),
      const SizedBox(height: 14),
      const Text('Fréquence', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      PillSelector<int>(
        items: const [
          PillItem(1,  'Chaque mois'),
          PillItem(2,  '2 mois'),
          PillItem(3,  '3 mois'),
          PillItem(4,  '4 mois'),
          PillItem(6,  '6 mois'),
          PillItem(12, '1 an'),
        ],
        selected: _interval,
        onChanged: (n) => setState(() => _interval = n),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: SoftButton(
            icon: Icons.play_arrow_rounded,
            label: 'Commence en ${_start.label}',
            onPressed: () async {
              final y = await pickYm(context, _start);
              if (y != null) setState(() => _start = y);
            },
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: SoftButton(
            icon: Icons.stop_rounded,
            label: _end == null ? 'Sans date de fin' : 'Se termine en ${_end!.label}',
            onPressed: () async {
              final y = await pickYm(context, _end ?? _start.add(12));
              if (y != null) setState(() => _end = y);
            },
          ),
        ),
      ]),
      if (_end != null)
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(onPressed: () => setState(() => _end = null), child: const Text('Sans date de fin')),
        ),
      // ── [Mode dev] Date de réception ─────────────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 12),
        _ReceiptDayPicker(
          receiptDay: _receiptDay,
          onChanged: (r) => setState(() => _receiptDay = r),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (_label.text.trim().isEmpty || v == null || v <= 0) {
            snack(context, 'Donnez un nom à ce revenu et entrez le montant.');
            return;
          }
          if (_end != null && _end!.isBefore(_start)) {
            snack(context, 'La date de fin doit être après la date de début.');
            return;
          }
          final devMode = ref.read(devModeProvider);
          ref.read(appProvider.notifier).updateRecurringIncome(widget.recurringId,
              label: _label.text.trim(), amount: v, start: _start, end: _end,
              intervalMonths: _interval,
              receiptDay: devMode ? _receiptDay : null);
          Navigator.pop(context);
        },
      ),
    ]);
  }
}


class AddIncomeSheet extends ConsumerStatefulWidget {
  final Ym month;
  final bool startRecurring;
  const AddIncomeSheet({super.key, required this.month, this.startRecurring = false});
  @override
  ConsumerState<AddIncomeSheet> createState() => _AddIncomeState();
}

class _AddIncomeState extends ConsumerState<AddIncomeSheet> {
  late bool _recurring = widget.startRecurring;
  IncomeKind _kind = IncomeKind.salary;
  late Ym _start = widget.month;
  Ym? _end;
  int _interval = 1;
  final _label = TextEditingController();
  final _amt = TextEditingController();

  @override
  void dispose() {
    _label.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final v = parseAmount(_amt.text);
    if (v == null || v <= 0) {
      snack(context, 'Entrez le montant de ce revenu.');
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (_recurring) {
      if (_end != null && _end!.isBefore(_start)) {
        snack(context, 'La date de fin doit être après la date de début.');
        return;
      }
      n.addRecurringIncome(_label.text.trim(), v, _start, _end, intervalMonths: _interval);
    } else {
      n.addExtraIncome(_kind, _label.text.trim(), v, widget.month);
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Drag handle ────────────────────────────────────────
        Center(child: Container(
          width: 36, height: 4,
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(color: AppColors.success.withAlpha(80), borderRadius: BorderRadius.circular(2)),
        )),
        // ── Ponctuel / Récurrent ───────────────────────────────
        TabSwitcher<bool>(
          tabs: const [
            (value: false, label: 'Ponctuel',   icon: Icons.bolt_rounded),
            (value: true,  label: 'Récurrent',  icon: Icons.repeat_rounded),
          ],
          selected: _recurring,
          onChanged: (v) => setState(() => _recurring = v),
        ),
        const SizedBox(height: 8),
        Row(children: [
          const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
          const SizedBox(width: 5),
          Expanded(child: Text(
            _recurring
                ? 'Ajouté automatiquement chaque mois. Modifiable à tout moment.'
                : 'Comptabilisé une seule fois en ${widget.month.label}.',
            style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
          )),
        ]),
        const SizedBox(height: 14),
        if (!_recurring) ...[
          PillSelector<IncomeKind>(
            items: [for (final k in IncomeKind.values) PillItem(k, k.label)],
            selected: _kind,
            onChanged: (k) => setState(() => _kind = k),
          ),
          const SizedBox(height: 12),
        ],
        // ── Libellé + Montant côte à côte ──────────────────────
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 3, child: _CompactField(
            controller: _label,
            hint: _recurring ? 'Nom (ex. Salaire, Loyer perçu)' : 'Description (optionnel)',
            icon: Icons.edit_note_rounded,
            textCapitalization: TextCapitalization.sentences,
            onChanged: (_) {},
          )),
          const SizedBox(width: 8),
          Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: AppColors.success)),
        ]),
        if (_recurring) ...[
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
              child: SoftButton(
                icon: Icons.play_arrow_rounded,
                label: 'Commence en ${_start.label}',
                onPressed: () async {
                  final y = await pickYm(context, _start);
                  if (y != null) setState(() => _start = y);
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: SoftButton(
                icon: Icons.stop_rounded,
                label: _end == null ? 'Sans date de fin' : 'Se termine en ${_end!.label}',
                onPressed: () async {
                  final y = await pickYm(context, _end ?? _start.add(12));
                  if (y != null) setState(() => _end = y);
                },
              ),
            ),
          ]),
          if (_end != null)
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(onPressed: () => setState(() => _end = null), child: const Text('Supprimer la date de fin')),
            ),
          const SizedBox(height: 12),
          const Text('Fréquence', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          PillSelector<int>(
            items: const [
              PillItem(1,  'Chaque mois'),
              PillItem(2,  '2 mois'),
              PillItem(3,  '3 mois'),
              PillItem(4,  '4 mois'),
              PillItem(6,  '6 mois'),
              PillItem(12, '1 an'),
            ],
            selected: _interval,
            onChanged: (n) => setState(() => _interval = n),
          ),
        ],
        const SizedBox(height: 16),
        _CancelSaveRow(saveLabel: 'Ajouter', onSave: _save),
      ]);
}

// ---------------- Charge fixe (création ou modification) ----------------
class AddFixedExpenseSheet extends ConsumerStatefulWidget {
  final FixedExpense? existing;
  const AddFixedExpenseSheet({super.key, this.existing});
  @override
  ConsumerState<AddFixedExpenseSheet> createState() => _AddFixedState();
}

class _AddFixedState extends ConsumerState<AddFixedExpenseSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _amt = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.amount == widget.existing!.amount.roundToDouble()
              ? widget.existing!.amount.round().toString()
              : widget.existing!.amount.toStringAsFixed(2)));
  late Ym _start = widget.existing?.start ?? ref.read(nowProvider);
  late Ym? _end = widget.existing?.end;
  late String _emoji = widget.existing?.emoji ?? '';
  late bool _useEmoji = (widget.existing?.emoji ?? '').isNotEmpty;
  late int _color = widget.existing?.colorValue ?? 0xFF9E9E9E;
  late int _interval = widget.existing?.intervalMonths ?? 1;
  late String? _leaveTypeId = widget.existing?.leaveTypeId;
  late String? _linkedCategoryId = widget.existing?.categoryId;
  // 0 = sans couleur, 1 = catégorie existante, 2 = nouvelle couleur personnalisée
  late int _colorMode = widget.existing?.categoryId != null ? 1
      : (widget.existing?.colorValue != null && widget.existing?.colorValue != 0xFF9E9E9E ? 2 : 0);
  bool _onlyThisMonth = false; // raccourci "seulement ce mois-ci"

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    final letter = _name.text.trim().isEmpty ? '?' : _name.text.trim().characters.first.toUpperCase();
    final accent = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _name,
          hint: 'Nom (ex. Loyer, Netflix, Assurance)',
          icon: Icons.edit_note_rounded,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) => setState(() {}),
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: accent)),
      ]),
      const SizedBox(height: 12),
      // Raccourci : juste ce mois-ci (une seule occurrence)
      if (widget.existing == null)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () {
              final now = ref.read(nowProvider);
              setState(() {
                _onlyThisMonth = !_onlyThisMonth;
                if (_onlyThisMonth) {
                  _start = now;
                  _end = now;
                  _interval = 1;
                } else {
                  _end = null;
                }
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: _onlyThisMonth ? AppColors.teal.withAlpha(20) : context.fieldColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _onlyThisMonth ? AppColors.teal : Colors.transparent,
                  width: 1.5,
                ),
              ),
              child: Row(children: [
                Icon(_onlyThisMonth ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: _onlyThisMonth ? AppColors.teal : AppColors.muted, size: 20),
                const SizedBox(width: 10),
                const Text('Juste ce mois', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              ]),
            ),
          ),
        ),
      if (!_onlyThisMonth) ...[
        Row(children: [
          Expanded(
            child: SoftButton(
              icon: Icons.play_arrow_rounded,
              label: 'Commence en ${_start.label}',
              onPressed: () async {
                final y = await pickYm(context, _start);
                if (y != null) setState(() => _start = y);
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: SoftButton(
              icon: Icons.stop_rounded,
              label: _end == null ? 'Sans date de fin' : 'Se termine en ${_end!.label}',
              onPressed: () async {
                final y = await pickYm(context, _end ?? _start.add(12));
                if (y != null) setState(() => _end = y);
              },
            ),
          ),
        ]),
        if (_end != null)
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(onPressed: () => setState(() => _end = null), child: const Text('Supprimer la date de fin')),
          ),
      ],
      const SizedBox(height: 14),
      const Text('Fréquence', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      PillSelector<int>(
        items: const [
          PillItem(1,  'Chaque mois'),
          PillItem(2,  '2 mois'),
          PillItem(3,  '3 mois'),
          PillItem(4,  '4 mois'),
          PillItem(6,  '6 mois'),
          PillItem(12, '1 an'),
        ],
        selected: _interval,
        onChanged: (n) => setState(() => _interval = n),
      ),
      const SizedBox(height: 14),
      const Text('Icône', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      TabSwitcher<bool>(
        tabs: const [
          (value: false, label: 'Initiale', icon: Icons.text_fields_rounded),
          (value: true,  label: 'Emoji',    icon: Icons.emoji_emotions_outlined),
        ],
        selected: _useEmoji,
        onChanged: (v) => setState(() {
          _useEmoji = v;
          if (v && _emoji.isEmpty) _emoji = '🏠';
        }),
      ),
      // Picker emoji visible quel que soit le mode couleur
      if (_useEmoji) ...[
        const SizedBox(height: 12),
        _EmojiQuickPicker(
          emoji: _emoji,
          onEmoji: (e) => setState(() => _emoji = e),
        ),
      ],
      const SizedBox(height: 12),
      // ── Catégorie / Couleur ───────────────────────────────────
      const Text('Couleur', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
      const SizedBox(height: 8),
      PillSelector<int>.row(
        items: const [
          PillItem(0, 'Neutre',   icon: Icons.circle_outlined),
          PillItem(1, 'Budget',   icon: Icons.label_rounded),
          PillItem(2, 'Couleur',  icon: Icons.palette_outlined),
        ],
        selected: _colorMode,
        onChanged: (v) => setState(() {
          _colorMode = v;
          if (v == 0) { _linkedCategoryId = null; _color = 0xFF9E9E9E; }
          if (v == 2) _linkedCategoryId = null;
        }),
      ),
      const SizedBox(height: 10),
      // Catégories existantes
      if (_colorMode == 1) Builder(builder: (ctx) {
        final cats = ref.watch(appProvider).categories;
        if (cats.isEmpty) return Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text('Aucune catégorie de budget créée.',
              style: TextStyle(color: context.mutedColor, fontSize: 13)),
        );
        return Wrap(spacing: 8, runSpacing: 8, children: [
          for (final cat in cats)
            GestureDetector(
              onTap: () => setState(() {
                _linkedCategoryId = cat.id;
                _color = cat.colorValue;
              }),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: _linkedCategoryId == cat.id
                      ? Color(cat.colorValue).withAlpha(30)
                      : context.fieldColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _linkedCategoryId == cat.id ? Color(cat.colorValue) : Colors.transparent,
                    width: 1.5,
                  ),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(cat.emoji.isNotEmpty ? cat.emoji : cat.name.characters.first.toUpperCase(),
                      style: const TextStyle(fontSize: 14)),
                  const SizedBox(width: 6),
                  Text(cat.name, style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: _linkedCategoryId == cat.id ? Color(cat.colorValue) : null)),
                ]),
              ),
            ),
        ]);
      }),
      // Couleur personnalisée — palette seule (emoji géré au-dessus)
      if (_colorMode == 2) ...[
        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (var i = 0; i < AppColors.palette.length; i++)
              _PaletteItem(
                color: AppColors.palette[i],
                label: AppColors.paletteLabels[i],
                selected: AppColors.palette[i].value == _color,
                onTap: () => setState(() => _color = AppColors.palette[i].value),
              ),
          ],
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (_name.text.trim().isEmpty || v == null || v <= 0) {
            snack(context, 'Donnez un nom à cette charge et entrez le montant.');
            return;
          }
          if (_end != null && _end!.isBefore(_start)) {
            snack(context, 'La date de fin doit être après la date de début.');
            return;
          }
          final n = ref.read(appProvider.notifier);
          final emoji = _useEmoji ? _emoji : '';
          // Couleur effective : depuis catégorie liée, personnalisée, ou gris neutre
          final effectiveColor = _colorMode == 0 ? null
              : _colorMode == 1 && _linkedCategoryId != null
                  ? _color  // déjà mis à jour depuis la catégorie
                  : _color;
          if (editing) {
            n.updateFixedExpense(FixedExpense(
                id: widget.existing!.id,
                name: _name.text.trim(),
                amount: v,
                start: _start,
                end: _end,
                emoji: emoji,
                colorValue: effectiveColor,
                categoryId: _colorMode == 1 ? _linkedCategoryId : null,
                intervalMonths: _interval,
                checkedMonths: widget.existing!.checkedMonths,
                leaveTypeId: _leaveTypeId));
          } else {
            n.addFixedExpense(_name.text.trim(), v, _start, _end,
                emoji: emoji, colorValue: effectiveColor, intervalMonths: _interval,
                leaveTypeId: _leaveTypeId,
                categoryId: _colorMode == 1 ? _linkedCategoryId : null);
          }
          Navigator.pop(context);
        },
      ),
      if (editing) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer...',
          onPressed: () async {
            final choice = await showQuickDialog<String>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('Supprimer ${widget.existing!.name} ?'),
                content: const Text('Pour toujours, seulement un mois, ou une période précise ?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                  TextButton(onPressed: () => Navigator.pop(ctx, 'one'), child: const Text('Un seul mois')),
                  TextButton(onPressed: () => Navigator.pop(ctx, 'range'), child: const Text('Une période')),
                  FilledButton(
                      onPressed: () => Navigator.pop(ctx, 'all'), child: const Text('Pour toujours')),
                ],
              ),
            );
            if (choice == null || !context.mounted) return;
            final n = ref.read(appProvider.notifier);
            if (choice == 'all') {
              n.removeFixedExpense(widget.existing!.id);
              Navigator.pop(context);
              return;
            }
            if (choice == 'one') {
              final y = await pickYm(context, ref.read(chargeMonthProvider));
              if (y != null) n.excludeFixedMonths(widget.existing!.id, [y]);
            } else if (choice == 'range') {
              final from = await pickYm(context, ref.read(chargeMonthProvider));
              if (from == null || !context.mounted) return;
              final to = await pickYm(context, from);
              if (to == null) return;
              final a = from.index <= to.index ? from : to;
              final b = from.index <= to.index ? to : from;
              final months = [for (var i = a.index; i <= b.index; i++) Ym.fromIndex(i)];
              n.excludeFixedMonths(widget.existing!.id, months);
            }
            if (context.mounted) Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}

class AddProjectSheet extends ConsumerStatefulWidget {
  final Project? existing; // non nul : modification d'un voyage
  const AddProjectSheet({super.key, this.existing});
  @override
  ConsumerState<AddProjectSheet> createState() => _AddProjectState();
}

class _AddProjectState extends ConsumerState<AddProjectSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _amt = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.target == widget.existing!.target.roundToDouble()
              ? widget.existing!.target.round().toString()
              : widget.existing!.target.toStringAsFixed(2)));
  late ProjectMode _mode = widget.existing?.mode ?? ProjectMode.expense;
  late Ym _target = widget.existing?.targetYm ?? Ym.now().add(6);
  late DateTime? _start = widget.existing?.tripStart;
  late DateTime? _end = widget.existing?.tripEnd;
  late int _who = widget.existing?.who ?? 0;
  late bool _trip = widget.existing?.isTrip ?? true;

  String _fd(DateTime x) =>
      '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}/${x.year}';

  /// Un seul calendrier : on touche un jour (départ), puis un autre (retour),
  /// et l'intervalle se sélectionne automatiquement. Il s'ouvre sur le mois actuel,
  /// avec un bouton « Aujourd'hui » directement dans le calendrier.
  Future<void> _pickDates() async {
    final range = await showSheet<DateTimeRange>(
      context,
      title: 'Dates du voyage',
      child: RangeCalendarSheet(
        initialMonth: _start ?? ref.read(nowProvider).firstDay,
        initialStart: _start,
        initialEnd: _end,
      ),
    );
    if (range == null) return;
    setState(() {
      _start = range.start;
      _end = range.end;
      _target = Ym.of(range.start); // le mois du voyage est déduit de la date de départ
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _doSaveProject(double v) {
    final n = ref.read(appProvider.notifier);
    if (widget.existing == null) {
      n.addProject(_name.text.trim(), v, _target, _mode,
          tripStart: _start, tripEnd: _end, who: _who, isTrip: _trip);
    } else {
      n.updateProject(widget.existing!.id,
          name: _name.text.trim(), target: v, targetYm: _target, mode: _mode,
          tripStart: _start, tripEnd: _end, who: _who, isTrip: _trip);
    }
    Navigator.pop(context);
  }

  Future<void> _trySave(BuildContext context) async {
    final v = parseAmount(_amt.text);
    if (_name.text.trim().isEmpty || v == null || v <= 0) {
      snack(context, 'Donnez un nom à ce projet et entrez le budget total prévu.');
      return;
    }
    final now = ref.read(nowProvider);
    if (_start != null && _end != null && _end!.isBefore(_start!)) {
      snack(context, 'La date de retour doit être après la date de départ.');
      return;
    }
    if (widget.existing == null) {
      if (_mode == ProjectMode.expense ? _target.isBefore(now) : !_target.isAfter(now)) {
        snack(context, _mode == ProjectMode.expense
            ? 'Choisissez le mois du voyage — le mois actuel ou un mois futur.'
            : 'Pour épargner, l\'objectif doit être dans un mois futur.');
        return;
      }
    }

    // ── Vérification de faisabilité (mode épargne uniquement) ──
    if (_mode == ProjectMode.savings && widget.existing == null) {
      final d = ref.read(appProvider);
      final months = max(1, _target.index - now.index);
      final monthlyNeeded = v / months;

      // Revenu moyen - charges fixes - budgets actuels
      final avgIncome = d.recurringIncomes.fold(0.0, (s, r) => s + r.amount);
      final avgFixed = d.fixedExpenses.where((f) => f.activeIn(now)).fold(0.0, (s, f) => s + f.amount);
      final currentBudgets = d.budgets.fold(0.0, (s, b) => s + b.amount);
      final disponible = avgIncome - avgFixed - currentBudgets;

      if (monthlyNeeded > disponible) {
        // Pas assez de marge → proposer de réduire des budgets
        final shortage = monthlyNeeded - disponible;
        final ok = await showSheet<bool>(
          context,
          title: 'Solde insuffisant pour épargner',
          child: _BudgetReduceSheet(
            projectName: _name.text.trim(),
            monthlyNeeded: monthlyNeeded,
            disponible: disponible,
            shortage: shortage,
            months: months,
          ),
        );
        if (ok != true) return; // l'utilisateur a annulé ou refusé
      }
    }

    _doSaveProject(v);

    // ── Calcul des jours de congés à poser pour ce voyage ──────
    if (_trip && _start != null && _end != null) {
      await _proposeLeaveForTrip(context, v);
    }
  }

  /// Calcule les jours de travail tombant pendant le voyage selon la tournante,
  /// et propose de les poser en congés.
  Future<void> _proposeLeaveForTrip(BuildContext context, double budget) async {
    final d = ref.read(appProvider);
    final schedule = d.shiftSchedule;
    final leaveTypes = d.leaveTypes;
    if (!d.user.leaveEnabled || leaveTypes.isEmpty) return;
    if (schedule == null && d.shiftSchedule == null) return;

    // Compter les jours de travail pendant le voyage
    final tripDays = <DateTime>[];
    if (schedule != null && _start != null && _end != null) {
      var cur = DateTime(_start!.year, _start!.month, _start!.day);
      final endDate = DateTime(_end!.year, _end!.month, _end!.day);
      while (!cur.isAfter(endDate)) {
        if (schedule.shiftOn(cur).isWorking) tripDays.add(cur);
        cur = cur.add(const Duration(days: 1));
      }
    }
    if (tripDays.isEmpty) return;

    // Regrouper par mois
    final Map<Ym, int> joursParMois = {};
    for (final d in tripDays) {
      final ym = Ym(d.year, d.month);
      joursParMois[ym] = (joursParMois[ym] ?? 0) + 1;
    }

    // Afficher la proposition
    if (!context.mounted) return;
    await showSheet(
      context,
      title: 'Congés pour ${_name.text.trim()}',
      child: _TripLeaveSheet(
        tripName: _name.text.trim(),
        joursParMois: joursParMois,
        leaveTypes: leaveTypes,
        tripStart: _start!,
        tripEnd: _end!,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final expense = _mode == ProjectMode.expense;
    final days = (_start != null && _end != null) ? _end!.difference(_start!).inDays + 1 : 0;
    final accent = _trip ? const Color(0xFF0A84FF) : AppColors.violet;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Voyage / Autre projet ─────────────────────────────────
      SizedBox(
        width: double.infinity,
        child: TabSwitcher<bool>(
          tabs: const [
            (value: true,  label: 'Voyage',       icon: Icons.flight_rounded),
            (value: false, label: 'Autre projet',  icon: Icons.flag_rounded),
          ],
          selected: _trip,
          onChanged: (v) => setState(() {
            _trip = v;
            if (!v) {
              _start = null;
              _end = null;
              if (widget.existing == null) _mode = ProjectMode.savings;
            }
          }),
        ),
      ),
      const SizedBox(height: 12),
      // ── Nom + Montant côte à côte ────────────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 3, child: _CompactField(
          controller: _name,
          hint: _trip ? 'Nom du voyage (ex. Thaïlande, Japon)' : 'Nom du projet (ex. Voiture, Apport)',
          icon: _trip ? Icons.flight_rounded : Icons.flag_outlined,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(flex: 2, child: _AmountFieldCompact(controller: _amt, accentColor: accent)),
      ]),
      const SizedBox(height: 12),
      if (!_trip)
        SoftButton(
          icon: Icons.flag_rounded,
          label: 'Mois cible : ${_target.label}',
          onPressed: () async {
            final y = await pickYm(context, _target);
            if (y != null) setState(() => _target = y);
          },
        ),
      if (_trip) ...[
      Row(children: [
        Expanded(
          child: SoftButton(
            icon: Icons.flight_takeoff_rounded,
            label: _start == null ? 'Choisir la date de départ' : 'Départ : ${_fd(_start!)}',
            onPressed: _pickDates,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: SoftButton(
            icon: Icons.flight_land_rounded,
            label: _end == null ? 'Choisir la date de retour' : 'Retour : ${_fd(_end!)}',
            onPressed: _pickDates,
          ),
        ),
      ]),
      const SizedBox(height: 8),
      if (_start == null)
        SoftButton(
          icon: Icons.calendar_month_rounded,
          label: 'Pas de dates précises — mois : ${_target.label}',
          onPressed: () async {
            final y = await pickYm(context, _target);
            if (y != null) setState(() => _target = y);
          },
        )
      else
        Text(
            'Voyage de $days jour${days > 1 ? 's' : ''} en ${_target.longName.toLowerCase()} ${_target.year}.'
            '${d.hasAE ? ' Vos passages clients pendant ces dates sont retirés.' : ''}',
            style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
      ],
      if (_trip && d.isCouple && d.hasAE) ...[
        const SizedBox(height: 12),
        const Text('Qui part ?', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        PillSelector<int>.row(
          items: [
            const PillItem(0, 'Les deux', icon: Icons.people_rounded),
            for (final p in [1, 2])
              PillItem(p, d.personName(p), icon: Icons.person_rounded),
          ],
          selected: _who,
          onChanged: (p) => setState(() => _who = p),
        ),
      ],
      const SizedBox(height: 14),
      const Text('Financement', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      TabSwitcher<ProjectMode>(
        tabs: <({ProjectMode value, String label, IconData? icon})>[
          (value: ProjectMode.expense, label: _trip ? 'Payer sur place' : "Payer d'un coup", icon: Icons.credit_card_rounded),
          (value: ProjectMode.savings, label: 'Épargner avant', icon: Icons.savings_rounded),
        ],
        selected: _mode,
        onChanged: (m) => setState(() => _mode = m),
      ),
      const SizedBox(height: 8),
      Text(
        expense
            ? (_trip
                ? 'Budget réservé pour le mois du voyage — tu notes tes dépenses sur place.'
                : 'Montant déduit du solde au mois prévu.')
            : (_trip
                ? 'On calcule une épargne mensuelle pour que tout soit prêt à l\'arrivée.'
                : 'Épargne mensuelle calculée pour atteindre l\'objectif.'),
        style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.35),
      ),
      if (widget.existing != null) ...[
        const SizedBox(height: 8),
        const Text(
            'Les dépenses déjà notées restent liées au projet.',
            style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: widget.existing == null ? (_trip ? 'Créer le voyage' : 'Créer le projet') : 'Enregistrer',
        onSave: () => _trySave(context),
      ),
    ]);
  }
}

// ---------------- Proposition de congés pour un voyage ----------------
class _TripLeaveSheet extends ConsumerStatefulWidget {
  final String tripName;
  final Map<Ym, int> joursParMois; // jours travaillés par mois pendant le voyage
  final List<LeaveType> leaveTypes;
  final DateTime tripStart;
  final DateTime tripEnd;
  const _TripLeaveSheet({
    required this.tripName,
    required this.joursParMois,
    required this.leaveTypes,
    required this.tripStart,
    required this.tripEnd,
  });
  @override
  ConsumerState<_TripLeaveSheet> createState() => _TripLeaveSheetState();
}

class _TripLeaveSheetState extends ConsumerState<_TripLeaveSheet> {
  // Pour chaque mois : répartition par type de congé (typeId -> jours)
  late Map<Ym, Map<String, int>> _repartition;
  late Map<Ym, int> _totalParMois;

  @override
  void initState() {
    super.initState();
    _totalParMois = Map.from(widget.joursParMois);
    _computeRepartition();
  }

  void _computeRepartition() {
    final d = ref.read(appProvider);
    final types = [...widget.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    _repartition = {};

    for (final entry in _totalParMois.entries) {
      final ym = entry.key;
      int remaining = entry.value;
      _repartition[ym] = {};

      for (final lt in types) {
        if (remaining <= 0) break;
        // Solde disponible ce mois
        double bal = lt.initialBalance;
        var cur = d.startYm;
        while (cur.index < ym.index) {
          bal += lt.accrualPerMonth;
          final posed = d.leaveEntries
              .where((e) => e.leaveTypeId == lt.id && e.month == cur && e.note != '__solde__')
              .fold(0.0, (s, e) => s + e.days);
          bal -= posed;
          cur = cur.add(1);
        }
        bal += lt.accrualPerMonth;
        final dispo = bal.floor().clamp(0, remaining);
        if (dispo > 0) {
          _repartition[ym]![lt.id] = dispo;
          remaining -= dispo;
        }
      }
      // Si remaining > 0 : pas assez de solde
      if (remaining > 0 && types.isNotEmpty) {
        _repartition[ym]![types.first.id] = (_repartition[ym]![types.first.id] ?? 0) + remaining;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final types = [...widget.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    final totalJours = _totalParMois.values.fold(0, (a, b) => a + b);
    final n = ref.read(appProvider.notifier);

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Résumé ───────────────────────────────────────────────
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.violet.withAlpha(15),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(children: [
          const Text('✈️', style: TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.tripName,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            Text(
              '${_fmtDate(widget.tripStart)} → ${_fmtDate(widget.tripEnd)} · $totalJours jour${totalJours > 1 ? 's' : ''} travaillé${totalJours > 1 ? 's' : ''} à couvrir',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
            ),
          ])),
        ]),
      ),
      const SizedBox(height: 14),
      // ── Répartition par mois ──────────────────────────────────
      for (final entry in _totalParMois.entries) ...[
        Text(
          entry.key.longName,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.muted),
        ),
        const SizedBox(height: 6),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 14),
          child: Column(children: [
            for (final lt in types) ...[
              Builder(builder: (_) {
                final posed = _repartition[entry.key]?[lt.id] ?? 0;
                final d = ref.read(appProvider);
                // Calculer le dispo
                double bal = lt.initialBalance;
                var cur = d.startYm;
                while (cur.index < entry.key.index) {
                  bal += lt.accrualPerMonth;
                  final p = d.leaveEntries
                      .where((e) => e.leaveTypeId == lt.id && e.month == cur && e.note != '__solde__')
                      .fold(0.0, (s, e) => s + e.days);
                  bal -= p;
                  cur = cur.add(1);
                }
                bal += lt.accrualPerMonth;
                final dispo = bal.floor().clamp(0, 999);
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(children: [
                    CircleAvatar(radius: 7, backgroundColor: Color(lt.colorValue)),
                    const SizedBox(width: 10),
                    Expanded(child: Text(lt.name,
                        style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text('dispo : $dispo j', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    const SizedBox(width: 10),
                    // Sélecteur de jours
                    Row(children: [
                      GestureDetector(
                        onTap: posed > 0 ? () => setState(() {
                          _repartition[entry.key]![lt.id] = posed - 1;
                        }) : null,
                        child: Container(
                          width: 28, height: 28,
                          decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(8)),
                          child: const Icon(Icons.remove_rounded, size: 14),
                        ),
                      ),
                      SizedBox(width: 32, child: Center(
                        child: Text('$posed j', style: TextStyle(
                            fontWeight: FontWeight.w800,
                            color: posed > dispo ? AppColors.danger : Color(lt.colorValue))),
                      )),
                      GestureDetector(
                        onTap: () => setState(() {
                          _repartition[entry.key]![lt.id] = posed + 1;
                        }),
                        child: Container(
                          width: 28, height: 28,
                          decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(8)),
                          child: const Icon(Icons.add_rounded, size: 14),
                        ),
                      ),
                    ]),
                  ]),
                );
              }),
            ],
          ]),
        ),
        const SizedBox(height: 10),
      ],
      const SizedBox(height: 6),
      // ── Boutons ───────────────────────────────────────────────
      GradientButton(
        label: 'Poser ces congés',
        onPressed: () {
          for (final moisEntry in _repartition.entries) {
            for (final typeEntry in moisEntry.value.entries) {
              if (typeEntry.value > 0) {
                n.setLeaveEntry(typeEntry.key, moisEntry.key, typeEntry.value.toDouble());
              }
            }
          }
          Navigator.pop(context);
          snack(context, '✅ Congés posés pour ${widget.tripName}');
        },
      ),
      const SizedBox(height: 8),
      SoftButton(
        icon: Icons.skip_next_rounded,
        label: 'Ne pas poser de congés maintenant',
        onPressed: () => Navigator.pop(context),
      ),
    ]);
  }

  String _fmtDate(DateTime d) => '${d.day}/${d.month}/${d.year}';
}

// ---------------- Réduction de budgets pour financer un projet ----------------
class _BudgetReduceSheet extends ConsumerStatefulWidget {
  final String projectName;
  final double monthlyNeeded;
  final double disponible;
  final double shortage;
  final int months;
  const _BudgetReduceSheet({
    required this.projectName,
    required this.monthlyNeeded,
    required this.disponible,
    required this.shortage,
    required this.months,
  });
  @override
  ConsumerState<_BudgetReduceSheet> createState() => _BudgetReduceSheetState();
}

class _BudgetReduceSheetState extends ConsumerState<_BudgetReduceSheet> {
  // réductions choisies par l'utilisateur : budgetId -> montant réduit
  late Map<String, double> _reductions;

  @override
  void initState() {
    super.initState();
    _reductions = {
      for (final b in ref.read(appProvider).budgets) b.id: 0.0,
    };
  }

  double get _totalReduced => _reductions.values.fold(0.0, (a, b) => a + b);
  double get _remaining => widget.shortage - _totalReduced;

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final budgets = d.budgets.where((b) => b.amount > 0).toList();
    final covered = _remaining <= 0.5;

    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.75,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // ── Résumé ────────────────────────────────────────────
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.warning.withAlpha(18),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppColors.warning.withAlpha(60)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Text('⚠️', style: TextStyle(fontSize: 18)),
                const SizedBox(width: 8),
                Expanded(child: Text(
                  '${eur(widget.monthlyNeeded)}/mois nécessaires pour "${widget.projectName}"',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
                )),
              ]),
              const SizedBox(height: 6),
              Text(
                'Il manque ${eur(widget.shortage)}/mois sur votre marge actuelle (${eur(widget.disponible)}/mois disponibles).',
                style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
              ),
              const SizedBox(height: 4),
              Text(
                'Choisissez les budgets à réduire pour dégager cette marge :',
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
              ),
            ]),
          ),
          const SizedBox(height: 14),

          // ── Barre de progression ──────────────────────────────
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(
                covered ? '✅ Objectif atteint !' : 'Marge dégagée',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 13.5,
                  color: covered ? AppColors.success : context.textColor,
                ),
              ),
              Text(
                '${eur(_totalReduced)} / ${eur(widget.shortage)}',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                  color: covered ? AppColors.success : AppColors.warning,
                ),
              ),
            ]),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: SizedBox(
                height: 14,
                child: Stack(children: [
                  // fond
                  Container(color: context.fieldColor),
                  // remplissage animé
                  AnimatedFractionallySizedBox(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOut,
                    widthFactor: (_totalReduced / widget.shortage).clamp(0.0, 1.0),
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: covered
                          ? [AppColors.success, AppColors.success]
                          : [AppColors.warning, AppColors.warning.withGreen(200)]),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 6),
            if (!covered)
              Text('Encore ${eur(_remaining)}/mois à dégager',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12)),
          ]),
          const SizedBox(height: 14),

          // ── Liste des budgets avec slider ─────────────────────
          for (final b in budgets) ...[
            _BudgetSliderTile(
              budget: b,
              reduction: _reductions[b.id] ?? 0,
              onChanged: (v) => setState(() => _reductions[b.id] = v),
              categoryName: d.category(b.categoryId)?.name ?? b.id,
              categoryColor: d.category(b.categoryId) != null
                  ? Color(d.category(b.categoryId)!.colorValue)
                  : AppColors.violet,
            ),
            const SizedBox(height: 8),
          ],

          const SizedBox(height: 8),

          // ── Boutons ───────────────────────────────────────────
          if (covered) ...[
            FilledButton(
              onPressed: () {
                // Appliquer les réductions
                final n = ref.read(appProvider.notifier);
                for (final b in budgets) {
                  final r = _reductions[b.id] ?? 0;
                  if (r > 0.5) n.setBudgetAmount(b.id, b.amount - r);
                }
                Navigator.pop(context, true);
              },
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
              child: const Text('Appliquer les réductions et créer le voyage',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ] else ...[
            OutlinedButton(
              onPressed: () => Navigator.pop(context, true),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Créer quand même sans modifier les budgets',
                  style: TextStyle(fontWeight: FontWeight.w600)),
            ),
          ],
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
        ],
      ),
    );
  }
}

class _BudgetSliderTile extends StatelessWidget {
  final Budget budget;
  final double reduction;
  final ValueChanged<double> onChanged;
  final String categoryName;
  final Color categoryColor;
  const _BudgetSliderTile({
    required this.budget,
    required this.reduction,
    required this.onChanged,
    required this.categoryName,
    required this.categoryColor,
  });

  @override
  Widget build(BuildContext context) {
    final newAmount = budget.amount - reduction;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 10, height: 10,
            decoration: BoxDecoration(color: categoryColor, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(categoryName,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
          Text(
            reduction > 0
                ? '${eur(budget.amount)} → ${eur(newAmount)}'
                : eur(budget.amount),
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 13,
              color: reduction > 0 ? AppColors.warning : AppColors.muted,
            ),
          ),
        ]),
        if (reduction > 0) ...[
          const SizedBox(height: 2),
          Text('Réduction : −${eur(reduction)}/mois',
              style: const TextStyle(color: AppColors.warning, fontSize: 11.5, fontWeight: FontWeight.w600)),
        ],
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 3,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
            activeTrackColor: categoryColor,
            thumbColor: categoryColor,
            inactiveTrackColor: categoryColor.withAlpha(40),
          ),
          child: Slider(
            value: reduction,
            min: 0,
            max: budget.amount,
            divisions: budget.amount > 10 ? (budget.amount / 5).round() : null,
            onChanged: (v) => onChanged((v * 2).round() / 2), // arrondi au 0.5 €
          ),
        ),
      ]),
    );
  }
}

// ---------------- Modifier un budget (tous les mois ou un seul mois) ----------------
class EditBudgetSheet extends ConsumerStatefulWidget {
  final String budgetId;
  final Ym month;
  const EditBudgetSheet({super.key, required this.budgetId, required this.month});
  @override
  ConsumerState<EditBudgetSheet> createState() => _EditBudgetState();
}

class _EditBudgetState extends ConsumerState<EditBudgetSheet> {
  bool _onlyThisMonth = false;
  late final TextEditingController _amt;
  late String _emojiSel;
  late int _colorSel;
  late ReceiptDayRule _debitDay;

  Budget? _find() {
    for (final b in ref.read(appProvider).budgets) {
      if (b.id == widget.budgetId) return b;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    final b = _find();
    _amt = TextEditingController(text: (b?.amount ?? 0).round().toString());
    final cat = b == null ? null : ref.read(appProvider).category(b.categoryId);
    _emojiSel = cat?.emoji ?? '💰';
    _colorSel = cat?.colorValue ?? AppColors.palette[2].value;
    _debitDay = b?.debitDay ?? ReceiptDayRule.none;
  }

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  void _setMode(bool only) {
    final b = _find();
    if (b == null) return;
    setState(() {
      _onlyThisMonth = only;
      _amt.text = (only ? b.amountIn(widget.month) : b.amount).round().toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    final b = ref.watch(appProvider).budgets.where((x) => x.id == widget.budgetId).firstOrNull;
    if (b == null) return const SizedBox.shrink();
    final n = ref.read(appProvider.notifier);
    final overridden = b.hasOverride(widget.month);
    final accent = Color(_colorSel);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: accent.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Montant ───────────────────────────────────────────────
      _AmountFieldCompact(controller: _amt, accentColor: accent),
      const SizedBox(height: 12),
      // ── Portée ────────────────────────────────────────────────
      TabSwitcher<bool>(
        tabs: <({bool value, String label, IconData? icon})>[
          (value: false, label: 'Pour toujours', icon: Icons.all_inclusive_rounded),
          (value: true,  label: 'En ${widget.month.label} seulement', icon: Icons.event_rounded),
        ],
        selected: _onlyThisMonth,
        onChanged: _setMode,
      ),
      const SizedBox(height: 6),
      Row(children: [
        const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
        const SizedBox(width: 5),
        Expanded(child: Text(
          _onlyThisMonth
              ? 'Tous les autres mois gardent leur budget habituel — seul ${widget.month.longName.toLowerCase()} sera différent.'
              : 'Ce nouveau montant s\'appliquera à tous les mois à venir'
                  '${overridden ? ' (sauf ${widget.month.longName.toLowerCase()} qui a déjà été modifié)' : ''}.',
          style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
        )),
      ]),
      if (ref.watch(appProvider).isCouple) ...[
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Un budget par personne', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(b.person != 0 ? 'Chaque personne gère son budget séparément.' : 'Un seul budget partagé entre les deux.'),
          value: b.person != 0,
          onChanged: (v) {
            n.setBudgetSeparate(b.categoryId, v);
            Navigator.pop(context);
          },
        ),
      ],
      const SizedBox(height: 16),
      const Text('Icône et couleur', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      StylePicker(
        emoji: _emojiSel,
        color: _colorSel,
        onEmoji: (e) => setState(() => _emojiSel = e),
        onColor: (c) => setState(() => _colorSel = c),
      ),
      // ── [Mode dev] Règle de débit du budget ──────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 16),
        const Text('Date de débit par défaut',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 4),
        const Text(
          'S\'applique à toutes les dépenses de ce budget. '
          'Une dépense avec sa propre date de débit la garde.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
        ),
        const SizedBox(height: 10),
        _BudgetDebitDayPicker(
          debitDay: _debitDay,
          onChanged: (r) => setState(() => _debitDay = r),
        ),
      ],
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: 'Enregistrer',
        onSave: () {
          final v = parseAmount(_amt.text);
          if (v == null || v < 0) return;
          if (_onlyThisMonth) {
            n.setBudgetOverride(b.id, widget.month, v);
          } else {
            n.setBudgetAmount(b.id, v);
          }
          n.setCategoryStyle(b.categoryId, _emojiSel, _colorSel);
          if (ref.read(devModeProvider)) {
            n.setBudgetDebitDay(b.id, _debitDay);
          }
          Navigator.pop(context);
        },
      ),
      if (overridden) ...[
        const SizedBox(height: 10),
        SoftButton(
          label: 'Annuler la modification de ${widget.month.label} — revenir au montant habituel',
          onPressed: () {
            n.setBudgetOverride(b.id, widget.month, null);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}

// ---------------- Couple : noms des deux conjoints ----------------
class CoupleSheet extends ConsumerStatefulWidget {
  const CoupleSheet({super.key});
  @override
  ConsumerState<CoupleSheet> createState() => _CoupleState();
}

class _CoupleState extends ConsumerState<CoupleSheet> {
  late final TextEditingController _p1;
  late final TextEditingController _p2;

  @override
  void initState() {
    super.initState();
    final u = ref.read(appProvider).user;
    _p1 = TextEditingController(text: u.isCouple ? u.person1 : '');
    _p2 = TextEditingController(text: u.isCouple ? u.person2 : '');
  }

  @override
  void dispose() {
    _p1.dispose();
    _p2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCouple = ref.watch(appProvider).isCouple;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Drag handle ──────────────────────────────────────────
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(color: AppColors.violet.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      // ── Info ─────────────────────────────────────────────────
      Row(children: [
        const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
        const SizedBox(width: 5),
        Expanded(child: Text(
          isCouple
              ? 'Modifiez les prénoms affichés sur les budgets et les dépenses.'
              : 'Vous pourrez séparer certains budgets (un par personne) et garder les autres en commun.',
          style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
        )),
      ]),
      const SizedBox(height: 14),
      // ── Prénom 1 + Prénom 2 côte à côte ─────────────────────
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(child: _CompactField(
          controller: _p1,
          hint: 'Vous',
          icon: Icons.person_outline_rounded,
          textCapitalization: TextCapitalization.words,
          onChanged: (_) {},
        )),
        const SizedBox(width: 8),
        Expanded(child: _CompactField(
          controller: _p2,
          hint: 'Conjoint(e)',
          icon: Icons.person_outline_rounded,
          textCapitalization: TextCapitalization.words,
          onChanged: (_) {},
        )),
      ]),
      const SizedBox(height: 16),
      _CancelSaveRow(
        saveLabel: isCouple ? 'Enregistrer' : 'Activer le mode couple',
        onSave: () {
          final a = _p1.text.trim();
          final b = _p2.text.trim();
          if (a.isEmpty || b.isEmpty) {
            snack(context, 'Renseignez les deux prénoms');
            return;
          }
          if (a.toLowerCase() == b.toLowerCase()) {
            snack(context, 'Les deux prénoms doivent être différents');
            return;
          }
          ref.read(appProvider.notifier).setCouple(true, person1: a, person2: b);
          Navigator.pop(context);
        },
      ),
    ]);
  }
}


// ── [Mode dev] Sélecteur de date de débit ────────────────────────────────────
/// Permet de choisir la date à laquelle une dépense sera débitée.
/// Raccourcis : "5 du mois prochain", "dernier jour ouvré", calendrier libre.
class _DebitDatePicker extends StatelessWidget {
  final DateTime expenseDate; // date de la dépense (référence pour les raccourcis)
  final DateTime? debitDate;
  final ValueChanged<DateTime?> onChanged;
  const _DebitDatePicker({required this.expenseDate, required this.debitDate, required this.onChanged});

  DateTime _fifthNextMonth() {
    final next = DateTime(expenseDate.year, expenseDate.month + 1, 5);
    return next;
  }

  DateTime _lastWorkingDayOfMonth() {
    final lastDay = DateTime(expenseDate.year, expenseDate.month + 1, 0).day;
    var d = DateTime(expenseDate.year, expenseDate.month, lastDay);
    while (d.weekday == DateTime.saturday || d.weekday == DateTime.sunday) {
      d = d.subtract(const Duration(days: 1));
    }
    return d;
  }

  String _fmt(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    final fifth = _fifthNextMonth();
    final lastWorking = _lastWorkingDayOfMonth();
    final hasFifth = debitDate != null && _isSameDay(debitDate!, fifth);
    final hasLast = debitDate != null && _isSameDay(debitDate!, lastWorking);
    final hasCustom = debitDate != null && !hasFifth && !hasLast;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: debitDate != null
            ? tint(AppColors.violet, .08)
            : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: debitDate != null ? AppColors.violet.withAlpha(80) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_outlined, size: 15,
              color: debitDate != null ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            debitDate != null ? 'Débit le ${_fmt(debitDate!)}' : 'Date de débit (optionnel)',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: debitDate != null ? AppColors.violet : AppColors.muted,
            ),
          ),
          if (debitDate != null) ...[
            const Spacer(),
            GestureDetector(
              onTap: () => onChanged(null),
              child: const Icon(Icons.close_rounded, size: 18, color: AppColors.muted),
            ),
          ],
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          // Raccourci 1 : le 5 du mois prochain
          _DebitChip(
            label: '5 du mois prochain',
            selected: hasFifth,
            onTap: () => onChanged(hasFifth ? null : fifth),
          ),
          // Raccourci 2 : dernier jour ouvré du mois
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: hasLast,
            onTap: () => onChanged(hasLast ? null : lastWorking),
          ),
          // Raccourci 3 : calendrier libre
          _DebitChip(
            label: hasCustom ? _fmt(debitDate!) : 'Autre date…',
            selected: hasCustom,
            icon: Icons.calendar_today_rounded,
            onTap: () async {
              final now = DateTime.now();
              final picked = await showDatePicker(
                context: context,
                initialDate: debitDate ?? expenseDate.add(const Duration(days: 3)),
                firstDate: DateTime(now.year - 1),
                lastDate: DateTime(now.year + 2),
              );
              if (picked != null) onChanged(picked);
            },
          ),
        ]),
      ]),
    );
  }
}

class _DebitChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;
  const _DebitChip({required this.label, required this.selected, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppColors.violet.withAlpha(25) : context.fieldColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.violet : context.trackColor,
            width: 1.5,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: selected ? AppColors.violet : AppColors.muted),
            const SizedBox(width: 5),
          ],
          Text(label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? AppColors.violet : context.textColor,
              )),
        ]),
      ),
    );
  }
}


// ── [Mode dev] Sélecteur de date de réception (revenus récurrents) ────────────
class _ReceiptDayPicker extends StatefulWidget {
  final ReceiptDayRule receiptDay;
  final ValueChanged<ReceiptDayRule> onChanged;
  const _ReceiptDayPicker({required this.receiptDay, required this.onChanged});

  @override
  State<_ReceiptDayPicker> createState() => _ReceiptDayPickerState();
}

class _ReceiptDayPickerState extends State<_ReceiptDayPicker> {
  late TextEditingController _dayCtrl;

  @override
  void initState() {
    super.initState();
    _dayCtrl = TextEditingController(
      text: widget.receiptDay.kind == ReceiptDayKind.fixedDay
          ? widget.receiptDay.day.toString()
          : '',
    );
  }

  @override
  void dispose() {
    _dayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rule = widget.receiptDay;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: rule.kind != ReceiptDayKind.none
            ? tint(AppColors.teal, .08)
            : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: rule.kind != ReceiptDayKind.none
              ? AppColors.teal.withAlpha(80)
              : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_rounded, size: 15,
              color: rule.kind != ReceiptDayKind.none ? AppColors.teal : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            _ruleLabel(rule),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: rule.kind != ReceiptDayKind.none ? AppColors.teal : AppColors.muted,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _DebitChip(
            label: 'Aucune règle',
            selected: rule.kind == ReceiptDayKind.none,
            onTap: () {
              widget.onChanged(ReceiptDayRule.none);
              setState(() => _dayCtrl.text = '');
            },
          ),
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: rule.kind == ReceiptDayKind.lastWorkingDay,
            onTap: () => widget.onChanged(
                const ReceiptDayRule(kind: ReceiptDayKind.lastWorkingDay)),
          ),
        ]),
        const SizedBox(height: 10),
        // Saisie d'un jour fixe
        Row(children: [
          Expanded(
            child: TextField(
              controller: _dayCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Jour fixe du mois (ex. 26)',
                suffixText: 'du mois',
                filled: true,
                fillColor: rule.kind == ReceiptDayKind.fixedDay
                    ? AppColors.teal.withAlpha(15)
                    : null,
              ),
              onChanged: (v) {
                final d = int.tryParse(v);
                if (d != null && d >= 1 && d <= 31) {
                  widget.onChanged(ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: d));
                }
              },
            ),
          ),
        ]),
        if (rule.kind == ReceiptDayKind.fixedDay)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Le salaire sera reçu le ${rule.day} de chaque mois.',
              style: const TextStyle(color: AppColors.teal, fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
      ]),
    );
  }

  String _ruleLabel(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => 'Date de réception (optionnel)',
        ReceiptDayKind.fixedDay => 'Reçu le ${r.day} du mois',
        ReceiptDayKind.lastWorkingDay => 'Reçu le dernier jour ouvré',
      };
}


// ── [Mode dev] Sélecteur de règle de débit pour un budget ────────────────────
class _BudgetDebitDayPicker extends StatefulWidget {
  final ReceiptDayRule debitDay;
  final ValueChanged<ReceiptDayRule> onChanged;
  const _BudgetDebitDayPicker({required this.debitDay, required this.onChanged});

  @override
  State<_BudgetDebitDayPicker> createState() => _BudgetDebitDayPickerState();
}

class _BudgetDebitDayPickerState extends State<_BudgetDebitDayPicker> {
  late TextEditingController _dayCtrl;

  @override
  void initState() {
    super.initState();
    _dayCtrl = TextEditingController(
      text: widget.debitDay.kind == ReceiptDayKind.fixedDay
          ? widget.debitDay.day.toString()
          : '',
    );
  }

  @override
  void dispose() {
    _dayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rule = widget.debitDay;
    final active = rule.kind != ReceiptDayKind.none;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: active ? tint(AppColors.violet, .08) : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: active ? AppColors.violet.withAlpha(80) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_outlined, size: 15,
              color: active ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            _ruleLabel(rule),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: active ? AppColors.violet : AppColors.muted,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _DebitChip(
            label: 'Aucune règle',
            selected: rule.kind == ReceiptDayKind.none,
            onTap: () {
              widget.onChanged(ReceiptDayRule.none);
              setState(() => _dayCtrl.text = '');
            },
          ),
          _DebitChip(
            label: '5 du mois prochain',
            selected: rule.kind == ReceiptDayKind.fixedDay && rule.day == 5,
            onTap: () {
              widget.onChanged(const ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: 5));
              setState(() => _dayCtrl.text = '5');
            },
          ),
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: rule.kind == ReceiptDayKind.lastWorkingDay,
            onTap: () => widget.onChanged(
                const ReceiptDayRule(kind: ReceiptDayKind.lastWorkingDay)),
          ),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _dayCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Autre jour fixe (ex. 10)',
                suffixText: 'du mois',
                filled: true,
                fillColor: rule.kind == ReceiptDayKind.fixedDay
                    ? AppColors.violet.withAlpha(15)
                    : null,
              ),
              onChanged: (v) {
                final d = int.tryParse(v);
                if (d != null && d >= 1 && d <= 31) {
                  widget.onChanged(ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: d));
                }
              },
            ),
          ),
        ]),
        if (active)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              _ruleExplain(rule),
              style: const TextStyle(
                  color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
            ),
          ),
      ]),
    );
  }

  String _ruleLabel(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => 'Pas de règle (débit immédiat)',
        ReceiptDayKind.fixedDay => r.day == 5
            ? 'Débité le 5 du mois prochain'
            : 'Débité le ${r.day} du mois',
        ReceiptDayKind.lastWorkingDay => 'Débité le dernier jour ouvré',
      };

  String _ruleExplain(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => '',
        ReceiptDayKind.fixedDay => r.day == 5
            ? 'Toutes les dépenses de ce budget seront comptées dans le mois suivant (débit le 5).'
            : 'Toutes les dépenses de ce budget seront débitées le ${r.day} du mois.',
        ReceiptDayKind.lastWorkingDay =>
            'Toutes les dépenses de ce budget seront débitées le dernier jour ouvré du mois.',
      };
}
