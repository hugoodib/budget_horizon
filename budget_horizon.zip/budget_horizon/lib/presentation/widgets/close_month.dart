import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:math';
import '../../core/money.dart';
import '../../domain/business.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';

/// Mois à clôturer en priorité : le plus ancien mois non clôturé jusqu'au mois courant.
Ym closeTargetMonth(AppData d, Ym now) {
  for (var i = d.startYm.index; i < now.index; i++) {
    final m = Ym.fromIndex(i);
    if (!d.isClosed(m)) return m;
  }
  return now;
}

/// Où en est-on dans le mois ? (jours restants, ou mois déjà terminé)
({int? daysLeft, bool overdue}) monthTiming(Ym month) {
  final today = DateTime.now();
  final real = Ym.of(today);
  if (month == real) {
    final last = DateTime(today.year, today.month + 1, 0).day;
    return (daysLeft: last - today.day, overdue: false);
  }
  if (month.isBefore(real)) return (daysLeft: null, overdue: true);
  return (daysLeft: null, overdue: false);
}

/// La clôture est-elle urgente (fin de mois proche ou mois dépassé) ?
bool closeIsDue(AppData d, Ym now) {
  final t = closeTargetMonth(d, now);
  if (d.isClosed(t)) return false;
  final tm = monthTiming(t);
  return tm.overdue || (tm.daysLeft != null && tm.daysLeft! <= 3);
}

void confirmCloseMonth(BuildContext context, WidgetRef ref, Ym ym) {
  final d = ref.read(appProvider);
  // Capturés maintenant : le bouton « Annuler » du message reste utilisable
  // même si l'on change d'onglet entre-temps.
  final notifier = ref.read(appProvider.notifier);
  final monthState = ref.read(budgetMonthProvider.notifier);
  final missed = d.projects
      .where((p) =>
          !p.isExpense &&
          !p.contributions.containsKey(ym.key) &&
          !ym.isBefore(p.startYm) &&
          ym.isBefore(p.targetYm))
      .map((p) => p.name)
      .toList();
  showQuickDialog(
    context: context,
    builder: (ctx) {
      final trips = d.projects.where((p) => p.targetYm == ym).toList();
      final unpaid = (d.hasAE && kInvoicesEnabled) ? d.unpaidReceivedIn(ym) : <InvoiceView>[];
      final uncheckedFixed = d.fixedExpenses.where((f) => f.activeIn(ym) && !f.isChecked(ym)).toList();
      final uncheckedRecurring =
          d.recurringIncomes.where((r) => r.activeIn(ym) && !r.isChecked(ym)).toList();
      final uncheckedOneOff = d.extraIncomes(ym).where((i) => !i.checked).toList();
      final uncheckedTx = d.transactionsIn(ym).where((t) => !t.checked).toList();
      final tripGain = trips.fold(0.0, (s, p) => s + max(0.0, p.target - d.tripSpentIn(ym, p.id)));
      final total = d.plannedIn(ym) - d.spentIn(ym) + tripGain;
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        title: Text('Clôturer ${ym.longName} ?'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final b in d.sortedBudgets)
              Builder(builder: (_) {
                final s = d.spentForBudget(b, ym);
                final saving = b.amountIn(ym) - s;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(children: [
                    Expanded(
                        child: Text(
                            '${d.budgetTitle(b)}\nPrévu ${eur(b.amountIn(ym))} · Dépensé ${eur(s)}',
                            style: const TextStyle(fontSize: 13))),
                    Text(saving >= 0 ? 'Économie ${eur(saving)}' : 'Dépassement ${eur(-saving)}',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: saving >= 0 ? AppColors.success : AppColors.warning)),
                  ]),
                );
              }),
            for (final p in trips)
              Builder(builder: (_) {
                final s = d.tripSpentIn(ym, p.id);
                final gain = p.target - s;
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(children: [
                    Expanded(
                        child: Text('✈️ ${p.name}\nBudget ${eur(p.target)} · Dépensé ${eur(s)}',
                            style: const TextStyle(fontSize: 13))),
                    Text(gain >= 0 ? 'Remis ${eur(gain)}' : 'Dépassement ${eur(-gain)}',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: gain >= 0 ? AppColors.success : AppColors.warning)),
                  ]),
                );
              }),
            if (unpaid.isNotEmpty) ...[
              const Divider(),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('⚠️ Factures non payées',
                    style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.warning)),
              ),
              for (final v in unpaid)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(
                        child: Text('${v.client.name}${v.ym != ym ? ' · facture de ${v.ym.longName.toLowerCase()}' : ''}',
                            style: const TextStyle(fontSize: 13))),
                    Text(eur(v.amount), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                ),
              const SizedBox(height: 4),
              Text(
                  'Elles seront reportées en ${ym.add(1).longName.toLowerCase()} (retard de paiement) et ne comptent pas dans votre salaire de ${ym.longName.toLowerCase()}. Déjà payées ? Annulez et cochez « payée » dans Factures.',
                  style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
            ],
            if (uncheckedFixed.isNotEmpty) ...[
              const Divider(),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('⚠️ Charges fixes non pointées',
                    style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.warning)),
              ),
              for (final f in uncheckedFixed)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(child: Text(f.name, style: const TextStyle(fontSize: 13))),
                    Text(eur(f.amount), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                ),
              const SizedBox(height: 4),
              Text(
                  'Vous ne les avez pas cochées comme débitées : si vous clôturez, elles seront retirées de ${ym.longName.toLowerCase()} et ajoutées à ${ym.add(1).longName.toLowerCase()} à la place.',
                  style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
            ],
            if (uncheckedRecurring.isNotEmpty || uncheckedOneOff.isNotEmpty) ...[
              const Divider(),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('⚠️ Revenus non pointés',
                    style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.warning)),
              ),
              for (final r in uncheckedRecurring)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(child: Text(r.label, style: const TextStyle(fontSize: 13))),
                    Text(eur(r.amountIn(ym)), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                ),
              for (final i in uncheckedOneOff)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(
                        child:
                            Text(i.label.isEmpty ? i.kind.label : i.label, style: const TextStyle(fontSize: 13))),
                    Text(eur(i.amount), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                ),
              const SizedBox(height: 4),
              Text(
                  'Vous ne les avez pas cochés comme reçus : si vous clôturez, ils seront retirés de ${ym.longName.toLowerCase()} et ajoutés à ${ym.add(1).longName.toLowerCase()} à la place.',
                  style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
            ],
            if (uncheckedTx.isNotEmpty) ...[
              const Divider(),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('⚠️ Dépenses non pointées',
                    style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.warning)),
              ),
              for (final t in uncheckedTx)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(child: Text(t.description, style: const TextStyle(fontSize: 13))),
                    Text(eur(t.amount), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                ),
              const SizedBox(height: 4),
              Text(
                  'Vous ne les avez pas pointées comme débitées (courses, charges, dépenses de voyage...) : si vous clôturez, elles seront retirées de ${ym.longName.toLowerCase()} et ajoutées à ${ym.add(1).longName.toLowerCase()} à la place.',
                  style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
            ],
            const Divider(),
            Text(
                total >= 0
                    ? 'Économies remises dans votre solde : ${eur(total)}'
                    : 'Dépassement : ${eur(-total)}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Text('Vous passerez ensuite à ${ym.add(1).longName}.',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            if (missed.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(
                  'Versement non marqué (${missed.join(', ')}) : il ne sera pas compté. Marquez-le d\'abord dans Voyages.',
                  style: const TextStyle(color: AppColors.warning, fontSize: 13, fontWeight: FontWeight.w600)),
            ],
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              ref.read(appProvider.notifier).closeMonth(ym,
                  deferFixedIds: uncheckedFixed.map((f) => f.id).toList(),
                  deferRecurringIds: uncheckedRecurring.map((r) => r.id).toList(),
                  deferOneOffIncomeIds: uncheckedOneOff.map((i) => i.id).toList(),
                  deferTransactionIds: uncheckedTx.map((t) => t.id).toList());
              // Bascule sur le mois suivant
              ref.read(budgetMonthProvider.notifier).state = ym.add(1);
              Navigator.pop(ctx);
              snack(
                context,
                '${ym.longName} clôturé · vous êtes maintenant en ${ym.add(1).longName}',
                actionLabel: 'Annuler',
                onAction: () {
                  notifier.reopenMonth(ym);
                  monthState.state = ym;
                },
              );
            },
            child: const Text('Clôturer'),
          ),
        ],
      );
    },
  );
}


/// Carte « Clôture du mois » : très visible, avec l'état du mois et le bouton de clôture.
class CloseMonthCard extends ConsumerWidget {
  final Ym month;
  const CloseMonthCard({super.key, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final closed = d.isClosed(month);
    final future = month.isAfter(now);
    final timing = monthTiming(month);
    final left = timing.daysLeft;
    final urgent = !closed && !future && (timing.overdue || (left != null && left <= 5));
    final prev = month.add(-1);
    final canUndoPrev = !closed && d.isClosed(prev) && prev.index >= d.startYm.index;

    if (closed) {
      final snap = d.snapshots[month.key];
      final s = snap?.savings ?? 0;
      return AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.check_circle_rounded, color: AppColors.success),
            const SizedBox(width: 8),
            Expanded(
              child: Text('${month.longName} est clôturé',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            ),
          ]),
          if (snap != null) ...[
            const SizedBox(height: 6),
            Text(
              'Prévu ${eur(snap.planned)} · Dépensé ${eur(snap.spent)}\n'
              '${s >= 0 ? 'Économie de ${eur(s)} ajoutée au solde du mois suivant.' : 'Dépassement de ${eur(-s)} déduit du mois suivant.'}',
              style: const TextStyle(color: AppColors.muted, fontSize: 13.5, height: 1.35),
            ),
          ],
          const SizedBox(height: 12),
          SoftButton(
            icon: Icons.lock_open_rounded,
            label: 'Rouvrir ${month.longName}',
            onPressed: () {
              ref.read(appProvider.notifier).reopenMonth(month);
              snack(context, '${month.longName} rouvert');
            },
          ),
        ]),
      );
    }

    if (future) {
      return AppCard(
        child: Row(children: [
          const Icon(Icons.lock_clock_rounded, color: AppColors.muted),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
                '${month.longName} n\'est pas encore en cours : vous pourrez le clôturer quand vous y serez.',
                style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
          ),
        ]),
      );
    }

    final subtitle = timing.overdue
        ? '${month.longName} est terminé : clôturez-le pour passer au mois suivant.'
        : left == null
            ? 'Quand vous avez tout noté, clôturez pour passer au mois suivant.'
            : left == 0
                ? 'Dernier jour du mois : pensez à clôturer.'
                : left <= 5
                    ? 'Plus que $left jour${left > 1 ? 's' : ''} : pensez à clôturer.'
                    : 'Fin du mois dans $left jours. Clôturez pour passer au mois suivant.';

    return AppCard(
      gradient: urgent ? brandGradient : null,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(urgent ? Icons.notifications_active_rounded : Icons.event_available_rounded,
              color: urgent ? AppColors.text : AppColors.violet),
          const SizedBox(width: 8),
          Expanded(
            child: Text('Clôturer ${month.longName}',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          ),
        ]),
        const SizedBox(height: 6),
        Text(subtitle,
            style: TextStyle(
                color: urgent ? AppColors.text : AppColors.muted, fontSize: 13.5, height: 1.35)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: urgent
              ? FilledButton.icon(
                  onPressed: () => confirmCloseMonth(context, ref, month),
                  icon: const Icon(Icons.task_alt_rounded, size: 20),
                  label: Text('Clôturer ${month.longName}',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppColors.text,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                  ),
                )
              : GradientButton(
                  label: 'Clôturer ${month.longName}',
                  icon: Icons.task_alt_rounded,
                  onPressed: () => confirmCloseMonth(context, ref, month),
                ),
        ),
        if (canUndoPrev) ...[
          const SizedBox(height: 6),
          Center(
            child: TextButton.icon(
              onPressed: () {
                ref.read(appProvider.notifier).reopenMonth(prev);
                ref.read(budgetMonthProvider.notifier).state = prev;
                snack(context, '${prev.longName} rouvert');
              },
              icon: const Icon(Icons.undo_rounded, size: 18),
              label: Text('Annuler la clôture de ${prev.longName}'),
            ),
          ),
        ],
      ]),
    );
  }
}
