import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../widgets/common.dart';
import 'balance_detail_screen.dart';

/// Détail du calcul de « Il vous restera » (solde prévu en fin de mois) : le départ, tout ce qui
/// est attendu ce mois-ci, puis le total. Page plein écran (croix pour fermer), catégories
/// repliées à l'ouverture, lignes cliquables qui mènent à l'écran concerné.
class ForecastDetailScreen extends ConsumerStatefulWidget {
  const ForecastDetailScreen({super.key});

  @override
  ConsumerState<ForecastDetailScreen> createState() => _ForecastDetailScreenState();
}

class _Group {
  final LineKind kind;
  final String emoji;
  final String title;
  final String sign;
  final Color color;
  final AppTab tab;
  const _Group(this.kind, this.emoji, this.title, this.sign, this.color, this.tab);
}

const _groups = [
  _Group(LineKind.income, '💰', 'Revenus attendus', '+', AppColors.success, AppTab.incomes),
  _Group(LineKind.fixed, '🏠', 'Charges fixes', '−', AppColors.pink, AppTab.charges),
  _Group(LineKind.budget, '🛒', 'Budgets & dépenses', '−', AppColors.warning, AppTab.budgets),
  _Group(LineKind.project, '✈️', 'Voyages & épargne', '−', AppColors.violet, AppTab.trips),
];

class _ForecastDetailScreenState extends ConsumerState<ForecastDetailScreen> {
  final Set<LineKind> _expanded = {};

  void _goTo(AppTab tab, Ym month) {
    switch (tab) {
      case AppTab.incomes:
        ref.read(incomeMonthProvider.notifier).state = month;
      case AppTab.charges:
        ref.read(chargeMonthProvider.notifier).state = month;
      case AppTab.budgets:
        ref.read(budgetMonthProvider.notifier).state = month;
      default:
        break;
    }
    ref.read(tabProvider.notifier).state = tab;
    Navigator.of(context).pop();
  }

  Widget _calcRow(String sign, String label, double value, Color color,
      {VoidCallback? onTap, bool bold = false, bool showSign = true}) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
        child: Row(children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color.withAlpha(34), shape: BoxShape.circle),
            child: Text(sign, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 15)),
          ),
          const SizedBox(width: 10),
          Expanded(
              child: Text(label,
                  style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: 14.5))),
          Text(showSign ? eur(value, sign: true) : eur(value),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: bold ? 17 : 15, color: color)),
          if (onTap != null) Icon(Icons.chevron_right_rounded, size: 18, color: context.mutedColor),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final fc = ref.watch(forecastProvider);
    final now = ref.watch(nowProvider);
    final devMode = ref.watch(devModeProvider);
    final cur = fc.at(now);
    final dark = context.isDark;
    if (cur == null) return const Scaffold(body: SizedBox.shrink());

    double sumOf(LineKind k) =>
        cur.lines.where((l) => l.kind == k).fold(0.0, (s, l) => s + l.amount);
    final incomeSum = sumOf(LineKind.income);
    final fixedSum = sumOf(LineKind.fixed);
    final budgetSum = sumOf(LineKind.budget);
    // Voyages & épargne : le reste exact, pour que la somme tombe toujours juste.
    final projectSum = cur.endBalance - cur.startBalance - incomeSum - fixedSum - budgetSum;
    final sums = {
      LineKind.income: incomeSum,
      LineKind.fixed: fixedSum,
      LineKind.budget: budgetSum,
      LineKind.project: projectSum,
    };
    final total = cur.endBalance;
    final current = Forecaster.currentBalance(d, cur, devMode: devMode);
    final delta = total - current;

    return Scaffold(
      backgroundColor: dark ? AppColors.bgDark : AppColors.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 40),
          children: [
            Row(children: [
              RoundIconButton(icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('Il vous restera',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
              ),
            ]),
            const SizedBox(height: 14),
            // ── Le solde prévu, en grand ───────────────────────────
            AppCard(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('FIN ${now.longName.toUpperCase()}',
                    style: TextStyle(
                        color: context.mutedColor, fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 1.8)),
                const SizedBox(height: 4),
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: total),
                  duration: const Duration(milliseconds: 650),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(eur(v),
                        style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -1.2,
                            color: total < 0
                                ? AppColors.danger
                                : (delta < 0 ? AppColors.warning : AppColors.success))),
                  ),
                ),
                const SizedBox(height: 10),
                // Aujourd'hui → fin de mois
                InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      fullscreenDialog: true,
                      builder: (_) => BalanceDetailScreen(onEditStart: () {}))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(children: [
                      Expanded(
                        child: Text(
                            'Sur le compte aujourd\'hui : ${eur(current)}\n'
                            '${delta >= 0 ? '+' : '−'}${eur(delta.abs())} d\'ici la fin du mois',
                            style: TextStyle(
                                color: context.mutedColor, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.35)),
                      ),
                      Icon(Icons.chevron_right_rounded, size: 18, color: context.mutedColor),
                    ]),
                  ),
                ),
              ]),
            ),
            // ── Le calcul ──────────────────────────────────────────
            const SizedBox(height: 12),
            AppCard(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Le calcul', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                const SizedBox(height: 6),
                _calcRow('🏦', 'Solde de départ · ${now.longName.toLowerCase()}', cur.startBalance, AppColors.blue,
                    showSign: false),
                _calcRow('+', 'Revenus attendus', incomeSum, AppColors.success),
                _calcRow('−', 'Charges fixes', fixedSum, AppColors.pink),
                _calcRow('−', devMode ? 'Dépenses débitées ce mois & paiements différés' : 'Budgets & dépenses',
                    budgetSum, AppColors.warning),
                if (projectSum.abs() > 0.005) _calcRow('−', 'Voyages & épargne', projectSum, AppColors.violet),
                Divider(height: 18, color: context.trackColor),
                _calcRow('=', 'Il vous restera', total, total < 0 ? AppColors.danger : context.textColor,
                    bold: true, showSign: false),
              ]),
            ),
            const SectionTitle('Le détail'),
            for (var i = 0; i < _groups.length; i++) ..._group(_groups[i], sums[_groups[i].kind] ?? 0, cur, now, i),
          ],
        ),
      ),
    );
  }

  List<Widget> _group(_Group g, double sum, MonthForecast cur, Ym month, int index) {
    final lines = cur.lines.where((l) => l.kind == g.kind && l.amount.abs() > 0.005).toList();
    if (lines.isEmpty && sum.abs() < 0.005) return const [];
    final open = _expanded.contains(g.kind);
    return [
      SizedBox(height: index == 0 ? 0 : 10),
      AppCard(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 4),
        child: Column(children: [
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => setState(() => open ? _expanded.remove(g.kind) : _expanded.add(g.kind)),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
              child: Row(children: [
                CircleEmoji(g.emoji, g.color, size: 38),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(g.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                    Text('${lines.length} ligne${lines.length > 1 ? 's' : ''}',
                        style: TextStyle(color: context.mutedColor, fontSize: 12)),
                  ]),
                ),
                Text(eur(sum, sign: true),
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: g.color)),
                Icon(open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: context.mutedColor),
              ]),
            ),
          ),
          if (open)
            for (final l in lines)
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => _goTo(g.tab, month),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 6, 8, 6),
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(l.label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                        if (l.note != null && l.note!.isNotEmpty)
                          Text(l.note!,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
                      ]),
                    ),
                    const SizedBox(width: 8),
                    Text(eur(l.amount, sign: true),
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5, color: g.color)),
                    Icon(Icons.chevron_right_rounded, size: 18, color: context.mutedColor),
                  ]),
                ),
              ),
        ]),
      ),
    ];
  }
}
