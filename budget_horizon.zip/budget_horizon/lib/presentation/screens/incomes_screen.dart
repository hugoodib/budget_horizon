import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/forecast.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

/// Onglet « Revenus » : revenus de chaque mois et revenus ponctuels du mois affiché.

/// Modifier le nom et le montant d'un revenu ponctuel.
Future<void> _editOneOff(BuildContext context, WidgetRef ref, Income i) async {
  final labelCtl = TextEditingController(text: i.label.isEmpty ? i.kind.label : i.label);
  final amtCtl = TextEditingController(text: i.amount == i.amount.roundToDouble() ? i.amount.round().toString() : i.amount.toString());
  final ok = await showQuickDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Modifier ce revenu'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: labelCtl,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Nom'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: amtCtl,
          autofocus: false,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(suffixText: '€'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
      ],
    ),
  );
  if (ok == true) {
    final x = parseAmount(amtCtl.text);
    ref.read(appProvider.notifier).updateIncome(i.id, label: labelCtl.text.trim(), amount: (x != null && x > 0) ? x : null);
  }
}

/// Dialog de suppression d'un revenu récurrent avec 3 options radio.
Future<void> _showDeleteRecurringDialog(
    BuildContext context, WidgetRef ref, RecurringIncome r, Ym currentYm, dynamic n) async {
  // 0 = ce mois-ci, 1 = de ce mois jusqu'à..., 2 = tous les mois
  int mode = 0;
  Ym untilYm = currentYm.add(1);

  await showQuickDialog<void>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text('Supprimer ${r.label} ?'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Option 1 — ce mois seulement
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => setState(() => mode = 0),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(children: [
                Radio<int>(value: 0, groupValue: mode, onChanged: (v) => setState(() => mode = v!)),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    'Ce mois-ci seulement (${currentYm.longName})',
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ]),
            ),
          ),
          // Option 2 — de ce mois jusqu'à un autre
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => setState(() => mode = 1),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(children: [
                Radio<int>(value: 1, groupValue: mode, onChanged: (v) => setState(() => mode = v!)),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    'De ${currentYm.longName} jusqu\'à...',
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ]),
            ),
          ),
          // Sélecteur de mois de fin (visible uniquement si mode == 1)
          if (mode == 1)
            Padding(
              padding: const EdgeInsets.only(left: 44, bottom: 4),
              child: SoftButton(
                icon: Icons.calendar_month_rounded,
                label: untilYm.longName,
                onPressed: () async {
                  final picked = await pickYm(ctx, untilYm);
                  if (picked != null && !picked.isBefore(currentYm)) {
                    setState(() => untilYm = picked);
                  }
                },
              ),
            ),
          // Option 3 — tous les mois
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => setState(() => mode = 2),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(children: [
                Radio<int>(value: 2, groupValue: mode, onChanged: (v) => setState(() => mode = v!)),
                const SizedBox(width: 4),
                const Expanded(
                  child: Text('Tous les mois (supprimer entièrement)', style: TextStyle(fontSize: 14)),
                ),
              ]),
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () {
              Navigator.pop(ctx);
              switch (mode) {
                case 0:
                  // Supprimer seulement ce mois → l'exclure
                  n.excludeRecurringMonth(r.id, currentYm);
                case 1:
                  // De ce mois jusqu'à untilYm inclus → exclure chaque mois
                  for (var i = currentYm.index; i <= untilYm.index; i++) {
                    n.excludeRecurringMonth(r.id, Ym.fromIndex(i));
                  }
                case 2:
                  n.removeRecurringIncome(r.id);
              }
            },
            child: const Text('Supprimer'),
          ),
        ],
      ),
    ),
  );
}

class IncomesScreen extends ConsumerStatefulWidget {
  const IncomesScreen({super.key});
  @override
  ConsumerState<IncomesScreen> createState() => _IncomesScreenState();
}

class _IncomesScreenState extends ConsumerState<IncomesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(incomeMonthProvider.notifier).state = ref.read(nowProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final ym = ref.watch(incomeMonthProvider);
    final f = ref.watch(forecastProvider).at(ym);
    final n = ref.read(appProvider.notifier);
    // Tous les revenus récurrents (pas seulement ceux actifs ce mois-ci) : on peut les
    // gérer sans avoir à chercher le bon mois, surtout pour les fréquences espacées.
    final recurring = [...d.recurringIncomes]..sort((a, b) => a.start.compareTo(b.start));
    final oneOff = d.extraIncomes(ym);
    final aePersons = [for (final p in [1, 2]) if (d.aeActive(p)) p];

    Widget addButton(VoidCallback onTap) => RoundIconButton(icon: Icons.add_rounded, size: 34, onTap: onTap);

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        // Swipe droite → Charges
        if (details.primaryVelocity != null && details.primaryVelocity! > 300) {
          ref.read(tabProvider.notifier).state = AppTab.charges;
        }
      },
      child: ScreenScaffold(
      title: 'Fixes',
      pinned: MonthSwitcher(
        value: ym,
        min: d.startYm,
        now: ref.watch(nowProvider),
        onChanged: (v) => ref.read(incomeMonthProvider.notifier).state = v,
      ),
      children: [
        const FixesSwitch(),
        AppCard(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Ce que vous gagnez en ${ym.longName}',
                style: const TextStyle(
                    color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 6),
            Text(eur(f?.income ?? 0),
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1)),
          ]),
        ),
        // ---- Chaque mois ----
        SectionTitle('Revenus réguliers',
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              // [Mode dev] Bouton Salaire 3×8
              if (ref.watch(devModeProvider))
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: Tooltip(
                    message: 'Salaire 3×8 (mode dev)',
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () {
                        final existing = d.recurringIncomes.where((r) => r.isShiftSalary).firstOrNull;
                        showSheet(context,
                            title: '🔄 Salaire 3×8',
                            child: ShiftSalarySheet(existing: existing, month: ym));
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: tint(AppColors.teal, .12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.teal.withAlpha(80)),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.schedule_rounded, size: 14, color: AppColors.teal),
                          const SizedBox(width: 4),
                          Text(
                            d.recurringIncomes.any((r) => r.isShiftSalary) ? 'Salaire 3×8 ✓' : 'Salaire 3×8',
                            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.teal),
                          ),
                        ]),
                      ),
                    ),
                  ),
                ),
              addButton(() => showSheet(context,
                  title: 'Nouveau revenu', child: AddIncomeSheet(month: ym, startRecurring: true))),
            ])),
        if (recurring.isEmpty && aePersons.isEmpty)
          const AppCard(child: Text('Aucun revenu régulier. Touchez + pour ajouter votre salaire ou tout autre revenu mensuel.', style: TextStyle(height: 1.4)))
        else
          Builder(builder: (_) {
            final now = ref.watch(nowProvider);
            final ongoing = recurring.where((r) => !r.start.isAfter(now) && (r.end == null || !r.end!.isBefore(now))).toList();
            final future = recurring.where((r) => r.start.isAfter(now)).toList();
            final past = recurring.where((r) => r.end != null && r.end!.isBefore(now)).toList();

            Widget tile(RecurringIncome r) {
              final active = r.activeIn(ym);
              final period = r.end == null
                  ? 'Reçu chaque mois depuis ${r.start.short} ${r.start.year}'
                  : 'De ${r.start.short} ${r.start.year} à ${r.end!.short} ${r.end!.year}';
              return ListTile(
                title: Text(r.label, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(!active
                    ? '$period · ne s\'applique pas ce mois-ci'
                    : (r.hasOverride(ym) ? '$period · montant modifié pour ce mois' : period)),
                isThreeLine: false,
                onTap: () => showSheet(context, title: 'Modifier ${r.label}', child: EditRecurringIncomeSheet(recurringId: r.id)),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(eur(active
                      ? (r.isShiftSalary ? (d.shiftSalaryAmountIn(r, ym) ?? r.amountIn(ym)) : r.amountIn(ym))
                      : r.amount),
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  if (active) CheckCircle(checked: r.isChecked(ym), onTap: () => n.toggleRecurringChecked(r.id, ym)),
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert_rounded, color: AppColors.muted),
                    onSelected: (v) async {
                      if (v == 'month') {
                        showSheet(context,
                            title: 'Modifier ${r.label} · ${ym.longName}',
                            child: RecurringOverrideSheet(month: ym, recurringId: r.id));
                      } else if (v == 'edit') {
                        showSheet(context, title: 'Modifier ${r.label}', child: EditRecurringIncomeSheet(recurringId: r.id));
                      } else {
                        await _showDeleteRecurringDialog(context, ref, r, ym, n);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'month', child: Text('Modifier ce mois-ci')),
                      PopupMenuItem(value: 'edit', child: Text('Modifier (nom, montant, fréquence...)')),
                      PopupMenuItem(value: 'del', child: Text('Supprimer')),
                    ],
                  ),
                ]),
              );
            }

            return Column(children: [
              if (ongoing.isNotEmpty || aePersons.isNotEmpty)
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(children: [
                    for (final r in ongoing) tile(r),
                    // Versements non pointés le mois précédent, reportés sur ce mois : ligne à part
                    for (final r in recurring.where((r) => r.carriedMonths.contains(ym.add(-1).key)))
                      ListTile(
                        title: Text('${r.label} · ${ym.add(-1).longName.toLowerCase()}',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('Non reçu en ${ym.add(-1).longName.toLowerCase()} — reporté ici. Touchez le rond quand vous l\'avez reçu.'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(eur(r.isShiftSalary
                              ? (d.shiftSalaryAmountIn(r, ym.add(-1)) ?? r.amountIn(ym.add(-1)))
                              : r.amountIn(ym.add(-1))),
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                          CheckCircle(
                            checked: r.isChecked(ym.add(-1)),
                            onTap: () => ref.read(appProvider.notifier).markCarriedRecurringChecked(r.id, ym.add(-1)),
                          ),
                        ]),
                      ),
                    for (final p in aePersons)
                      ListTile(
                        title: Text(
                            d.isCouple ? 'Salaire auto-entrepreneur · ${d.personName(p)}' : 'Salaire auto-entrepreneur',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(d.lateGrossReceivedIn(ym, p) > 0.005
                            ? 'Calculé depuis vos factures · ${eur(d.netFromGross(d.lateGrossReceivedIn(ym, p)))} de retards non inclus'
                            : 'Calculé automatiquement depuis vos factures du mois'),
                        trailing: Text(eur(d.netFromGross(d.grossReceivedIn(ym, p) - d.lateGrossReceivedIn(ym, p))),
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                      ),
                  ]),
                ),
              if (future.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Pas encore actifs', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.muted, fontSize: 13))),
                const SizedBox(height: 6),
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(children: [for (final r in future) tile(r)]),
                ),
              ],
              if (past.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Anciens revenus', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.muted, fontSize: 13))),
                const SizedBox(height: 6),
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(children: [for (final r in past) tile(r)]),
                ),
              ],
            ]);
          }),
        // ---- [Mode dev] Congés ----
        if (ref.watch(devModeProvider) && (
              (d.recurringIncomes.any((r) => r.isShiftSalary) && d.shiftSchedule != null) ||
              (d.user.leaveEnabled && d.leaveTypes.isNotEmpty)
            ))
          _LeaveCard(month: ym),
        // ---- Ponctuels du mois affiché ----
        SectionTitle('Revenus exceptionnels · ${ym.longName}',
            trailing: addButton(() => showSheet(context,
                title: 'Nouveau revenu ponctuel', child: AddIncomeSheet(month: ym)))),
        if (oneOff.isEmpty)
          const AppCard(child: Text('Rien ce mois-ci. Touchez + pour ajouter une prime, un remboursement, une vente…', style: TextStyle(height: 1.4)))
        else
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(children: [
              for (final i in oneOff)
                ListTile(
                  title: Text(i.label.isEmpty ? i.kind.label : i.label,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(i.kind.label),
                  onTap: () => _editOneOff(context, ref, i),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(eur(i.amount, sign: true),
                        style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.success, fontSize: 17)),
                    CheckCircle(checked: i.checked, onTap: () => n.toggleIncomeChecked(i.id)),
                    IconButton(
                      onPressed: () => n.removeIncome(i.id),
                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.muted),
                    ),
                  ]),
                ),
            ]),
          ),
      ],
    ),
    );
  }
}

// ── [Mode dev] Feuille de configuration du salaire 3×8 ───────────────────────
class ShiftSalarySheet extends ConsumerStatefulWidget {
  final RecurringIncome? existing; // null = création
  final Ym month;
  const ShiftSalarySheet({super.key, this.existing, required this.month});
  @override
  ConsumerState<ShiftSalarySheet> createState() => _ShiftSalarySheetState();
}

class _ShiftSalarySheetState extends ConsumerState<ShiftSalarySheet> {
  late final TextEditingController _labelCtrl;
  late final TextEditingController _baseCtrl;

  @override
  void initState() {
    super.initState();
    _labelCtrl = TextEditingController(
        text: widget.existing?.label ?? 'Salaire');
    _baseCtrl = TextEditingController(
        text: (widget.existing?.baseSalary ?? 0) == 0
            ? ''
            : (widget.existing!.baseSalary.round().toString()));
  }

  @override
  void dispose() {
    _labelCtrl.dispose();
    _baseCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final n = ref.read(appProvider.notifier);
    final schedule = d.shiftSchedule;
    final now = ref.read(nowProvider);

    // Prévisualisation : M = now, primes depuis M-2
    final base = double.tryParse(_baseCtrl.text.replaceAll(',', '.')) ?? 0;
    final primeYm = now.add(-2);
    final primes = schedule?.totalAllowanceIn(primeYm) ?? 0;
    final totalPreview = base + primes;
    final joursPreview = schedule?.workingDayCountIn(primeYm) ?? 0;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Avertissement si pas de tournante ────────────────────
      if (schedule == null)
        Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: tint(AppColors.warning, .12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Row(children: [
            Text('⚠️', style: TextStyle(fontSize: 18)),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'Tournante non configurée. Va dans Paramètres → Développeur → Tournante 3×8.',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, height: 1.4),
              ),
            ),
          ]),
        ),

      // ── Nom ──────────────────────────────────────────────────
      TextField(
        controller: _labelCtrl,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(labelText: 'Nom (ex. Salaire)'),
      ),
      const SizedBox(height: 12),

      // ── Salaire de base ──────────────────────────────────────
      TextField(
        controller: _baseCtrl,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'Salaire fixe de base', suffixText: '€'),
        onChanged: (_) => setState(() {}),
      ),
      const SizedBox(height: 16),

      // ── Explication du calcul ─────────────────────────────────
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: tint(AppColors.teal, .08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.teal.withAlpha(60)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Comment ça marche',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: AppColors.teal)),
          const SizedBox(height: 6),
          const Text(
            'Chaque mois, ton salaire = salaire fixe + primes du mois M−2.\n'
            'Les primes sont calculées automatiquement depuis ta tournante.',
            style: TextStyle(fontSize: 13, height: 1.5, color: AppColors.muted),
          ),
          if (schedule != null && base > 0) ...[
            const Divider(height: 20),
            Text('Aperçu pour ${now.longName} :',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: AppColors.teal)),
            const SizedBox(height: 6),
            Text(
              '${eur(base)} fixe  +  ${eur(primes)} primes ($joursPreview j · ${primeYm.longName})',
              style: const TextStyle(fontSize: 13, height: 1.5),
            ),
            const SizedBox(height: 4),
            Text(
              '= ${eur(totalPreview)}',
              style: const TextStyle(
                  fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.teal, letterSpacing: -0.5),
            ),
          ],
        ]),
      ),
      const SizedBox(height: 16),

      // ── Bouton enregistrer ───────────────────────────────────
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: widget.existing != null ? 'Mettre à jour' : 'Créer le salaire 3×8',
          onPressed: () {
            final base = double.tryParse(_baseCtrl.text.replaceAll(',', '.'));
            if (base == null || base < 0) {
              snack(context, 'Salaire de base invalide');
              return;
            }
            final label = _labelCtrl.text.trim().isEmpty ? 'Salaire' : _labelCtrl.text.trim();
            if (widget.existing != null) {
              // Mise à jour
              n.updateRecurringIncome(widget.existing!.id,
                  label: label,
                  amount: base, // stocké dans amount pour compatibilité
                  start: widget.existing!.start,
                  end: widget.existing!.end,
                  intervalMonths: widget.existing!.intervalMonths,
                  receiptDay: widget.existing!.receiptDay,
                  isShiftSalary: true,
                  baseSalary: base);
            } else {
              // Création
              n.addShiftSalaryIncome(label, base, widget.month);
            }
            Navigator.pop(context);
            snack(context, widget.existing != null ? 'Salaire 3×8 mis à jour ✓' : 'Salaire 3×8 créé ✓');
          },
        ),
      ),

      // ── Supprimer ────────────────────────────────────────────
      if (widget.existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer ce salaire',
          onPressed: () {
            n.removeRecurringIncome(widget.existing!.id);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}

// ── [Mode dev] Carte congés du mois ──────────────────────────────────────────
class _LeaveCard extends ConsumerStatefulWidget {
  final Ym month;
  const _LeaveCard({required this.month});
  @override
  ConsumerState<_LeaveCard> createState() => _LeaveCardState();
}

class _LeaveCardState extends ConsumerState<_LeaveCard> {
  late TextEditingController _ctrl;

  @override
  void initState() {
    super.initState();
    final leave = ref.read(appProvider).shiftSchedule?.leaveCountIn(widget.month) ?? 0;
    _ctrl = TextEditingController(text: leave > 0 ? leave.toString() : '');
  }

  @override
  void didUpdateWidget(_LeaveCard old) {
    super.didUpdateWidget(old);
    if (old.month != widget.month) {
      final leave = ref.read(appProvider).shiftSchedule?.leaveCountIn(widget.month) ?? 0;
      _ctrl.text = leave > 0 ? leave.toString() : '';
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _openLeaveSheet(BuildContext context, WidgetRef ref, int currentLeave) {
    final d = ref.read(appProvider);
    final leaveEnabled = d.user.leaveEnabled && d.leaveTypes.isNotEmpty;
    if (leaveEnabled) {
      // Sheet avec répartition par priorité
      showSheet(context,
          title: 'Congés · ${widget.month.longName}',
          child: _LeaveInputSheet(
            month: widget.month,
            onSaved: (total) {
              // Synchronise aussi la tournante 3×8 si active
              if (d.shiftSchedule != null) {
                ref.read(appProvider.notifier).setLeaveDays(widget.month, total);
              }
            },
          ));
    } else {
      // Dialog simple (mode 3×8 sans leaveEnabled)
      _showSimpleDialog(context, ref, currentLeave);
    }
  }

  Future<void> _showSimpleDialog(BuildContext context, WidgetRef ref, int currentLeave) async {
    final c = TextEditingController(text: currentLeave > 0 ? currentLeave.toString() : '');
    final result = await showDialog<int>(
      context: context,
      barrierDismissible: true,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text('Congés · ${widget.month.longName}'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Jours de congés', suffixText: 'j'),
          onSubmitted: (v) => Navigator.pop(ctx, int.tryParse(v) ?? 0),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, int.tryParse(c.text) ?? 0), child: const Text('Valider')),
        ],
      ),
    );
    c.dispose();
    if (result != null) ref.read(appProvider.notifier).setLeaveDays(widget.month, result);
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final schedule = d.shiftSchedule;
    final leaveEnabled = d.user.leaveEnabled && d.leaveTypes.isNotEmpty;

    // Congés posés : priorité au compteur de congés si actif, sinon tournante
    int leave = 0;
    if (leaveEnabled) {
      leave = d.leaveEntries
          .where((e) => e.month == widget.month && e.note != '__solde__')
          .fold(0, (s, e) => s + e.days.round());
      // Synchroniser la tournante si elle est aussi active
      final scheduleLeave = schedule?.leaveCountIn(widget.month) ?? 0;
      if (scheduleLeave != leave && schedule != null) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          ref.read(appProvider.notifier).setLeaveDays(widget.month, leave);
        });
      }
    } else if (schedule != null) {
      leave = schedule.leaveCountIn(widget.month);
    }

    final rawDays = schedule?.workingDaysIn(widget.month).length ?? 0;
    final worked = schedule != null ? schedule.workingDayCountIn(widget.month) : 0;
    final primes = schedule != null ? schedule.totalAllowanceIn(widget.month) : 0.0;
    final impactYm = widget.month.add(2);
    final hasShift = schedule != null && d.recurringIncomes.any((r) => r.isShiftSalary);

    // Résumé des poses par type (si leaveEnabled)
    final poses = leaveEnabled
        ? d.leaveEntries
            .where((e) => e.month == widget.month && e.note != '__solde__')
            .toList()
        : <dynamic>[];

    return Column(children: [
      const SizedBox(height: 4),
      AppCard(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(Icons.beach_access_rounded, size: 18,
                color: leave > 0 ? AppColors.violet : AppColors.muted),
            const SizedBox(width: 8),
            Text('Congés · ${widget.month.longName}',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14,
                    color: leave > 0 ? AppColors.violet : null)),
          ]),
          const SizedBox(height: 4),
          if (hasShift)
            Text(
              '$rawDays jours travaillés selon la tournante'
              '${leave > 0 ? ' · $leave j de congés → $worked j effectifs' : ''}',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
            ),
          // Résumé par type si leaveEnabled
          if (leaveEnabled && poses.isNotEmpty) ...[
            const SizedBox(height: 6),
            for (final e in poses)
              Builder(builder: (_) {
                final lt = d.leaveTypes.where((t) => t.id == e.leaveTypeId).firstOrNull;
                if (lt == null) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Row(children: [
                    CircleAvatar(radius: 5, backgroundColor: Color(lt.colorValue)),
                    const SizedBox(width: 6),
                    Text('${lt.name} : ${e.days.round()} j',
                        style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                  ]),
                );
              }),
          ],
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: SoftButton(
                icon: leave > 0 ? Icons.edit_rounded : Icons.add_rounded,
                label: leave > 0 ? '$leave jour${leave > 1 ? 's' : ''} de congés' : 'Ajouter des congés',
                onPressed: () => _openLeaveSheet(context, ref, leave),
              ),
            ),
            if (leave > 0) ...[
              const SizedBox(width: 10),
              IconButton.filledTonal(
                tooltip: 'Effacer',
                onPressed: () {
                  if (leaveEnabled) {
                    for (final lt in d.leaveTypes) {
                      ref.read(appProvider.notifier).setLeaveEntry(lt.id, widget.month, 0);
                    }
                  }
                  if (schedule != null) {
                    ref.read(appProvider.notifier).setLeaveDays(widget.month, 0);
                  }
                },
                icon: const Icon(Icons.close_rounded, size: 18),
              ),
            ],
          ]),
          if (leave > 0 && hasShift) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              decoration: BoxDecoration(
                color: tint(AppColors.violet, .08),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(children: [
                const Icon(Icons.info_outline_rounded, size: 15, color: AppColors.violet),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Impact sur ${impactYm.longName} : ${eur(primes)} de primes '
                    '($worked j × ${eur(schedule!.transportAllowance + schedule.mealAllowance)}/j)',
                    style: const TextStyle(
                        fontSize: 12.5, color: AppColors.violet,
                        fontWeight: FontWeight.w600, height: 1.4),
                  ),
                ),
              ]),
            ),
          ],
        ]),
      ),
      const SizedBox(height: 4),
    ]);
  }
}

// ── Sheet de pose avec répartition automatique par priorité ──────────────────
class _LeaveInputSheet extends ConsumerStatefulWidget {
  final Ym month;
  final void Function(int total)? onSaved;
  const _LeaveInputSheet({required this.month, this.onSaved});
  @override
  ConsumerState<_LeaveInputSheet> createState() => _LeaveInputSheetState();
}

class _LeaveInputSheetState extends ConsumerState<_LeaveInputSheet> {
  final _ctrl = TextEditingController();
  // ignore: unused_field
  String _input = ''; // pour déclencher le rebuild sur chaque frappe

  @override
  void initState() {
    super.initState();
    _ctrl.addListener(() => setState(() => _input = _ctrl.text));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final types = [...d.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));
    final n = ref.read(appProvider.notifier);

    // Solde disponible par type (début du mois + cumul)
    Map<String, int> soldes = {};
    for (final lt in types) {
      // Solde début = soldeFin mois précédent ou override manuel
      final prevManual = d.leaveEntries
          .where((e) => e.leaveTypeId == lt.id && e.month == widget.month && e.note == '__solde__')
          .firstOrNull;
      double debut;
      if (prevManual != null) {
        debut = prevManual.days;
      } else if (widget.month.index <= d.startYm.index) {
        debut = lt.initialBalance;
      } else {
        // Recalcul depuis startYm
        double bal = lt.initialBalance;
        var cur = d.startYm;
        while (cur.index < widget.month.index) {
          bal += lt.accrualPerMonth;
          final entry = d.leaveEntries
              .where((e) => e.leaveTypeId == lt.id && e.month == cur && e.note != '__solde__')
              .firstOrNull;
          if (entry != null) bal -= entry.days;
          cur = cur.add(1);
        }
        debut = bal;
      }
      soldes[lt.id] = (debut + lt.accrualPerMonth).floor();
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Info ordre de priorité
      Row(children: [
        const Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted),
        const SizedBox(width: 6),
        Expanded(child: Text(
          'Les jours seront prélevés dans l\'ordre de priorité : ${types.map((t) => t.name).join(' → ')}.',
          style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
        )),
      ]),
      const SizedBox(height: 12),
      // Soldes disponibles
      AppCard(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
        child: Column(children: [
          for (final lt in types)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(children: [
                CircleAvatar(radius: 7, backgroundColor: Color(lt.colorValue)),
                const SizedBox(width: 8),
                Expanded(child: Text(lt.name,
                    style: const TextStyle(fontWeight: FontWeight.w600))),
                Text('${soldes[lt.id] ?? 0} j dispo',
                    style: TextStyle(color: Color(lt.colorValue),
                        fontWeight: FontWeight.w700, fontSize: 13)),
              ]),
            ),
        ]),
      ),
      const SizedBox(height: 14),
      // Saisie du nombre total
      TextField(
        controller: _ctrl,
        autofocus: true,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: 'Nombre de jours à poser',
          suffixText: 'j entiers',
          prefixIcon: const Icon(Icons.wb_sunny_rounded),
          // Afficher le max disponible comme hint
          helperText: () {
            final totalDispo = soldes.values.fold(0, (a, b) => a + b);
            return 'Maximum disponible ce mois : $totalDispo j';
          }(),
          helperStyle: const TextStyle(color: AppColors.muted, fontSize: 12),
        ),
      ),
      // Alerte si dépassement
      Builder(builder: (_) {
        final total = int.tryParse(_ctrl.text.trim()) ?? 0;
        final totalDispo = soldes.values.fold(0, (a, b) => a + b);
        if (total <= 0 || total <= totalDispo) return const SizedBox.shrink();
        return Container(
          margin: const EdgeInsets.only(top: 8),
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          decoration: BoxDecoration(
            color: AppColors.danger.withAlpha(18),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.danger.withAlpha(80)),
          ),
          child: Row(children: [
            const Icon(Icons.block_rounded, size: 15, color: AppColors.danger),
            const SizedBox(width: 8),
            Expanded(child: Text(
              'Solde insuffisant. Tu ne peux poser que $totalDispo j maximum ce mois.',
              style: const TextStyle(color: AppColors.danger, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
            )),
          ]),
        );
      }),
      // Alerte prospective : impact sur les mois futurs déjà planifiés
      Builder(builder: (_) {
        final total = int.tryParse(_ctrl.text.trim()) ?? 0;
        final totalDispo = soldes.values.fold(0, (a, b) => a + b);
        if (total <= 0 || total > totalDispo) return const SizedBox.shrink();
        // Simuler la répartition et chercher un conflit futur
        final futurePlanned = d.leaveEntries
            .where((e) => e.month.index > widget.month.index && e.note != '__solde__')
            .toList();
        if (futurePlanned.isEmpty) return const SizedBox.shrink();
        // Calculer l'impact : ces jours posés réduisent les soldes futurs
        // Chercher le premier mois futur où le solde devient insuffisant
        for (final lt in types) {
          final posedExtra = (soldes[lt.id] ?? 0).clamp(0, total);
          if (posedExtra == 0) continue;
          final futureForType = futurePlanned.where((e) => e.leaveTypeId == lt.id).toList();
          for (final fe in futureForType) {
            // Solde futur simulé = solde actuel calculé - extra posé maintenant
            // (approximation : on soustrait directement)
            // Si la pose future dépasse le solde restant simulé, conflit
            final soldeApres = (soldes[lt.id] ?? 0) - posedExtra;
            if (fe.days > soldeApres) {
              return Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                decoration: BoxDecoration(
                  color: AppColors.warning.withAlpha(18),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.warning.withAlpha(80)),
                ),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.warning_amber_rounded, size: 15, color: AppColors.warning),
                  const SizedBox(width: 8),
                  Expanded(child: Text(
                    'Attention : en posant $total j maintenant, tu n\'auras peut-être plus assez de ${lt.name} pour tes congés prévus en ${fe.month.longName}.',
                    style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
                  )),
                ]),
              );
            }
          }
        }
        return const SizedBox.shrink();
      }),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          flex: 2,
          child: OutlinedButton(
            onPressed: () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 3,
          child: Builder(builder: (ctx) {
            final total = int.tryParse(_ctrl.text.trim()) ?? 0;
            final totalDispo = soldes.values.fold(0, (a, b) => a + b);
            final blocked = total <= 0 || total > totalDispo;
            return GradientButton(
              label: 'Poser les congés',
              onPressed: blocked ? null : () async {
                // Vérifier si conflit prospectif → demander confirmation
                final futurePlanned = d.leaveEntries
                    .where((e) => e.month.index > widget.month.index && e.note != '__solde__')
                    .isNotEmpty;
                bool proceed = true;
                if (futurePlanned) {
                  proceed = await showQuickDialog<bool>(
                    context: context,
                    builder: (dctx) => AlertDialog(
                      title: const Text('Confirmer la pose ?'),
                      content: Text(
                        'Tu vas poser $total j en ${widget.month.longName}. '
                        'Cela pourrait impacter des congés déjà planifiés dans les mois suivants. '
                        'Es-tu sûr(e) ?',
                      ),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(dctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(dctx, true), child: const Text('Confirmer')),
                      ],
                    ),
                  ) ?? false;
                }
                if (!proceed) return;
                // Répartition par priorité (strict — jamais au-delà du dispo)
                int remaining = total;
                for (final lt in types) {
                  if (remaining <= 0) break;
                  final dispo = soldes[lt.id] ?? 0;
                  final pose = remaining.clamp(0, dispo);
                  if (pose > 0) {
                    n.setLeaveEntry(lt.id, widget.month, pose.toDouble());
                    remaining -= pose;
                  }
                }
                widget.onSaved?.call(total);
                if (context.mounted) Navigator.pop(context);
              },
            );
          }),
        ),
      ]),
    ]);
  }
}
