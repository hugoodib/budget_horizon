import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../domain/business.dart';
import '../../domain/forecast.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

/// Onglet « Revenus » : revenus de chaque mois et revenus ponctuels du mois affiché.

/// Modifier le nom et le montant d'un revenu ponctuel.
Future<void> _editOneOff(BuildContext context, WidgetRef ref, Income i) async {
  final labelCtl = TextEditingController(text: i.label.isEmpty ? i.kind.label : i.label);
  final amtCtl = TextEditingController(text: i.amount == i.amount.roundToDouble() ? i.amount.round().toString() : i.amount.toString());
  final ok = await showQuickDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Modifier ce revenu'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: labelCtl,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Nom'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: amtCtl,
          autofocus: false,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(suffixText: '€'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
      ],
    ),
  );
  if (ok == true) {
    final x = parseAmount(amtCtl.text);
    ref.read(appProvider.notifier).updateIncome(i.id, label: labelCtl.text.trim(), amount: (x != null && x > 0) ? x : null);
  }
}

class IncomesScreen extends ConsumerStatefulWidget {
  const IncomesScreen({super.key});
  @override
  ConsumerState<IncomesScreen> createState() => _IncomesScreenState();
}

class _IncomesScreenState extends ConsumerState<IncomesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(incomeMonthProvider.notifier).state = ref.read(nowProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final ym = ref.watch(incomeMonthProvider);
    final f = ref.watch(forecastProvider).at(ym);
    final n = ref.read(appProvider.notifier);
    // Tous les revenus récurrents (pas seulement ceux actifs ce mois-ci) : on peut les
    // gérer sans avoir à chercher le bon mois, surtout pour les fréquences espacées.
    final recurring = [...d.recurringIncomes]..sort((a, b) => a.start.compareTo(b.start));
    final oneOff = d.extraIncomes(ym);
    final aePersons = [for (final p in [1, 2]) if (d.aeActive(p)) p];

    Widget addButton(VoidCallback onTap) => RoundIconButton(icon: Icons.add_rounded, size: 34, onTap: onTap);

    return ScreenScaffold(
      title: 'Fixes',
      children: [
        const FixesSwitch(),
        MonthSwitcher(
          value: ym,
          min: d.startYm,
          now: ref.watch(nowProvider),
          onChanged: (v) => ref.read(incomeMonthProvider.notifier).state = v,
        ),
        AppCard(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('REVENUS · ${ym.longName.toUpperCase()}',
                style: const TextStyle(
                    color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 2)),
            const SizedBox(height: 6),
            Text(eur(f?.income ?? 0),
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1)),
          ]),
        ),
        // ---- Chaque mois ----
        SectionTitle('Chaque mois',
            trailing: addButton(() => showSheet(context,
                title: 'Nouveau revenu', child: AddIncomeSheet(month: ym, startRecurring: true)))),
        if (recurring.isEmpty && aePersons.isEmpty)
          const AppCard(child: Text('Aucun revenu régulier. Touchez + pour ajouter un salaire.'))
        else
          Builder(builder: (_) {
            final now = ref.watch(nowProvider);
            final ongoing = recurring.where((r) => !r.start.isAfter(now) && (r.end == null || !r.end!.isBefore(now))).toList();
            final future = recurring.where((r) => r.start.isAfter(now)).toList();
            final past = recurring.where((r) => r.end != null && r.end!.isBefore(now)).toList();

            Widget tile(RecurringIncome r) {
              final active = r.activeIn(ym);
              final period = r.end == null
                  ? 'Depuis ${r.start.short} ${r.start.year}'
                  : 'Depuis ${r.start.short} ${r.start.year} jusqu\'à ${r.end!.short} ${r.end!.year}';
              return ListTile(
                title: Text(r.label, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(!active
                    ? '$period · inactif ce mois-ci'
                    : (r.hasOverride(ym) ? '$period · modifié ce mois-ci' : period)),
                isThreeLine: false,
                onTap: () => showSheet(context, title: 'Modifier ${r.label}', child: EditRecurringIncomeSheet(recurringId: r.id)),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(eur(active ? r.amountIn(ym) : r.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  if (active) CheckCircle(checked: r.isChecked(ym), onTap: () => n.toggleRecurringChecked(r.id, ym)),
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert_rounded, color: AppColors.muted),
                    onSelected: (v) async {
                      if (v == 'month') {
                        showSheet(context,
                            title: 'Modifier ${r.label} · ${ym.longName}',
                            child: RecurringOverrideSheet(month: ym, recurringId: r.id));
                      } else if (v == 'edit') {
                        showSheet(context, title: 'Modifier ${r.label}', child: EditRecurringIncomeSheet(recurringId: r.id));
                      } else {
                        final choice = await showQuickDialog<String>(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: Text('Supprimer ${r.label} ?'),
                            content: const Text(
                                'Supprimer seulement ce revenu à vie, ou uniquement à partir d\'un mois précis ?'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                              TextButton(
                                  onPressed: () => Navigator.pop(ctx, 'from'),
                                  child: const Text('À partir d\'un mois...')),
                              FilledButton(
                                  onPressed: () => Navigator.pop(ctx, 'all'),
                                  child: const Text('Supprimer entièrement')),
                            ],
                          ),
                        );
                        if (choice == 'all') {
                          n.removeRecurringIncome(r.id);
                        } else if (choice == 'from' && context.mounted) {
                          final y = await pickYm(context, ym);
                          if (y != null) n.endRecurringFrom(r.id, y);
                        }
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'month', child: Text('Modifier ce mois-ci')),
                      PopupMenuItem(value: 'edit', child: Text('Modifier (nom, montant, fréquence...)')),
                      PopupMenuItem(value: 'del', child: Text('Supprimer')),
                    ],
                  ),
                ]),
              );
            }

            return Column(children: [
              if (ongoing.isNotEmpty || aePersons.isNotEmpty)
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(children: [
                    for (final r in ongoing) tile(r),
                    // Versements non pointés le mois précédent, reportés sur ce mois : ligne à part
                    for (final r in recurring.where((r) => r.carriedMonths.contains(ym.add(-1).key)))
                      ListTile(
                        title: Text('${r.label} · ${ym.add(-1).longName.toLowerCase()}',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('Report de ${ym.add(-1).longName.toLowerCase()} · touchez ✓ pour marquer reçu'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text(eur(r.amountIn(ym.add(-1))),
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                          CheckCircle(
                            checked: r.isChecked(ym.add(-1)),
                            onTap: () => ref.read(appProvider.notifier).markCarriedRecurringChecked(r.id, ym.add(-1)),
                          ),
                        ]),
                      ),
                    for (final p in aePersons)
                      ListTile(
                        title: Text(
                            d.isCouple ? 'Salaire auto-entrepreneur · ${d.personName(p)}' : 'Salaire auto-entrepreneur',
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text(d.lateGrossReceivedIn(ym, p) > 0.005
                            ? 'Calculé depuis vos clients · hors retards (${eur(d.netFromGross(d.lateGrossReceivedIn(ym, p)))} de retards de paiement en plus)'
                            : 'Calculé depuis vos clients'),
                        trailing: Text(eur(d.netFromGross(d.grossReceivedIn(ym, p) - d.lateGrossReceivedIn(ym, p))),
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                      ),
                  ]),
                ),
              if (future.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('À venir', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.muted, fontSize: 13))),
                const SizedBox(height: 6),
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(children: [for (final r in future) tile(r)]),
                ),
              ],
              if (past.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Terminés', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.muted, fontSize: 13))),
                const SizedBox(height: 6),
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(children: [for (final r in past) tile(r)]),
                ),
              ],
            ]);
          }),
        // ---- Ponctuels du mois affiché ----
        SectionTitle('Ponctuels · ${ym.longName}',
            trailing: addButton(() => showSheet(context,
                title: 'Nouveau revenu ponctuel', child: AddIncomeSheet(month: ym)))),
        if (oneOff.isEmpty)
          const AppCard(child: Text('Rien ce mois-ci. Touchez + pour ajouter une prime, une vente…'))
        else
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(children: [
              for (final i in oneOff)
                ListTile(
                  title: Text(i.label.isEmpty ? i.kind.label : i.label,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(i.kind.label),
                  onTap: () => _editOneOff(context, ref, i),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(eur(i.amount, sign: true),
                        style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.success, fontSize: 17)),
                    CheckCircle(checked: i.checked, onTap: () => n.toggleIncomeChecked(i.id)),
                    IconButton(
                      onPressed: () => n.removeIncome(i.id),
                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.muted),
                    ),
                  ]),
                ),
            ]),
          ),
      ],
    );
  }
}
