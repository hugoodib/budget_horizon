import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../widgets/common.dart';

/// Détail du calcul du « Solde actuel » : page plein écran (fermable avec la croix ou la flèche
/// retour). Chaque ligne est cliquable (elle mène à l'écran concerné) et peut être pointée
/// directement ici : le solde se met à jour en direct.
class BalanceDetailScreen extends ConsumerStatefulWidget {
  /// Ouvre la modification du solde de départ (gérée par l'accueil).
  final VoidCallback onEditStart;
  const BalanceDetailScreen({super.key, required this.onEditStart});

  @override
  ConsumerState<BalanceDetailScreen> createState() => _BalanceDetailScreenState();
}

class _SectionDef {
  final BalKind kind;
  final String emoji;
  final String title;
  final String sign; // +, −
  final Color color;
  final String empty;
  const _SectionDef(this.kind, this.emoji, this.title, this.sign, this.color, this.empty);
}

const _sections = [
  _SectionDef(BalKind.income, '💰', 'Revenus', '+', AppColors.success, 'Aucun revenu ce mois-ci'),
  _SectionDef(BalKind.fixed, '🏠', 'Charges fixes', '−', AppColors.pink, 'Aucune charge ce mois-ci'),
  _SectionDef(BalKind.spend, '🛒', 'Dépenses', '−', AppColors.warning, 'Aucune dépense ce mois-ci'),
  _SectionDef(BalKind.other, '✈️', 'Voyages & épargne', '−', AppColors.violet, ''),
];

class _BalanceDetailScreenState extends ConsumerState<BalanceDetailScreen> {
  // Les catégories sont repliées à l'ouverture : on touche une catégorie pour la déplier.
  final Set<BalKind> _expanded = {};

  void _toggle(BalItem it, Ym month) {
    final n = ref.read(appProvider.notifier);
    switch (it.action) {
      case 'recurring':
        n.toggleRecurringChecked(it.id!, it.ym ?? month);
      case 'carried':
        n.markCarriedRecurringChecked(it.id!, it.ym ?? month);
      case 'income':
        n.toggleIncomeChecked(it.id!);
      case 'fixed':
        n.toggleFixedChecked(it.id!, it.ym ?? month);
      case 'tx':
        n.toggleTransactionChecked(it.id!);
    }
  }

  bool _canToggle(BalItem it) =>
      it.id != null && const {'recurring', 'carried', 'income', 'fixed', 'tx'}.contains(it.action);

  /// Ferme la page et ouvre l'écran lié à la ligne.
  void _goTo(BalItem it, Ym month) {
    AppTab? tab;
    switch (it.action) {
      case 'recurring' || 'carried' || 'income':
        tab = AppTab.incomes;
        ref.read(incomeMonthProvider.notifier).state = month;
      case 'fixed':
        tab = AppTab.charges;
        ref.read(chargeMonthProvider.notifier).state = month;
      case 'tx':
        tab = AppTab.budgets;
        ref.read(budgetMonthProvider.notifier).state = month;
      case 'invoices':
        tab = AppTab.invoices;
        ref.read(invoiceMonthProvider.notifier).state = month;
      case 'trips':
        tab = AppTab.trips;
    }
    if (tab == null) return;
    ref.read(tabProvider.notifier).state = tab;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final fc = ref.watch(forecastProvider);
    final now = ref.watch(nowProvider);
    final cur = fc.at(now);
    final dark = context.isDark;
    if (cur == null) return const Scaffold(body: SizedBox.shrink());
    final detail = Forecaster.balanceDetail(d, cur, devMode: ref.watch(devModeProvider));
    final total = detail.total;
    final counted = detail.items.where((i) => i.counts).length;
    final all = detail.items.length;

    return Scaffold(
      backgroundColor: dark ? AppColors.bgDark : AppColors.bg,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 40),
          children: [
            // ── Barre du haut : fermer ─────────────────────────────
            Row(children: [
              RoundIconButton(icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
              const SizedBox(width: 12),
              const Expanded(
                child: Text('Mon solde actuel',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
              ),
            ]),
            const SizedBox(height: 14),
            // ── Le solde, en grand ─────────────────────────────────
            AppCard(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('EN ${now.longName.toUpperCase()}',
                    style: TextStyle(
                        color: context.mutedColor, fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 1.8)),
                const SizedBox(height: 4),
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: total),
                  duration: const Duration(milliseconds: 650),
                  curve: Curves.easeOutCubic,
                  builder: (_, v, __) => FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(eur(v),
                        style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -1.2,
                            color: total < 0 ? AppColors.danger : context.textColor)),
                  ),
                ),
                const SizedBox(height: 4),
                Text('$counted / $all éléments pointés',
                    style: TextStyle(color: context.mutedColor, fontSize: 12.5, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                AppProgress(value: all == 0 ? 0 : counted / all, color: AppColors.teal),
                const SizedBox(height: 14),
                const SizedBox(height: 12),
                Row(children: [
                  Icon(Icons.touch_app_rounded, size: 15, color: context.mutedColor),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                        'Dépliez une catégorie, puis touchez le rond pour pointer ou une ligne pour y aller.',
                        style: TextStyle(color: context.mutedColor, fontSize: 12, height: 1.3)),
                  ),
                ]),
              ]),
            ),
            // ── Le calcul : addition, soustractions, total ───────────
            const SizedBox(height: 12),
            _calcCard(detail, now),
            // ── Détail par catégorie ───────────────────────────────
            const SectionTitle('Le détail'),
            for (final def in _sections) ..._section(def, detail, now, first: def == _sections.first),
          ],
        ),
      ),
    );
  }

  Widget _calcRow(String sign, String label, double value, Color color,
      {VoidCallback? onTap, bool bold = false, bool showSign = true}) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
        child: Row(children: [
          Container(
            width: 26,
            height: 26,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: color.withAlpha(34), shape: BoxShape.circle),
            child: Text(sign, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 15)),
          ),
          const SizedBox(width: 10),
          Expanded(
              child: Text(label,
                  style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: 14.5))),
          Text(showSign ? eur(value, sign: true) : eur(value),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: bold ? 17 : 15, color: color)),
          if (onTap != null) Icon(Icons.edit_outlined, size: 14, color: context.mutedColor),
        ]),
      ),
    );
  }

  Widget _calcCard(BalanceDetail detail, Ym month) {
    final other = detail.sumChecked(BalKind.other);
    final total = detail.total;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Le calcul', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
        const SizedBox(height: 6),
        _calcRow('🏦', 'Solde de départ · ${month.longName.toLowerCase()}', detail.start, AppColors.blue,
            showSign: false, onTap: () {
          Navigator.of(context).pop();
          widget.onEditStart();
        }),
        _calcRow('+', 'Revenus reçus (cochés)', detail.sumChecked(BalKind.income), AppColors.success),
        _calcRow('−', 'Charges prélevées (cochées)', detail.sumChecked(BalKind.fixed), AppColors.pink),
        _calcRow('−', ref.watch(devModeProvider) ? 'Dépenses sorties du compte (débit passé)' : 'Dépenses débitées (cochées)',
            detail.sumChecked(BalKind.spend), AppColors.warning),
        if (other.abs() > 0.005) _calcRow('−', 'Voyages & épargne', other, AppColors.violet),
        Divider(height: 18, color: context.trackColor),
        _calcRow('=', 'Solde actuel', total, total < 0 ? AppColors.danger : context.textColor,
            bold: true, showSign: false),
      ]),
    );
  }

  List<Widget> _section(_SectionDef def, BalanceDetail detail, Ym month, {bool first = false}) {
    final items = detail.items.where((i) => i.kind == def.kind).toList();
    if (def.kind == BalKind.other && items.isEmpty) return const [];
    // Les lignes pointées d'abord, puis celles à venir.
    items.sort((a, b) => (a.counts == b.counts) ? 0 : (a.counts ? -1 : 1));
    final done = items.where((i) => i.counts).length;
    final doneSum = detail.sumChecked(def.kind);
    final pendingSum = detail.sumPending(def.kind);
    final open = _expanded.contains(def.kind);
    return [
      SizedBox(height: first ? 0 : 10),
      AppCard(
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 4),
        child: Column(children: [
          InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => setState(() => open ? _expanded.remove(def.kind) : _expanded.add(def.kind)),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
              child: Row(children: [
                CircleEmoji(def.emoji, def.color, size: 38),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(def.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5)),
                    Text(
                        items.isEmpty
                            ? def.empty
                            : '$done / ${items.length} pointé${done > 1 ? 's' : ''}'
                                '${pendingSum.abs() > 0.005 ? ' · ${eur(pendingSum.abs())} à venir' : ''}',
                        style: TextStyle(color: context.mutedColor, fontSize: 12)),
                  ]),
                ),
                if (items.isNotEmpty)
                  Text(eur(doneSum, sign: true),
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: def.color)),
                Icon(open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: context.mutedColor),
              ]),
            ),
          ),
          if (open)
            for (final it in items) _row(it, def, month),
        ]),
      ),
    ];
  }

  Widget _row(BalItem it, _SectionDef def, Ym month) {
    final canToggle = _canToggle(it);
    final canGo = it.action != null;
    return Opacity(
      opacity: it.counts ? 1 : .6,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: canGo ? () => _goTo(it, month) : null,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 8, 4),
          child: Row(children: [
            if (canToggle)
              CheckCircle(checked: it.checked, onTap: () => _toggle(it, month))
            else
              const SizedBox(width: 12),
            if (it.emoji != null && it.emoji!.isNotEmpty) ...[
              Text(it.emoji!, style: const TextStyle(fontSize: 18)),
              const SizedBox(width: 8),
            ],
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(it.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  Text(it.deferred ? (it.note ?? '') : (it.checked ? (it.note ?? '') : 'À venir${it.note != null ? ' · ${it.note}' : ''}'),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
                ]),
              ),
            ),
            const SizedBox(width: 8),
            Text(eur(it.amount, sign: true),
                style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 14.5,
                    color: it.counts ? def.color : context.mutedColor)),
            if (canGo) Icon(Icons.chevron_right_rounded, size: 18, color: context.mutedColor),
          ]),
        ),
      ),
    );
  }
}
