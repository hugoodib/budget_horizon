import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart' show StylePicker;
import '../widgets/tips.dart';

String _pct(double v) => '${v.toStringAsFixed(2).replaceAll('.', ',')} %';

/// Onglet « Clients » : les clients de l'auto-entrepreneur et le salaire net qui en découle.
/// Sélecteur Clients | Factures, en haut des deux pages (un seul onglet dans la barre).
/// Bascule Clients / Factures : très visible, pour toujours savoir où l'on est.
class ClientsSwitch extends ConsumerWidget {
  final AppTab current;
  const ClientsSwitch({super.key, required this.current});

  @override
  Widget build(BuildContext context, WidgetRef ref) => TabSwitcher<AppTab>(
        tabs: const [
          (value: AppTab.clients,  label: 'Clients',  icon: Icons.groups_rounded),
          (value: AppTab.invoices, label: 'Factures', icon: Icons.description_rounded),
        ],
        selected: current,
        hint: Hint.clientsSwitch,
        onChanged: (t) => ref.read(tabProvider.notifier).state = t,
      );
}

class ClientsScreen extends ConsumerWidget {
  const ClientsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final persons = [for (final p in [1, 2]) if (d.aeActive(p)) p];
    double net(Ym ym, [int? person]) {
      final gross = person == null
          ? persons.fold(0.0, (s, p) => s + d.grossReceivedIn(ym, p))
          : d.grossReceivedIn(ym, person);
      return d.netFromGross(gross);
    }

    final gross = persons.fold(0.0, (s, p) => s + d.grossReceivedIn(now, p));
    final clients = d.clients.where((c) => d.aeActive(c.owner) && !c.isOneOff).toList();

    void open(Client? c) =>
        showSheet(context, title: c == null ? 'Nouveau client' : c.name, child: ClientSheet(existing: c));

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        // Swipe gauche → Factures
        if (details.primaryVelocity != null && details.primaryVelocity! < -300) {
          ref.read(tabProvider.notifier).state = AppTab.invoices;
        }
      },
      child: ScreenScaffold(
      title: 'Clients',
      actions: [RoundIconButton(key: TourKeys.addClient, icon: Icons.add_rounded, hint: Hint.clientsAdd, onTap: () => open(null))],
      pinned: const ClientsSwitch(current: AppTab.clients),
      children: [
        const SizedBox(height: 4),
        const SizedBox(height: 12),
        AppCard(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('En ${now.longName}',
                style: const TextStyle(
                    color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 6),
            Text(eur(net(now)),
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1)),
            const SizedBox(height: 4),
            Text('${d.user.privateMode ? 'Après retenue Unipro' : 'Brut'} ${eur(gross)} − charges URSSAF ${_pct(d.user.urssafRate)}',
                style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
            if (persons.length == 2) ...[
              const SizedBox(height: 10),
              for (final p in persons)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(children: [
                    Expanded(child: Text(d.personName(p), style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text(eur(net(now, p)), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                ),
            ],
            const SizedBox(height: 12),
            const Text('Prochains mois (net)',
                style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12.5)),
            const SizedBox(height: 6),
            Row(children: [
              for (var i = 1; i <= 3; i++)
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(now.add(i).short, style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                    Text(eur(net(now.add(i))), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                ),
            ]),
            const SizedBox(height: 10),
            const Text(
                'Comptabilisé automatiquement dans vos revenus.',
                style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
          ]),
        ),
        SectionTitle(
          'Vos clients',
          tip: 'clients1',
          trailing: GestureDetector(
            onTap: () { HapticFeedback.selectionClick(); open(null); },
            child: Container(
              padding: const EdgeInsets.fromLTRB(10, 6, 14, 6),
              decoration: BoxDecoration(
                gradient: brandGradient,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.add_rounded, size: 18, color: Colors.white),
                SizedBox(width: 4),
                Text('Nouveau', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5)),
              ]),
            ),
          ),
        ),
        if (clients.isEmpty)
          const AppCard(
            child: Text(
                'Aucun client. Touchez + pour en ajouter un.',
                style: TextStyle(height: 1.35)),
          ),
        for (final c in clients) ...[
          Builder(builder: (_) {
            final v = d.invoiceView(c, now);
            return AppCard(
              onTap: () => runWithHint(context, Hint.clientsRow, () => open(c)),
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              child: Row(children: [
                CircleEmoji(c.name.characters.first.toUpperCase(), clientColorOf(c), letter: true),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Flexible(child: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                      if (d.user.privateMode && c.unipro) ...[const SizedBox(width: 8), const UniproBadge()],
                    ]),
                    const SizedBox(height: 2),
                    Text(c.frequencyLabel, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                    if (c.colorValue != null && d.colorName('client', c.colorValue!) != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Container(width: 8, height: 8, decoration: BoxDecoration(color: Color(c.colorValue!), shape: BoxShape.circle)),
                          const SizedBox(width: 5),
                          Text(d.colorName('client', c.colorValue!)!,
                              style: TextStyle(color: Color(c.colorValue!), fontSize: 12, fontWeight: FontWeight.w700)),
                        ]),
                      ),
                    Text(
                        '${eur(c.amount)} / passage · ${c.durationLabel}${persons.length == 2 ? ' · ${d.personName(c.owner)}' : ''}',
                        style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                  ]),
                ),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(eur(v.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  Text('ce mois-ci', style: const TextStyle(color: AppColors.muted, fontSize: 11.5)),
                ]),
              ]),
            );
          }),
          const SizedBox(height: 10),
        ],
      ],
    ),
    );
  }
}

/// Création / modification d'un client.
class ClientSheet extends ConsumerStatefulWidget {
  final Client? existing;
  /// Premiers pas : le client n'est pas ajouté à l'app, il est renvoyé à l'appelant.
  final ValueChanged<Client>? onCollect;
  /// Premiers pas : propriétaires possibles (1 et/ou 2) et leurs prénoms.
  final List<int>? owners;
  final List<String>? ownerNames;
  const ClientSheet({super.key, this.existing, this.onCollect, this.owners, this.ownerNames});
  @override
  ConsumerState<ClientSheet> createState() => _ClientSheetState();
}

class _ClientSheetState extends ConsumerState<ClientSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _price = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.amount == widget.existing!.amount.roundToDouble()
              ? widget.existing!.amount.round().toString()
              : widget.existing!.amount.toString()));
  late final TextEditingController _duration =
      TextEditingController(text: (widget.existing?.durationMin ?? 60).toString());
  late FreqKind _kind = widget.existing?.kind ?? FreqKind.weekdays;
  late Set<int> _days = {...(widget.existing?.weekdays ?? const <int>[])};
  late int _times = widget.existing?.times ?? 1;
  late int _interval = widget.existing?.interval ?? 2;
  late Ym _start = widget.existing?.start ?? ref.read(nowProvider);
  late bool _unipro = widget.existing?.unipro ?? false;
  late int? _color = widget.existing?.colorValue;
  late final Map<int, String> _names = {
    for (final e in ref.read(appProvider).colorNames.entries)
      if (e.key.startsWith('client:')) int.parse(e.key.substring(7)): e.value,
  };
  late int _owner = widget.existing?.owner ?? _defaultOwner();
  // [Mode dev] forfait mensuel lissé
  late bool _forfaitOn = widget.existing?.forfait != null;
  late final TextEditingController _forfait = TextEditingController(
      text: widget.existing?.forfait == null
          ? ''
          : (widget.existing!.forfait! == widget.existing!.forfait!.roundToDouble()
              ? widget.existing!.forfait!.round().toString()
              : widget.existing!.forfait!.toString()));

  int _defaultOwner() {
    if (widget.owners != null && widget.owners!.isNotEmpty) return widget.owners!.first;
    final d = ref.read(appProvider);
    final me = ref.read(myPersonProvider);
    if (d.aeActive(me)) return me;
    if (d.aeActive(1)) return 1;
    return d.aeActive(2) ? 2 : 1;
  }

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    _duration.dispose();
    _forfait.dispose();
    super.dispose();
  }

  Widget _stepper(String suffix, int value, ValueChanged<int> onChanged, {int min = 1, int max = 10}) =>
      Row(children: [
        IconButton(
            onPressed: value > min ? () => onChanged(value - 1) : null,
            icon: const Icon(Icons.remove_circle_outline_rounded)),
        Text('$value $suffix', style: const TextStyle(fontWeight: FontWeight.w700)),
        IconButton(
            onPressed: value < max ? () => onChanged(value + 1) : null,
            icon: const Icon(Icons.add_circle_outline_rounded)),
      ]);

  Widget _cap(String t, {Hint? hint, String? sub}) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          hint == null
              ? Text(t, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600))
              : labelWithInfo(t, hint, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
          if (sub != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(sub, style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
            ),
        ]),
      );

  Widget _freqCard(FreqKind k, IconData icon, String title, String example) {
    final on = _kind == k;
    return GestureDetector(
      onTap: () { HapticFeedback.selectionClick(); setState(() => _kind = k); },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: on ? AppColors.violet.withAlpha(28) : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: on ? AppColors.violet.withAlpha(140) : Colors.transparent, width: 1.5),
        ),
        child: Row(children: [
          Icon(icon, size: 18, color: on ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 8),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: on ? AppColors.violet : null)),
              Text(example,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: AppColors.muted, fontSize: 11.5)),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _note(String t) => Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(
              padding: EdgeInsets.only(top: 1),
              child: Icon(Icons.info_outline_rounded, size: 13, color: AppColors.muted)),
          const SizedBox(width: 5),
          Expanded(child: Text(t, style: const TextStyle(color: AppColors.muted, fontSize: 12.5))),
        ]),
      );

  void _save() {
    final price = parseAmount(_price.text);
    final minutes = int.tryParse(_duration.text.trim());
    if (_name.text.trim().isEmpty || price == null || price <= 0) {
      snack(context, 'Nom et montant requis');
      return;
    }
    if (minutes == null || minutes <= 0) {
      snack(context, 'Durée requise (en minutes)');
      return;
    }
    if (_kind == FreqKind.weekdays && _days.isEmpty) {
      snack(context, 'Choisissez au moins un jour de la semaine');
      return;
    }
    final dev = ref.read(devModeProvider);
    double? forfait = widget.existing?.forfait; // hors mode dev : on conserve l'existant
    if (dev) {
      forfait = null;
      if (_forfaitOn) {
        forfait = parseAmount(_forfait.text);
        if (forfait == null || forfait <= 0) {
          snack(context, 'Indique le montant du forfait');
          return;
        }
      }
    }
    final c = Client(
      forfait: forfait,
      unipro: ref.read(appProvider).user.privateMode && _unipro,
      colorValue: _color,
      id: widget.existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: _name.text.trim(),
      owner: _owner,
      amount: price,
      durationMin: minutes,
      kind: _kind,
      weekdays: _days.toList()..sort(),
      times: _times,
      interval: _interval,
      start: _start,
      end: widget.existing?.end,
    );
    if (widget.onCollect != null) {
      widget.onCollect!(c);
      Navigator.pop(context);
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (_color != null) n.setColorNames('client', _names);
    widget.existing == null ? n.addClient(c) : n.updateClient(c);
    Navigator.pop(context);
  }

  /// [Mode dev] Forfait mensuel lissé sur l'année : même facture chaque mois,
  /// on ne déduit que les passages manqués.
  List<Widget> _forfaitSection() {
    final price = parseAmount(_price.text) ?? 0;
    final perWeek = _kind == FreqKind.weekdays
        ? _days.length
        : (_kind == FreqKind.weekly ? _times : 0);
    final equiv = price * perWeek * 4.33;
    return [
      const Divider(height: 28),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Forfait mensuel', style: TextStyle(fontWeight: FontWeight.w700)),
        subtitle: const Text('Même montant chaque mois, lissé sur l\'année. Seuls les passages manqués sont déduits.'),
        value: _forfaitOn,
        onChanged: (v) => setState(() => _forfaitOn = v),
      ),
      if (_forfaitOn) ...[
        const SizedBox(height: 6),
        TextField(
          controller: _forfait,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(labelText: 'Montant du forfait par mois', suffixText: '€'),
        ),
        if (price > 0 && perWeek > 0) ...[
          const SizedBox(height: 8),
          GestureDetector(
            onTap: () => setState(() => _forfait.text = equiv.round().toString()),
            child: Text(
              '${eur(price)} × $perWeek par semaine × 4,33 = ${eur(equiv)}  ·  toucher pour utiliser ${equiv.round()} €',
              style: const TextStyle(color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
        ],
        const SizedBox(height: 6),
        Text(
          'Si un passage n\'est pas fait, la facture baisse de ${price > 0 ? eur(price) : 'un passage'} par absence (à saisir dans la facture du mois).',
          style: TextStyle(color: context.mutedColor, fontSize: 12.5, height: 1.3),
        ),
      ],
    ];
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final both = widget.owners != null ? widget.owners!.length > 1 : d.aeActive(1) && d.aeActive(2);
    final anchored = _kind == FreqKind.everyMonths || _kind == FreqKind.yearly;
    final curMin = int.tryParse(_duration.text.trim()) ?? -1;
    String hm(int m) => m < 60 ? '$m min' : (m % 60 == 0 ? '${m ~/ 60} h' : '${m ~/ 60} h ${m % 60}');
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(
          controller: _name,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
              labelText: 'Nom du client', prefixIcon: Icon(Icons.person_outline_rounded, size: 20))),
      if (both) ...[
        const SizedBox(height: 12),
        TabSwitcher<int>(
          tabs: <({int value, String label, IconData? icon})>[
            for (final p in [1, 2]) (value: p, label: widget.ownerNames != null ? widget.ownerNames![p - 1] : d.personName(p), icon: Icons.person_rounded),
          ],
          selected: _owner,
          onChanged: (p) => setState(() => _owner = p),
        ),
      ],
      const SizedBox(height: 18),
      _cap('Un passage', sub: 'Combien tu factures et combien de temps ça dure.'),
      Row(children: [
        Expanded(
          child: FieldInfo(Hint.fieldVisitPrice, child: TextField(
            controller: _price,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Prix d\'un passage', suffixText: '€ '),
          )),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: FieldInfo(Hint.fieldDuration, child: TextField(
            controller: _duration,
            keyboardType: TextInputType.number,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(labelText: 'Durée', suffixText: 'min '),
          )),
        ),
      ]),
      const SizedBox(height: 10),
      PillSelector<int>.scroll(
        items: [for (final m in const [30, 45, 60, 90, 120, 150, 180, 210, 240, 300, 360, 420, 480]) PillItem(m, hm(m))],
        selected: curMin,
        onChanged: (m) => setState(() => _duration.text = '$m'),
      ),
      const SizedBox(height: 18),
      _cap('Fréquence des passages', hint: Hint.fieldClientFreq, sub: 'Choisis ce qui ressemble le plus à ce client.'),
      GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 3.1,
        children: [
          _freqCard(FreqKind.weekdays, Icons.calendar_view_week_rounded, 'Certains jours', 'Ex. lundi et jeudi'),
          _freqCard(FreqKind.weekly, Icons.repeat_rounded, 'Par semaine', 'Ex. 2 fois / semaine'),
          _freqCard(FreqKind.monthly, Icons.calendar_month_rounded, 'Par mois', 'Ex. 3 fois / mois'),
          _freqCard(FreqKind.everyMonths, Icons.event_repeat_rounded, 'Un mois sur N', 'Ex. 1 mois sur 3'),
          _freqCard(FreqKind.yearly, Icons.celebration_rounded, '1 fois par an', 'Ex. ramonage'),
        ],
      ),
      const SizedBox(height: 10),
      if (_kind == FreqKind.weekdays) ...[
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (var i = 1; i <= 7; i++)
            GestureDetector(
              onTap: () => setState(() => _days.contains(i) ? _days.remove(i) : _days.add(i)),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: _days.contains(i) ? AppColors.violet.withAlpha(28) : Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _days.contains(i) ? AppColors.violet.withAlpha(140) : Colors.transparent, width: 1.5),
                ),
                child: Center(child: Text(weekdayNames[i - 1].substring(0, 2),
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
                    color: _days.contains(i) ? AppColors.violet : Theme.of(context).colorScheme.onSurface.withAlpha(120)))),
              ),
            ),
        ]),
        const SizedBox(height: 4),
        const Text('Chaque semaine, les jours cochés (ex. lundi et mardi).',
            style: TextStyle(color: AppColors.muted, fontSize: 12.5)),
      ],
      if (_kind == FreqKind.weekly) _stepper('fois par semaine', _times, (v) => setState(() => _times = v), max: 7),
      if (_kind == FreqKind.monthly) _stepper('fois par mois', _times, (v) => setState(() => _times = v), max: 20),
      if (_kind == FreqKind.everyMonths) ...[
        _cap('Un mois sur combien ?'),
        PillSelector<int>.scroll(
          items: const [
            PillItem(2,  '1 sur 2'),
            PillItem(3,  '1 sur 3'),
            PillItem(4,  '1 sur 4'),
            PillItem(6,  '1 sur 6'),
            PillItem(12, '1 par an'),
          ],
          selected: _interval,
          onChanged: (n) => setState(() => _interval = n),
        ),
        const SizedBox(height: 12),
        _cap('Combien de passages ce mois-là ?'),
        _stepper(_times > 1 ? 'passages' : 'passage', _times, (v) => setState(() => _times = v), max: 20),
        const SizedBox(height: 4),
        Row(children: [
          for (var i = 0; i < 12; i++)
            Expanded(
              child: Builder(builder: (_) {
                final on = i % _interval == 0;
                const mn = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 1.5),
                  height: 30,
                  decoration: BoxDecoration(
                    color: on ? AppColors.violet : Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(
                    child: Text(mn[(_start.add(i).month - 1) % 12],
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: on ? Colors.white : AppColors.muted)),
                  ),
                );
              }),
            ),
        ]),
        _note('En violet : les mois où tu y vas ($_times passage${_times > 1 ? 's' : ''} ${_interval == 12 ? 'par an' : 'tous les $_interval mois'}).'),
      ],
      const SizedBox(height: 10),
      SoftButton(
        icon: Icons.play_arrow_rounded,
        label: anchored ? 'Premier passage en : ${_start.label}' : 'Client actif depuis : ${_start.label}',
        onPressed: () async {
          final y = await pickYm(context, _start);
          if (y != null) setState(() => _start = y);
        },
      ),
      const Divider(height: 28),
      _cap('Couleur du client', sub: 'Nomme-la (Particuliers, Vitres…) pour classer tes clients d\'un coup d\'œil.'),
      StylePicker(
        emoji: '',
        color: _color ?? AppColors.palette[_name.text.length % AppColors.palette.length].value,
        showEmoji: false,
        previewLetter: _name.text.trim().isEmpty ? '?' : _name.text.trim().characters.first.toUpperCase(),
        onEmoji: (_) {},
        onColor: (v) => setState(() => _color = v),
        colorNames: _names,
        onRenameColor: (v, t) => setState(() => _names[v] = t),
      ),
      if (ref.watch(appProvider).user.privateMode) ...[
        const Divider(height: 28),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Client via Unipro', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(
              'La coopérative retient ${ref.watch(appProvider).user.uniproRate.toStringAsFixed(2).replaceAll('.', ',')} % de chaque facture, puis les charges URSSAF s\'appliquent sur le reste.'),
          value: _unipro,
          onChanged: (v) => setState(() => _unipro = v),
        ),
      ],
      if (ref.watch(devModeProvider)) ..._forfaitSection(),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: GradientButton(label: 'Enregistrer', onPressed: _save)),
      if (widget.existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer ce client',
          onPressed: () {
            ref.read(appProvider.notifier).removeClient(widget.existing!.id);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}
