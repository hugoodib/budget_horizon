import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';

String _pct(double v) => '${v.toStringAsFixed(2).replaceAll('.', ',')} %';

/// Onglet « Clients » : les clients de l'auto-entrepreneur et le salaire net qui en découle.
/// Sélecteur Clients | Factures, en haut des deux pages (un seul onglet dans la barre).
/// Bascule Clients / Factures : très visible, pour toujours savoir où l'on est.
class ClientsSwitch extends ConsumerWidget {
  final AppTab current;
  const ClientsSwitch({super.key, required this.current});

  @override
  Widget build(BuildContext context, WidgetRef ref) => TabSwitcher<AppTab>(
        tabs: const [
          (value: AppTab.clients,  label: 'Clients',  icon: Icons.groups_rounded),
          (value: AppTab.invoices, label: 'Factures', icon: Icons.description_rounded),
        ],
        selected: current,
        onChanged: (t) => ref.read(tabProvider.notifier).state = t,
      );
}

class ClientsScreen extends ConsumerWidget {
  const ClientsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final persons = [for (final p in [1, 2]) if (d.aeActive(p)) p];
    double net(Ym ym, [int? person]) {
      final gross = person == null
          ? persons.fold(0.0, (s, p) => s + d.grossReceivedIn(ym, p))
          : d.grossReceivedIn(ym, person);
      return d.netFromGross(gross);
    }

    final gross = persons.fold(0.0, (s, p) => s + d.grossReceivedIn(now, p));
    final clients = d.clients.where((c) => d.aeActive(c.owner)).toList();

    void open(Client? c) =>
        showSheet(context, title: c == null ? 'Nouveau client' : c.name, child: ClientSheet(existing: c));

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        // Swipe gauche → Factures
        if (details.primaryVelocity != null && details.primaryVelocity! < -300) {
          ref.read(tabProvider.notifier).state = AppTab.invoices;
        }
      },
      child: ScreenScaffold(
      title: 'Clients',
      actions: [RoundIconButton(key: TourKeys.addClient, icon: Icons.add_rounded, onTap: () => open(null))],
      pinned: const ClientsSwitch(current: AppTab.clients),
      children: [
        const SizedBox(height: 4),
        const SizedBox(height: 12),
        AppCard(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('SALAIRE NET · ${now.longName.toUpperCase()}',
                style: const TextStyle(
                    color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 2)),
            const SizedBox(height: 6),
            Text(eur(net(now)),
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1)),
            const SizedBox(height: 4),
            Text('Brut ${eur(gross)} − charges URSSAF ${_pct(d.user.urssafRate)}',
                style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
            if (persons.length == 2) ...[
              const SizedBox(height: 10),
              for (final p in persons)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(children: [
                    Expanded(child: Text(d.personName(p), style: const TextStyle(fontWeight: FontWeight.w600))),
                    Text(eur(net(now, p)), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                ),
            ],
            const SizedBox(height: 12),
            const Text('Prochains mois (net)',
                style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12.5)),
            const SizedBox(height: 6),
            Row(children: [
              for (var i = 1; i <= 3; i++)
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(now.add(i).short, style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                    Text(eur(net(now.add(i))), style: const TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                ),
            ]),
            const SizedBox(height: 10),
            const Text(
                'Ce salaire est ajouté automatiquement à vos revenus.',
                style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
          ]),
        ),
        const SectionTitle('Vos clients'),
        if (clients.isEmpty)
          const AppCard(
            child: Text(
                'Aucun client. Touchez + pour en ajouter un.',
                style: TextStyle(height: 1.35)),
          ),
        for (final c in clients) ...[
          Builder(builder: (_) {
            final v = d.invoiceView(c, now);
            return AppCard(
              onTap: () => open(c),
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              child: Row(children: [
                CircleEmoji(c.name.characters.first.toUpperCase(), AppColors.palette[c.name.length % AppColors.palette.length], letter: true),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 2),
                    Text(c.frequencyLabel, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                    Text(
                        '${eur(c.amount)} / passage · ${c.durationLabel}${persons.length == 2 ? ' · ${d.personName(c.owner)}' : ''}',
                        style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                  ]),
                ),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(eur(v.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  Text('ce mois-ci', style: const TextStyle(color: AppColors.muted, fontSize: 11.5)),
                ]),
              ]),
            );
          }),
          const SizedBox(height: 10),
        ],
      ],
    ),
    );
  }
}

/// Création / modification d'un client.
class ClientSheet extends ConsumerStatefulWidget {
  final Client? existing;
  const ClientSheet({super.key, this.existing});
  @override
  ConsumerState<ClientSheet> createState() => _ClientSheetState();
}

class _ClientSheetState extends ConsumerState<ClientSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _price = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.amount == widget.existing!.amount.roundToDouble()
              ? widget.existing!.amount.round().toString()
              : widget.existing!.amount.toString()));
  late final TextEditingController _duration =
      TextEditingController(text: (widget.existing?.durationMin ?? 60).toString());
  late FreqKind _kind = widget.existing?.kind ?? FreqKind.weekdays;
  late Set<int> _days = {...(widget.existing?.weekdays ?? const <int>[])};
  late int _times = widget.existing?.times ?? 1;
  late int _interval = widget.existing?.interval ?? 2;
  late Ym _start = widget.existing?.start ?? ref.read(nowProvider);
  late int _owner = widget.existing?.owner ?? _defaultOwner();

  int _defaultOwner() {
    final d = ref.read(appProvider);
    if (d.aeActive(1)) return 1;
    return d.aeActive(2) ? 2 : 1;
  }

  @override
  void dispose() {
    _name.dispose();
    _price.dispose();
    _duration.dispose();
    super.dispose();
  }

  Widget _stepper(String suffix, int value, ValueChanged<int> onChanged, {int min = 1, int max = 10}) =>
      Row(children: [
        IconButton(
            onPressed: value > min ? () => onChanged(value - 1) : null,
            icon: const Icon(Icons.remove_circle_outline_rounded)),
        Text('$value $suffix', style: const TextStyle(fontWeight: FontWeight.w700)),
        IconButton(
            onPressed: value < max ? () => onChanged(value + 1) : null,
            icon: const Icon(Icons.add_circle_outline_rounded)),
      ]);

  void _save() {
    final price = parseAmount(_price.text);
    final minutes = int.tryParse(_duration.text.trim());
    if (_name.text.trim().isEmpty || price == null || price <= 0) {
      snack(context, 'Renseignez un nom et le montant d\'un passage');
      return;
    }
    if (minutes == null || minutes <= 0) {
      snack(context, 'Renseignez la durée d\'un passage (en minutes)');
      return;
    }
    if (_kind == FreqKind.weekdays && _days.isEmpty) {
      snack(context, 'Choisissez au moins un jour de la semaine');
      return;
    }
    final c = Client(
      id: widget.existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: _name.text.trim(),
      owner: _owner,
      amount: price,
      durationMin: minutes,
      kind: _kind,
      weekdays: _days.toList()..sort(),
      times: _times,
      interval: _interval,
      start: _start,
      end: widget.existing?.end,
    );
    final n = ref.read(appProvider.notifier);
    widget.existing == null ? n.addClient(c) : n.updateClient(c);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final both = d.aeActive(1) && d.aeActive(2);
    final anchored = _kind == FreqKind.everyMonths || _kind == FreqKind.yearly;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(
          controller: _name,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Nom du client')),
      if (both) ...[
        const SizedBox(height: 12),
        TabSwitcher<int>(
          tabs: <({int value, String label, IconData? icon})>[
            for (final p in [1, 2]) (value: p, label: d.personName(p), icon: Icons.person_rounded),
          ],
          selected: _owner,
          onChanged: (p) => setState(() => _owner = p),
        ),
      ],
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: TextField(
            controller: _price,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Montant d\'un passage', suffixText: '€'),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: TextField(
            controller: _duration,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Durée', suffixText: 'min'),
          ),
        ),
      ]),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 6, children: [
        for (final m in const [30, 60, 90, 120, 180])
          GestureDetector(
            onTap: () { HapticFeedback.selectionClick(); setState(() => _duration.text = '$m'); },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                m < 60 ? '$m min' : (m % 60 == 0 ? '${m ~/ 60} h' : '${m ~/ 60} h 30'),
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurface.withAlpha(160)),
              ),
            ),
          ),
      ]),
      const SizedBox(height: 14),
      const Text('Fréquence des passages', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      PillSelector<FreqKind>(
        items: const [
          PillItem(FreqKind.weekdays,   'Certains jours'),
          PillItem(FreqKind.weekly,     'Par semaine'),
          PillItem(FreqKind.monthly,    'Par mois'),
          PillItem(FreqKind.everyMonths,'Tous les N mois'),
          PillItem(FreqKind.yearly,     '1 fois / an'),
        ],
        selected: _kind,
        onChanged: (k) => setState(() => _kind = k),
      ),
      const SizedBox(height: 10),
      if (_kind == FreqKind.weekdays) ...[
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (var i = 1; i <= 7; i++)
            GestureDetector(
              onTap: () => setState(() => _days.contains(i) ? _days.remove(i) : _days.add(i)),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                width: 40, height: 40,
                decoration: BoxDecoration(
                  color: _days.contains(i) ? AppColors.violet.withAlpha(28) : Theme.of(context).cardColor,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _days.contains(i) ? AppColors.violet.withAlpha(140) : Colors.transparent, width: 1.5),
                ),
                child: Center(child: Text(weekdayNames[i - 1].substring(0, 2),
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
                    color: _days.contains(i) ? AppColors.violet : Theme.of(context).colorScheme.onSurface.withAlpha(120)))),
              ),
            ),
        ]),
        const SizedBox(height: 4),
        const Text('Chaque semaine, les jours cochés (ex. lundi et mardi).',
            style: TextStyle(color: AppColors.muted, fontSize: 12.5)),
      ],
      if (_kind == FreqKind.weekly) _stepper('fois par semaine', _times, (v) => setState(() => _times = v), max: 7),
      if (_kind == FreqKind.monthly) _stepper('fois par mois', _times, (v) => setState(() => _times = v), max: 20),
      if (_kind == FreqKind.everyMonths)
        PillSelector<int>(
          items: const [
            PillItem(2,  'Tous les 2 mois'),
            PillItem(3,  'Tous les 3 mois'),
            PillItem(4,  'Tous les 4 mois'),
            PillItem(6,  'Tous les 6 mois'),
            PillItem(12, '1 fois par an'),
          ],
          selected: _interval,
          onChanged: (n) => setState(() => _interval = n),
        ),
      const SizedBox(height: 10),
      SoftButton(
        icon: Icons.play_arrow_rounded,
        label: anchored ? 'Premier passage en : ${_start.label}' : 'Client actif depuis : ${_start.label}',
        onPressed: () async {
          final y = await pickYm(context, _start);
          if (y != null) setState(() => _start = y);
        },
      ),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: GradientButton(label: 'Enregistrer', onPressed: _save)),
      if (widget.existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer ce client',
          onPressed: () {
            ref.read(appProvider.notifier).removeClient(widget.existing!.id);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}
