import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/forecast.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

/// Onglet « Charges » : total du mois, répartition, évolution sur 12 mois et liste détaillée.
class FixedExpensesScreen extends ConsumerStatefulWidget {
  const FixedExpensesScreen({super.key});
  @override
  ConsumerState<FixedExpensesScreen> createState() => _FixedExpensesScreenState();
}

enum _ChargeSort { alpha, uncheckedFirst, checkedFirst }

class _FixedExpensesScreenState extends ConsumerState<FixedExpensesScreen> {
  _ChargeSort _sort = _ChargeSort.alpha;

  @override
  void initState() {
    super.initState();
    // À chaque ouverture de l'onglet : revenir sur le mois actuel.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(chargeMonthProvider.notifier).state = ref.read(nowProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final ym = ref.watch(chargeMonthProvider);
    final fc = ref.watch(forecastProvider);
    final cur = fc.at(ym);

    final all = d.fixedExpenses;
    Color colorOf(FixedExpense f) => f.colorValue != null
        ? Color(f.colorValue!)
        : AppColors.palette[all.indexWhere((e) => e.id == f.id) % AppColors.palette.length];

    int byName(FixedExpense a, FixedExpense b) => a.name.toLowerCase().compareTo(b.name.toLowerCase());
    int byCheck(FixedExpense a, FixedExpense b) {
      final ca = a.isChecked(ym) ? 1 : 0;
      final cb = b.isChecked(ym) ? 1 : 0;
      if (_sort == _ChargeSort.uncheckedFirst) {
        final diff = ca.compareTo(cb);
        return diff != 0 ? diff : byName(a, b);
      }
      // checkedFirst
      final diff = cb.compareTo(ca);
      return diff != 0 ? diff : byName(a, b);
    }

    List<FixedExpense> sortList(List<FixedExpense> list) {
      if (_sort == _ChargeSort.alpha) return list..sort(byName);
      return list..sort(byCheck);
    }

    final active = sortList(all.where((f) => f.activeIn(ym) && !f.isChecked(ym)).toList());
    final checked = sortList(all.where((f) => f.activeIn(ym) && f.isChecked(ym)).toList());
    final upcoming = all.where((f) => f.start.isAfter(ym)).toList()..sort(byName);
    // Terminées : celles dont la fin est exactement ce mois affiché (dernier mois actif = ym)
    final ended = all.where((f) => f.end != null && f.end! == ym).toList()..sort(byName);
    // Répartition : les segments de même couleur sont regroupés côte à côte.
    final activeByColor = [...active]..sort((a, b) => colorOf(a).value.compareTo(colorOf(b).value));

    final total = active.fold(0.0, (s, f) => s + f.amount);
    final income = cur?.income ?? 0;
    final ratio = income > 0 ? total / income : 0.0;
    final months12 = [for (var i = 0; i < 12; i++) fc.at(now.add(i))].whereType<MonthForecast>().toList();
    final year = months12.fold(0.0, (s, m) => s + m.fixed);

    void open(FixedExpense? f) => showSheet(context,
        title: f == null ? 'Nouvelle charge fixe' : f.name,
        child: AddFixedExpenseSheet(existing: f));

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        // Swipe gauche → Revenus
        if (details.primaryVelocity != null && details.primaryVelocity! < -300) {
          ref.read(tabProvider.notifier).state = AppTab.incomes;
        }
      },
      child: ScreenScaffold(
      title: 'Mensuel',
      actions: [RoundIconButton(icon: Icons.add_rounded, onTap: () => open(null))],
      pinned: MonthSwitcher(
        value: ym,
        min: d.startYm,
        now: now,
        onChanged: (v) => ref.read(chargeMonthProvider.notifier).state = v,
      ),
      children: [
        const FixesSwitch(),
        // ---- Total du mois ----
        AppCard(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Ce que vous payez en ${ym.longName}',
                style: const TextStyle(
                    color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 6),
            Text(eur(total),
                style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: -1)),
            const SizedBox(height: 4),
            Text(
              active.isEmpty
                  ? 'Aucune charge ce mois-ci'
                  : '${active.length} charge${active.length > 1 ? 's' : ''} · environ ${eur(year)} sur l\'année',
              style: const TextStyle(color: AppColors.muted, fontSize: 13.5),
            ),
            if (active.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                  '${active.where((f) => f.isChecked(ym)).length} sur ${active.length} déjà prélevées — touchez le cercle pour cocher',
                  style: const TextStyle(color: AppColors.success, fontSize: 12.5, fontWeight: FontWeight.w600)),
            ],
            if (active.isNotEmpty) ...[
              const SizedBox(height: 16),
              // Répartition : un segment coloré par charge, regroupées par couleur, sans espace
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Row(children: [
                  for (final f in activeByColor)
                    Expanded(
                      flex: max(1, (f.amount * 10).round()),
                      child: Container(
                        height: 10,
                        color: colorOf(f),
                      ),
                    ),
                ]),
              ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: Text(
                    income > 0
                        ? '${(ratio * 100).round()} % de vos revenus — vos charges représentent ${eur(total)} sur ${eur(income)} gagnés'
                        : 'Aucun revenu renseigné ce mois-ci',
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              AppProgress(value: ratio, color: ratio > .6 ? AppColors.warning : AppColors.teal),
              const SizedBox(height: 8),
              Text('Il vous reste ${eur(income - total)} après avoir tout payé',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ],
          ]),
        ),
        // ---- Listes ----
        if (all.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 16),
            child: AppCard(child: Text('Aucune charge fixe. Touchez + pour ajouter votre loyer, vos abonnements, votre assurance…', style: TextStyle(height: 1.4))),
          ),
        if (active.isNotEmpty) ...[
          // ── Trier (juste au-dessus des dépenses) ─────────────
          Padding(
            padding: const EdgeInsets.only(top: 4, bottom: 4),
            child: PillSelector<_ChargeSort>.scroll(
                items: const [
                  PillItem(_ChargeSort.alpha,         'Par nom'),
                  PillItem(_ChargeSort.uncheckedFirst,'Non cochées en premier'),
                  PillItem(_ChargeSort.checkedFirst,  'Cochées en premier'),
                ],
                selected: _sort,
                onChanged: (s) => setState(() => _sort = s),
            ),
          ),
          const SectionTitle('À payer ce mois'),
          for (final f in active) ...[
            _ChargeCard(
                f: f,
                now: ym,
                color: colorOf(f),
                onTap: () => open(f),
                checked: false,
                onCheck: () => ref.read(appProvider.notifier).toggleFixedChecked(f.id, ym)),
            const SizedBox(height: 10),
          ],
        ],
        // ---- Évolution sur 12 mois (toujours à partir d'aujourd'hui) ----
        if (total > 0 || year > 0) ...[
          const SectionTitle('Ce que vous allez payer dans les 12 prochains mois'),
          AppCard(
            padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
            child: SizedBox(
              height: 150,
              child: BarChart(BarChartData(
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: 1,
                      reservedSize: 24,
                      getTitlesWidget: (v, meta) {
                        final i = v.toInt();
                        if (i < 0 || i >= months12.length) return const SizedBox.shrink();
                        final s = months12[i].ym.short;
                        return SideTitleWidget(
                          axisSide: meta.axisSide,
                          child: Text(s.substring(0, min(3, s.length)),
                              style: const TextStyle(fontSize: 9.5, color: AppColors.muted)),
                        );
                      },
                    ),
                  ),
                ),
                barTouchData: BarTouchData(
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipItem: (g, gi, rod, ri) => BarTooltipItem(
                        eur(rod.toY), const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ),
                ),
                barGroups: [
                  for (var i = 0; i < months12.length; i++)
                    BarChartGroupData(x: i, barRods: [
                      BarChartRodData(
                        toY: months12[i].fixed,
                        width: 13,
                        borderRadius: BorderRadius.circular(5),
                        color: i == 0 ? null : (Theme.of(context).brightness == Brightness.dark ? AppColors.trackDark : const Color(0xFFD9DCEB)),
                        gradient: i == 0 ? brandGradient : null,
                      ),
                    ]),
                ],
              )),
            ),
          ),
        ],
        if (upcoming.isNotEmpty) ...[
          const SectionTitle('Pas encore commencées'),
          for (final f in upcoming) ...[
            _ChargeCard(f: f, now: ym, color: colorOf(f), onTap: () => open(f)),
            const SizedBox(height: 10),
          ],
        ],
        if (checked.isNotEmpty) ...[
          const SectionTitle('Déjà prélevées ce mois'),
          for (final f in checked) ...[
            _ChargeCard(
                f: f,
                now: ym,
                color: colorOf(f),
                onTap: () => open(f),
                checked: true,
                onCheck: () => ref.read(appProvider.notifier).toggleFixedChecked(f.id, ym)),
            const SizedBox(height: 10),
          ],
        ],

      ],
    ),
    );
  }
}

class _ChargeCard extends StatelessWidget {
  final FixedExpense f;
  final Ym now;
  final Color color;
  final VoidCallback onTap;
  final bool checked;
  final VoidCallback? onCheck;
  const _ChargeCard(
      {required this.f,
      required this.now,
      required this.color,
      required this.onTap,
      this.checked = false,
      this.onCheck});

  @override
  Widget build(BuildContext context) {
    final isEnded = f.end != null && f.end!.isBefore(now);
    final isUpcoming = f.start.isAfter(now);
    final freq = f.intervalMonths > 1 ? ' · ${f.frequencyLabel.toLowerCase()}' : '';
    final period = f.end == null
        ? 'Tous les mois depuis ${f.start.short} ${f.start.year}$freq'
        : 'De ${f.start.short} ${f.start.year} à ${f.end!.short} ${f.end!.year}$freq';
    String? extra;
    if (!isEnded && f.end != null) {
      final from = isUpcoming ? f.start : now;
      final left = f.end!.index - from.index + 1;
      extra = isUpcoming
          ? 'Pendant $left mois — ${eur(f.amount * left)} au total'
          : 'Encore $left mois à payer — ${eur(f.amount * left)} restants';
    } else if (isUpcoming) {
      extra = 'Commence en ${f.start.longName.toLowerCase()} ${f.start.year}';
    }
    final faded = isEnded;
    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.fromLTRB(14, 12, 16, 12),
      child: Opacity(
        opacity: faded ? .55 : 1,
        child: Row(children: [
          f.emoji.isNotEmpty
              ? CircleEmoji(f.emoji, color)
              : CircleEmoji(f.name.characters.first.toUpperCase(), color, letter: true),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(f.name,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                if (f.leaveTypeId != null)
                  Consumer(builder: (ctx, ref, _) {
                    final lt = ref.watch(appProvider).leaveTypes
                        .where((t) => t.id == f.leaveTypeId).firstOrNull;
                    if (lt == null) return const SizedBox.shrink();
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: Color(lt.colorValue).withAlpha(25),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Color(lt.colorValue).withAlpha(80)),
                      ),
                      child: Text('🏖️ ${lt.name}',
                          style: TextStyle(
                              fontSize: 10, fontWeight: FontWeight.w700,
                              color: Color(lt.colorValue))),
                    );
                  }),
              ]),
              const SizedBox(height: 2),
              Text(period, style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
              if (extra != null)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(extra,
                      style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
                ),
            ]),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(eur(f.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const Text('par mois', style: TextStyle(color: AppColors.muted, fontSize: 11.5)),
          ]),
          if (onCheck != null) ...[
            const SizedBox(width: 4),
            CheckCircle(checked: checked, onTap: onCheck),
          ],
        ]),
      ),
    );
  }
}
