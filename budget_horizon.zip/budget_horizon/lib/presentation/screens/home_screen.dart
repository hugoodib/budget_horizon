import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/forecast.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/close_month.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';
import 'budgets_screen.dart' show BudgetDetailSheet, showBudgetDetailSheet;
import '../widgets/trip_cards.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final fc = ref.watch(forecastProvider);
    final now = ref.watch(nowProvider);
    final cur = fc.at(now);
    if (cur == null) return const SizedBox.shrink();
    final balance = Forecaster.currentBalance(d, cur);
    final delta = cur.endBalance - balance;


    // Budgets par catégorie.
    final sharedRows = <Widget>[];
    // Pour les séparés : on collecte les catégories (pas des widgets par ligne)
    final splitCats = <({Category cat, Budget b1, Budget b2})>[];

    for (final c in d.categories) {
      final bs = d.sortedBudgets.where((b) => b.categoryId == c.id).toList();
      if (bs.isEmpty) continue;
      if (d.isCouple && bs.any((b) => b.person != 0)) {
        final b1 = bs.where((b) => b.person == 1).firstOrNull;
        final b2 = bs.where((b) => b.person == 2).firstOrNull;
        if (b1 != null && b2 != null) {
          splitCats.add((cat: c, b1: b1, b2: b2));
        }
      } else {
        final b = bs.first;
        final cat = c;
        sharedRows.add(BudgetRow(
          emoji: c.emoji,
          tileColor: Color(c.colorValue),
          name: c.name,
          spent: bs.fold(0.0, (s, b) => s + d.spentForBudget(b, now)),
          planned: bs.fold(0.0, (s, b) => s + b.amountIn(now)),
          onTap: () => showBudgetDetailSheet(context,
              budgetId: b.id, categoryId: cat.id, month: now),
        ));
      }
    }

    // Deux bulles côte à côte : Hugo à gauche, Lisa à droite
    List<({Category cat, String? budgetId, double spent, double planned})> itemsFor(int person) =>
        splitCats.map((e) {
          final b = person == 1 ? e.b1 : e.b2;
          return (cat: e.cat, budgetId: b.id, spent: d.spentForBudget(b, now), planned: b.amountIn(now));
        }).toList();

    void openDetail(String budgetId, Category cat, int person, Ym month) {
      showBudgetDetailSheet(context,
          budgetId: budgetId, categoryId: cat.id, month: month, person: person);
    }

    final budgetWidgets = <Widget>[
      ...sharedRows,
      if (splitCats.isNotEmpty)
        IntrinsicHeight(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(child: PersonBudgetBubble(
                person: 1, items: itemsFor(1), month: now, onItemTap: openDetail)),
            const SizedBox(width: 10),
            Expanded(child: PersonBudgetBubble(
                person: 2, items: itemsFor(2), month: now, onItemTap: openDetail)),
          ]),
        ),
    ];
    final planned = d.plannedIn(now);
    final spent = d.spentIn(now);

    return ScreenScaffold(
      title: now.label,
      children: [
        // ── Bandeau mode démo ────────────────────────────────────
        if (d.user.isDemo)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [Color(0xFF9E8DF3), Color(0xFF6FD3BE)]),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(children: [
              const Text('🎭', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Données d\'exemple', style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14)),
                  Text('L\'app est préremplie pour vous montrer comment ça marche. Effacez tout quand vous êtes prêt à saisir vos vraies données.',
                      style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4)),
                ]),
              ),
              TextButton(
                onPressed: () => _showResetDialog(context, ref),
                style: TextButton.styleFrom(
                  backgroundColor: Colors.white.withAlpha(40),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Effacer', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ]),
          ),
        AppCard(
          key: TourKeys.balance,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // ── Deux soldes côte à côte ────────────────────────────
            IntrinsicHeight(
              child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                // Gauche : solde actuel (cliquable pour modifier)
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      final displayStart = double.parse(cur.startBalance.toStringAsFixed(2));
                      final v = await askAmount(
                          context, 'Solde au début de ${now.longName.toLowerCase()}', displayStart,
                          hint:
                              'C\'est le montant sur votre compte au 1er ${now.longName.toLowerCase()}, avant que vos revenus et dépenses de ce mois arrivent.');
                      if (v != null) {
                        final delta = v - displayStart;
                        final newStart = double.parse((d.startBalance + delta).toStringAsFixed(2));
                        ref.read(appProvider.notifier).setStartBalance(newStart);
                      }
                    },
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        const Text("SOLDE ACTUEL",
                            style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600,
                                fontSize: 11, letterSpacing: 1.8)),
                        const SizedBox(width: 4),
                        const Icon(Icons.edit_outlined, size: 13, color: AppColors.muted),
                      ]),
                      const SizedBox(height: 4),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(eurDec(balance),
                            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900,
                                letterSpacing: -1.0)),
                      ),
                    ]),
                  ),
                ),
                // Séparateur vertical
                Container(
                  width: 1,
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
                  color: context.trackColor,
                ),
                // Droite : solde prévu fin de mois
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('IL VOUS RESTERA',
                        style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600,
                            fontSize: 11, letterSpacing: 1.8)),
                    const SizedBox(height: 4),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(eur(cur.endBalance),
                          style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w900,
                              letterSpacing: -1.0,
                              color: cur.endBalance < 0 ? AppColors.danger
                                  : delta < 0 ? AppColors.warning : AppColors.success)),
                    ),
                    Text(
                      delta >= 0
                          ? '+${eur(delta)} d\'ici la fin du mois'
                          : '−${eur(-delta)} d\'ici la fin du mois',
                      style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          color: delta >= 0 ? AppColors.success : AppColors.danger),
                    ),
                  ]),
                ),
              ]),
            ),
            const SizedBox(height: 10),
            // Reste à dépenser par jour jusqu'à la fin du mois (budgets restants ÷ jours restants)
            Builder(builder: (_) {
              final today = DateTime.now();
              final lastDay = DateTime(now.year, now.month + 1, 0).day;
              final isRealMonth = today.year == now.year && today.month == now.month;
              final daysLeft = isRealMonth ? lastDay - today.day + 1 : lastDay;
              final left = d.plannedIn(now) - d.spentIn(now);
              if (d.plannedIn(now) <= 0) return const SizedBox.shrink();
              final perDay = left / daysLeft;
              final ok = left >= 0;
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                  decoration: BoxDecoration(
                    color: ok ? context.fieldColor : tint(AppColors.danger, .12),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(children: [
                    Container(
                      width: 4, height: 36,
                      decoration: BoxDecoration(
                        color: ok ? AppColors.teal : AppColors.danger,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ok ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text.rich(TextSpan(children: [
                          TextSpan(text: eur(perDay),
                              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                          const TextSpan(text: ' par jour'),
                        ]), style: TextStyle(fontSize: 14, color: context.textColor)),
                        Text(
                          'Enveloppe restante répartie sur $daysLeft jour${daysLeft > 1 ? 's' : ''}',
                          style: const TextStyle(fontSize: 12, color: AppColors.muted),
                        ),
                      ]) : Text.rich(TextSpan(children: [
                        const TextSpan(text: 'Vos dépenses dépassent vos budgets de '),
                        TextSpan(text: eur(-left),
                            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.danger)),
                        const TextSpan(text: ' ce mois-ci.'),
                      ]), style: TextStyle(fontSize: 13.5, height: 1.3, color: context.textColor)),
                    ),
                  ]),
                ),
              );
            }),

          ]),
        ),
        const SizedBox(height: 12),
        // Voyage du mois : son budget s'applique pendant le mois du voyage
        for (final p in d.projects.where((p) => p.tripIn(now))) ...[
          TripBudgetCard(project: p, month: now),
          const SizedBox(height: 12),
        ],
        if (d.hasAE)
          Builder(builder: (_) {
            final overdue = d.invoicesReceivedIn(now).where((v) => v.isLate && !v.paid).toList();
            if (overdue.isEmpty) return const SizedBox.shrink();
            final sum = overdue.fold(0.0, (s, v) => s + v.amount);
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: AppCard(
                onTap: () => ref.read(tabProvider.notifier).state = AppTab.invoices,
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                child: Row(children: [
                  const Text('⚠️', style: TextStyle(fontSize: 22)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                        'Retard de paiement : ${overdue.length} facture${overdue.length > 1 ? 's' : ''} de mois précédents (${eur(sum)} brut). Cochez « payée » dans Factures dès réception.',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5, height: 1.3)),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                ]),
              ),
            );
          }),
        // 1. Solde actuel + prévu fin de mois : ci-dessus.
        // 2. Revenus et charges fixes.
        Row(key: TourKeys.stats, children: [
          Expanded(
              child: _StatCard(
                  label: 'Vous gagnez',
                  sublabel: 'ce mois-ci',
                  value: eur(cur.income),
                  color: AppColors.teal,
                  onTap: () => ref.read(tabProvider.notifier).state = AppTab.incomes)),
          const SizedBox(width: 12),
          Expanded(
              child: _StatCard(
                  label: 'Charges fixes',
                  sublabel: 'loyer, abonnements…',
                  value: eur(cur.fixed),
                  color: AppColors.pink,
                  onTap: () => ref.read(tabProvider.notifier).state = AppTab.charges)),
        ]),
        const SizedBox(height: 12),
        // 3. Budgets — version visuellement marquante
        _BudgetCard(
          key: TourKeys.budgetsCard,
          now: now,
          spent: spent,
          planned: planned,
          budgetWidgets: budgetWidgets,
          unexpected: d.unexpectedIn(now),
          onTap: () => ref.read(tabProvider.notifier).state = AppTab.budgets,
        ),
        // 4. Fin du mois — affiché en bas à moins de 7 jours de la fin (ou mois dépassé)
        Builder(builder: (_) {
          final target = closeTargetMonth(d, now);
          if (d.isClosed(target)) return const SizedBox.shrink();
          final timing = monthTiming(target);
          final show = timing.overdue ||
              (timing.daysLeft != null && timing.daysLeft! <= 7);
          if (!show) return const SizedBox.shrink();
          return Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 12),
            CloseMonthCard(month: target),
          ]);
        }),
      ],
    );
  }
}


/// Carte budgets de l'accueil : visuellement marquante.
/// Grand indicateur coloré du reste, tuiles par catégorie avec fond teinté.
class _BudgetCard extends StatelessWidget {
  final Ym now;
  final double spent;
  final double planned;
  final List<Widget> budgetWidgets;
  final double unexpected;
  final VoidCallback onTap;
  const _BudgetCard({
    super.key,
    required this.now,
    required this.spent,
    required this.planned,
    required this.budgetWidgets,
    required this.unexpected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final remaining = planned - spent;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final statusColor = ratio >= 1
        ? AppColors.danger
        : ratio >= .8
            ? AppColors.warning
            : AppColors.teal;
    return GestureDetector(
      onTap: onTap,
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // En-tête : titre + reste mis en avant
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Ce qu\'il reste à dépenser',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.muted)),
                const SizedBox(height: 4),
                Text(eur(remaining),
                    style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w900,
                        color: statusColor,
                        letterSpacing: -0.5)),
                Text('sur ${eur(planned)} de budget prévu',
                    style: const TextStyle(color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w500)),
              ]),
            ),
            // Indicateur circulaire
            SizedBox(
              width: 110,
              height: 110,
              child: ArcProgress(
                value: ratio.clamp(0.0, 1.0),
                color: statusColor,
                trackColor: context.trackColor,
                strokeWidth: 10,
                child: Text('${(ratio * 100).round()}%',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: statusColor)),
              ),
            ),
          ]),
          const SizedBox(height: 6),
          // Barre de progression épaisse
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: ratio.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: context.trackColor,
              valueColor: AlwaysStoppedAnimation(statusColor),
            ),
          ),
          if (unexpected > 0) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: tint(AppColors.warning, .12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(children: [
                const Text('⚡', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 8),
                const Expanded(child: Text('Imprévus',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
                Text(eur(-unexpected),
                    style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w800, fontSize: 14)),
              ]),
            ),
          ],
          if (budgetWidgets.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Divider(height: 1),
            const SizedBox(height: 16),
            for (var i = 0; i < budgetWidgets.length; i++) ...[
              if (i > 0) const SizedBox(height: 10),
              budgetWidgets[i],
            ],
          ] else ...[
            const SizedBox(height: 12),
            const Text('Vous n\'avez pas encore de budget. Allez dans l\'onglet Budgets pour définir vos enveloppes (courses, loisirs…).',
                style: TextStyle(color: AppColors.muted, fontSize: 13, height: 1.4)),
          ],
          const SizedBox(height: 8),
          // Bouton discret pour aller sur l'onglet budgets
          Align(
            alignment: Alignment.centerRight,
            child: Text('Gérer mes budgets →',
                style: TextStyle(
                    color: AppColors.violet,
                    fontWeight: FontWeight.w700,
                    fontSize: 13)),
          ),
        ]),
      ),
    );
  }
}

/// Budget en demi-largeur (colonne d'un conjoint).
class _SplitBudget extends StatelessWidget {
  final String title;
  final double spent;
  final double planned;
  const _SplitBudget({required this.title, required this.spent, required this.planned});

  @override
  Widget build(BuildContext context) {
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = ratio >= 1
        ? AppColors.danger
        : ratio >= .8
            ? AppColors.warning
            : AppColors.teal;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15)),
      const SizedBox(height: 2),
      Text('${eur(spent)} / ${eur(planned)}',
          style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
      const SizedBox(height: 8),
      AppProgress(value: ratio, color: color),
    ]);
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final String? sublabel;
  final Color color;
  final VoidCallback onTap;
  const _StatCard({required this.label, required this.value, required this.color, required this.onTap, this.sublabel});

  @override
  Widget build(BuildContext context) => AppCard(
        onTap: onTap,
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w600)),
          if (sublabel != null)
            Text(sublabel!, style: const TextStyle(color: AppColors.muted, fontSize: 11.5)),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Text('Voir', style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(width: 2),
            Icon(Icons.chevron_right_rounded, color: color, size: 17),
          ]),
        ]),
      );
}

void _showResetDialog(BuildContext context, WidgetRef ref) {
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
      title: const Text('Effacer toutes les données ?'),
      content: const Text(
        'Toutes les dépenses, budgets, revenus et projets seront supprimés. '
        'Vous repartirez d\'une page blanche pour saisir votre vraie situation financière.',
        style: TextStyle(height: 1.4),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Annuler')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
          onPressed: () {
            Navigator.pop(ctx);
            final now = ref.read(nowProvider);
            ref.read(appProvider.notifier).resetToEmpty(now);
          },
          child: const Text('Effacer et recommencer'),
        ),
      ],
    ),
  );
}
