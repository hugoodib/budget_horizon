import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../domain/forecast.dart';
import '../../domain/business.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/close_month.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';
import '../widgets/trip_cards.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final fc = ref.watch(forecastProvider);
    final now = ref.watch(nowProvider);
    final cur = fc.at(now);
    if (cur == null) return const SizedBox.shrink();
    final balance = Forecaster.currentBalance(d, cur);
    final delta = cur.endBalance - balance;
    final trendColor = delta < 0 ? AppColors.pink : AppColors.success;


    // Budgets par catégorie. En couple, « Loisirs » est affiché en deux colonnes
    // (un budget par conjoint) ; les autres catégories additionnent les deux.
    final sharedRows = <Widget>[];
    final splitRows = <Widget>[];
    for (final c in d.categories) {
      final bs = d.sortedBudgets.where((b) => b.categoryId == c.id).toList();
      if (bs.isEmpty) continue;
      if (d.isCouple && bs.any((b) => b.person != 0)) {
        splitRows.add(Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          for (var i = 0; i < bs.length; i++) ...[
            if (i > 0) const SizedBox(width: 18),
            Expanded(
              child: _SplitBudget(
                title: '${c.emoji}  ${c.name}',
                spent: d.spentForBudget(bs[i], now),
                planned: bs[i].amountIn(now),
              ),
            ),
          ],
        ]));
      } else {
        sharedRows.add(BudgetRow(
          emoji: c.emoji,
          tileColor: Color(c.colorValue),
          name: c.name,
          spent: bs.fold(0.0, (s, b) => s + d.spentForBudget(b, now)),
          planned: bs.fold(0.0, (s, b) => s + b.amountIn(now)),
        ));
      }
    }
    // Budgets communs d'abord, puis les budgets individuels sous les photos des deux colonnes
    final budgetWidgets = <Widget>[
      ...sharedRows,
      if (splitRows.isNotEmpty) ...[
        Row(children: [
          for (final p in [1, 2]) ...[
            if (p == 2) const SizedBox(width: 18),
            Expanded(
              child: Row(children: [
                PersonAvatar(person: p, size: 30),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(d.personName(p),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                ),
              ]),
            ),
          ],
        ]),
        ...splitRows,
      ],
    ];
    final planned = d.plannedIn(now);
    final spent = d.spentIn(now);

    return ScreenScaffold(
      title: now.label,
      children: [
        AppCard(
          key: TourKeys.balance,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(
                child: Text('SOLDE ACTUEL',
                    style: TextStyle(
                        color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 12, letterSpacing: 2.6)),
              ),
              RoundIconButton(
                icon: Icons.edit_outlined,
                size: 36,
                onTap: () async {
                  final v = await askAmount(
                      context, 'Solde au début de ${now.longName.toLowerCase()}', cur.startBalance,
                      hint:
                          'Le montant que vous aviez juste après la fin de ${now.add(-1).longName.toLowerCase()}, avant vos revenus et dépenses de ce mois-ci.');
                  if (v != null) {
                    ref.read(appProvider.notifier).setStartBalance(d.startBalance + (v - cur.startBalance));
                  }
                },
              ),
            ]),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(eurDec(balance),
                  style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w800, letterSpacing: -1.2)),
            ),
            const SizedBox(height: 10),
            // Solde prévu à la fin du mois : l'information clé, bien visible
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 12, 14, 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [tint(AppColors.teal, .30), tint(AppColors.violet, .30)]),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('PRÉVU FIN ${now.longName.toUpperCase()}',
                        style: const TextStyle(
                            color: AppColors.text, fontWeight: FontWeight.w700, fontSize: 11.5, letterSpacing: 1.8)),
                    const SizedBox(height: 2),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: Text(eur(cur.endBalance),
                          style: TextStyle(
                              fontSize: 32,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -0.8,
                              color: cur.endBalance < 0 ? AppColors.danger : AppColors.text)),
                    ),
                  ]),
                ),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Icon(delta < 0 ? Icons.trending_down_rounded : Icons.trending_up_rounded,
                      color: trendColor, size: 26),
                  const SizedBox(height: 2),
                  Text(eur(delta, sign: true),
                      style: TextStyle(color: trendColor, fontWeight: FontWeight.w800, fontSize: 14.5)),
                ]),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        // Voyage du mois : son budget s'applique pendant le mois du voyage
        for (final p in d.projects.where((p) => p.targetYm == now)) ...[
          TripBudgetCard(project: p, month: now),
          const SizedBox(height: 12),
        ],
        if (d.hasAE)
          Builder(builder: (_) {
            final overdue = d.invoicesReceivedIn(now).where((v) => v.isLate && !v.paid).toList();
            if (overdue.isEmpty) return const SizedBox.shrink();
            final sum = overdue.fold(0.0, (s, v) => s + v.amount);
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: AppCard(
                onTap: () => ref.read(tabProvider.notifier).state = AppTab.invoices,
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                child: Row(children: [
                  const Text('⚠️', style: TextStyle(fontSize: 22)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                        'Retard de paiement : ${overdue.length} facture${overdue.length > 1 ? 's' : ''} de mois précédents (${eur(sum)} brut). Cochez « payée » dans Factures dès réception.',
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5, height: 1.3)),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                ]),
              ),
            );
          }),
        // 1. Solde actuel + prévu fin de mois : ci-dessus.
        // 2. Revenus et charges fixes.
        Row(key: TourKeys.stats, children: [
          Expanded(
              child: _StatCard(
                  label: 'Revenus',
                  value: eur(cur.income),
                  color: AppColors.teal,
                  onTap: () => ref.read(tabProvider.notifier).state = AppTab.incomes)),
          const SizedBox(width: 12),
          Expanded(
              child: _StatCard(
                  label: 'Charges fixes',
                  value: eur(cur.fixed),
                  color: AppColors.pink,
                  onTap: () => ref.read(tabProvider.notifier).state = AppTab.charges)),
        ]),
        const SizedBox(height: 12),
        // 3. Clôturer le mois.
        CloseMonthCard(month: closeTargetMonth(d, now)),
        const SizedBox(height: 12),
        // 4. Budgets.
        AppCard(
          key: TourKeys.budgetsCard,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
          child: Column(children: [
            Row(children: [
              Expanded(
                child: Text('Budgets · ${now.longName}',
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              ),
              Text('Reste ${eur(planned - spent)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
            ]),
            const SizedBox(height: 16),
            BudgetRow(emoji: '', name: 'Budget total', spent: spent, planned: planned),
            if (d.unexpectedIn(now) > 0) ...[
              const SizedBox(height: 12),
              Row(children: [
                const CircleEmoji('⚡', Color(0xFFFF9F0A), size: 32),
                const SizedBox(width: 10),
                const Expanded(
                    child: Text('Imprévus', style: TextStyle(fontWeight: FontWeight.w500, fontSize: 15))),
                Text(eur(-d.unexpectedIn(now)),
                    style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700, fontSize: 14)),
              ]),
            ],
            const Divider(height: 28),
            for (var i = 0; i < budgetWidgets.length; i++) ...[
              if (i > 0) const SizedBox(height: 16),
              budgetWidgets[i],
            ],
            if (budgetWidgets.isEmpty)
              const Text('Aucun budget défini', style: TextStyle(color: AppColors.muted)),
          ]),
        ),
      ],
    );
  }
}

/// Budget en demi-largeur (colonne d'un conjoint).
class _SplitBudget extends StatelessWidget {
  final String title;
  final double spent;
  final double planned;
  const _SplitBudget({required this.title, required this.spent, required this.planned});

  @override
  Widget build(BuildContext context) {
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = ratio >= 1
        ? AppColors.danger
        : ratio >= .8
            ? AppColors.warning
            : AppColors.teal;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15)),
      const SizedBox(height: 2),
      Text('${eur(spent)} / ${eur(planned)}',
          style: const TextStyle(color: AppColors.muted, fontSize: 13.5)),
      const SizedBox(height: 8),
      AppProgress(value: ratio, color: color),
    ]);
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final Color color;
  final VoidCallback onTap;
  const _StatCard({required this.label, required this.value, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => AppCard(
        onTap: onTap,
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Text('Gérer', style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w500)),
            const SizedBox(width: 2),
            Icon(Icons.chevron_right_rounded, color: color, size: 19),
          ]),
        ]),
      );
}
