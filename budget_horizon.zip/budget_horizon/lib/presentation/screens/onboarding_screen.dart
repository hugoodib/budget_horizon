import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../data/firebase_config.dart';
import '../../data/onboarding_builder.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';

part 'onboarding/onboarding_data.dart';
part 'onboarding/onboarding_widgets.dart';

/// Premiers pas : une aventure en 8 niveaux, une question à la fois, pour créer son
/// profil et saisir toutes ses données en quelques minutes.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  static const _lastStep = 8;
  int _step = 0;
  final _spentKey = GlobalKey(); // repère de « Une dernière question » (étape des budgets)
  bool _forward = true;
  int _sub = 0; // sous-écran (étape 6 : 0 = charges, 1 = point sur ce mois)
  bool? _doneAns; // « des lignes sont-elles déjà passées ce mois-ci ? » (null = pas répondu)
  bool? _spentAns; // « déjà dépensé dans les enveloppes ce mois-ci ? »
  bool _couple = false;
  bool _ae1 = false;
  bool _ae2 = false;
  final _urssaf = TextEditingController(text: '23,68');
  String? _error;
  final _first = TextEditingController();
  final _lastName = TextEditingController();
  final _partner = TextEditingController();
  final _balance = TextEditingController();
  final List<_Line> _incomes = [_Line(n: 'Salaire', icon: Icons.work_outline_rounded)];
  final List<_Line> _fixed = [_Line(n: 'Loyer', icon: Icons.home_outlined)];
  final List<_Line> _budgets = [
    _Line(n: 'Courses', icon: Icons.shopping_basket_outlined),
    _Line(n: 'Essence', icon: Icons.local_gas_station_outlined),
    _Line(n: 'Loisirs', icon: Icons.sports_esports_outlined),
    _Line(n: 'Restaurants', icon: Icons.restaurant_outlined),
  ];

  @override
  void dispose() {
    _first.dispose();
    _lastName.dispose();
    _partner.dispose();
    _balance.dispose();
    _urssaf.dispose();
    for (final l in [..._incomes, ..._fixed, ..._budgets]) {
      l.dispose();
    }
    super.dispose();
  }

  // ─── Données ────────────────────────────────────────────────────────────────
  List<OnboardingEntry> _collect(List<_Line> lines) {
    final now = ref.read(realNowProvider);
    final out = <OnboardingEntry>[];
    for (final l in lines) {
      final n = l.name.text.trim();
      final a = parseAmount(l.amount.text);
      if (n.isNotEmpty && a != null && a > 0) {
        out.add(OnboardingEntry(
          n,
          a,
          isOneOff: l.isOneOff,
          intervalMonths: l.intervalMonths,
          oneOffYm: l.isOneOff ? now : null,
          alreadyDone: _doneAns == true && l.done,
          spent: _spentAns == true ? (parseAmount(l.spent.text) ?? 0) : 0,
        ));
      }
    }
    return out;
  }

  double _monthly(List<_Line> lines) {
    double total = 0;
    for (final l in lines) {
      final a = parseAmount(l.amount.text) ?? 0;
      if (a <= 0) continue;
      total += l.isOneOff ? a : a / l.intervalMonths;
    }
    return total;
  }

  double _sumBudgets() {
    double total = 0;
    for (final l in _budgets) {
      final a = parseAmount(l.amount.text) ?? 0;
      if (a <= 0) continue;
      // En couple, « Loisirs » est séparé (un par personne), les autres sont communs.
      final twice = _couple && l.name.text.toLowerCase().contains('loisir');
      total += twice ? a * 2 : a;
    }
    return total;
  }

  bool get _allAE => _ae1 && (!_couple || _ae2);
  bool get _anyAE => _ae1 || (_couple && _ae2);
  String get _p1 => _first.text.trim().isEmpty ? 'Toi' : _first.text.trim();
  String get _p2 => _partner.text.trim().isEmpty ? 'Ton conjoint' : _partner.text.trim();

  bool _hasAmount(_Line l) => (parseAmount(l.amount.text) ?? 0) > 0;
  List<_Line> get _checkpointLines => [
        if (!_allAE) ..._incomes.where(_hasAmount),
        ..._fixed.where(_hasAmount),
      ];

  String? _validate() {
    if (_step == 6 && _sub == 1) {
      if (_doneAns == null) return 'Choisis une réponse pour continuer.';
      if (_doneAns == true && !_checkpointLines.any((l) => l.done)) {
        return 'Coche ce qui est déjà arrivé ou prélevé sur ton compte, ou choisis « Non, rien pour l\'instant ».';
      }
    }
    if (_step == 7 && _sumBudgets() > 0) {
      if (_spentAns == null) return 'Réponds à la question « Une dernière question » pour continuer.';
      if (_spentAns == true && !_budgets.any((l) => _hasAmount(l) && (parseAmount(l.spent.text) ?? 0) > 0)) {
        return 'Indique le montant déjà dépensé, ou choisis « Non, rien pour l\'instant ».';
      }
    }
    if (_step == 1 && _first.text.trim().isEmpty) return 'Indique au moins ton prénom.';
    if (_step == 2 && _couple) {
      if (_partner.text.trim().isEmpty) return 'Indique le prénom de ton conjoint.';
      if (_partner.text.trim().toLowerCase() == _first.text.trim().toLowerCase()) {
        return 'Les deux prénoms doivent être différents.';
      }
    }
    if (_step == 3 && _anyAE) {
      final r = parseAmount(_urssaf.text);
      if (r == null || r < 0 || r >= 100) return 'Indique un taux de charges entre 0 et 100 %.';
    }
    if (_step == 4 && parseAmount(_balance.text) == null) {
      return 'Indique un montant (0 si tu ne sais pas).';
    }
    return null;
  }

  void _go(int to) {
    HapticFeedback.selectionClick();
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() {
      _forward = to > _step;
      _error = null;
      _step = to;
      _sub = 0;
    });
  }

  void _next() {
    // Étape 6 : après les charges, un écran « point sur ce mois » (si des lignes sont saisies).
    if (_step == 6 && _sub == 0 && _checkpointLines.isNotEmpty) {
      HapticFeedback.selectionClick();
      FocusManager.instance.primaryFocus?.unfocus();
      setState(() {
        _forward = true;
        _error = null;
        _sub = 1;
      });
      return;
    }
    final err = _validate();
    if (err != null) {
      HapticFeedback.mediumImpact();
      setState(() => _error = err);
      // La question à laquelle il manque une réponse peut être hors de l'écran : on y amène.
      if (_step == 7) _revealSpent();
      return;
    }
    if (_step == _lastStep) {
      _finish();
      return;
    }
    _go(_step + 1);
  }

  List<_Line> get _currentList => switch (_step) {
        5 => _incomes,
        6 => _fixed,
        7 => _budgets,
        _ => const <_Line>[],
      };

  /// Valide la saisie en cours : passe au montant vide suivant de la liste, ou ferme le clavier.
  void _validateField() {
    final list = _currentList;
    final i = list.indexWhere((l) => l.amountFocus.hasFocus || l.nameFocus.hasFocus);
    if (i >= 0) {
      for (var j = i + 1; j < list.length; j++) {
        if (list[j].amount.text.trim().isEmpty) {
          HapticFeedback.selectionClick();
          list[j].amountFocus.requestFocus();
          return;
        }
      }
    }
    FocusManager.instance.primaryFocus?.unfocus();
    // Dernière étape des budgets : la question suivante apparaît sous les enveloppes.
    if (_step == 7 && _sumBudgets() > 0 && _spentAns == null) _revealSpent();
  }

  void _back() {
    if (_step == 6 && _sub == 1) {
      setState(() {
        _forward = false;
        _error = null;
        _sub = 0;
      });
      return;
    }
    if (_step > 0) _go(_step - 1);
  }

  void _finish() {
    final answers = OnboardingAnswers(
      firstName: _first.text,
      lastName: _lastName.text,
      isCouple: _couple,
      partnerName: _partner.text,
      currentBalance: parseAmount(_balance.text) ?? 0,
      incomes: _allAE ? const [] : _collect(_incomes),
      fixed: _collect(_fixed),
      budgets: _collect(_budgets),
      ae1: _ae1,
      ae2: _couple && _ae2,
      urssaf: parseAmount(_urssaf.text) ?? 23.68,
    );
    final uid = ref.read(authProvider).session?.uid ?? 'local';
    final data = OnboardingBuilder.build(answers, ref.read(realNowProvider), uid);
    FocusManager.instance.primaryFocus?.unfocus();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    ref.read(appProvider.notifier).completeOnboarding(data);
    // La visite guidée démarre tout de suite sur l'écran d'accueil.
    ref.read(tourProvider.notifier).start();
  }

  Future<void> _joinShare() async {
    final c = TextEditingController();
    final code = await showQuickDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rejoindre un budget partagé'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
              'Saisis le code que ton conjoint a obtenu dans Paramètres → Compte → Partager avec mon conjoint.'),
          const SizedBox(height: 12),
          TextField(
            controller: c,
            autofocus: true,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(labelText: 'Code'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Rejoindre')),
        ],
      ),
    );
    c.dispose();
    if (code == null || !mounted) return;
    final ok = await ref.read(authProvider.notifier).joinShare(code);
    if (!ok && mounted) snack(context, ref.read(authProvider).error ?? 'Code invalide');
  }

  // ─── Gestion des lignes ─────────────────────────────────────────────────────
  void _addLine(List<_Line> list, IconData icon, String name) {
    final l = _Line(n: name, icon: icon);
    HapticFeedback.selectionClick();
    setState(() => list.add(l));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      (name.isEmpty ? l.nameFocus : l.amountFocus).requestFocus();
    });
  }

  void _removeLine(List<_Line> list, _Line l) {
    setState(() => list.remove(l));
    WidgetsBinding.instance.addPostFrameCallback((_) => l.dispose());
  }

  Future<void> _pickFreq(_Line l) async {
    final f = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 18, 20, 6),
            child: Text('À quel rythme ?', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          ),
          for (final n in _kFreqs.where((n) => n != 1))
            ListTile(
              title: Text(_freqLabel(n), style: const TextStyle(fontWeight: FontWeight.w600)),
              trailing: (!l.isOneOff && l.intervalMonths == n)
                  ? const Icon(Icons.check_circle_rounded, color: AppColors.success)
                  : null,
              onTap: () => Navigator.pop(ctx, n),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (f == null || !mounted) return;
    setState(() {
      l.isOneOff = false;
      l.intervalMonths = f;
    });
  }

  // ─── Briques visuelles ──────────────────────────────────────────────────────
  Color get _brand => context.isDark ? AppColors.violetDark : const Color(0xFF7466E0);

  Widget _hero(IconData icon, {double size = 80}) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.85, end: 1),
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOutBack,
        builder: (_, v, child) => Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.scale(scale: v, child: child)),
        child: Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: tint(_brand, .12),
            borderRadius: BorderRadius.circular(size * .32),
            border: Border.all(color: tint(_brand, .25)),
          ),
          child: Icon(icon, size: size * .46, color: _brand),
        ),
      );

  Widget _iconTile(IconData icon, Color color, {double size = 44}) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: tint(color, .14),
          borderRadius: BorderRadius.circular(size * .3),
        ),
        child: Icon(icon, size: size * .5, color: color),
      );

  Widget _title(String t, [String? sub]) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 18),
        child: Column(children: [
          Text(t,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, letterSpacing: -0.5, height: 1.2)),
          if (sub != null) ...[
            const SizedBox(height: 8),
            Text(sub,
                textAlign: TextAlign.center,
                style: TextStyle(color: context.mutedColor, fontSize: 15.5, height: 1.4)),
          ],
        ]),
      );

  Widget _tip(List<String> lines, {IconData icon = Icons.lightbulb_outline_rounded}) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 6),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: tint(_brand, .09),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, size: 22, color: _brand),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                for (var i = 0; i < lines.length; i++) ...[
                  if (i > 0) const SizedBox(height: 6),
                  Text(lines[i], style: const TextStyle(fontSize: 14, height: 1.45)),
                ],
              ]),
            ),
          ]),
        ),
      );

  Widget _choice({
    required IconData icon,
    required String title,
    String? subtitle,
    required bool selected,
    required VoidCallback onTap,
    bool compact = false,
  }) {
    final accent = _brand;
    final textCol = Column(
      crossAxisAlignment: compact ? CrossAxisAlignment.center : CrossAxisAlignment.start,
      children: [
        Text(title,
            textAlign: compact ? TextAlign.center : TextAlign.start,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        if (subtitle != null) ...[
          const SizedBox(height: 2),
          Text(subtitle,
              textAlign: compact ? TextAlign.center : TextAlign.start,
              style: TextStyle(color: context.mutedColor, fontSize: 13, height: 1.3)),
        ],
      ],
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: compact ? 16 : 16),
        decoration: BoxDecoration(
          color: selected ? tint(accent, .16) : context.cardColor.withAlpha(context.isDark ? 255 : 215),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: selected ? accent : Colors.transparent, width: 2),
        ),
        child: compact
            ? Column(children: [
                _iconTile(icon, selected ? accent : context.mutedColor, size: 46),
                const SizedBox(height: 10),
                textCol,
              ])
            : Row(children: [
                _iconTile(icon, selected ? accent : context.mutedColor, size: 48),
                const SizedBox(width: 16),
                Expanded(child: textCol),
                AnimatedOpacity(
                  opacity: selected ? 1 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(Icons.check_circle_rounded, color: accent),
                ),
              ]),
      ),
    );
  }

  Widget _pill(String label, bool selected, VoidCallback onTap, Color accent) => GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          onTap();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: selected ? accent : context.fieldColor,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: selected ? Colors.white : context.textColor)),
        ),
      );

  /// « Déjà reçu / déjà débitée ce mois-ci » : un seul toucher.
  Widget _doneRow(_Line l, String label) => Padding(
        padding: const EdgeInsets.only(top: 10, right: 6),
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => l.done = !l.done);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            decoration: BoxDecoration(
              color: l.done ? tint(AppColors.success, .14) : context.fieldColor,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              Icon(l.done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                  size: 22, color: l.done ? AppColors.success : context.mutedColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 14, fontWeight: l.done ? FontWeight.w600 : FontWeight.w500)),
              ),
            ]),
          ),
        ),
      );

  /// Budgets : montant déjà dépensé ce mois-ci (visible si la réponse est « Oui »).
  Widget _spentRow(_Line l) {
    if (_spentAns != true) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 10, right: 6),
      child: TextField(
        controller: l.spent,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        onChanged: (_) => setState(() => _error = null),
        style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15.5),
        decoration: const InputDecoration(
            labelText: 'Déjà dépensé depuis le 1er', suffixText: ' €', isDense: true),
      ),
    );
  }

  Widget _lineCard(List<_Line> list, _Line l,
      {required bool showFreq,
      required Color accent,
      required String nameHint,
      String? doneLabel}) {
    final other = !l.isOneOff && l.intervalMonths != 1;
    return Padding(
      key: ObjectKey(l),
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(12, 12, 6, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _iconTile(l.icon, accent, size: 46),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: l.name,
                focusNode: l.nameFocus,
                textCapitalization: TextCapitalization.sentences,
                textInputAction: TextInputAction.next,
                onSubmitted: (_) => l.amountFocus.requestFocus(),
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15.5),
                decoration: InputDecoration(hintText: nameHint, isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16)),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 124,
              child: TextField(
                controller: l.amount,
                focusNode: l.amountFocus,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textAlign: TextAlign.right,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                decoration: const InputDecoration(suffixText: ' €', isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 16)),
              ),
            ),
            IconButton(
              onPressed: () => _removeLine(list, l),
              icon: Icon(Icons.close_rounded, color: context.mutedColor, size: 20),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
            ),
          ]),
          if (showFreq) ...[
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: Wrap(spacing: 8, runSpacing: 6, children: [
                _pill('Chaque mois', !l.isOneOff && l.intervalMonths == 1, () {
                  setState(() {
                    l.isOneOff = false;
                    l.intervalMonths = 1;
                  });
                }, accent),
                _pill('Une seule fois', l.isOneOff, () => setState(() => l.isOneOff = true), accent),
                _pill(other ? _freqLabel(l.intervalMonths) : 'Autre rythme  ▾', other,
                    () => _pickFreq(l), accent),
              ]),
            ),
            if (l.isOneOff)
              Padding(
                padding: const EdgeInsets.only(top: 6, left: 2),
                child: Text('Compté pour ce mois-ci uniquement.',
                    style: TextStyle(fontSize: 12.5, color: context.mutedColor)),
              ),
          ],
          if (doneLabel != null) _doneRow(l, doneLabel),
          if (!showFreq) _spentRow(l),
        ]),
      ),
    );
  }

  /// Étape « liste » : cartes saisies + suggestions à toucher.
  List<Widget> _listStep({
    required IconData icon,
    required String title,
    required String sub,
    required List<_Line> list,
    required List<_Sugg> suggs,
    required Color accent,
    required String nameHint,
    required bool showFreq,
    required List<String> tip,
    bool paletteAccent = false,
    String? doneLabel,
    String? bulkLabel,
    Widget? extra,
  }) {
    final remaining = suggs
        .where((s) => !list.any((l) => l.name.text.trim().toLowerCase() == s.name.toLowerCase()))
        .toList();
    return [
      Center(child: _hero(icon)),
      _title(title, sub),
      for (var i = 0; i < list.length; i++)
        _lineCard(list, list[i],
            showFreq: showFreq,
            accent: paletteAccent ? AppColors.palette[i % AppColors.palette.length] : accent,
            nameHint: nameHint,
            doneLabel: doneLabel),
      if (bulkLabel != null && list.length >= 2)
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () {
              final all = list.every((l) => l.done);
              setState(() {
                for (final l in list) {
                  l.done = !all;
                }
              });
            },
            icon: Icon(list.every((l) => l.done) ? Icons.remove_done_rounded : Icons.done_all_rounded,
                size: 18, color: _brand),
            label: Text(list.every((l) => l.done) ? 'Tout décocher' : bulkLabel,
                style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: _brand)),
          ),
        ),
      if (list.isEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Center(
            child: Text('Rien pour l\'instant — touche une idée ci-dessous',
                style: TextStyle(color: context.mutedColor, fontSize: 13)),
          ),
        ),
      const SizedBox(height: 4),
      Text('Touche pour ajouter :',
          style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (final s in remaining)
          _SuggChip(icon: s.icon, label: s.name, accent: accent, onTap: () => _addLine(list, s.icon, s.name)),
        _SuggChip(icon: Icons.edit_outlined, label: 'Autre…', accent: accent, onTap: () => _addLine(list, Icons.sell_outlined, '')),
      ]),
      const SizedBox(height: 14),
      _tip(tip),
      if (extra != null) ...[const SizedBox(height: 18), extra],
    ];
  }

  // ─── Point sur le mois en cours ───────────────────────────────────────────
  static const _kMonths = [
    'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
    'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre',
  ];

  /// Frise du mois : du 1er à aujourd'hui = « déjà passé », d'aujourd'hui à la fin = « à venir ».
  Widget _monthTimeline() {
    final now = DateTime.now();
    final days = DateTime(now.year, now.month + 1, 0).day;
    final frac = days <= 1 ? 0.0 : ((now.day - 1) / (days - 1)).clamp(0.0, 1.0);
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Aujourd\'hui, nous sommes le ${now.day} ${_kMonths[now.month - 1]}',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
        const SizedBox(height: 14),
        LayoutBuilder(builder: (_, c) {
          final w = c.maxWidth;
          return SizedBox(
            height: 22,
            child: Stack(clipBehavior: Clip.none, children: [
              Positioned(
                left: 0, right: 0, top: 7,
                child: Container(
                    height: 8,
                    decoration: BoxDecoration(color: context.trackColor, borderRadius: BorderRadius.circular(8))),
              ),
              Positioned(
                left: 0, top: 7,
                child: Container(
                    width: w * frac,
                    height: 8,
                    decoration: BoxDecoration(color: AppColors.teal, borderRadius: BorderRadius.circular(8))),
              ),
              Positioned(
                left: (w * frac - 11).clamp(0.0, w - 22), top: 0,
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: BoxDecoration(
                    color: _brand,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                  ),
                ),
              ),
            ]),
          );
        }),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text('Le 1er', style: TextStyle(fontSize: 12.5, color: context.mutedColor)),
          Text('Déjà fait  ·  À venir', style: TextStyle(fontSize: 12.5, color: context.mutedColor)),
          Text('Fin du mois', style: TextStyle(fontSize: 12.5, color: context.mutedColor)),
        ]),
      ]),
    );
  }

  /// Ligne à cocher du point sur le mois.
  Widget _checkRow(_Line l) {
    final a = parseAmount(l.amount.text) ?? 0;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() {
            l.done = !l.done;
            _error = null;
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: l.done ? tint(AppColors.success, .14) : context.cardColor.withAlpha(context.isDark ? 255 : 215),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: l.done ? AppColors.success : Colors.transparent, width: 1.5),
          ),
          child: Row(children: [
            Icon(l.done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                size: 26, color: l.done ? AppColors.success : context.mutedColor),
            const SizedBox(width: 12),
            Expanded(
              child: Text(l.name.text.trim().isEmpty ? 'Sans nom' : l.name.text.trim(),
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15.5)),
            ),
            Text(eur(a), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ]),
        ),
      ),
    );
  }

  List<Widget> _checkpointWidgets() {
    final incomes = _allAE ? <_Line>[] : _incomes.where(_hasAmount).toList();
    final fixed = _fixed.where(_hasAmount).toList();
    final all = [...incomes, ...fixed];
    final allDone = all.isNotEmpty && all.every((l) => l.done);
    Widget heading(String t) => Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 8, left: 2),
          child: Text(t, style: TextStyle(color: context.mutedColor, fontWeight: FontWeight.w700, fontSize: 13)),
        );
    return [
      Center(child: _hero(Icons.event_available_outlined)),
      _title('Fais le point sur ce mois',
          'Depuis le 1er du mois, certains revenus sont peut-être déjà arrivés et certaines charges déjà prélevées sur ton compte. Hever doit le savoir pour ne pas les compter deux fois.'),
      _monthTimeline(),
      const SizedBox(height: 14),
      _choice(
        icon: Icons.hourglass_empty_rounded,
        title: 'Non, rien pour l\'instant',
        subtitle: 'Aucun de ces éléments n\'a encore été reçu ou débité ce mois-ci.',
        selected: _doneAns == false,
        onTap: () => setState(() {
          _doneAns = false;
          _error = null;
          for (final l in all) {
            l.done = false;
          }
        }),
      ),
      const SizedBox(height: 10),
      _choice(
        icon: Icons.task_alt_rounded,
        title: 'Oui, certains ont déjà eu lieu',
        subtitle: 'Je coche ce qui est déjà arrivé (revenus) ou déjà prélevé (charges).',
        selected: _doneAns == true,
        onTap: () => setState(() {
          _doneAns = true;
          _error = null;
        }),
      ),
      AnimatedSize(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
        alignment: Alignment.topCenter,
        child: _doneAns == true
            ? Padding(
                padding: const EdgeInsets.only(top: 16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (incomes.isNotEmpty) ...[heading('Revenus déjà reçus ?'), for (final l in incomes) _checkRow(l)],
                  if (fixed.isNotEmpty) ...[heading('Charges déjà débitées ?'), for (final l in fixed) _checkRow(l)],
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () => setState(() {
                        for (final l in all) {
                          l.done = !allDone;
                        }
                        _error = null;
                      }),
                      icon: Icon(allDone ? Icons.remove_done_rounded : Icons.done_all_rounded, size: 18, color: _brand),
                      label: Text(allDone ? 'Tout décocher' : 'Tout cocher',
                          style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: _brand)),
                    ),
                  ),
                ]),
              )
            : const SizedBox(width: double.infinity),
      ),
      const SizedBox(height: 12),
      _tip(const [
        'Astuce : ouvre ton appli bancaire et regarde les opérations depuis le 1er du mois.',
        'Un élément coché est considéré comme déjà inclus dans le solde que tu as indiqué.',
      ]),
    ];
  }

  /// Budgets : « as-tu déjà dépensé depuis le 1er ? » (réponse obligatoire).
  /// Fait défiler la page jusqu'à « Une dernière question » (sans que l'utilisateur ait à descendre).
  void _revealSpent() {
    // Petit délai : le clavier se referme d'abord, ce qui libère de la place pour défiler.
    Future.delayed(const Duration(milliseconds: 320), () {
      final ctx = _spentKey.currentContext;
      if (!mounted || ctx == null) return;
      Scrollable.ensureVisible(ctx,
          alignment: 0.05, duration: const Duration(milliseconds: 450), curve: Curves.easeOutCubic);
    });
  }

  Widget _spentQuestion() => Column(key: _spentKey, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Une dernière question',
            style: TextStyle(color: context.mutedColor, fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 8),
        _monthTimeline(),
        const SizedBox(height: 14),
        const Text('As-tu déjà dépensé dans ces catégories depuis le 1er du mois ?',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, height: 1.3)),
        const SizedBox(height: 10),
        _choice(
          icon: Icons.hourglass_empty_rounded,
          title: 'Non, rien pour l\'instant',
          subtitle: 'Les enveloppes sont encore pleines.',
          selected: _spentAns == false,
          onTap: () => setState(() {
            _spentAns = false;
            _error = null;
          }),
        ),
        const SizedBox(height: 10),
        _choice(
          icon: Icons.receipt_long_outlined,
          title: 'Oui, j\'ai déjà dépensé',
          subtitle: 'J\'indique le montant dans chaque catégorie concernée.',
          selected: _spentAns == true,
          onTap: () => setState(() {
            _spentAns = true;
            _error = null;
          }),
        ),
      ]);

  // ─── Étapes ────────────────────────────────────────────────────────────────
  List<Widget> _stepWidgets() {
    switch (_step) {
      case 0:
        final auth = ref.watch(authProvider);
        return [
          const SizedBox(height: 24),
          const Center(child: AppLogo(size: 120)),
          _title('Bienvenue sur Hever !', 'En 2 minutes, tu sauras combien il te restera à la fin de chaque mois.'),
          const SizedBox(height: 6),
          for (final p in const [
            (Icons.sports_esports_outlined, 'Une question à la fois', '8 petits niveaux, c\'est rapide et sans prise de tête.'),
            (Icons.touch_app_outlined, 'Presque tout en un clic', 'Des idées à toucher : tu n\'as plus qu\'à mettre les montants.'),
            (Icons.tune_rounded, 'Rien n\'est définitif', 'Tu pourras tout modifier plus tard.'),
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  _iconTile(p.$1, _brand, size: 44),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(p.$2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                      const SizedBox(height: 2),
                      Text(p.$3, style: TextStyle(color: context.mutedColor, fontSize: 13.5, height: 1.3)),
                    ]),
                  ),
                ]),
              ),
            ),
          const SizedBox(height: 8),
          if (FirebaseConfig.enabled && auth.session != null) ...[
            SoftButton(
              icon: Icons.group_add_outlined,
              label: "J'ai un code pour rejoindre le budget de mon conjoint",
              onPressed: _joinShare,
            ),
            const SizedBox(height: 6),
          ],
          if (FirebaseConfig.enabled && auth.session == null) ...[
            SoftButton(
              icon: Icons.person_add_alt_outlined,
              label: 'Créer un compte ou me connecter',
              onPressed: () => ref.read(authProvider.notifier).showAuth(),
            ),
            const SizedBox(height: 6),
          ],
          TextButton(
            onPressed: () => ref.read(appProvider.notifier).skipOnboarding(),
            child: Text("Je veux juste explorer avec des données d'exemple",
                textAlign: TextAlign.center, style: TextStyle(color: context.mutedColor)),
          ),
        ];
      case 1:
        return [
          Center(child: _hero(Icons.waving_hand_outlined)),
          _title('Salut ! Comment tu t\'appelles ?', 'Juste pour personnaliser ton espace.'),
          TextField(
            controller: _first,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            textInputAction: TextInputAction.next,
            onChanged: (_) => setState(() => _error = null),
            style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w500),
            decoration: const InputDecoration(labelText: 'Ton prénom'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _lastName,
            textCapitalization: TextCapitalization.words,
            style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w500),
            decoration: const InputDecoration(labelText: 'Ton nom (facultatif)'),
          ),
        ];
      case 2:
        return [
          Center(child: _hero(_couple ? Icons.people_outline_rounded : Icons.person_outline_rounded)),
          _title(
              _first.text.trim().isEmpty ? 'Tu gères ton budget…' : 'Enchanté ${_first.text.trim()} ! Tu gères ton budget…'),
          _choice(
            icon: Icons.person_outline_rounded,
            title: 'Tout seul(e)',
            subtitle: 'Un budget rien que pour toi.',
            selected: !_couple,
            onTap: () => setState(() => _couple = false),
          ),
          const SizedBox(height: 10),
          _choice(
            icon: Icons.people_outline_rounded,
            title: 'À deux, en couple',
            subtitle: 'Un budget commun, avec des budgets perso pour chacun.',
            selected: _couple,
            onTap: () => setState(() => _couple = true),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            alignment: Alignment.topCenter,
            child: _couple
                ? Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: TextField(
                      controller: _partner,
                      textCapitalization: TextCapitalization.words,
                      onChanged: (_) => setState(() => _error = null),
                      decoration: const InputDecoration(labelText: 'Le prénom de ton conjoint'),
                    ),
                  )
                : const SizedBox(width: double.infinity),
          ),
          const SizedBox(height: 14),
          _tip(['Pas de panique : tu pourras changer ça plus tard dans les paramètres.']),
        ];
      case 3:
        return [
          Center(child: _hero(_anyAE ? Icons.receipt_long_outlined : Icons.work_outline_rounded)),
          _title('Comment tu es payé(e) ?', _couple ? 'Choisis pour chacun de vous deux.' : 'Ça change la façon de calculer tes revenus.'),
          if (_couple) Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(_p1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5)),
          ),
          Row(children: [
            Expanded(
              child: _choice(
                compact: true,
                icon: Icons.work_outline_rounded,
                title: 'Salarié(e)',
                subtitle: 'Un revenu régulier',
                selected: !_ae1,
                onTap: () => setState(() => _ae1 = false),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _choice(
                compact: true,
                icon: Icons.receipt_long_outlined,
                title: 'Auto-entrepreneur',
                subtitle: 'Payé par tes clients',
                selected: _ae1,
                onTap: () => setState(() => _ae1 = true),
              ),
            ),
          ]),
          if (_couple) ...[
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(_p2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5)),
            ),
            Row(children: [
              Expanded(
                child: _choice(
                  compact: true,
                  icon: Icons.work_outline_rounded,
                  title: 'Salarié(e)',
                  subtitle: 'Un revenu régulier',
                  selected: !_ae2,
                  onTap: () => setState(() => _ae2 = false),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _choice(
                  compact: true,
                  icon: Icons.receipt_long_outlined,
                  title: 'Auto-entrepreneur',
                  subtitle: 'Payé par ses clients',
                  selected: _ae2,
                  onTap: () => setState(() => _ae2 = true),
                ),
              ),
            ]),
          ],
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            alignment: Alignment.topCenter,
            child: _anyAE
                ? Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      TextField(
                        controller: _urssaf,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        onChanged: (_) => setState(() => _error = null),
                        decoration: const InputDecoration(labelText: 'Charges URSSAF', suffixText: '%'),
                      ),
                      const SizedBox(height: 8),
                      _tip(const [
                        'Pas sûr du taux ? Garde cette valeur, tu pourras la changer dans les paramètres.',
                        'Ensuite, tu ajouteras tes clients : Hever calcule ton salaire net tout seul.',
                      ], icon: Icons.calculate_outlined),
                    ]),
                  )
                : const SizedBox(width: double.infinity),
          ),
        ];
      case 4:
        return [
          Center(child: _hero(Icons.account_balance_outlined)),
          _title('Combien as-tu sur ton compte ?', 'Le solde d\'aujourd\'hui, en tenant compte de tout ce qui est déjà arrivé ou prélevé ce mois-ci.'),
          TextField(
            controller: _balance,
            autofocus: true,
            textAlign: TextAlign.center,
            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
            onChanged: (_) => setState(() => _error = null),
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700),
            decoration: const InputDecoration(suffixText: ' €'),
          ),
          const SizedBox(height: 10),
          Center(
            child: TextButton(
              onPressed: () {
                _balance.text = '0';
                _next();
              },
              child: const Text('Je ne sais pas, on verra plus tard'),
            ),
          ),
          const SizedBox(height: 6),
          _tip(const [
            'Ouvre ton appli bancaire : c\'est le solde affiché maintenant. Pas besoin du centime près.',
            'Tu indiqueras ensuite ce qui est déjà arrivé ou prélevé : Hever ne le comptera pas deux fois.',
          ], icon: Icons.smartphone_rounded),
        ];
      case 5:
        if (_allAE) {
          return [
            Center(child: _hero(Icons.receipt_long_outlined)),
            _title('Tes revenus arrivent tout seuls', 'Rien à saisir ici.'),
            _tip(const [
              'Comme tu es auto-entrepreneur, ton salaire net est calculé depuis l\'onglet Clients.',
              'Tu les ajouteras juste après cette installation.',
            ], icon: Icons.auto_fix_high_rounded),
          ];
        }
        return _listStep(
          icon: Icons.payments_outlined,
          title: 'Qu\'est-ce qui rentre ?',
          sub: _anyAE
              ? 'Ici, uniquement les revenus de la personne salariée.'
              : (_couple ? 'Les revenus de votre foyer.' : 'Salaire, primes, aides…'),
          list: _incomes,
          suggs: _kIncomeSuggs,
          accent: AppColors.success,
          nameHint: 'Nom du revenu',
          showFreq: true,
          tip: const [
            'Chaque mois : ton salaire, par exemple.',
            'Une seule fois : une prime ou un remboursement ce mois-ci.',
          ],
        );
      case 6:
        if (_sub == 1) return _checkpointWidgets();
        return _listStep(
          icon: Icons.home_outlined,
          title: 'Qu\'est-ce qui sort chaque mois ?',
          sub: 'Les charges fixes : loyer, abonnements, assurances…',
          list: _fixed,
          suggs: _kFixedSuggs,
          accent: AppColors.pink,
          nameHint: 'Nom de la charge',
          showFreq: true,
          tip: const [
            'Une assurance annuelle ? Choisis « Autre rythme » → « 1 fois par an ».',
            'Si tu hésites sur un montant, mets une estimation : tu pourras corriger.',
          ],
        );
      case 7:
        return _listStep(
          icon: Icons.shopping_basket_outlined,
          title: 'Tes enveloppes du mois',
          sub: 'Combien tu veux dépenser, au maximum, par catégorie.',
          list: _budgets,
          suggs: _kBudgetSuggs,
          accent: AppColors.warning,
          nameHint: 'Catégorie',
          showFreq: false,
          paletteAccent: true,
          extra: _spentQuestion(),
          tip: [
            'Une enveloppe, c\'est une somme à ne pas dépasser chaque mois. Hever la déduit déjà de ta prévision de fin de mois.',
            if (_couple) 'En couple : Loisirs est séparé pour chacun, les autres enveloppes sont communes.',
          ],
        );
      default:
        final income = _allAE ? 0.0 : _monthly(_incomes);
        final fixed = _monthly(_fixed);
        final budgets = _sumBudgets();
        final rest = income - fixed - budgets;
        // Ce mois-ci : ce qui reste à recevoir / à payer, à partir du solde d'aujourd'hui.
        double pendingOf(List<_Line> ls) => ls.fold(0.0, (t, l) {
              final a = parseAmount(l.amount.text) ?? 0;
              return (a > 0 && !(_doneAns == true && l.done)) ? t + a : t;
            });
        final balanceNow = parseAmount(_balance.text) ?? 0;
        final pendIncome = _allAE ? 0.0 : pendingOf(_incomes);
        final pendFixed = pendingOf(_fixed);
        var pendBudgets = 0.0;
        for (final l in _budgets) {
          final p = parseAmount(l.amount.text) ?? 0;
          if (p <= 0) continue;
          final sp = _spentAns == true ? (parseAmount(l.spent.text) ?? 0) : 0.0;
          final twice = _couple && l.name.text.toLowerCase().contains('loisir');
          pendBudgets += (p - sp > 0 ? p - sp : 0.0) + (twice ? p : 0.0);
        }
        final endOfMonth = balanceNow + pendIncome - pendFixed - pendBudgets;
        Widget row(IconData ic, String l, String v, Color c) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Row(children: [
                _iconTile(ic, _brand, size: 36),
                const SizedBox(width: 12),
                Expanded(child: Text(l, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15.5))),
                Text(v, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5, color: c)),
              ]),
            );
        return [
          Center(child: _hero(Icons.flag_outlined)),
          _title(
              _first.text.trim().isEmpty ? 'Bravo, tout est prêt !' : 'Bravo ${_first.text.trim()}, tout est prêt !',
              'Voici où tu en es ce mois-ci, et à quoi ressemble un mois type.'),
          AppCard(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
            child: Column(children: [
              row(Icons.account_balance_outlined, 'Sur ton compte aujourd\'hui', eur(balanceNow), context.textColor),
              if (!_allAE) row(Icons.payments_outlined, 'Encore à recevoir', eur(pendIncome, sign: true), AppColors.success),
              row(Icons.home_outlined, 'Charges encore à payer', eur(-pendFixed), context.textColor),
              row(Icons.shopping_basket_outlined, 'Enveloppes restantes', eur(-pendBudgets), context.textColor),
              const Divider(height: 22),
              Text('Il te restera à la fin de ce mois',
                  style: TextStyle(color: context.mutedColor, fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(height: 2),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: endOfMonth),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Text(
                  eur(v),
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                      color: endOfMonth < 0 ? AppColors.danger : AppColors.success),
                ),
              ),
              if (_anyAE)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('(avant ton salaire d\'auto-entrepreneur)',
                      style: TextStyle(color: context.mutedColor, fontSize: 12)),
                ),
            ]),
          ),
          const SizedBox(height: 14),
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text('Et sur un mois type',
                style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: .4)),
          ),
          AppCard(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
            child: Column(children: [
              if (_allAE)
                row(Icons.receipt_long_outlined, 'Revenus', 'via tes clients', AppColors.success)
              else
                row(Icons.payments_outlined, 'Ce qui rentre', eur(income, sign: true), AppColors.success),
              row(Icons.home_outlined, 'Charges fixes', eur(-fixed), context.textColor),
              row(Icons.shopping_basket_outlined, 'Enveloppes', eur(-budgets), context.textColor),
              const Divider(height: 22),
              Text('Il te restera environ',
                  style: TextStyle(color: context.mutedColor, fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(height: 2),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: rest),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Text(
                  '${eur(v)} / mois',
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                      color: rest < 0 ? AppColors.danger : AppColors.success),
                ),
              ),
              if (_allAE)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('(avant ton salaire d\'auto-entrepreneur)',
                      style: TextStyle(color: context.mutedColor, fontSize: 12)),
                ),
            ]),
          ),
          if (rest < 0 && !_allAE) ...[
            const SizedBox(height: 10),
            _tip(const ['Ça dépasse un peu : pas grave, tu peux ajuster tes enveloppes maintenant ou plus tard.'],
                icon: Icons.warning_amber_rounded),
            const SizedBox(height: 6),
            SoftButton(icon: Icons.edit_rounded, label: 'Revoir mes enveloppes', onPressed: () => _go(7)),
          ],
          const SizedBox(height: 16),
          Text('Les 3 gestes à retenir',
              style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: .4)),
          const SizedBox(height: 8),
          for (final g in const [
            (Icons.add_circle_outline_rounded, 'Note chaque dépense', 'Dès que tu paies quelque chose.'),
            (Icons.check_circle_outline_rounded, 'Coche quand c\'est débité', 'Pour que ton solde actuel reste juste.'),
            (Icons.flag_outlined, 'Clôture à la fin du mois', 'Un seul geste pour passer au mois suivant.'),
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                padding: const EdgeInsets.all(14),
                child: Row(children: [
                  _iconTile(g.$1, _brand, size: 40),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(g.$2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      Text(g.$3, style: TextStyle(color: context.mutedColor, fontSize: 13)),
                    ]),
                  ),
                ]),
              ),
            ),
          const SizedBox(height: 4),
          _tip(const ['Une petite visite guidée de 30 secondes va te montrer où tout se trouve. Tu pourras la revoir dans les Paramètres.'],
              icon: Icons.explore_outlined),
        ];
    }
  }

  // ─── Cadre de l'écran ──────────────────────────────────────────────────────
  Widget _header() {
    Widget badge(int s) {
      final done = _step > s;
      final cur = _step == s;
      return AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutBack,
        width: cur ? 36 : 30,
        height: cur ? 36 : 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: (done || cur) ? brandGradient : null,
          color: (done || cur) ? null : context.fieldColor,
          shape: BoxShape.circle,
          boxShadow: cur ? [BoxShadow(color: tint(AppColors.violet, .4), blurRadius: 10, offset: const Offset(0, 3))] : null,
        ),
        child: done
            ? const Icon(Icons.check_rounded, size: 16, color: AppColors.text)
            : Icon(_kBadges[s - 1], size: cur ? 20 : 16, color: cur ? AppColors.text : context.mutedColor),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(children: [
        Row(children: [
          for (var s = 1; s <= _lastStep; s++) ...[
            badge(s),
            if (s < _lastStep)
              Expanded(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  height: 3,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: _step > s ? AppColors.teal : context.trackColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
          ],
        ]),
        const SizedBox(height: 10),
        Text('Niveau $_step sur $_lastStep · ${_kLevels[_step]}',
            style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _totalBar() {
    final (label, value, color) = switch (_step) {
      5 => ('Ce qui rentre', _monthly(_incomes), AppColors.success),
      6 => ('Charges fixes', _monthly(_fixed), AppColors.pink),
      _ => ('Enveloppes', _sumBudgets(), AppColors.warning),
    };
    if (_step == 5 && _allAE) return const SizedBox.shrink();
    if (value <= 0) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(color: tint(color, .14), borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5)),
          const Spacer(),
          Text('${eur(value)} / mois', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: color)),
        ]),
      ),
    );
  }

  Widget _bottomBar() {
    final isList = _step >= 5 && _step <= 7 && !(_step == 6 && _sub == 1);
    final toCheckpoint = _step == 6 && _sub == 0 && _checkpointLines.isNotEmpty;
    final listEmpty = switch (_step) {
      5 => _allAE || _monthly(_incomes) <= 0,
      6 => _monthly(_fixed) <= 0,
      7 => _sumBudgets() <= 0,
      _ => false,
    };
    final keyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;
    final label = switch (_step) {
      0 => 'Commencer',
      _lastStep => 'Découvrir Hever',
      5 when _allAE => 'Étape suivante',
      _ when isList && keyboardOpen => 'Valider',
      _ when toCheckpoint => 'Continuer',
      _ when isList && listEmpty => 'Passer cette étape',
      _ when isList => 'Étape suivante',
      _ => 'Continuer',
    };
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: tint(AppColors.danger, .14), borderRadius: BorderRadius.circular(14)),
              child: Text(_error!,
                  style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600, fontSize: 14)),
            ),
          ),
        if (isList) _totalBar(),
        Row(children: [
          if (_step > 0) ...[
            GestureDetector(
              onTap: _back,
              child: Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(22)),
                child: Icon(Icons.arrow_back_rounded, color: context.textColor),
              ),
            ),
            const SizedBox(width: 10),
          ],
          Expanded(child: _Cta(label: label, onPressed: (isList && keyboardOpen) ? _validateField : _next)),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = context.isDark;
    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: dark ? Colors.white.withAlpha(40) : const Color(0xFFC9CCE0), width: 1.2),
    );
    final theme = Theme.of(context).copyWith(
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF1E2440) : Colors.white,
        border: fieldBorder,
        enabledBorder: fieldBorder,
        focusedBorder: fieldBorder.copyWith(borderSide: BorderSide(color: _brand, width: 2)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        hintStyle: TextStyle(color: context.mutedColor),
        labelStyle: TextStyle(color: context.mutedColor),
      ),
    );
    return Theme(
      data: theme,
      child: Scaffold(
      body: SafeArea(
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          child: Stack(children: [
            Column(children: [
              // L'en-tête apparaît en douceur (plus de saut de mise en page à la 1re étape).
              AnimatedSize(
                duration: const Duration(milliseconds: 280),
                curve: Curves.easeOutCubic,
                alignment: Alignment.topCenter,
                child: _step > 0 ? _header() : const SizedBox(width: double.infinity),
              ),
              Expanded(
                child: ClipRect(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 380),
                    switchInCurve: Curves.easeOutCubic,
                    switchOutCurve: Curves.easeInCubic,
                    // Les deux pages restent en haut, côte à côte : pas de saut de hauteur.
                    layoutBuilder: (current, previous) => Stack(
                      alignment: Alignment.topCenter,
                      children: [...previous, if (current != null) current],
                    ),
                    transitionBuilder: (child, anim) {
                      final incoming = child.key == ValueKey('$_step.$_sub');
                      // Entrée : glisse depuis le côté ; sortie : part de l'autre côté.
                      final dir = _forward ? 1.0 : -1.0;
                      final begin = incoming ? Offset(0.18 * dir, 0) : Offset(-0.18 * dir, 0);
                      return FadeTransition(
                        opacity: CurvedAnimation(parent: anim, curve: const Interval(0.35, 1.0)),
                        child: SlideTransition(
                          position: Tween<Offset>(begin: begin, end: Offset.zero).animate(anim),
                          child: child,
                        ),
                      );
                    },
                    child: KeyedSubtree(
                      key: ValueKey('$_step.$_sub'),
                      child: RepaintBoundary(
                        child: ListView(
                          padding: const EdgeInsets.fromLTRB(18, 12, 18, 16),
                          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                          children: _stepWidgets(),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              _bottomBar(),
            ]),
            if (_step == _lastStep) const Positioned.fill(child: IgnorePointer(child: _Confetti())),
          ]),
        ),
      ),
    ),
    );
  }
}
