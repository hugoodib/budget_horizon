import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../data/firebase_config.dart';
import '../../data/onboarding_builder.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../widgets/common.dart';

// ─── Fréquences disponibles ───────────────────────────────────────────────────
const _kFreqs = [1, 2, 3, 4, 6, 12];
String _freqLabel(int n) => switch (n) {
      1 => 'Chaque mois',
      2 => '1 mois sur 2',
      3 => 'Tous les 3 mois',
      4 => 'Tous les 4 mois',
      6 => 'Tous les 6 mois',
      12 => '1 fois par an',
      _ => 'Tous les $n mois',
    };

// ─── Ligne de saisie ─────────────────────────────────────────────────────────
class _Line {
  final TextEditingController name;
  final TextEditingController amount;
  bool isOneOff; // true = ponctuel
  int intervalMonths; // 1, 2, 3, 4, 6, 12

  _Line([String n = '', String a = '', this.isOneOff = false, this.intervalMonths = 1])
      : name = TextEditingController(text: n),
        amount = TextEditingController(text: a);

  void dispose() {
    name.dispose();
    amount.dispose();
  }
}

/// Assistant de configuration affiché à la première utilisation :
/// identité, couple, solde, revenus, charges fixes, budgets, avec explications.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  static const _lastStep = 6;
  int _step = 0;
  bool _couple = false;
  bool _ae1 = false;
  bool _ae2 = false;
  final _urssaf = TextEditingController();
  String? _error;
  final _first = TextEditingController();
  final _lastName = TextEditingController();
  final _partner = TextEditingController();
  final _balance = TextEditingController();
  // Rien de pré-rempli : l'utilisateur part de zéro.
  final List<_Line> _incomes = [_Line()];
  final List<_Line> _fixed = [_Line()];
  final List<_Line> _budgets = [
    _Line('Courses'),
    _Line('Essence'),
    _Line('Loisirs'),
    _Line('Restaurants'),
  ];

  @override
  void dispose() {
    _first.dispose();
    _lastName.dispose();
    _partner.dispose();
    _balance.dispose();
    _urssaf.dispose();
    for (final l in [..._incomes, ..._fixed, ..._budgets]) {
      l.dispose();
    }
    super.dispose();
  }

  List<OnboardingEntry> _collect(List<_Line> lines) {
    final now = ref.read(realNowProvider);
    final out = <OnboardingEntry>[];
    for (final l in lines) {
      final n = l.name.text.trim();
      final a = parseAmount(l.amount.text);
      if (n.isNotEmpty && a != null && a > 0) {
        out.add(OnboardingEntry(
          n,
          a,
          isOneOff: l.isOneOff,
          intervalMonths: l.intervalMonths,
          oneOffYm: l.isOneOff ? now : null,
        ));
      }
    }
    return out;
  }

  // Calcule le revenu mensuel "moyen" pour le résumé (ponctuels comptés 1 fois)
  double _sumIncomes() {
    final now = ref.read(realNowProvider);
    double total = 0;
    for (final l in _incomes) {
      final a = parseAmount(l.amount.text) ?? 0;
      if (a <= 0) continue;
      if (l.isOneOff) {
        total += a; // comptabilisé une fois dans le résumé
      } else {
        // contribution mensuelle proportionnelle
        total += a / l.intervalMonths;
      }
    }
    return total;
  }

  double _sumFixed() {
    double total = 0;
    for (final l in _fixed) {
      final a = parseAmount(l.amount.text) ?? 0;
      if (a <= 0) continue;
      if (l.isOneOff) {
        total += a; // ponctuel : compte une fois
      } else {
        total += a / l.intervalMonths;
      }
    }
    return total;
  }

  String? _validate() {
    if (_step == 1) {
      if (_first.text.trim().isEmpty) return 'Indiquez votre prénom.';
      if (_couple && _partner.text.trim().isEmpty) return 'Indiquez le prénom de votre conjoint.';
      if (_couple &&
          _partner.text.trim().toLowerCase() == _first.text.trim().toLowerCase()) {
        return 'Les deux prénoms doivent être différents.';
      }
      if (_ae1 || (_couple && _ae2)) {
        final r = parseAmount(_urssaf.text);
        if (r == null || r < 0 || r >= 100) return 'Indiquez un taux URSSAF entre 0 et 100 %.';
      }
    }
    if (_step == 2 && parseAmount(_balance.text) == null) {
      return 'Indiquez le solde actuel de votre compte (0 si vous ne savez pas).';
    }
    return null;
  }

  void _next() {
    final err = _validate();
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    if (_step == _lastStep) {
      _finish();
      return;
    }
    setState(() {
      _error = null;
      _step++;
    });
  }

  void _back() => setState(() {
        _error = null;
        _step--;
      });

  void _finish() {
    final answers = OnboardingAnswers(
      firstName: _first.text,
      lastName: _lastName.text,
      isCouple: _couple,
      partnerName: _partner.text,
      currentBalance: parseAmount(_balance.text) ?? 0,
      incomes: _collect(_incomes),
      fixed: _collect(_fixed),
      budgets: _collect(_budgets),
      ae1: _ae1,
      ae2: _couple && _ae2,
      urssaf: parseAmount(_urssaf.text) ?? 23.68,
    );
    final uid = ref.read(authProvider).session?.uid ?? 'local';
    final data = OnboardingBuilder.build(answers, ref.read(realNowProvider), uid);
    ref.read(appProvider.notifier).completeOnboarding(data);
  }

  Future<void> _joinShare() async {
    final c = TextEditingController();
    final code = await showQuickDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rejoindre un budget partagé'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
              'Saisissez le code que votre conjoint a obtenu dans Paramètres → Compte → Partager avec mon conjoint.'),
          const SizedBox(height: 12),
          TextField(
            controller: c,
            autofocus: true,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(labelText: 'Code'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Rejoindre')),
        ],
      ),
    );
    c.dispose();
    if (code == null || !mounted) return;
    final ok = await ref.read(authProvider.notifier).joinShare(code);
    if (!ok && mounted) snack(context, ref.read(authProvider).error ?? 'Code invalide');
  }

  // ─── Blocs réutilisables ────────────────────────────────────────────────────
  Widget _info(List<String> lines) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: AppCard(
          padding: const EdgeInsets.all(14),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.lightbulb_outline_rounded, color: AppColors.violet, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                for (var i = 0; i < lines.length; i++) ...[
                  if (i > 0) const SizedBox(height: 6),
                  Text(lines[i], style: const TextStyle(fontSize: 13.5, height: 1.35)),
                ],
              ]),
            ),
          ]),
        ),
      );

  /// Éditeur enrichi : nom + montant + bascule ponctuel/récurrent + fréquence
  Widget _editor(List<_Line> list, {required String nameLabel, bool showFrequency = true}) =>
      Column(children: [
        for (final l in list)
          Padding(
            key: ObjectKey(l),
            padding: const EdgeInsets.only(bottom: 12),
            child: AppCard(
              padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // ── Ligne nom + montant + supprimer ──────────────────────────
                Row(children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: l.name,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: InputDecoration(
                        labelText: nameLabel,
                        isDense: true,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: TextField(
                      controller: l.amount,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Montant',
                        suffixText: '€',
                        isDense: true,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() {
                      list.remove(l);
                      l.dispose();
                    }),
                    icon: const Icon(Icons.close_rounded, color: AppColors.muted),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                  ),
                ]),
                if (showFrequency) ...[
                  const Divider(height: 14),
                  // ── Bascule ponctuel / récurrent ─────────────────────────
                  Row(children: [
                    const SizedBox(width: 4),
                    Expanded(
                      child: TabSwitcher<bool>(
                        tabs: const [
                          (value: false, label: 'Récurrent',  icon: Icons.repeat_rounded),
                          (value: true,  label: 'Ponctuel',   icon: Icons.looks_one_rounded),
                        ],
                        selected: l.isOneOff,
                        onChanged: (v) => setState(() => l.isOneOff = v),
                      ),
                    ),
                  ]),
                  // ── Fréquence (uniquement si récurrent) ──────────────────
                  if (!l.isOneOff) ...[
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.only(left: 4, right: 8),
                      child: Row(children: [
                        const Icon(Icons.schedule_rounded, size: 15, color: AppColors.muted),
                        const SizedBox(width: 6),
                        const Text('Fréquence :',
                            style: TextStyle(fontSize: 13, color: AppColors.muted)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: _kFreqs.contains(l.intervalMonths)
                                ? l.intervalMonths
                                : 1,
                            isDense: true,
                            decoration: const InputDecoration(
                              isDense: true,
                              border: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              contentPadding: EdgeInsets.zero,
                            ),
                            items: [
                              for (final f in _kFreqs)
                                DropdownMenuItem(
                                  value: f,
                                  child: Text(_freqLabel(f),
                                      style: const TextStyle(fontSize: 13.5)),
                                ),
                            ],
                            onChanged: (v) {
                              if (v != null) setState(() => l.intervalMonths = v);
                            },
                          ),
                        ),
                      ]),
                    ),
                  ],
                  if (l.isOneOff) ...[
                    const SizedBox(height: 4),
                    Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: Text(
                        'Ce montant sera pris en compte pour ce mois uniquement.',
                        style: TextStyle(
                            fontSize: 12, color: AppColors.muted, fontStyle: FontStyle.italic),
                      ),
                    ),
                  ],
                ],
              ]),
            ),
          ),
      ]);

  Widget _addButton(String label, List<_Line> list) => SoftButton(
        icon: Icons.add_rounded,
        label: label,
        onPressed: () => setState(() => list.add(_Line())),
      );

  Widget _title(String t, [String? sub]) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t,
              style: const TextStyle(
                  fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.4)),
          if (sub != null) ...[
            const SizedBox(height: 4),
            Text(sub, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
          ],
        ]),
      );

  // ─── Étapes ────────────────────────────────────────────────────────────────
  List<Widget> _stepWidgets() {
    final auth = ref.watch(authProvider);
    switch (_step) {
      case 0:
        return [
          _title('Bienvenue 👋', 'Configurons votre budget en quelques minutes.'),
          _info([
            'Hever vous montre combien il vous restera à la fin de chaque mois.',
            "Répondez à quelques questions : c'est prêt en 2 minutes.",
          ]),
          if (FirebaseConfig.enabled && auth.session != null) ...[
            SoftButton(
              icon: Icons.group_add_outlined,
              label: "J'ai un code pour rejoindre le budget de mon conjoint",
              onPressed: _joinShare,
            ),
            const SizedBox(height: 10),
          ],
          TextButton(
            onPressed: () => ref.read(appProvider.notifier).skipOnboarding(),
            child: const Text("Passer et utiliser des données d'exemple"),
          ),
        ];
      case 1:
        return [
          _title('Qui êtes-vous ?'),
          TextField(
              controller: _first,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Prénom')),
          const SizedBox(height: 10),
          TextField(
              controller: _lastName,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Nom')),
          const SizedBox(height: 14),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            child: SwitchListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 12),
              title: const Text('Vous êtes en couple ?',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              value: _couple,
              onChanged: (v) => setState(() => _couple = v),
            ),
          ),
          if (_couple) ...[
            const SizedBox(height: 10),
            TextField(
                controller: _partner,
                textCapitalization: TextCapitalization.words,
                decoration:
                    const InputDecoration(labelText: 'Prénom de votre conjoint')),
          ],
          const SizedBox(height: 10),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            child: Column(children: [
              SwitchListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                title: const Text('Auto-entrepreneur ?',
                    style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(_couple
                    ? 'Vous'
                    : 'Votre salaire est calculé à partir de vos clients'),
                value: _ae1,
                onChanged: (v) => setState(() => _ae1 = v),
              ),
              if (_couple)
                SwitchListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  title: Text(
                      _partner.text.trim().isEmpty
                          ? 'Votre conjoint'
                          : _partner.text.trim(),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: const Text('Auto-entrepreneur'),
                  value: _ae2,
                  onChanged: (v) => setState(() => _ae2 = v),
                ),
            ]),
          ),
          if (_ae1 || (_couple && _ae2)) ...[
            const SizedBox(height: 10),
            TextField(
              controller: _urssaf,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration:
                  const InputDecoration(labelText: 'Charges URSSAF', suffixText: '%'),
            ),
            const SizedBox(height: 6),
            const Text(
                'Vous ajouterez vos clients ensuite. Le salaire net est calculé pour vous.',
                style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
          ],
          const SizedBox(height: 14),
          _info(_couple
              ? [
                  'En couple, vous pouvez garder des budgets communs ou en séparer certains.',
                  'Pour partager le budget depuis deux comptes : Paramètres → Compte.'
                ]
              : ["Vous pourrez activer le mode couple plus tard dans les paramètres."]),
        ];
      case 2:
        return [
          _title('Votre solde actuel', "Combien y a-t-il sur votre compte aujourd'hui ?"),
          TextField(
            controller: _balance,
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true, signed: true),
            decoration: const InputDecoration(labelText: 'Solde actuel', suffixText: '€'),
          ),
          const SizedBox(height: 14),
          _info([
            "C'est votre point de départ.",
            'Vous pourrez le corriger à tout moment.',
          ]),
        ];
      case 3:
        // Si les deux (seul AE ou couple) sont AE, on montre juste l'info clients
        final allAE = _ae1 && (!_couple || _ae2);
        final anyAE = _ae1 || (_couple && _ae2);
        return [
          _title('Vos revenus', allAE ? 'Votre salaire est calculé depuis vos clients.' : 'Salaire, primes, remboursements…'),
          if (anyAE)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.teal.withAlpha(18),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.teal.withAlpha(60)),
              ),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('💼', style: TextStyle(fontSize: 20)),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text(
                    'Mode auto-entrepreneur actif : votre salaire net est calculé automatiquement depuis votre onglet Clients. Pas besoin de saisir un montant fixe.',
                    style: TextStyle(fontSize: 13, height: 1.4, fontWeight: FontWeight.w600),
                  ),
                ),
              ]),
            ),
          if (!allAE) ...[
            _editor(_incomes, nameLabel: 'Nom (ex. Salaire)'),
            _addButton('Ajouter un revenu', _incomes),
          ],
          const SizedBox(height: 14),
          _info(anyAE && !allAE
              ? [
                  'Saisissez ici les revenus de la personne salariée.',
                  'Le salaire auto-entrepreneur sera calculé depuis l\'onglet Clients.',
                ]
              : allAE
              ? ['Vous ajouterez vos clients dans l\'onglet dédié. Aucun montant à saisir ici.']
              : [
                  '• Récurrent : revenu qui tombe régulièrement (chaque mois, tous les 2 mois…).',
                  '• Ponctuel : versement unique ce mois-ci (prime exceptionnelle, remboursement…).',
                  'Vous pourrez tout modifier ou ajouter des revenus à tout moment.',
                ]),
        ];
      case 4:
        return [
          _title('Vos charges fixes', 'Loyer, abonnements, assurances…'),
          _editor(_fixed, nameLabel: 'Nom (ex. Loyer)'),
          _addButton('Ajouter une charge', _fixed),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final s in const [
              'Électricité',
              'Internet',
              'Téléphone',
              'Assurance',
              'Mutuelle',
              'Transports',
              'Abonnement'
            ])
              ActionChip(
                label: Text('+ $s'),
                onPressed: () => setState(() {
                  if (!_fixed.any(
                      (l) => l.name.text.trim().toLowerCase() == s.toLowerCase())) {
                    _fixed.add(_Line(s));
                  }
                }),
              ),
          ]),
          const SizedBox(height: 14),
          _info([
            '• Récurrente : sort tous les mois (ou tous les N mois : assurance annuelle, etc.).',
            '• Ponctuelle : dépense unique à noter maintenant (réparation, achat exceptionnel…).',
          ]),
        ];
      case 5:
        return [
          _title('Vos budgets', 'Montant mensuel par catégorie.'),
          _editor(_budgets, nameLabel: 'Catégorie', showFrequency: false),
          _addButton('Ajouter une catégorie', _budgets),
          const SizedBox(height: 14),
          _info([
            "Un budget, c'est une somme à ne pas dépasser chaque mois pour une catégorie.",
            "Ce qui compte : ne pas dépasser le total.",
            if (_couple) 'Loisirs est séparé pour chacun ; les autres budgets sont communs.',
          ]),
        ];
      default:
        final income = _sumIncomes();
        final fixed = _sumFixed();
        final budgets =
            _collect(_budgets).fold(0.0, (s, e) => s + e.amount) * (_couple ? 2 : 1);
        final rest = income - fixed - budgets;
        Widget row(String l, String v, {Color? c, bool bold = false}) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                Expanded(
                    child: Text(l,
                        style: const TextStyle(
                            color: AppColors.muted, fontWeight: FontWeight.w600))),
                Text(v,
                    style: TextStyle(
                        fontWeight: bold ? FontWeight.w800 : FontWeight.w700, color: c)),
              ]),
            );
        return [
          _title('Tout est prêt ✅', 'Voici le résumé de votre mois type.'),
          AppCard(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              row('Revenus', eur(income, sign: true), c: AppColors.success),
              row('Charges fixes', eur(-fixed)),
              row('Budgets', eur(-budgets)),
              const Divider(),
              row('Reste par mois', eur(rest, sign: true),
                  c: rest < 0 ? AppColors.danger : AppColors.success, bold: true),
            ]),
          ),
          const SizedBox(height: 16),
          _info([
            'Notez vos dépenses avec le bouton + Dépense.',
            'En fin de mois, touchez « Fin du mois ✓ ».',
            'Une visite guidée va démarrer : vous pourrez la revoir dans les Paramètres.',
          ]),
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              children: [
                Text('Étape ${_step + 1} sur ${_lastStep + 1}',
                    style: const TextStyle(
                        color: AppColors.muted, fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                AppProgress(value: (_step + 1) / (_lastStep + 1)),
                const SizedBox(height: 20),
                ..._stepWidgets(),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(_error!,
                        style: const TextStyle(
                            color: AppColors.danger, fontWeight: FontWeight.w600)),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
            child: Row(children: [
              if (_step > 0) ...[
                Expanded(child: SoftButton(label: 'Retour', onPressed: _back)),
                const SizedBox(width: 10),
              ],
              Expanded(
                flex: 2,
                child: GradientButton(
                    label: _step == _lastStep ? 'Terminer' : 'Suivant', onPressed: _next),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
