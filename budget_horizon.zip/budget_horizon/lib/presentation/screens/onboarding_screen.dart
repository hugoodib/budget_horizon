import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../data/firebase_config.dart';
import '../../data/onboarding_builder.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';

// ─── Fréquences disponibles ───────────────────────────────────────────────────
const _kFreqs = [1, 2, 3, 4, 6, 12];
String _freqLabel(int n) => switch (n) {
      1 => 'Chaque mois',
      2 => '1 mois sur 2',
      3 => 'Tous les 3 mois',
      4 => 'Tous les 4 mois',
      6 => 'Tous les 6 mois',
      12 => '1 fois par an',
      _ => 'Tous les $n mois',
    };

// ─── Suggestions « un clic » ──────────────────────────────────────────────────
class _Sugg {
  final IconData icon;
  final String name;
  const _Sugg(this.icon, this.name);
}

const _kIncomeSuggs = [
  _Sugg(Icons.work_outline_rounded, 'Salaire'),
  _Sugg(Icons.card_giftcard_rounded, 'Prime'),
  _Sugg(Icons.account_balance_rounded, 'Allocations'),
  _Sugg(Icons.payments_outlined, 'Pension'),
  _Sugg(Icons.home_outlined, 'Loyer perçu'),
  _Sugg(Icons.currency_exchange_rounded, 'Remboursement'),
];

const _kFixedSuggs = [
  _Sugg(Icons.home_outlined, 'Loyer'),
  _Sugg(Icons.bolt_rounded, 'Électricité'),
  _Sugg(Icons.wifi_rounded, 'Internet'),
  _Sugg(Icons.smartphone_rounded, 'Téléphone'),
  _Sugg(Icons.shield_outlined, 'Assurance'),
  _Sugg(Icons.health_and_safety_outlined, 'Mutuelle'),
  _Sugg(Icons.directions_transit_rounded, 'Transports'),
  _Sugg(Icons.subscriptions_outlined, 'Abonnements'),
  _Sugg(Icons.account_balance_outlined, 'Crédit'),
  _Sugg(Icons.water_drop_outlined, 'Eau'),
  _Sugg(Icons.fitness_center_rounded, 'Salle de sport'),
  _Sugg(Icons.receipt_long_outlined, 'Impôts'),
];

const _kBudgetSuggs = [
  _Sugg(Icons.shopping_basket_outlined, 'Courses'),
  _Sugg(Icons.local_gas_station_outlined, 'Essence'),
  _Sugg(Icons.sports_esports_outlined, 'Loisirs'),
  _Sugg(Icons.restaurant_outlined, 'Restaurants'),
  _Sugg(Icons.shopping_bag_outlined, 'Shopping'),
  _Sugg(Icons.medication_outlined, 'Santé'),
  _Sugg(Icons.directions_bus_outlined, 'Transports'),
  _Sugg(Icons.pets_outlined, 'Animaux'),
  _Sugg(Icons.card_giftcard_rounded, 'Cadeaux'),
];

// ─── Ligne de saisie ─────────────────────────────────────────────────────────
class _Line {
  final TextEditingController name;
  final TextEditingController amount;
  final FocusNode nameFocus = FocusNode();
  final FocusNode amountFocus = FocusNode();
  IconData icon;
  bool isOneOff; // true = ponctuel
  int intervalMonths; // 1, 2, 3, 4, 6, 12

  _Line({String n = '', String a = '', this.icon = Icons.sell_outlined, this.isOneOff = false, this.intervalMonths = 1})
      : name = TextEditingController(text: n),
        amount = TextEditingController(text: a);

  void dispose() {
    name.dispose();
    amount.dispose();
    nameFocus.dispose();
    amountFocus.dispose();
  }
}

const _kLevels = [
  '',
  'Faisons connaissance',
  'Ton équipe',
  'Comment tu es payé(e)',
  'Ton point de départ',
  'Ce qui rentre',
  'Ce qui sort chaque mois',
  'Tes enveloppes',
  'Ton mois type',
];
const _kBadges = <IconData>[
  Icons.person_outline_rounded,
  Icons.people_outline_rounded,
  Icons.work_outline_rounded,
  Icons.account_balance_outlined,
  Icons.payments_outlined,
  Icons.home_outlined,
  Icons.shopping_basket_outlined,
  Icons.flag_outlined,
];

/// Premiers pas : une aventure en 8 niveaux, une question à la fois, pour créer son
/// profil et saisir toutes ses données en quelques minutes.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  static const _lastStep = 8;
  int _step = 0;
  bool _forward = true;
  bool _couple = false;
  bool _ae1 = false;
  bool _ae2 = false;
  final _urssaf = TextEditingController(text: '23,68');
  String? _error;
  final _first = TextEditingController();
  final _lastName = TextEditingController();
  final _partner = TextEditingController();
  final _balance = TextEditingController();
  final List<_Line> _incomes = [_Line(n: 'Salaire', icon: Icons.work_outline_rounded)];
  final List<_Line> _fixed = [_Line(n: 'Loyer', icon: Icons.home_outlined)];
  final List<_Line> _budgets = [
    _Line(n: 'Courses', icon: Icons.shopping_basket_outlined),
    _Line(n: 'Essence', icon: Icons.local_gas_station_outlined),
    _Line(n: 'Loisirs', icon: Icons.sports_esports_outlined),
    _Line(n: 'Restaurants', icon: Icons.restaurant_outlined),
  ];

  @override
  void dispose() {
    _first.dispose();
    _lastName.dispose();
    _partner.dispose();
    _balance.dispose();
    _urssaf.dispose();
    for (final l in [..._incomes, ..._fixed, ..._budgets]) {
      l.dispose();
    }
    super.dispose();
  }

  // ─── Données ────────────────────────────────────────────────────────────────
  List<OnboardingEntry> _collect(List<_Line> lines) {
    final now = ref.read(realNowProvider);
    final out = <OnboardingEntry>[];
    for (final l in lines) {
      final n = l.name.text.trim();
      final a = parseAmount(l.amount.text);
      if (n.isNotEmpty && a != null && a > 0) {
        out.add(OnboardingEntry(
          n,
          a,
          isOneOff: l.isOneOff,
          intervalMonths: l.intervalMonths,
          oneOffYm: l.isOneOff ? now : null,
        ));
      }
    }
    return out;
  }

  double _monthly(List<_Line> lines) {
    double total = 0;
    for (final l in lines) {
      final a = parseAmount(l.amount.text) ?? 0;
      if (a <= 0) continue;
      total += l.isOneOff ? a : a / l.intervalMonths;
    }
    return total;
  }

  double _sumBudgets() {
    double total = 0;
    for (final l in _budgets) {
      final a = parseAmount(l.amount.text) ?? 0;
      if (a <= 0) continue;
      // En couple, « Loisirs » est séparé (un par personne), les autres sont communs.
      final twice = _couple && l.name.text.toLowerCase().contains('loisir');
      total += twice ? a * 2 : a;
    }
    return total;
  }

  bool get _allAE => _ae1 && (!_couple || _ae2);
  bool get _anyAE => _ae1 || (_couple && _ae2);
  String get _p1 => _first.text.trim().isEmpty ? 'Toi' : _first.text.trim();
  String get _p2 => _partner.text.trim().isEmpty ? 'Ton conjoint' : _partner.text.trim();

  String? _validate() {
    if (_step == 1 && _first.text.trim().isEmpty) return 'Indique au moins ton prénom.';
    if (_step == 2 && _couple) {
      if (_partner.text.trim().isEmpty) return 'Indique le prénom de ton conjoint.';
      if (_partner.text.trim().toLowerCase() == _first.text.trim().toLowerCase()) {
        return 'Les deux prénoms doivent être différents.';
      }
    }
    if (_step == 3 && _anyAE) {
      final r = parseAmount(_urssaf.text);
      if (r == null || r < 0 || r >= 100) return 'Indique un taux de charges entre 0 et 100 %.';
    }
    if (_step == 4 && parseAmount(_balance.text) == null) {
      return 'Indique un montant (0 si tu ne sais pas).';
    }
    return null;
  }

  void _go(int to) {
    HapticFeedback.selectionClick();
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() {
      _forward = to > _step;
      _error = null;
      _step = to;
    });
  }

  void _next() {
    final err = _validate();
    if (err != null) {
      HapticFeedback.mediumImpact();
      setState(() => _error = err);
      return;
    }
    if (_step == _lastStep) {
      _finish();
      return;
    }
    _go(_step + 1);
  }

  List<_Line> get _currentList => switch (_step) {
        5 => _incomes,
        6 => _fixed,
        7 => _budgets,
        _ => const <_Line>[],
      };

  /// Valide la saisie en cours : passe au montant vide suivant de la liste, ou ferme le clavier.
  void _validateField() {
    final list = _currentList;
    final i = list.indexWhere((l) => l.amountFocus.hasFocus || l.nameFocus.hasFocus);
    if (i >= 0) {
      for (var j = i + 1; j < list.length; j++) {
        if (list[j].amount.text.trim().isEmpty) {
          HapticFeedback.selectionClick();
          list[j].amountFocus.requestFocus();
          return;
        }
      }
    }
    FocusManager.instance.primaryFocus?.unfocus();
  }

  void _back() {
    if (_step > 0) _go(_step - 1);
  }

  void _finish() {
    final answers = OnboardingAnswers(
      firstName: _first.text,
      lastName: _lastName.text,
      isCouple: _couple,
      partnerName: _partner.text,
      currentBalance: parseAmount(_balance.text) ?? 0,
      incomes: _allAE ? const [] : _collect(_incomes),
      fixed: _collect(_fixed),
      budgets: _collect(_budgets),
      ae1: _ae1,
      ae2: _couple && _ae2,
      urssaf: parseAmount(_urssaf.text) ?? 23.68,
    );
    final uid = ref.read(authProvider).session?.uid ?? 'local';
    final data = OnboardingBuilder.build(answers, ref.read(realNowProvider), uid);
    FocusManager.instance.primaryFocus?.unfocus();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    ref.read(appProvider.notifier).completeOnboarding(data);
    // La visite guidée démarre tout de suite sur l'écran d'accueil.
    ref.read(tourProvider.notifier).start();
  }

  Future<void> _joinShare() async {
    final c = TextEditingController();
    final code = await showQuickDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rejoindre un budget partagé'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text(
              'Saisis le code que ton conjoint a obtenu dans Paramètres → Compte → Partager avec mon conjoint.'),
          const SizedBox(height: 12),
          TextField(
            controller: c,
            autofocus: true,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(labelText: 'Code'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Rejoindre')),
        ],
      ),
    );
    c.dispose();
    if (code == null || !mounted) return;
    final ok = await ref.read(authProvider.notifier).joinShare(code);
    if (!ok && mounted) snack(context, ref.read(authProvider).error ?? 'Code invalide');
  }

  // ─── Gestion des lignes ─────────────────────────────────────────────────────
  void _addLine(List<_Line> list, IconData icon, String name) {
    final l = _Line(n: name, icon: icon);
    HapticFeedback.selectionClick();
    setState(() => list.add(l));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      (name.isEmpty ? l.nameFocus : l.amountFocus).requestFocus();
    });
  }

  void _removeLine(List<_Line> list, _Line l) {
    setState(() => list.remove(l));
    WidgetsBinding.instance.addPostFrameCallback((_) => l.dispose());
  }

  Future<void> _pickFreq(_Line l) async {
    final f = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 18, 20, 6),
            child: Text('À quel rythme ?', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          ),
          for (final n in _kFreqs.where((n) => n != 1))
            ListTile(
              title: Text(_freqLabel(n), style: const TextStyle(fontWeight: FontWeight.w600)),
              trailing: (!l.isOneOff && l.intervalMonths == n)
                  ? const Icon(Icons.check_circle_rounded, color: AppColors.success)
                  : null,
              onTap: () => Navigator.pop(ctx, n),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (f == null || !mounted) return;
    setState(() {
      l.isOneOff = false;
      l.intervalMonths = f;
    });
  }

  // ─── Briques visuelles ──────────────────────────────────────────────────────
  Color get _brand => context.isDark ? AppColors.violetDark : const Color(0xFF7466E0);

  Widget _hero(IconData icon, {double size = 80}) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.85, end: 1),
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeOutBack,
        builder: (_, v, child) => Opacity(opacity: v.clamp(0.0, 1.0), child: Transform.scale(scale: v, child: child)),
        child: Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: tint(_brand, .12),
            borderRadius: BorderRadius.circular(size * .32),
            border: Border.all(color: tint(_brand, .25)),
          ),
          child: Icon(icon, size: size * .46, color: _brand),
        ),
      );

  Widget _iconTile(IconData icon, Color color, {double size = 44}) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: tint(color, .14),
          borderRadius: BorderRadius.circular(size * .3),
        ),
        child: Icon(icon, size: size * .5, color: color),
      );

  Widget _title(String t, [String? sub]) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 18),
        child: Column(children: [
          Text(t,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, letterSpacing: -0.5, height: 1.2)),
          if (sub != null) ...[
            const SizedBox(height: 8),
            Text(sub,
                textAlign: TextAlign.center,
                style: TextStyle(color: context.mutedColor, fontSize: 15.5, height: 1.4)),
          ],
        ]),
      );

  Widget _tip(List<String> lines, {IconData icon = Icons.lightbulb_outline_rounded}) => Padding(
        padding: const EdgeInsets.only(top: 6, bottom: 6),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: tint(_brand, .09),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, size: 22, color: _brand),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                for (var i = 0; i < lines.length; i++) ...[
                  if (i > 0) const SizedBox(height: 6),
                  Text(lines[i], style: const TextStyle(fontSize: 14, height: 1.45)),
                ],
              ]),
            ),
          ]),
        ),
      );

  Widget _choice({
    required IconData icon,
    required String title,
    String? subtitle,
    required bool selected,
    required VoidCallback onTap,
    bool compact = false,
  }) {
    final accent = _brand;
    final textCol = Column(
      crossAxisAlignment: compact ? CrossAxisAlignment.center : CrossAxisAlignment.start,
      children: [
        Text(title,
            textAlign: compact ? TextAlign.center : TextAlign.start,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        if (subtitle != null) ...[
          const SizedBox(height: 2),
          Text(subtitle,
              textAlign: compact ? TextAlign.center : TextAlign.start,
              style: TextStyle(color: context.mutedColor, fontSize: 13, height: 1.3)),
        ],
      ],
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: compact ? 16 : 16),
        decoration: BoxDecoration(
          color: selected ? tint(accent, .16) : context.cardColor.withAlpha(context.isDark ? 255 : 215),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: selected ? accent : Colors.transparent, width: 2),
        ),
        child: compact
            ? Column(children: [
                _iconTile(icon, selected ? accent : context.mutedColor, size: 46),
                const SizedBox(height: 10),
                textCol,
              ])
            : Row(children: [
                _iconTile(icon, selected ? accent : context.mutedColor, size: 48),
                const SizedBox(width: 16),
                Expanded(child: textCol),
                AnimatedOpacity(
                  opacity: selected ? 1 : 0,
                  duration: const Duration(milliseconds: 200),
                  child: Icon(Icons.check_circle_rounded, color: accent),
                ),
              ]),
      ),
    );
  }

  Widget _pill(String label, bool selected, VoidCallback onTap, Color accent) => GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          onTap();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: selected ? accent : context.fieldColor,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(label,
              style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w600,
                  color: selected ? Colors.white : context.textColor)),
        ),
      );

  Widget _lineCard(List<_Line> list, _Line l,
      {required bool showFreq, required Color accent, required String nameHint}) {
    final other = !l.isOneOff && l.intervalMonths != 1;
    return Padding(
      key: ObjectKey(l),
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        padding: const EdgeInsets.fromLTRB(12, 12, 6, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _iconTile(l.icon, accent, size: 46),
            const SizedBox(width: 10),
            Expanded(
              child: TextField(
                controller: l.name,
                focusNode: l.nameFocus,
                textCapitalization: TextCapitalization.sentences,
                textInputAction: TextInputAction.next,
                onSubmitted: (_) => l.amountFocus.requestFocus(),
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 15.5),
                decoration: InputDecoration(hintText: nameHint, isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16)),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 124,
              child: TextField(
                controller: l.amount,
                focusNode: l.amountFocus,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textAlign: TextAlign.right,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 16),
                decoration: const InputDecoration(suffixText: ' €', isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 16)),
              ),
            ),
            IconButton(
              onPressed: () => _removeLine(list, l),
              icon: Icon(Icons.close_rounded, color: context.mutedColor, size: 20),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
            ),
          ]),
          if (showFreq) ...[
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: Wrap(spacing: 8, runSpacing: 6, children: [
                _pill('Chaque mois', !l.isOneOff && l.intervalMonths == 1, () {
                  setState(() {
                    l.isOneOff = false;
                    l.intervalMonths = 1;
                  });
                }, accent),
                _pill('Une seule fois', l.isOneOff, () => setState(() => l.isOneOff = true), accent),
                _pill(other ? _freqLabel(l.intervalMonths) : 'Autre rythme  ▾', other,
                    () => _pickFreq(l), accent),
              ]),
            ),
            if (l.isOneOff)
              Padding(
                padding: const EdgeInsets.only(top: 6, left: 2),
                child: Text('Compté pour ce mois-ci uniquement.',
                    style: TextStyle(fontSize: 12.5, color: context.mutedColor)),
              ),
          ],
        ]),
      ),
    );
  }

  /// Étape « liste » : cartes saisies + suggestions à toucher.
  List<Widget> _listStep({
    required IconData icon,
    required String title,
    required String sub,
    required List<_Line> list,
    required List<_Sugg> suggs,
    required Color accent,
    required String nameHint,
    required bool showFreq,
    required List<String> tip,
    bool paletteAccent = false,
  }) {
    final remaining = suggs
        .where((s) => !list.any((l) => l.name.text.trim().toLowerCase() == s.name.toLowerCase()))
        .toList();
    return [
      Center(child: _hero(icon)),
      _title(title, sub),
      for (var i = 0; i < list.length; i++)
        _lineCard(list, list[i],
            showFreq: showFreq,
            accent: paletteAccent ? AppColors.palette[i % AppColors.palette.length] : accent,
            nameHint: nameHint),
      if (list.isEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Center(
            child: Text('Rien pour l\'instant — touche une idée ci-dessous',
                style: TextStyle(color: context.mutedColor, fontSize: 13)),
          ),
        ),
      const SizedBox(height: 4),
      Text('Touche pour ajouter :',
          style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (final s in remaining)
          _SuggChip(icon: s.icon, label: s.name, accent: accent, onTap: () => _addLine(list, s.icon, s.name)),
        _SuggChip(icon: Icons.edit_outlined, label: 'Autre…', accent: accent, onTap: () => _addLine(list, Icons.sell_outlined, '')),
      ]),
      const SizedBox(height: 14),
      _tip(tip),
    ];
  }

  // ─── Étapes ────────────────────────────────────────────────────────────────
  List<Widget> _stepWidgets() {
    switch (_step) {
      case 0:
        final auth = ref.watch(authProvider);
        return [
          const SizedBox(height: 24),
          Center(child: _hero(Icons.rocket_launch_outlined, size: 96)),
          _title('Bienvenue sur Hever !', 'En 2 minutes, tu sauras combien il te restera à la fin de chaque mois.'),
          const SizedBox(height: 6),
          for (final p in const [
            (Icons.sports_esports_outlined, 'Une question à la fois', '8 petits niveaux, c\'est rapide et sans prise de tête.'),
            (Icons.touch_app_outlined, 'Presque tout en un clic', 'Des idées à toucher : tu n\'as plus qu\'à mettre les montants.'),
            (Icons.tune_rounded, 'Rien n\'est définitif', 'Tu pourras tout modifier plus tard.'),
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  _iconTile(p.$1, _brand, size: 44),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(p.$2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                      const SizedBox(height: 2),
                      Text(p.$3, style: TextStyle(color: context.mutedColor, fontSize: 13.5, height: 1.3)),
                    ]),
                  ),
                ]),
              ),
            ),
          const SizedBox(height: 8),
          if (FirebaseConfig.enabled && auth.session != null) ...[
            SoftButton(
              icon: Icons.group_add_outlined,
              label: "J'ai un code pour rejoindre le budget de mon conjoint",
              onPressed: _joinShare,
            ),
            const SizedBox(height: 6),
          ],
          TextButton(
            onPressed: () => ref.read(appProvider.notifier).skipOnboarding(),
            child: Text("Je veux juste explorer avec des données d'exemple",
                textAlign: TextAlign.center, style: TextStyle(color: context.mutedColor)),
          ),
        ];
      case 1:
        return [
          Center(child: _hero(Icons.waving_hand_outlined)),
          _title('Salut ! Comment tu t\'appelles ?', 'Juste pour personnaliser ton espace.'),
          TextField(
            controller: _first,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            textInputAction: TextInputAction.next,
            onChanged: (_) => setState(() => _error = null),
            style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w500),
            decoration: const InputDecoration(labelText: 'Ton prénom'),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _lastName,
            textCapitalization: TextCapitalization.words,
            style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w500),
            decoration: const InputDecoration(labelText: 'Ton nom (facultatif)'),
          ),
        ];
      case 2:
        return [
          Center(child: _hero(_couple ? Icons.people_outline_rounded : Icons.person_outline_rounded)),
          _title(
              _first.text.trim().isEmpty ? 'Tu gères ton budget…' : 'Enchanté ${_first.text.trim()} ! Tu gères ton budget…'),
          _choice(
            icon: Icons.person_outline_rounded,
            title: 'Tout seul(e)',
            subtitle: 'Un budget rien que pour toi.',
            selected: !_couple,
            onTap: () => setState(() => _couple = false),
          ),
          const SizedBox(height: 10),
          _choice(
            icon: Icons.people_outline_rounded,
            title: 'À deux, en couple',
            subtitle: 'Un budget commun, avec des budgets perso pour chacun.',
            selected: _couple,
            onTap: () => setState(() => _couple = true),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            alignment: Alignment.topCenter,
            child: _couple
                ? Padding(
                    padding: const EdgeInsets.only(top: 14),
                    child: TextField(
                      controller: _partner,
                      textCapitalization: TextCapitalization.words,
                      onChanged: (_) => setState(() => _error = null),
                      decoration: const InputDecoration(labelText: 'Le prénom de ton conjoint'),
                    ),
                  )
                : const SizedBox(width: double.infinity),
          ),
          const SizedBox(height: 14),
          _tip(['Pas de panique : tu pourras changer ça plus tard dans les paramètres.']),
        ];
      case 3:
        return [
          Center(child: _hero(_anyAE ? Icons.receipt_long_outlined : Icons.work_outline_rounded)),
          _title('Comment tu es payé(e) ?', _couple ? 'Choisis pour chacun de vous deux.' : 'Ça change la façon de calculer tes revenus.'),
          if (_couple) Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(_p1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5)),
          ),
          Row(children: [
            Expanded(
              child: _choice(
                compact: true,
                icon: Icons.work_outline_rounded,
                title: 'Salarié(e)',
                subtitle: 'Un revenu régulier',
                selected: !_ae1,
                onTap: () => setState(() => _ae1 = false),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _choice(
                compact: true,
                icon: Icons.receipt_long_outlined,
                title: 'Auto-entrepreneur',
                subtitle: 'Payé par tes clients',
                selected: _ae1,
                onTap: () => setState(() => _ae1 = true),
              ),
            ),
          ]),
          if (_couple) ...[
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(_p2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5)),
            ),
            Row(children: [
              Expanded(
                child: _choice(
                  compact: true,
                  icon: Icons.work_outline_rounded,
                  title: 'Salarié(e)',
                  subtitle: 'Un revenu régulier',
                  selected: !_ae2,
                  onTap: () => setState(() => _ae2 = false),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _choice(
                  compact: true,
                  icon: Icons.receipt_long_outlined,
                  title: 'Auto-entrepreneur',
                  subtitle: 'Payé par ses clients',
                  selected: _ae2,
                  onTap: () => setState(() => _ae2 = true),
                ),
              ),
            ]),
          ],
          AnimatedSize(
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut,
            alignment: Alignment.topCenter,
            child: _anyAE
                ? Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      TextField(
                        controller: _urssaf,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        onChanged: (_) => setState(() => _error = null),
                        decoration: const InputDecoration(labelText: 'Charges URSSAF', suffixText: '%'),
                      ),
                      const SizedBox(height: 8),
                      _tip(const [
                        'Pas sûr du taux ? Garde cette valeur, tu pourras la changer dans les paramètres.',
                        'Ensuite, tu ajouteras tes clients : Hever calcule ton salaire net tout seul.',
                      ], icon: Icons.calculate_outlined),
                    ]),
                  )
                : const SizedBox(width: double.infinity),
          ),
        ];
      case 4:
        return [
          Center(child: _hero(Icons.account_balance_outlined)),
          _title('Combien as-tu sur ton compte ?', 'C\'est ton point de départ.'),
          TextField(
            controller: _balance,
            autofocus: true,
            textAlign: TextAlign.center,
            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
            onChanged: (_) => setState(() => _error = null),
            style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700),
            decoration: const InputDecoration(suffixText: ' €'),
          ),
          const SizedBox(height: 10),
          Center(
            child: TextButton(
              onPressed: () {
                _balance.text = '0';
                _next();
              },
              child: const Text('Je ne sais pas, on verra plus tard'),
            ),
          ),
          const SizedBox(height: 6),
          _tip(const [
            'Ouvre ton appli bancaire : c\'est le solde affiché. Pas besoin du centime près.',
            'Tu pourras le corriger à tout moment.',
          ], icon: Icons.smartphone_rounded),
        ];
      case 5:
        if (_allAE) {
          return [
            Center(child: _hero(Icons.receipt_long_outlined)),
            _title('Tes revenus arrivent tout seuls', 'Rien à saisir ici.'),
            _tip(const [
              'Comme tu es auto-entrepreneur, ton salaire net est calculé depuis l\'onglet Clients.',
              'Tu les ajouteras juste après cette installation.',
            ], icon: Icons.auto_fix_high_rounded),
          ];
        }
        return _listStep(
          icon: Icons.payments_outlined,
          title: 'Qu\'est-ce qui rentre ?',
          sub: _anyAE
              ? 'Ici, uniquement les revenus de la personne salariée.'
              : (_couple ? 'Les revenus de votre foyer.' : 'Salaire, primes, aides…'),
          list: _incomes,
          suggs: _kIncomeSuggs,
          accent: AppColors.success,
          nameHint: 'Nom du revenu',
          showFreq: true,
          tip: const [
            'Chaque mois : ton salaire, par exemple.',
            'Une seule fois : une prime ou un remboursement ce mois-ci.',
          ],
        );
      case 6:
        return _listStep(
          icon: Icons.home_outlined,
          title: 'Qu\'est-ce qui sort chaque mois ?',
          sub: 'Les charges fixes : loyer, abonnements, assurances…',
          list: _fixed,
          suggs: _kFixedSuggs,
          accent: AppColors.pink,
          nameHint: 'Nom de la charge',
          showFreq: true,
          tip: const [
            'Une assurance annuelle ? Choisis « Autre rythme » → « 1 fois par an ».',
            'Si tu hésites sur un montant, mets une estimation : tu pourras corriger.',
          ],
        );
      case 7:
        return _listStep(
          icon: Icons.shopping_basket_outlined,
          title: 'Tes enveloppes du mois',
          sub: 'Combien tu veux dépenser, au maximum, par catégorie.',
          list: _budgets,
          suggs: _kBudgetSuggs,
          accent: AppColors.warning,
          nameHint: 'Catégorie',
          showFreq: false,
          paletteAccent: true,
          tip: [
            'Une enveloppe, c\'est une somme à ne pas dépasser chaque mois. Hever la déduit déjà de ta prévision de fin de mois.',
            if (_couple) 'En couple : Loisirs est séparé pour chacun, les autres enveloppes sont communes.',
          ],
        );
      default:
        final income = _allAE ? 0.0 : _monthly(_incomes);
        final fixed = _monthly(_fixed);
        final budgets = _sumBudgets();
        final rest = income - fixed - budgets;
        Widget row(IconData ic, String l, String v, Color c) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Row(children: [
                _iconTile(ic, _brand, size: 36),
                const SizedBox(width: 12),
                Expanded(child: Text(l, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15.5))),
                Text(v, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5, color: c)),
              ]),
            );
        return [
          Center(child: _hero(Icons.flag_outlined)),
          _title(
              _first.text.trim().isEmpty ? 'Bravo, tout est prêt !' : 'Bravo ${_first.text.trim()}, tout est prêt !',
              'Voilà à quoi ressemble ton mois type.'),
          AppCard(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
            child: Column(children: [
              if (_allAE)
                row(Icons.receipt_long_outlined, 'Revenus', 'via tes clients', AppColors.success)
              else
                row(Icons.payments_outlined, 'Ce qui rentre', eur(income, sign: true), AppColors.success),
              row(Icons.home_outlined, 'Charges fixes', eur(-fixed), context.textColor),
              row(Icons.shopping_basket_outlined, 'Enveloppes', eur(-budgets), context.textColor),
              const Divider(height: 22),
              Text('Il te restera environ',
                  style: TextStyle(color: context.mutedColor, fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(height: 2),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: rest),
                duration: const Duration(milliseconds: 900),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Text(
                  '${eur(v)} / mois',
                  style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.8,
                      color: rest < 0 ? AppColors.danger : AppColors.success),
                ),
              ),
              if (_allAE)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('(avant ton salaire d\'auto-entrepreneur)',
                      style: TextStyle(color: context.mutedColor, fontSize: 12)),
                ),
            ]),
          ),
          if (rest < 0 && !_allAE) ...[
            const SizedBox(height: 10),
            _tip(const ['Ça dépasse un peu : pas grave, tu peux ajuster tes enveloppes maintenant ou plus tard.'],
                icon: Icons.warning_amber_rounded),
            const SizedBox(height: 6),
            SoftButton(icon: Icons.edit_rounded, label: 'Revoir mes enveloppes', onPressed: () => _go(7)),
          ],
          const SizedBox(height: 16),
          Text('Les 3 gestes à retenir',
              style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: .4)),
          const SizedBox(height: 8),
          for (final g in const [
            (Icons.add_circle_outline_rounded, 'Note chaque dépense', 'Dès que tu paies quelque chose.'),
            (Icons.check_circle_outline_rounded, 'Coche quand c\'est débité', 'Pour que ton solde actuel reste juste.'),
            (Icons.flag_outlined, 'Clôture à la fin du mois', 'Un seul geste pour passer au mois suivant.'),
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                padding: const EdgeInsets.all(14),
                child: Row(children: [
                  _iconTile(g.$1, _brand, size: 40),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(g.$2, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      Text(g.$3, style: TextStyle(color: context.mutedColor, fontSize: 13)),
                    ]),
                  ),
                ]),
              ),
            ),
          const SizedBox(height: 4),
          _tip(const ['Une petite visite guidée de 30 secondes va te montrer où tout se trouve. Tu pourras la revoir dans les Paramètres.'],
              icon: Icons.explore_outlined),
        ];
    }
  }

  // ─── Cadre de l'écran ──────────────────────────────────────────────────────
  Widget _header() {
    Widget badge(int s) {
      final done = _step > s;
      final cur = _step == s;
      return AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutBack,
        width: cur ? 36 : 30,
        height: cur ? 36 : 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          gradient: (done || cur) ? brandGradient : null,
          color: (done || cur) ? null : context.fieldColor,
          shape: BoxShape.circle,
          boxShadow: cur ? [BoxShadow(color: tint(AppColors.violet, .4), blurRadius: 10, offset: const Offset(0, 3))] : null,
        ),
        child: done
            ? const Icon(Icons.check_rounded, size: 16, color: AppColors.text)
            : Icon(_kBadges[s - 1], size: cur ? 20 : 16, color: cur ? AppColors.text : context.mutedColor),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Column(children: [
        Row(children: [
          for (var s = 1; s <= _lastStep; s++) ...[
            badge(s),
            if (s < _lastStep)
              Expanded(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  height: 3,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: _step > s ? AppColors.teal : context.trackColor,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
          ],
        ]),
        const SizedBox(height: 10),
        Text('Niveau $_step sur $_lastStep · ${_kLevels[_step]}',
            style: TextStyle(color: context.mutedColor, fontSize: 13, fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _totalBar() {
    final (label, value, color) = switch (_step) {
      5 => ('Ce qui rentre', _monthly(_incomes), AppColors.success),
      6 => ('Charges fixes', _monthly(_fixed), AppColors.pink),
      _ => ('Enveloppes', _sumBudgets(), AppColors.warning),
    };
    if (_step == 5 && _allAE) return const SizedBox.shrink();
    if (value <= 0) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(color: tint(color, .14), borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14.5)),
          const Spacer(),
          Text('${eur(value)} / mois', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: color)),
        ]),
      ),
    );
  }

  Widget _bottomBar() {
    final isList = _step >= 5 && _step <= 7;
    final listEmpty = switch (_step) {
      5 => _allAE || _monthly(_incomes) <= 0,
      6 => _monthly(_fixed) <= 0,
      7 => _sumBudgets() <= 0,
      _ => false,
    };
    final keyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0;
    final label = switch (_step) {
      0 => 'Commencer',
      _lastStep => 'Découvrir Hever',
      5 when _allAE => 'Étape suivante',
      _ when isList && keyboardOpen => 'Valider',
      _ when isList && listEmpty => 'Passer cette étape',
      _ when isList => 'Étape suivante',
      _ => 'Continuer',
    };
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: tint(AppColors.danger, .14), borderRadius: BorderRadius.circular(14)),
              child: Text(_error!,
                  style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600, fontSize: 14)),
            ),
          ),
        if (isList) _totalBar(),
        Row(children: [
          if (_step > 0) ...[
            GestureDetector(
              onTap: _back,
              child: Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(22)),
                child: Icon(Icons.arrow_back_rounded, color: context.textColor),
              ),
            ),
            const SizedBox(width: 10),
          ],
          Expanded(child: _Cta(label: label, onPressed: (isList && keyboardOpen) ? _validateField : _next)),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = context.isDark;
    final fieldBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: dark ? Colors.white.withAlpha(40) : const Color(0xFFC9CCE0), width: 1.2),
    );
    final theme = Theme.of(context).copyWith(
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF1E2440) : Colors.white,
        border: fieldBorder,
        enabledBorder: fieldBorder,
        focusedBorder: fieldBorder.copyWith(borderSide: BorderSide(color: _brand, width: 2)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        hintStyle: TextStyle(color: context.mutedColor),
        labelStyle: TextStyle(color: context.mutedColor),
      ),
    );
    return Theme(
      data: theme,
      child: Scaffold(
      body: SafeArea(
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          child: Stack(children: [
            Column(children: [
              if (_step > 0) _header(),
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 320),
                  transitionBuilder: (child, anim) {
                    final incoming = child.key == ValueKey(_step);
                    final dx = (_forward ? 1.0 : -1.0) * 0.10 * (incoming ? 1 : -1);
                    return FadeTransition(
                      opacity: anim,
                      child: SlideTransition(
                        position: Tween<Offset>(begin: Offset(dx, 0), end: Offset.zero).animate(anim),
                        child: child,
                      ),
                    );
                  },
                  child: KeyedSubtree(
                    key: ValueKey(_step),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(18, 12, 18, 16),
                      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                      children: _stepWidgets(),
                    ),
                  ),
                ),
              ),
              _bottomBar(),
            ]),
            if (_step == _lastStep) const Positioned.fill(child: IgnorePointer(child: _Confetti())),
          ]),
        ),
      ),
    ),
    );
  }
}

/// Pastille de suggestion à toucher.
class _SuggChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  const _SuggChip({required this.icon, required this.label, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
          decoration: BoxDecoration(
            color: context.cardColor.withAlpha(context.isDark ? 255 : 220),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: tint(accent, .35), width: 1.2),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 18, color: accent),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(width: 6),
            Icon(Icons.add_rounded, size: 16, color: context.mutedColor),
          ]),
        ),
      );
}

/// Confettis de célébration (une seule chute).
class _Confetti extends StatefulWidget {
  const _Confetti();
  @override
  State<_Confetti> createState() => _ConfettiState();
}

class _Piece {
  final double x, delay, speed, phase, size, spin;
  final Color color;
  _Piece(this.x, this.delay, this.speed, this.phase, this.size, this.spin, this.color);
}

class _ConfettiState extends State<_Confetti> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3200))..forward();
  late final List<_Piece> _pieces;

  @override
  void initState() {
    super.initState();
    final r = Random(7);
    _pieces = List.generate(
      70,
      (_) => _Piece(
        r.nextDouble(),
        r.nextDouble() * 0.35,
        0.75 + r.nextDouble() * 0.5,
        r.nextDouble() * 6.28,
        6 + r.nextDouble() * 7,
        r.nextDouble() * 6.28,
        AppColors.palette[r.nextInt(AppColors.palette.length)],
      ),
    );
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(painter: _ConfettiPainter(_pieces, _c.value)),
      );
}

class _ConfettiPainter extends CustomPainter {
  final List<_Piece> pieces;
  final double t;
  _ConfettiPainter(this.pieces, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in pieces) {
      final prog = ((t - p.delay) / (1 - p.delay)).clamp(0.0, 1.0);
      if (prog <= 0 || prog >= 1) continue;
      final y = -20 + prog * p.speed * (size.height + 40);
      final x = p.x * size.width + sin(prog * 8 + p.phase) * 22;
      final paint = Paint()..color = p.color.withAlpha(((1 - prog * prog) * 255).round());
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(p.spin + prog * 9);
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: p.size, height: p.size * .55),
            const Radius.circular(2)),
        paint,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => old.t != t;
}

/// Bouton principal des premiers pas : grand, lisible, facile à atteindre du pouce.
class _Cta extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  const _Cta({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) => Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: brandGradient,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [BoxShadow(color: tint(AppColors.violet, .3), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: onPressed,
            child: Center(
              child: Text(label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w700, fontSize: 16.5)),
            ),
          ),
        ),
      );
}
