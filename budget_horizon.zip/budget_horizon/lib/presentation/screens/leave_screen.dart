import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';

// ══════════════════════════════════════════════════════════════════════════════
// Écran Congés
// ══════════════════════════════════════════════════════════════════════════════

class LeaveScreen extends ConsumerStatefulWidget {
  const LeaveScreen({super.key});
  @override
  ConsumerState<LeaveScreen> createState() => _LeaveScreenState();
}

class _LeaveScreenState extends ConsumerState<LeaveScreen> {
  late Ym _month;

  @override
  void initState() {
    super.initState();
    _month = ref.read(leaveMonthProvider);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Sync si leaveMonthProvider a été changé depuis l'extérieur (ex. alerte)
    final providerMonth = ref.read(leaveMonthProvider);
    if (providerMonth != _month) {
      setState(() => _month = providerMonth);
    }
  }

  /// Solde à la fin du mois [ym] = soldeDebut(ym) + cumul(ym) - poses(ym).
  double _soldeFin(LeaveType lt, Ym ym, AppData d) {
    return _soldeDebut(lt, ym, d) + lt.accrualPerMonth - _poses(lt, ym, d);
  }

  /// Solde au début du mois [ym].
  double _soldeDebut(LeaveType lt, Ym ym, AppData d) {
    final manual = d.leaveEntries
        .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note == '__solde__')
        .firstOrNull;
    if (manual != null) return manual.days;
    if (ym.index <= d.startYm.index) return lt.initialBalance;
    return _soldeFin(lt, ym.add(-1), d);
  }

  /// Jours posés pour un type dans un mois.
  double _poses(LeaveType lt, Ym ym, AppData d) => d.leaveEntries
      .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note != '__solde__')
      .fold(0.0, (s, e) => s + e.days);

  /// Solde disponible = soldeDebut + cumul du mois.
  double _disponible(LeaveType lt, Ym ym, AppData d) =>
      _soldeDebut(lt, ym, d) + lt.accrualPerMonth;

  /// Maximum posable dans [ym] pour [lt].
  int _maxPosable(LeaveType lt, Ym ym, AppData d) =>
      _disponible(lt, ym, d).floor().clamp(0, 999).toInt();

  /// Maximum total posable tous types confondus.
  int _maxTotal(List<LeaveType> types, AppData d) =>
      types.fold(0, (s, lt) => s + _maxPosable(lt, _month, d));

  /// Total posé tous types confondus.
  double _totalPose(List<LeaveType> types, AppData d) =>
      types.fold(0.0, (s, lt) => s + _poses(lt, _month, d));

  _LeaveConflict? _findConflict(LeaveType lt, Ym from, double extraDays, AppData d) {
    final futurePoses = d.leaveEntries
        .where((e) => e.leaveTypeId == lt.id && e.month.index > from.index && e.note != '__solde__')
        .toList();
    if (futurePoses.isEmpty) return null;
    for (final entry in futurePoses) {
      final soldeFinReel = _soldeFin(lt, entry.month, d);
      final soldeFinSimule = soldeFinReel - extraDays;
      if (soldeFinSimule < 0) {
        return _LeaveConflict(month: entry.month, manque: -soldeFinSimule);
      }
    }
    return null;
  }

  String _fmt(double v) => v == v.roundToDouble()
      ? v.round().toString()
      : v.toStringAsFixed(2).replaceAll('.', ',');

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final n = ref.read(appProvider.notifier);
    final types = [...d.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));

    return ScreenScaffold(
      title: 'Congés',
      actions: [
        RoundIconButton(
          icon: Icons.settings_rounded,
          onTap: () => showSheet(context,
              title: 'Catégories de congés', child: _LeaveTypesManagerSheet()),
        ),
      ],
      pinned: MonthSwitcher(
        value: _month,
        min: d.startYm,
        now: now,
        onChanged: (v) {
          setState(() => _month = v);
          ref.read(leaveMonthProvider.notifier).state = v;
        },
      ),
      children: types.isEmpty
          ? [
              const SizedBox(height: 60),
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('🏖️', style: TextStyle(fontSize: 52)),
                  const SizedBox(height: 16),
                  const Text('Aucune catégorie',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                  const SizedBox(height: 8),
                  const Text(
                    'Ajoutez vos types de congés (CP, RTT…)\ndepuis l\'icône ⚙️ en haut à droite.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.muted, height: 1.5),
                  ),
                ]),
              ),
            ]
          : [
              // ── Alerte si un mois précédent a changé et impacte ici ──
              ..._buildPrevMonthAlerts(types, d, n),

              // ══════════════════════════════════════════════════
              // 1. CARTE SOLDE FIN DE MOIS (tout en haut)
              // ══════════════════════════════════════════════════
              _SoldeFinCard(
                types: types,
                soldeFin: (lt) => _soldeFin(lt, _month, d),
                fmt: _fmt,
              ),
              const SizedBox(height: 16),

              // ══════════════════════════════════════════════════
              // 2. SAISIE : combien je veux poser + répartition auto
              // ══════════════════════════════════════════════════
              _QuickDistributionCard(
                month: _month,
                types: types,
                d: d,
                maxTotal: _maxTotal(types, d),
                totalPose: _totalPose(types, d),
                maxPosable: (lt) => _maxPosable(lt, _month, d),
                fmt: _fmt,
                onDistribute: (totalDays) async {
                  // Vérifier si des mois futurs deviennent impossibles
                  final conflicts = n.checkTotalLeave(_month, totalDays);
                  if (conflicts.isNotEmpty) {
                    final ok = await _showConflictDialog(context, conflicts, totalDays, _fmt);
                    if (ok != true) return;
                  }
                  n.setTotalLeave(_month, totalDays);
                },
              ),
              const SizedBox(height: 16),

              // ══════════════════════════════════════════════════
              // 3. DÉTAIL PAR TYPE (réglage fin si besoin)
              // ══════════════════════════════════════════════════
              const SectionTitle('Répartition par type'),
              AppCard(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(children: [
                  for (final lt in types) ...[
                    _PoseTile(
                      lt: lt,
                      taken: _poses(lt, _month, d),
                      maxPosable: _maxPosable(lt, _month, d),
                      onConflictCheck: (extra) => _findConflict(lt, _month, extra, d),
                      soldeAvant: _soldeDebut(lt, _month, d),
                      accrual: lt.accrualPerMonth,
                      fmt: _fmt,
                      onChanged: (v) async {
                        // Calculer le nouveau total ce mois si on change ce type
                        final autresTypes = types.where((t) => t.id != lt.id);
                        final autresPoses = autresTypes.fold(0.0, (s, t) => s + _poses(t, _month, d));
                        final newTotal = autresPoses + v;

                        final conflicts = n.checkTotalLeave(_month, newTotal);
                        if (conflicts.isNotEmpty) {
                          final ok = await _showConflictDialog(context, conflicts, newTotal, _fmt);
                          if (ok != true) return;
                        }
                        n.setTotalLeave(_month, newTotal);
                      },
                    ),
                    if (lt != types.last) const Divider(height: 1, indent: 16),
                  ],
                ]),
              ),
            ],
    );
  }

  List<Widget> _buildPrevMonthAlerts(List<LeaveType> types, AppData d, AppNotifier n) {
    final alerts = <Widget>[];
    for (final lt in types) {
      final dispo = _disponible(lt, _month, d);
      final pose = _poses(lt, _month, d);
      if (pose > dispo && pose > 0) {
        final surplus = pose - dispo;
        alerts.add(Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          decoration: BoxDecoration(
            color: AppColors.warning.withAlpha(18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.warning.withAlpha(80)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.warning_amber_rounded, size: 16, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(
                '${lt.name} : tu poses ${_fmt(pose)} j mais seulement ${_fmt(dispo)} j sont disponibles ce mois.',
                style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700, fontSize: 13),
              )),
            ]),
            const SizedBox(height: 6),
            Text(
              'Un mois précédent a peut-être été modifié. Il manque ${_fmt(surplus)} j.',
              style: const TextStyle(color: AppColors.warning, fontSize: 12, height: 1.4),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => n.setLeaveEntry(lt.id, _month, dispo.floorToDouble()),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.warning),
                    foregroundColor: AppColors.warning,
                    minimumSize: const Size.fromHeight(36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text('Ajuster à ${_fmt(dispo.floorToDouble())} j'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => n.setLeaveEntry(lt.id, _month, 0),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.danger),
                    foregroundColor: AppColors.danger,
                    minimumSize: const Size.fromHeight(36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('Effacer'),
                ),
              ),
            ]),
          ]),
        ));
      }
    }
    return alerts;
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Carte SOLDE FIN DE MOIS — tout en haut, mise en avant
// ══════════════════════════════════════════════════════════════════════════════
class _SoldeFinCard extends StatelessWidget {
  final List<LeaveType> types;
  final double Function(LeaveType) soldeFin;
  final String Function(double) fmt;

  const _SoldeFinCard({
    required this.types,
    required this.soldeFin,
    required this.fmt,
  });

  @override
  Widget build(BuildContext context) {
    // Jours entiers seulement : 0,21 + 0,22 = 0 j (on ne peut pas additionner des fractions)
    final totalFin = types.fold(0, (s, lt) => s + soldeFin(lt).floor());
    final totalNeg = totalFin < 0;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── En-tête : total fin de mois ──────────────────────
        Row(children: [
          const Text('🏖️', style: TextStyle(fontSize: 20)),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('Solde fin du mois',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(
              '$totalFin j',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 26,
                color: totalNeg ? AppColors.danger : AppColors.violet,
              ),
            ),
            Text(
              'au total',
              style: TextStyle(
                fontSize: 11,
                color: AppColors.muted,
                fontWeight: FontWeight.w500,
              ),
            ),
          ]),
        ]),

        // ── Séparateur si plusieurs types ─────────────────────
        if (types.length > 1) ...[
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 10),
          // Détail par type
          for (final lt in types) ...[
            _SoldeFinRow(lt: lt, solde: soldeFin(lt), fmt: fmt),
            if (lt != types.last) const SizedBox(height: 8),
          ],
        ],
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Carte SAISIE RAPIDE — "je veux poser X jours" avec répartition auto
// ══════════════════════════════════════════════════════════════════════════════
class _QuickDistributionCard extends StatefulWidget {
  final Ym month;
  final List<LeaveType> types;
  final AppData d;
  final int maxTotal;
  final double totalPose;
  final int Function(LeaveType) maxPosable;
  final String Function(double) fmt;
  final void Function(double totalDays) onDistribute;

  const _QuickDistributionCard({
    required this.month,
    required this.types,
    required this.d,
    required this.maxTotal,
    required this.totalPose,
    required this.maxPosable,
    required this.fmt,
    required this.onDistribute,
  });

  @override
  State<_QuickDistributionCard> createState() => _QuickDistributionCardState();
}

class _QuickDistributionCardState extends State<_QuickDistributionCard> {
  final _ctrl = TextEditingController();
  final _focus = FocusNode();
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _cancel() {
    _ctrl.clear();
    setState(() => _error = null);
    _focus.unfocus();
  }

  void _distribute() {
    final text = _ctrl.text.trim();
    final total = int.tryParse(text);
    if (total == null || total < 0) {
      setState(() => _error = 'Entrez un nombre de jours valide');
      return;
    }
    if (total > widget.maxTotal) {
      setState(() => _error = 'Vous n\'avez que ${widget.maxTotal} j disponibles ce mois');
      return;
    }
    setState(() => _error = null);
    _focus.unfocus(); // ferme le clavier
    widget.onDistribute(total.toDouble());
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    final hasPose = widget.totalPose > 0;
    final maxTotal = widget.maxTotal;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Titre + total posé actuel ──────────────────────────
        Row(children: [
          const Text('✏️', style: TextStyle(fontSize: 16)),
          const SizedBox(width: 8),
          const Expanded(
            child: Text('Jours à poser ce mois',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
          if (hasPose)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.violet.withAlpha(20),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                '${widget.fmt(widget.totalPose)} j posés',
                style: const TextStyle(
                    color: AppColors.violet, fontWeight: FontWeight.w700, fontSize: 12),
              ),
            ),
        ]),
        const SizedBox(height: 4),
        // Sous-titre : maximum disponible
        Text(
          maxTotal > 0
              ? '$maxTotal j disponibles${widget.types.length > 1 ? ' au total' : ''}'
              : 'Aucun jour disponible ce mois',
          style: TextStyle(
            color: maxTotal > 0 ? AppColors.muted : AppColors.danger,
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 12),

        // ── Saisie ────────────────────────────────────────────
        TextField(
          controller: _ctrl,
          focusNode: _focus,
          keyboardType: TextInputType.number,
          textInputAction: TextInputAction.done,
          enabled: maxTotal > 0,
          onSubmitted: (_) => _distribute(),
          onChanged: (_) => setState(() => _error = null),
          decoration: InputDecoration(
            hintText: maxTotal > 0 ? 'Combien de jours ?' : '—',
            suffixText: maxTotal > 0 ? 'j' : null,
            errorText: _error,
          ),
        ),
        const SizedBox(height: 12),
        // ── Annuler / Enregistrer ──────────────────────────────
        Row(children: [
          Expanded(
            flex: 2,
            child: TextButton(
              onPressed: _cancel,
              style: TextButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                foregroundColor: Theme.of(context).colorScheme.onSurface,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            flex: 3,
            child: GradientButton(
              label: 'Enregistrer',
              onPressed: maxTotal > 0 ? _distribute : null,
            ),
          ),
        ]),

        // ── Info répartition si plusieurs types ───────────────
        if (widget.types.length > 1 && maxTotal > 0) ...[
          const SizedBox(height: 10),
          _PriorityHint(types: widget.types, maxPosable: widget.maxPosable),
        ],
      ]),
    );
  }
}

// ── Petit hint sur l'ordre de priorité ───────────────────────────────────────
class _PriorityHint extends StatelessWidget {
  final List<LeaveType> types;
  final int Function(LeaveType) maxPosable;
  const _PriorityHint({required this.types, required this.maxPosable});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        color: AppColors.violet.withAlpha(10),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.violet.withAlpha(30)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.info_outline_rounded, size: 14, color: AppColors.violet),
        const SizedBox(width: 8),
        Expanded(
          child: Wrap(
            spacing: 4,
            runSpacing: 2,
            children: [
              const Text(
                'Ordre de priorité : ',
                style: TextStyle(fontSize: 12, color: AppColors.muted),
              ),
              for (int i = 0; i < types.length; i++) ...[
                Row(mainAxisSize: MainAxisSize.min, children: [
                  CircleAvatar(radius: 5, backgroundColor: Color(types[i].colorValue)),
                  const SizedBox(width: 4),
                  Text(
                    '${types[i].name} (${maxPosable(types[i])} j max)',
                    style: TextStyle(
                        fontSize: 12,
                        color: AppColors.muted,
                        fontWeight: FontWeight.w600),
                  ),
                  if (i < types.length - 1)
                    const Text(' → ',
                        style: TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ],
            ],
          ),
        ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Modèle de conflit prospectif
// ══════════════════════════════════════════════════════════════════════════════
class _LeaveConflict {
  final Ym month;
  final double manque;
  const _LeaveConflict({required this.month, required this.manque});
}

// ══════════════════════════════════════════════════════════════════════════════
// Tile de pose par type (réglage fin)
// ══════════════════════════════════════════════════════════════════════════════
class _PoseTile extends StatefulWidget {
  final LeaveType lt;
  final double taken;
  final int maxPosable;
  final _LeaveConflict? Function(double extra) onConflictCheck;
  final double soldeAvant;
  final double accrual;
  final String Function(double) fmt;
  final ValueChanged<double> onChanged;
  const _PoseTile({
    required this.lt,
    required this.taken,
    required this.maxPosable,
    required this.onConflictCheck,
    required this.soldeAvant,
    required this.accrual,
    required this.fmt,
    required this.onChanged,
  });
  @override
  State<_PoseTile> createState() => _PoseTileState();
}

class _PoseTileState extends State<_PoseTile> {
  _LeaveConflict? _conflict;

  void _trySet(double newVal) {
    final capped = newVal.clamp(0.0, widget.maxPosable.toDouble());
    final extra = capped - widget.taken;
    if (extra > 0) {
      setState(() => _conflict = widget.onConflictCheck(extra));
    } else {
      setState(() => _conflict = null);
    }
    widget.onChanged(capped.toDouble());
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(widget.lt.colorValue);
    final taken = widget.taken;
    final max = widget.maxPosable;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 8, backgroundColor: color),
          const SizedBox(width: 10),
          Expanded(child: Text(widget.lt.name,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
          Text('Max : $max j',
              style: TextStyle(
                  color: max <= 0 ? AppColors.danger : AppColors.muted,
                  fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          _StepBtn(
            icon: Icons.remove_rounded,
            onTap: taken >= 1 ? () => _trySet(taken - 1) : null,
          ),
          const SizedBox(width: 8),
          Expanded(child: Column(children: [
            Text('${widget.fmt(taken)} j posés',
                style: TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 16,
                    color: taken > 0 ? color : AppColors.muted)),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: SizedBox(
                height: 8,
                child: Stack(children: [
                  Container(color: color.withAlpha(25)),
                  AnimatedFractionallySizedBox(
                    duration: const Duration(milliseconds: 200),
                    widthFactor: max <= 0 ? 0 : (taken / max).clamp(0.0, 1.0),
                    child: Container(color: color),
                  ),
                ]),
              ),
            ),
          ])),
          const SizedBox(width: 8),
          _StepBtn(
            icon: Icons.add_rounded,
            onTap: taken < max ? () => _trySet(taken + 1) : null,
          ),
        ]),

        if (_conflict != null)
          Container(
            margin: const EdgeInsets.only(top: 6),
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            decoration: BoxDecoration(
              color: AppColors.warning.withAlpha(18),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.warning.withAlpha(80)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.warning_amber_rounded, size: 15, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'Attention : en posant ces jours, il te manquera ${widget.fmt(_conflict!.manque)} j '
                'en ${_conflict!.month.longName} pour tes congés déjà planifiés.',
                style: const TextStyle(
                    color: AppColors.warning, fontSize: 12,
                    fontWeight: FontWeight.w600, height: 1.4),
              )),
            ]),
          ),
        if (max == 0)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(children: [
              const Icon(Icons.block_rounded, size: 13, color: AppColors.danger),
              const SizedBox(width: 4),
              const Expanded(child: Text('Solde insuffisant — impossible de poser des jours ce mois.',
                  style: TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600))),
            ]),
          ),
      ]),
    );
  }
}

class _StepBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _StepBtn({required this.icon, this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: onTap != null ? context.fieldColor : context.fieldColor.withAlpha(60),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18,
              color: onTap != null ? context.textColor : AppColors.muted),
        ),
      );
}

// ── Ligne solde fin ───────────────────────────────────────────────────────────
class _SoldeFinRow extends StatelessWidget {
  final LeaveType lt;
  final double solde;
  final String Function(double) fmt;
  const _SoldeFinRow({required this.lt, required this.solde, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final color = Color(lt.colorValue);
    final isNeg = solde < 0;
    return Row(children: [
      CircleAvatar(radius: 8, backgroundColor: color),
      const SizedBox(width: 10),
      Expanded(child: Text(lt.name,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
      if (isNeg)
        const Padding(
          padding: EdgeInsets.only(right: 6),
          child: Icon(Icons.warning_rounded, size: 15, color: AppColors.danger),
        ),
      Text('${fmt(solde)} j',
          style: TextStyle(
              fontWeight: FontWeight.w800, fontSize: 15,
              color: isNeg ? AppColors.danger : color)),
    ]);
  }
}

// ── Dialogue d'avertissement : mois futurs impactés ──────────────────────────
Future<bool?> _showConflictDialog(
  BuildContext context,
  List<LeaveConflict> conflicts,
  double totalDays,
  String Function(double) fmt,
) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Row(children: [
        const Text('⚠️', style: TextStyle(fontSize: 22)),
        const SizedBox(width: 10),
        const Expanded(
          child: Text('Congés futurs impactés',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        ),
      ]),
      content: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(
            'En posant ces ${fmt(totalDays)} jours, tu n\'auras plus assez de solde pour :',
            style: const TextStyle(fontSize: 14, height: 1.4),
          ),
          const SizedBox(height: 12),
          for (final c in conflicts) ...[
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                color: AppColors.warning.withAlpha(18),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.warning.withAlpha(60)),
              ),
              child: Row(children: [
                const Icon(Icons.beach_access_rounded, size: 18, color: AppColors.warning),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.month.longName,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  Text(
                    'Tu as prévu ${fmt(c.demande)} j — il n\'en restera que ${fmt(c.disponible)} j disponibles.',
                    style: const TextStyle(fontSize: 12.5, height: 1.3, color: AppColors.warning),
                  ),
                ])),
              ]),
            ),
          ],
          const SizedBox(height: 4),
          const Text(
            'Tu peux quand même confirmer — il faudra ajuster ces mois-là manuellement.',
            style: TextStyle(fontSize: 12.5, color: AppColors.muted, height: 1.4),
          ),
        ]),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
        FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.warning,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('Confirmer quand même', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// Sheet : gérer les catégories
// ══════════════════════════════════════════════════════════════════════════════

class _LeaveTypesManagerSheet extends ConsumerWidget {
  const _LeaveTypesManagerSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final types = [...ref.watch(appProvider).leaveTypes]
      ..sort((a, b) => a.priority.compareTo(b.priority));

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (types.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text('Aucune catégorie de congé. Commencez par en ajouter une.',
              style: TextStyle(color: AppColors.muted)),
        )
      else
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            for (final lt in types) ...[
              ListTile(
                leading: CircleAvatar(radius: 12, backgroundColor: Color(lt.colorValue)),
                title: Text(lt.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('+${lt.accrualPerMonth.toStringAsFixed(2).replaceAll('.', ',')} j/mois'),
                trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                onTap: () => showSheet(context,
                    title: 'Modifier ${lt.name}', child: _LeaveTypeSheet(existing: lt)),
              ),
              if (lt != types.last) const Divider(height: 1, indent: 16),
            ],
          ]),
        ),
      const SizedBox(height: 16),
      if (types.length > 1) ...[
        const SizedBox(height: 16),
        const Text('Ordre de priorité', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
          'Glissez pour définir quel type est utilisé en premier lors de la répartition automatique.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5),
        ),
        const SizedBox(height: 8),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: SizedBox(
            height: types.length * 56.0,
            child: ReorderableListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              onReorder: (oldIdx, newIdx) {
                if (newIdx > oldIdx) newIdx--;
                final reordered = [...types];
                final item = reordered.removeAt(oldIdx);
                reordered.insert(newIdx, item);
                ref.read(appProvider.notifier).reorderLeaveTypes([
                  for (int i = 0; i < reordered.length; i++)
                    reordered[i].copyWith(priority: i),
                ]);
              },
              children: [
                for (int i = 0; i < types.length; i++)
                  ListTile(
                    key: ValueKey(types[i].id),
                    dense: true,
                    leading: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${i + 1}', style: TextStyle(
                          color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
                      const SizedBox(width: 8),
                      CircleAvatar(radius: 10, backgroundColor: Color(types[i].colorValue)),
                    ]),
                    title: Text(types[i].name,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('+${types[i].accrualPerMonth.toStringAsFixed(2).replaceAll('.', ',')} j/mois',
                        style: const TextStyle(fontSize: 12)),
                    trailing: const Icon(Icons.drag_handle_rounded, color: AppColors.muted),
                  ),
              ],
            ),
          ),
        ),
      ],
      const SizedBox(height: 16),
      GradientButton(
        label: 'Ajouter une catégorie',
        onPressed: () => showSheet(context,
            title: 'Nouvelle catégorie', child: const _LeaveTypeSheet()),
      ),
    ]);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Sheet : créer / modifier un type
// ══════════════════════════════════════════════════════════════════════════════

class _LeaveTypeSheet extends ConsumerStatefulWidget {
  final LeaveType? existing;
  const _LeaveTypeSheet({super.key, this.existing});
  @override
  ConsumerState<_LeaveTypeSheet> createState() => _LeaveTypeSheetState();
}

class _LeaveTypeSheetState extends ConsumerState<_LeaveTypeSheet> {
  late final TextEditingController _name;
  late final TextEditingController _accrual;
  late final TextEditingController _initial;
  late int _color;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _accrual = TextEditingController(
        text: e == null ? '2,50' : e.accrualPerMonth.toStringAsFixed(2).replaceAll('.', ','));
    _initial = TextEditingController(
        text: e == null ? '0,00' : e.initialBalance.toStringAsFixed(2).replaceAll('.', ','));
    _color = e?.colorValue ?? AppColors.palette[0].value;
  }

  @override
  void dispose() {
    _name.dispose();
    _accrual.dispose();
    _initial.dispose();
    super.dispose();
  }

  void _save() {
    final accrual = double.tryParse(_accrual.text.replaceAll(',', '.'));
    final initial = double.tryParse(_initial.text.replaceAll(',', '.'));
    if (_name.text.trim().isEmpty || accrual == null) {
      snack(context, 'Nom et cumul mensuel requis');
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (widget.existing == null) {
      n.addLeaveType(_name.text.trim(), accrual, initial ?? 0, _color);
    } else {
      n.updateLeaveType(widget.existing!.copyWith(
        name: _name.text.trim(),
        accrualPerMonth: accrual,
        initialBalance: initial ?? 0,
        colorValue: _color,
      ));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
            color: color.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      TextField(
        controller: _name,
        textCapitalization: TextCapitalization.sentences,
        autofocus: true,
        decoration: const InputDecoration(
          labelText: 'Nom (ex. Congés payés, RTT)',
          prefixIcon: Icon(Icons.beach_access_rounded),
        ),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: TextField(
          controller: _accrual,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Cumul par mois', suffixText: 'j'),
        )),
        const SizedBox(width: 10),
        Expanded(child: TextField(
          controller: _initial,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Solde initial', suffixText: 'j'),
        )),
      ]),
      const SizedBox(height: 14),
      const Text('Couleur', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (int i = 0; i < AppColors.palette.length; i++)
          GestureDetector(
            onTap: () => setState(() => _color = AppColors.palette[i].value),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: AppColors.palette[i],
                shape: BoxShape.circle,
                border: _color == AppColors.palette[i].value
                    ? Border.all(color: context.textColor, width: 3)
                    : null,
              ),
            ),
          ),
      ]),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          flex: 2,
          child: TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
              foregroundColor: Theme.of(context).colorScheme.onSurface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 3,
          child: GradientButton(
            label: widget.existing == null ? 'Créer' : 'Enregistrer',
            onPressed: _save,
          ),
        ),
      ]),
      if (widget.existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer ${widget.existing!.name}',
          onPressed: () async {
            final ok = await showQuickDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('Supprimer ${widget.existing!.name} ?'),
                content: const Text('Toutes les poses associées seront aussi supprimées.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                  FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('Supprimer'),
                  ),
                ],
              ),
            );
            if (ok == true) {
              ref.read(appProvider.notifier).deleteLeaveType(widget.existing!.id);
              if (context.mounted) Navigator.pop(context);
            }
          },
        ),
      ],
    ]);
  }
}
