import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';

// ══════════════════════════════════════════════════════════════════════════════
// Écran Congés
// ══════════════════════════════════════════════════════════════════════════════

class LeaveScreen extends ConsumerStatefulWidget {
  const LeaveScreen({super.key});
  @override
  ConsumerState<LeaveScreen> createState() => _LeaveScreenState();
}

class _LeaveScreenState extends ConsumerState<LeaveScreen> {
  late Ym _month;

  @override
  void initState() {
    super.initState();
    _month = ref.read(nowProvider);
  }

  /// Solde à la fin du mois [ym] = soldeDebut(ym) + cumul(ym) - poses(ym).
  /// Le solde de début est soit une valeur manuelle saisie, soit calculé depuis le mois précédent.
  double _soldeFin(LeaveType lt, Ym ym, AppData d) {
    return _soldeDebut(lt, ym, d) + lt.accrualPerMonth - _poses(lt, ym, d);
  }

  /// Solde au début du mois [ym].
  /// Si une entrée manuelle existe pour ce mois, on l'utilise.
  /// Sinon : soldeFin(mois précédent).
  double _soldeDebut(LeaveType lt, Ym ym, AppData d) {
    // Chercher une override manuelle
    final manual = d.leaveEntries
        .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note == '__solde__')
        .firstOrNull;
    if (manual != null) return manual.days;
    // Sinon : soldeFin du mois précédent
    if (ym.index <= d.startYm.index) return lt.initialBalance;
    return _soldeFin(lt, ym.add(-1), d);
  }

  /// Jours posés pour un type dans un mois.
  double _poses(LeaveType lt, Ym ym, AppData d) => d.leaveEntries
      .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note != '__solde__')
      .fold(0.0, (s, e) => s + e.days);

  /// Solde disponible pour poser dans [ym] = soldeDebut + cumul du mois.
  double _disponible(LeaveType lt, Ym ym, AppData d) =>
      _soldeDebut(lt, ym, d) + lt.accrualPerMonth;

  /// Cherche le premier mois futur après [from] où poser [extraDays] supplémentaires
  /// dans [lt] rendrait le solde négatif à cause de poses déjà planifiées.
  /// Retourne null si aucun conflit.
  _LeaveConflict? _findConflict(LeaveType lt, Ym from, double extraDays, AppData d) {
    // Simuler le solde en ajoutant extraDays au mois [from]
    // puis vérifier chaque mois futur qui a des poses planifiées
    final futurePoses = d.leaveEntries
        .where((e) => e.leaveTypeId == lt.id && e.month.index > from.index && e.note != '__solde__')
        .toList();
    if (futurePoses.isEmpty) return null;

    // Calculer le solde simulé à chaque mois futur avec la pose supplémentaire
    for (final entry in futurePoses) {
      // Solde simulé à la fin du mois de la pose future
      // = soldeFin réel à ce mois - extraDays (car extraDays réduit le solde initial)
      final soldeFinReel = _soldeFin(lt, entry.month, d);
      final soldeFinSimule = soldeFinReel - extraDays;
      if (soldeFinSimule < 0) {
        return _LeaveConflict(
          month: entry.month,
          manque: -soldeFinSimule,
        );
      }
    }
    return null;
  }

  /// Maximum posable dans [ym] pour [lt] sans dépasser le solde disponible.
  /// Toujours un entier positif ou nul.
  int _maxPosable(LeaveType lt, Ym ym, AppData d) =>
      _disponible(lt, ym, d).floor().clamp(0, 999).toInt();

  String _fmt(double v) => v == v.roundToDouble()
      ? v.round().toString()
      : v.toStringAsFixed(2).replaceAll('.', ',');

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final n = ref.read(appProvider.notifier);
    final types = [...d.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));

    return ScreenScaffold(
      title: 'Congés',
      actions: [
        RoundIconButton(
          icon: Icons.settings_rounded,
          onTap: () => showSheet(context,
              title: 'Catégories de congés', child: _LeaveTypesManagerSheet()),
        ),
      ],
      pinned: MonthSwitcher(
        value: _month,
        min: d.startYm,
        now: now,
        onChanged: (v) => setState(() => _month = v),
      ),
      children: types.isEmpty
          ? [
              const SizedBox(height: 60),
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('🏖️', style: TextStyle(fontSize: 52)),
                  const SizedBox(height: 16),
                  const Text('Aucune catégorie',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                  const SizedBox(height: 8),
                  const Text(
                    'Ajoutez vos types de congés (CP, RTT…)\ndepuis l\'icône ⚙️ en haut à droite.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.muted, height: 1.5),
                  ),
                ]),
              ),
            ]
          : [
              // ── Alerte si un mois précédent a changé et impacte ici ──
              ..._buildPrevMonthAlerts(types, d, n),

              // ── 1. Solde début du mois (modifiable) ───────────
              const SectionTitle('Solde début du mois'),
              AppCard(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(children: [
                  for (final lt in types) ...[
                    ListTile(
                      leading: CircleAvatar(
                          radius: 10, backgroundColor: Color(lt.colorValue)),
                      title: Text(lt.name,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text('${_fmt(_soldeDebut(lt, _month, d))} j',
                            style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                                color: Color(lt.colorValue))),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => _editSoldeDebut(context, lt, d, n),
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: context.fieldColor,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.edit_rounded,
                                size: 15, color: AppColors.muted),
                          ),
                        ),
                      ]),
                    ),
                    if (lt != types.last) const Divider(height: 1, indent: 16),
                  ],
                ]),
              ),
              const SizedBox(height: 16),

              // ── 2. Poses ce mois ───────────────────────────────
              SectionTitle('Congés posés',
                trailing: _buildTotalPoseChip(types, d),
              ),
              // Saisie manuelle du total avec répartition auto
              _ManualDistributionTile(
                month: _month,
                types: types,
                d: d,
                soldeDebut: (lt) => _soldeDebut(lt, _month, d),
                maxPosable: (lt) => _maxPosable(lt, _month, d),
                onDistribute: (repartition) {
                  for (final e in repartition.entries) {
                    n.setLeaveEntry(e.key, _month, e.value.toDouble());
                  }
                },
              ),
              const SizedBox(height: 8),
              AppCard(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(children: [
                  for (final lt in types) ...[
                    _PoseTile(
                      lt: lt,
                      taken: _poses(lt, _month, d),
                      maxPosable: _maxPosable(lt, _month, d),
                      onConflictCheck: (extra) => _findConflict(lt, _month, extra, d),
                      soldeAvant: _soldeDebut(lt, _month, d),
                      accrual: lt.accrualPerMonth,
                      fmt: _fmt,
                      onChanged: (v) => n.setLeaveEntry(lt.id, _month, v),
                    ),
                    if (lt != types.last) const Divider(height: 1, indent: 16),
                  ],
                ]),
              ),
              // Total en bas
              _TotalPoseBar(types: types, d: d, month: _month, poses: _poses, fmt: _fmt),
              const SizedBox(height: 16),

              // ── 3. Solde fin du mois ───────────────────────────
              const SectionTitle('Solde fin du mois'),
              AppCard(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (final lt in types) ...[
                    _SoldeFinRow(
                      lt: lt,
                      solde: _soldeFin(lt, _month, d),
                      fmt: _fmt,
                    ),
                    if (lt != types.last) ...[
                      const SizedBox(height: 10),
                      const Divider(height: 1),
                      const SizedBox(height: 10),
                    ],
                  ],
                ]),
              ),
            ],
    );
  }

  /// Vérifie si des poses dans ce mois dépassent le solde disponible
  /// (ce qui peut arriver si un mois précédent a été modifié).
  List<Widget> _buildPrevMonthAlerts(List<LeaveType> types, AppData d, AppNotifier n) {
    final alerts = <Widget>[];
    for (final lt in types) {
      final dispo = _disponible(lt, _month, d);
      final pose = _poses(lt, _month, d);
      if (pose > dispo && pose > 0) {
        final surplus = pose - dispo;
        alerts.add(Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          decoration: BoxDecoration(
            color: AppColors.warning.withAlpha(18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.warning.withAlpha(80)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.warning_amber_rounded, size: 16, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(
                '${lt.name} : tu poses ${_fmt(pose)} j mais seulement ${_fmt(dispo)} j sont disponibles ce mois.',
                style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700, fontSize: 13),
              )),
            ]),
            const SizedBox(height: 6),
            Text(
              'Un mois précédent a peut-être été modifié. Il manque ${_fmt(surplus)} j.',
              style: const TextStyle(color: AppColors.warning, fontSize: 12, height: 1.4),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => n.setLeaveEntry(lt.id, _month, dispo.floorToDouble()),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.warning),
                    foregroundColor: AppColors.warning,
                    minimumSize: const Size.fromHeight(36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text('Ajuster à ${_fmt(dispo.floorToDouble())} j'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => n.setLeaveEntry(lt.id, _month, 0),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.danger),
                    foregroundColor: AppColors.danger,
                    minimumSize: const Size.fromHeight(36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('Effacer'),
                ),
              ),
            ]),
          ]),
        ));
      }
    }
    return alerts;
  }

  Widget _buildTotalPoseChip(List<LeaveType> types, AppData d) {
    final total = types.fold(0.0, (s, lt) => s + _poses(lt, _month, d));
    if (total == 0) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.violet.withAlpha(20),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text('Total : ${_fmt(total)} j',
          style: const TextStyle(color: AppColors.violet, fontWeight: FontWeight.w700, fontSize: 12)),
    );
  }

  Future<void> _editSoldeDebut(BuildContext context, LeaveType lt, AppData d, AppNotifier n) async {
    final current = _soldeDebut(lt, _month, d);
    final ctrl = TextEditingController(text: _fmt(current));
    final ok = await showQuickDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Solde début — ${lt.name}'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(suffixText: 'j'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('OK')),
        ],
      ),
    );
    if (ok == true) {
      final v = double.tryParse(ctrl.text.replaceAll(',', '.'));
      if (v != null) n.setLeaveEntry(lt.id, _month, v, note: '__solde__');
    }
    ctrl.dispose();
  }
}

// ── Tile de pose avec curseur ─────────────────────────────────────────────────
// ── Saisie manuelle du total avec répartition automatique ────────────────────
class _ManualDistributionTile extends StatefulWidget {
  final Ym month;
  final List<LeaveType> types;
  final AppData d;
  final double Function(LeaveType) soldeDebut;
  final int Function(LeaveType) maxPosable;
  final void Function(Map<String, double>) onDistribute;
  const _ManualDistributionTile({
    required this.month,
    required this.types,
    required this.d,
    required this.soldeDebut,
    required this.maxPosable,
    required this.onDistribute,
  });
  @override
  State<_ManualDistributionTile> createState() => _ManualDistributionTileState();
}

class _ManualDistributionTileState extends State<_ManualDistributionTile> {
  final _ctrl = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _distribute() {
    final total = int.tryParse(_ctrl.text.trim());
    if (total == null || total <= 0) {
      setState(() => _error = 'Entrez un nombre entier valide');
      return;
    }
    final totalDispo = widget.types.fold(0, (s, lt) => s + widget.maxPosable(lt));
    if (total > totalDispo) {
      setState(() => _error = 'Maximum disponible : $totalDispo j');
      return;
    }
    setState(() => _error = null);
    // Répartition par priorité
    final result = <String, double>{};
    int remaining = total;
    for (final lt in widget.types) {
      if (remaining <= 0) break;
      final dispo = widget.maxPosable(lt);
      final pose = remaining.clamp(0, dispo);
      if (pose > 0) {
        result[lt.id] = pose.toDouble();
        remaining -= pose;
      }
    }
    widget.onDistribute(result);
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: TextField(
              controller: _ctrl,
              keyboardType: TextInputType.number,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _distribute(),
              decoration: InputDecoration(
                hintText: 'Max : ${widget.types.fold(0, (s, lt) => s + widget.maxPosable(lt))} j',
                suffixText: 'j',
                errorText: _error,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            height: 50,
            child: GradientButton(
              label: 'Répartir',
              onPressed: _distribute,
            ),
          ),
        ]),
      );
}

// ── Barre de total en bas ─────────────────────────────────────────────────────
class _TotalPoseBar extends StatelessWidget {
  final List<LeaveType> types;
  final AppData d;
  final Ym month;
  final double Function(LeaveType, Ym, AppData) poses;
  final String Function(double) fmt;
  const _TotalPoseBar({
    required this.types,
    required this.d,
    required this.month,
    required this.poses,
    required this.fmt,
  });

  @override
  Widget build(BuildContext context) {
    final total = types.fold(0.0, (s, lt) => s + poses(lt, month, d));
    if (total == 0) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: BoxDecoration(
        color: AppColors.violet.withAlpha(15),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.violet.withAlpha(40)),
      ),
      child: Row(children: [
        const Icon(Icons.wb_sunny_rounded, size: 18, color: AppColors.violet),
        const SizedBox(width: 10),
        const Text('Total posé ce mois',
            style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.violet)),
        const Spacer(),
        Text('${fmt(total)} j',
            style: const TextStyle(
                fontWeight: FontWeight.w900, fontSize: 20, color: AppColors.violet)),
      ]),
    );
  }
}

// ── Modèle de conflit prospectif ─────────────────────────────────────────────
class _LeaveConflict {
  final Ym month;
  final double manque;
  const _LeaveConflict({required this.month, required this.manque});
}

// ── Tile de pose avec plafond strict et alerte prospective ────────────────────
class _PoseTile extends StatefulWidget {
  final LeaveType lt;
  final double taken;
  final int maxPosable;
  final _LeaveConflict? Function(double extra) onConflictCheck;
  final double soldeAvant;
  final double accrual;
  final String Function(double) fmt;
  final ValueChanged<double> onChanged;
  const _PoseTile({
    required this.lt,
    required this.taken,
    required this.maxPosable,
    required this.onConflictCheck,
    required this.soldeAvant,
    required this.accrual,
    required this.fmt,
    required this.onChanged,
  });
  @override
  State<_PoseTile> createState() => _PoseTileState();
}

class _PoseTileState extends State<_PoseTile> {
  _LeaveConflict? _conflict;

  void _trySet(double newVal) {
    final capped = newVal.clamp(0.0, widget.maxPosable.toDouble());
    final extra = capped - widget.taken;
    if (extra > 0) {
      setState(() => _conflict = widget.onConflictCheck(extra));
    } else {
      setState(() => _conflict = null);
    }
    widget.onChanged(capped.toDouble());
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(widget.lt.colorValue);
    final taken = widget.taken;
    final max = widget.maxPosable;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 8, backgroundColor: color),
          const SizedBox(width: 10),
          Expanded(child: Text(widget.lt.name,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
          Text('Max : $max j',
              style: TextStyle(
                  color: max <= 0 ? AppColors.danger : AppColors.muted,
                  fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          _StepBtn(
            icon: Icons.remove_rounded,
            onTap: taken >= 1 ? () => _trySet(taken - 1) : null,
          ),
          const SizedBox(width: 8),
          Expanded(child: Column(children: [
            Text('${widget.fmt(taken)} j posés',
                style: TextStyle(
                    fontWeight: FontWeight.w900, fontSize: 16,
                    color: taken > 0 ? color : AppColors.muted)),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: SizedBox(
                height: 8,
                child: Stack(children: [
                  Container(color: color.withAlpha(25)),
                  AnimatedFractionallySizedBox(
                    duration: const Duration(milliseconds: 200),
                    widthFactor: max <= 0 ? 0 : (taken / max).clamp(0.0, 1.0),
                    child: Container(color: color),
                  ),
                ]),
              ),
            ),
          ])),
          const SizedBox(width: 8),
          _StepBtn(
            icon: Icons.add_rounded,
            onTap: taken < max ? () => _trySet(taken + 1) : null,
          ),
        ]),
        if (max > 0 && max <= 30)
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
              activeTrackColor: color,
              thumbColor: color,
              inactiveTrackColor: color.withAlpha(30),
            ),
            child: Slider(
              value: taken.clamp(0, max.toDouble()),
              min: 0,
              max: max.toDouble(),
              divisions: max,
              onChanged: (v) => _trySet(v.round().toDouble()),
            ),
          ),
        // ── Alerte prospective ──────────────────────────────────
        if (_conflict != null)
          Container(
            margin: const EdgeInsets.only(top: 6),
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            decoration: BoxDecoration(
              color: AppColors.warning.withAlpha(18),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.warning.withAlpha(80)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.warning_amber_rounded, size: 15, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'Attention : en posant ces jours, il te manquera ${widget.fmt(_conflict!.manque)} j '
                'en ${_conflict!.month.longName} pour tes congés déjà planifiés.',
                style: const TextStyle(
                    color: AppColors.warning, fontSize: 12,
                    fontWeight: FontWeight.w600, height: 1.4),
              )),
            ]),
          ),
        // ── Solde nul ──────────────────────────────────────────
        if (max == 0)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(children: [
              const Icon(Icons.block_rounded, size: 13, color: AppColors.danger),
              const SizedBox(width: 4),
              const Expanded(child: Text('Solde insuffisant — impossible de poser des jours ce mois.',
                  style: TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600))),
            ]),
          ),
      ]),
    );
  }
}

class _StepBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _StepBtn({required this.icon, this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: onTap != null ? context.fieldColor : context.fieldColor.withAlpha(60),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18,
              color: onTap != null ? context.textColor : AppColors.muted),
        ),
      );
}

// ── Ligne solde fin ───────────────────────────────────────────────────────────
class _SoldeFinRow extends StatelessWidget {
  final LeaveType lt;
  final double solde;
  final String Function(double) fmt;
  const _SoldeFinRow({required this.lt, required this.solde, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final color = Color(lt.colorValue);
    final isNeg = solde < 0;
    return Row(children: [
      CircleAvatar(radius: 8, backgroundColor: color),
      const SizedBox(width: 10),
      Expanded(child: Text(lt.name,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
      if (isNeg)
        const Padding(
          padding: EdgeInsets.only(right: 6),
          child: Icon(Icons.warning_rounded, size: 15, color: AppColors.danger),
        ),
      Text('${fmt(solde)} j',
          style: TextStyle(
              fontWeight: FontWeight.w900, fontSize: 18,
              color: isNeg ? AppColors.danger : color)),
    ]);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Sheet : gérer les catégories (liste + ajout + modif + suppression)
// ══════════════════════════════════════════════════════════════════════════════

class _LeaveTypesManagerSheet extends ConsumerWidget {
  const _LeaveTypesManagerSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final types = [...ref.watch(appProvider).leaveTypes]
      ..sort((a, b) => a.priority.compareTo(b.priority));

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (types.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text('Aucune catégorie de congé. Commencez par en ajouter une.',
              style: TextStyle(color: AppColors.muted)),
        )
      else
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            for (final lt in types) ...[
              ListTile(
                leading: CircleAvatar(radius: 12, backgroundColor: Color(lt.colorValue)),
                title: Text(lt.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('+${lt.accrualPerMonth.toStringAsFixed(2).replaceAll('.', ',')} j/mois'),
                trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                onTap: () => showSheet(context,
                    title: 'Modifier ${lt.name}', child: _LeaveTypeSheet(existing: lt)),
              ),
              if (lt != types.last) const Divider(height: 1, indent: 16),
            ],
          ]),
        ),
      const SizedBox(height: 16),
      if (types.length > 1) ...[
        const SizedBox(height: 16),
        const Text('Ordre de priorité', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
          'Glissez pour définir quel type est utilisé en premier lors de la répartition automatique.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5),
        ),
        const SizedBox(height: 8),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: SizedBox(
            height: types.length * 56.0,
            child: ReorderableListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              onReorder: (oldIdx, newIdx) {
                if (newIdx > oldIdx) newIdx--;
                final reordered = [...types];
                final item = reordered.removeAt(oldIdx);
                reordered.insert(newIdx, item);
                ref.read(appProvider.notifier).reorderLeaveTypes([
                  for (int i = 0; i < reordered.length; i++)
                    reordered[i].copyWith(priority: i),
                ]);
              },
              children: [
                for (int i = 0; i < types.length; i++)
                  ListTile(
                    key: ValueKey(types[i].id),
                    dense: true,
                    leading: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${i + 1}', style: TextStyle(
                          color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
                      const SizedBox(width: 8),
                      CircleAvatar(radius: 10, backgroundColor: Color(types[i].colorValue)),
                    ]),
                    title: Text(types[i].name,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('+${types[i].accrualPerMonth.toStringAsFixed(2).replaceAll('.', ',')} j/mois',
                        style: const TextStyle(fontSize: 12)),
                    trailing: const Icon(Icons.drag_handle_rounded, color: AppColors.muted),
                  ),
              ],
            ),
          ),
        ),
      ],
      const SizedBox(height: 16),
      GradientButton(
        label: 'Ajouter une catégorie',
        onPressed: () => showSheet(context,
            title: 'Nouvelle catégorie', child: const _LeaveTypeSheet()),
      ),
    ]);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Sheet : créer / modifier un type
// ══════════════════════════════════════════════════════════════════════════════

class _LeaveTypeSheet extends ConsumerStatefulWidget {
  final LeaveType? existing;
  const _LeaveTypeSheet({super.key, this.existing});
  @override
  ConsumerState<_LeaveTypeSheet> createState() => _LeaveTypeSheetState();
}

class _LeaveTypeSheetState extends ConsumerState<_LeaveTypeSheet> {
  late final TextEditingController _name;
  late final TextEditingController _accrual;
  late final TextEditingController _initial;
  late int _color;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _accrual = TextEditingController(
        text: e == null ? '2,50' : e.accrualPerMonth.toStringAsFixed(2).replaceAll('.', ','));
    _initial = TextEditingController(
        text: e == null ? '0,00' : e.initialBalance.toStringAsFixed(2).replaceAll('.', ','));
    _color = e?.colorValue ?? AppColors.palette[0].value;
  }

  @override
  void dispose() {
    _name.dispose();
    _accrual.dispose();
    _initial.dispose();
    super.dispose();
  }

  void _save() {
    final accrual = double.tryParse(_accrual.text.replaceAll(',', '.'));
    final initial = double.tryParse(_initial.text.replaceAll(',', '.'));
    if (_name.text.trim().isEmpty || accrual == null) {
      snack(context, 'Renseignez un nom et un cumul mensuel');
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (widget.existing == null) {
      n.addLeaveType(_name.text.trim(), accrual, initial ?? 0, _color);
    } else {
      n.updateLeaveType(widget.existing!.copyWith(
        name: _name.text.trim(),
        accrualPerMonth: accrual,
        initialBalance: initial ?? 0,
        colorValue: _color,
      ));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
            color: color.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      TextField(
        controller: _name,
        textCapitalization: TextCapitalization.sentences,
        autofocus: true,
        decoration: const InputDecoration(
          labelText: 'Nom (ex. Congés payés, RTT)',
          prefixIcon: Icon(Icons.beach_access_rounded),
        ),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: TextField(
          controller: _accrual,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Cumul par mois', suffixText: 'j'),
        )),
        const SizedBox(width: 10),
        Expanded(child: TextField(
          controller: _initial,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Solde initial', suffixText: 'j'),
        )),
      ]),
      const SizedBox(height: 14),
      const Text('Couleur', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (int i = 0; i < AppColors.palette.length; i++)
          GestureDetector(
            onTap: () => setState(() => _color = AppColors.palette[i].value),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: AppColors.palette[i],
                shape: BoxShape.circle,
                border: _color == AppColors.palette[i].value
                    ? Border.all(color: context.textColor, width: 3)
                    : null,
              ),
            ),
          ),
      ]),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          flex: 2,
          child: OutlinedButton(
            onPressed: () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 3,
          child: GradientButton(
            label: widget.existing == null ? 'Créer' : 'Enregistrer',
            onPressed: _save,
          ),
        ),
      ]),
      if (widget.existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer ${widget.existing!.name}',
          onPressed: () async {
            final ok = await showQuickDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('Supprimer ${widget.existing!.name} ?'),
                content: const Text('Toutes les poses associées seront aussi supprimées.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                  FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('Supprimer'),
                  ),
                ],
              ),
            );
            if (ok == true) {
              ref.read(appProvider.notifier).deleteLeaveType(widget.existing!.id);
              if (context.mounted) Navigator.pop(context);
            }
          },
        ),
      ],
    ]);
  }
}
