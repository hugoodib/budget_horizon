import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/close_month.dart';
import '../widgets/total_budget.dart';
import '../widgets/trip_cards.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

class BudgetsScreen extends ConsumerStatefulWidget {
  const BudgetsScreen({super.key});
  @override
  ConsumerState<BudgetsScreen> createState() => _BudgetsScreenState();
}

class _BudgetsScreenState extends ConsumerState<BudgetsScreen> {
  @override
  void initState() {
    super.initState();
    // À chaque ouverture de l'onglet : revenir sur le mois actuel.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(budgetMonthProvider.notifier).state = ref.read(nowProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final ym = ref.watch(budgetMonthProvider);
    final planned = d.plannedIn(ym);
    final spent = d.spentIn(ym);
    final txs = d.transactionsIn(ym);
    final cats = d.categories.where((c) => d.budgets.any((b) => b.categoryId == c.id)).toList();

    return ScreenScaffold(
      title: 'Budgets',
      actions: [
        RoundIconButton(
          icon: Icons.add_rounded,
          onTap: () => showSheet(context, title: 'Nouvelle catégorie', child: const AddCategorySheet()),
        ),
      ],
      children: [
        Row(children: [
          _Chevron(
            icon: Icons.chevron_left_rounded,
            onTap: ym.index <= d.startYm.index
                ? null
                : () => ref.read(budgetMonthProvider.notifier).state = ym.add(-1),
          ),
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () async {
                final y = await pickYm(context, ym);
                if (y != null) ref.read(budgetMonthProvider.notifier).state = y;
              },
              child: Text('${ym.label} · ${eur(spent)} sur ${eur(planned)}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.muted, fontSize: 14)),
            ),
          ),
          _Chevron(
            icon: Icons.chevron_right_rounded,
            onTap: () => ref.read(budgetMonthProvider.notifier).state = ym.add(1),
          ),
          _Chevron(
            icon: Icons.today_rounded,
            onTap: ym == now ? null : () => ref.read(budgetMonthProvider.notifier).state = now,
          ),
          MonthCalendarButton(value: ym, onChanged: (v) => ref.read(budgetMonthProvider.notifier).state = v),
        ]),
        TotalBudgetCard(month: ym),
        const SizedBox(height: 12),
        UnexpectedCard(month: ym),
        const SizedBox(height: 12),
        for (final p in d.projects.where((p) => p.targetYm == ym)) ...[
          TripBudgetCard(project: p, month: ym),
          const SizedBox(height: 12),
        ],
        if (d.isCouple)
          _CoupleBudgets(month: ym, cats: cats)
        else
          for (final c in cats) ...[
            for (final b in d.budgets.where((b) => b.categoryId == c.id))
              _BudgetCard(budget: b, category: c, month: ym),
            const SizedBox(height: 10),
          ],
        const SizedBox(height: 6),
        GradientButton(
          key: TourKeys.addExpense,
          label: 'Ajouter une dépense',
          icon: Icons.add_rounded,
          onPressed: () => showSheet(context, title: 'Nouvelle dépense', child: AddExpenseSheet(month: ym)),
        ),
        SectionTitle('Dépenses de ${ym.longName}',
            trailing: txs.isEmpty
                ? null
                : Text('${txs.where((t) => t.checked).length}/${txs.length} pointées',
                    style: const TextStyle(color: AppColors.muted, fontSize: 13))),
        if (txs.isEmpty)
          const AppCard(child: Text('Aucune dépense ce mois-ci.', style: TextStyle(color: AppColors.muted)))
        else
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(children: [
              for (final t in txs)
                Dismissible(
                  key: ValueKey(t.id),
                  direction: DismissDirection.endToStart,
                  background: Container(
                    color: AppColors.danger,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete_rounded, color: Colors.white),
                  ),
                  onDismissed: (_) => ref.read(appProvider.notifier).deleteTransaction(t.id),
                  child: _TxTile(
                    tx: t,
                    cat: d.category(t.categoryId),
                    who: d.isCouple ? d.personName(t.person) : '',
                    tripName: t.tripId == null
                        ? null
                        : d.projects.where((p) => p.id == t.tripId).firstOrNull?.name,
                    onCheck: () => ref.read(appProvider.notifier).toggleTransactionChecked(t.id)),
                ),
            ]),
          ),
        const SizedBox(height: 12),
        CloseMonthCard(key: TourKeys.closeMonth, month: ym),
      ],
    );
  }
}

class _Chevron extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _Chevron({required this.icon, this.onTap});
  @override
  Widget build(BuildContext context) => IconButton(
        onPressed: onTap,
        icon: Icon(icon, color: onTap == null ? AppColors.track : AppColors.muted),
      );
}

Future<void> _confirmDeleteCategory(BuildContext context, WidgetRef ref, Category c) async {
  final ok = await showQuickDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text('Supprimer « ${c.name} » ?'),
      content: const Text('Le budget est supprimé pour tous les mois. Les dépenses déjà saisies restent comptées.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
      ],
    ),
  );
  if (ok == true) ref.read(appProvider.notifier).removeBudget(c.id);
}

Color _statusColor(AppData d, Ym month, double planned, double spent) {
  final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
  final overColor = d.spentIn(month) > d.plannedIn(month) ? AppColors.danger : AppColors.warning;
  return ratio >= 1 ? overColor : (ratio >= .8 ? AppColors.warning : AppColors.teal);
}

/// Carte pleine largeur (mode solo).
class _BudgetCard extends ConsumerWidget {
  final Budget budget;
  final Category category;
  final Ym month;
  const _BudgetCard({required this.budget, required this.category, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final planned = budget.amountIn(month);
    final spent = d.spentForBudget(budget, month);
    final remaining = planned - spent;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = _statusColor(d, month, planned, spent);
    return AppCard(
      padding: const EdgeInsets.fromLTRB(18, 14, 8, 16),
      onTap: () => showSheet(context,
          title: 'Budget ${category.name}',
          child: EditBudgetSheet(budgetId: budget.id, month: month)),
      child: Column(children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleEmoji(category.emoji, Color(category.colorValue)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(category.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              const SizedBox(height: 4),
              Text('${eur(spent)} utilisé · ${eur(planned)} prévu',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
              if (budget.hasOverride(month))
                const Padding(
                  padding: EdgeInsets.only(top: 3),
                  child: Text('Modifié pour ce mois',
                      style: TextStyle(color: AppColors.violet, fontWeight: FontWeight.w600, fontSize: 12.5)),
                ),
            ]),
          ),
          Text(eur(remaining),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: remaining >= 0 ? AppColors.teal : color)),
          IconButton(
            visualDensity: VisualDensity.compact,
            onPressed: () => _confirmDeleteCategory(context, ref, category),
            icon: const Icon(Icons.delete_outline_rounded, color: AppColors.muted),
          ),
        ]),
        const SizedBox(height: 12),
        Padding(padding: const EdgeInsets.only(right: 8), child: AppProgress(value: ratio, color: color)),
      ]),
    );
  }
}

/// Mode couple : deux colonnes, une par conjoint, alignées par catégorie.
class _CoupleBudgets extends ConsumerWidget {
  final Ym month;
  final List<Category> cats;
  const _CoupleBudgets({required this.month, required this.cats});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);

    Widget header(int p) {
      final bs = d.budgets.where((b) => b.person == p).toList();
      final planned = bs.fold(0.0, (s, b) => s + b.amountIn(month));
      final spent = bs.fold(0.0, (s, b) => s + d.spentForBudget(b, month));
      return AppCard(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(children: [
          PersonAvatar(person: p, size: 32),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(d.personName(p),
                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text('${eur(spent)} / ${eur(planned)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12)),
            ]),
          ),
        ]),
      );
    }

    Widget half(Category c, int p) {
      final b = d.budgets.where((b) => b.categoryId == c.id && b.person == p).firstOrNull;
      if (b == null) return const SizedBox.shrink();
      final planned = b.amountIn(month);
      final spent = d.spentForBudget(b, month);
      final remaining = planned - spent;
      final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
      final color = _statusColor(d, month, planned, spent);
      return AppCard(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
        onTap: () => showSheet(context,
            title: 'Budget ${c.name} · ${d.personName(p)}',
            child: EditBudgetSheet(budgetId: b.id, month: month)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(eur(remaining),
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: remaining >= 0 ? AppColors.teal : color)),
          ),
          const SizedBox(height: 2),
          Text('${eur(spent)} / ${eur(planned)}',
              style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          if (b.hasOverride(month))
            const Text('Modifié ce mois', style: TextStyle(color: AppColors.violet, fontSize: 11.5, fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          AppProgress(value: ratio, color: color),
        ]),
      );
    }

    bool separate(Category c) => d.budgets.any((b) => b.categoryId == c.id && b.person != 0);
    final shared = cats.where((c) => !separate(c)).toList();
    final split = cats.where(separate).toList();
    final mixed = shared.isNotEmpty && split.isNotEmpty;
    return Column(children: [
      // Budgets communs
      if (mixed)
        const Padding(
          padding: EdgeInsets.fromLTRB(6, 0, 6, 10),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Communs', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ),
      for (final c in shared) ...[
        for (final b in d.budgets.where((b) => b.categoryId == c.id))
          _BudgetCard(budget: b, category: c, month: month),
        const SizedBox(height: 10),
      ],
      // Budgets individuels : photos au-dessus des deux colonnes
      if (split.isNotEmpty) ...[
        if (mixed) const Divider(height: 26),
        Padding(
          padding: const EdgeInsets.fromLTRB(6, 0, 6, 10),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Séparés', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ),
        Row(children: [
          Expanded(child: header(1)),
          const SizedBox(width: 12),
          Expanded(child: header(2)),
        ]),
        const SizedBox(height: 8),
        for (final c in split) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 8, 0, 6),
            child: Row(children: [
              Expanded(
                  child: Text('${c.emoji}  ${c.name}',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
              IconButton(
                visualDensity: VisualDensity.compact,
                onPressed: () => _confirmDeleteCategory(context, ref, c),
                icon: const Icon(Icons.delete_outline_rounded, size: 20, color: AppColors.muted),
              ),
            ]),
          ),
          IntrinsicHeight(
            child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Expanded(child: half(c, 1)),
              const SizedBox(width: 12),
              Expanded(child: half(c, 2)),
            ]),
          ),
        ],
      ],
    ]);
  }
}

class _TxTile extends StatelessWidget {
  final Transaction tx;
  final Category? cat;
  final String who;
  final String? tripName;
  final VoidCallback onCheck;
  const _TxTile(
      {required this.tx, required this.cat, required this.who, this.tripName, required this.onCheck});

  @override
  Widget build(BuildContext context) => ListTile(
        tileColor: Colors.transparent,
        leading: CircleEmoji(cat?.emoji ?? '💶', Color(cat?.colorValue ?? AppColors.blue.value)),
        title: Text(tx.description, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
            '${tripName != null ? 'Voyage · $tripName' : (cat?.name ?? '')}${who.isEmpty ? '' : ' · $who'} · ${tx.date.day.toString().padLeft(2, '0')}/${tx.date.month.toString().padLeft(2, '0')}'),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          Text('−${eur(tx.amount)}', style: const TextStyle(fontWeight: FontWeight.w800)),
          CheckCircle(checked: tx.checked, onTap: onCheck),
        ]),
      );
}

class _ClosedSummary extends StatelessWidget {
  final MonthSnapshot snapshot;
  const _ClosedSummary({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    final s = snapshot.savings;
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        child: Row(children: [
          Icon(s >= 0 ? Icons.savings_rounded : Icons.warning_amber_rounded,
              color: s >= 0 ? AppColors.success : AppColors.danger),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              s >= 0
                  ? 'Prévu ${eur(snapshot.planned)} · Dépensé ${eur(snapshot.spent)}\nÉconomie de ${eur(s)} ajoutée au solde du mois suivant.'
                  : 'Prévu ${eur(snapshot.planned)} · Dépensé ${eur(snapshot.spent)}\nDépassement de ${eur(-s)} déduit du mois suivant.',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ]),
      ),
    );
  }
}
