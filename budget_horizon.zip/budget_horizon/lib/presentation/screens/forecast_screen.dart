import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';
import '../widgets/tips.dart';

/// Onglet « Prévisions » : combien aurez-vous à la fin de n'importe quel mois ?
class ForecastScreen extends ConsumerStatefulWidget {
  const ForecastScreen({super.key});
  @override
  ConsumerState<ForecastScreen> createState() => _ForecastScreenState();
}

class _ForecastScreenState extends ConsumerState<ForecastScreen> {
  static const _yearsAhead = 60;
  late Ym _sel = ref.read(nowProvider);
  late int _year = _sel.year;
  int _trendYears = 1;
  final _yearsCtl = ScrollController();
  static const _chipW = 78.0, _chipGap = 8.0;

  @override
  void dispose() {
    _yearsCtl.dispose();
    super.dispose();
  }

  /// Place l'année actuelle tout à gauche de la bande des années.
  void _scrollYearsToNow({bool animate = false}) {
    if (!_yearsCtl.hasClients) return;
    final d = ref.read(appProvider);
    final now = ref.read(nowProvider);
    final idx = max(0, now.year - d.startYm.year);
    final target = (idx * (_chipW + _chipGap)).clamp(0.0, _yearsCtl.position.maxScrollExtent);
    if (animate) {
      _yearsCtl.animateTo(target, duration: const Duration(milliseconds: 350), curve: Curves.easeOutCubic);
    } else {
      _yearsCtl.jumpTo(target);
    }
  }

  @override
  void initState() {
    super.initState();
    // « Année par année » s'ouvre d'office sur l'année actuelle, vers la droite :
    // on peut ensuite se déplacer librement, sans que ça saute ailleurs.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      setState(() => _year = ref.read(nowProvider).year);
      _scrollYearsToNow();
    });
  }

  void _select(Ym y) {
    var v = y;
    final start = ref.read(appProvider).startYm;
    if (v.isBefore(start)) v = start;
    setState(() {
      _sel = v;
      _year = v.year;
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final firstYear = d.startYm.year;
    final lastYear = max(now.year + _yearsAhead, _sel.year);
    if (_year < firstYear) _year = firstYear;

    final toIdx = max(_sel.index, Ym(_year, 12).index);
    final devMode = ref.watch(devModeProvider);
    final fc = Forecaster.compute(d, now: now, to: Ym.fromIndex(toIdx), devMode: devMode);
    final sel = fc.at(_sel);
    final curF = fc.at(now);
    final current = curF == null ? 0.0 : Forecaster.currentBalance(d, curF, devMode: devMode);
    final months = [for (var m = 1; m <= 12; m++) fc.at(Ym(_year, m))].whereType<MonthForecast>().toList();

    final quick = <(String, Ym)>[
      ('Fin d\'année', Ym(now.year, 12)),
      ('+3 mois', now.add(3)),
      ('+6 mois', now.add(6)),
      ('+1 an', now.add(12)),
      ('+2 ans', now.add(24)),
      ('+5 ans', now.add(60)),
      ('+10 ans', now.add(120)),
    ];

    return ScreenScaffold(
      title: 'Prévisions',
      children: [
        // ---- Explorateur : le solde de fin de n'importe quel mois ----
        AppCard(
          key: TourKeys.forecastPicker,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => _select(now),
              child: Row(children: [
                const Expanded(
                  child: Text('Solde fin du mois',
                      style: TextStyle(
                          color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
                ),
                const Icon(Icons.replay_rounded, size: 16, color: AppColors.muted),
              ]),
            ),
            const SizedBox(height: 10),
            Row(children: [
              IconButton(
                onPressed: _sel.index <= d.startYm.index ? null : () => runWithHint(context, Hint.forecastMonth, () => _select(_sel.add(-1))),
                icon: const Icon(Icons.chevron_left_rounded),
              ),
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => runWithHint(context, Hint.forecastMonth, () async {
                    final y = await pickYm(context, _sel);
                    if (y != null) _select(y);
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(16)),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.calendar_month_rounded, size: 19, color: AppColors.violet),
                      const SizedBox(width: 8),
                      Text(_sel.label, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: context.textColor)),
                      const Icon(Icons.arrow_drop_down_rounded, color: AppColors.muted),
                    ]),
                  ),
                ),
              ),
              IconButton(
                onPressed: () => runWithHint(context, Hint.forecastMonth, () => _select(_sel.add(1))),
                icon: const Icon(Icons.chevron_right_rounded),
              ),
            ]),
            const SizedBox(height: 10),
            PillSelector<Ym>.scroll(
              hint: Hint.forecastMonth,
              items: [for (final q in quick) PillItem(q.$2, q.$1)],
              selected: _sel,
              onChanged: _select,
              fontSize: 12.5,
            ),
            const SizedBox(height: 14),
            if (sel == null)
              const Text('Aucune donnée disponible pour ce mois.', style: TextStyle(color: AppColors.muted))
            else ...[
              Text('Fin ${_sel.longName.toLowerCase()} ${_sel.year}',
                  style: const TextStyle(
                      color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(eur(sel.endBalance),
                    style: TextStyle(
                        fontSize: 42,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -1.2,
                        color: sel.endBalance < 0 ? AppColors.danger : context.textColor)),
              ),
              const SizedBox(height: 4),
              Text(
                '${sel.endBalance - current >= 0 ? '+${eur(sel.endBalance - current)}' : '-${eur(current - sel.endBalance)}'} vs aujourd\'hui (${eur(current)})'
                '${_sel.index > now.index ? ' · dans ${_sel.index - now.index} mois' : ''}',
                style: TextStyle(
                    color: sel.endBalance - current >= 0 ? AppColors.success : AppColors.pink,
                    fontWeight: FontWeight.w600,
                    fontSize: 13.5),
              ),
              const SizedBox(height: 12),
              _line('Solde de départ', eur(sel.startBalance)),
              _line('Revenus du mois', eur(sel.income, sign: true), color: AppColors.success),
              _line('Charges fixes', eur(-sel.fixed)),
              _line('Dépenses courantes', eur(-sel.budgets)),
              // Un ligne par projet, avec son vrai nom (voyage, voiture, apport…)
              for (final l in sel.lines.where((l) => l.kind == LineKind.project))
                _line(l.label, eur(l.amount)),
              if (sel.unexpected > 0) _line('Dépenses imprévues', eur(-sel.unexpected)),
            ],
          ]),
        ),
        // ---- Tendance : 1, 5, 10 ou 20 ans ----
        const SectionTitle('Évolution du solde', tip: 'forecast1'),
        AppCard(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            PillSelector<int>.row(
              hint: Hint.forecastHorizon,
              items: const [
                PillItem(1,  '1 an'),
                PillItem(5,  '5 ans'),
                PillItem(10, '10 ans'),
                PillItem(20, '20 ans'),
              ],
              selected: _trendYears,
              onChanged: (y) => setState(() => _trendYears = y),
            ),
            const SizedBox(height: 14),
            Builder(builder: (_) {
              final trendTo = now.add(_trendYears * 12);
              final trendFc = Forecaster.compute(d, now: now, to: trendTo, devMode: devMode);
              final trendMonths =
                  [for (var i = 0; i <= _trendYears * 12; i++) trendFc.at(now.add(i))].whereType<MonthForecast>().toList();
              if (trendMonths.isEmpty) return const SizedBox.shrink();
              final start = trendMonths.first.startBalance;
              final end = trendMonths.last.endBalance;
              final tDelta = end - start;
              final tColor = tDelta < 0 ? AppColors.pink : AppColors.success;
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Dans ${_trendYears == 1 ? '1 an' : '$_trendYears ans'} (${trendMonths.last.ym.label}) : ${eur(end)}',
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                const SizedBox(height: 2),
                Text('${eur(tDelta, sign: true)} par rapport à aujourd\'hui',
                    style: TextStyle(color: tColor, fontWeight: FontWeight.w600, fontSize: 13.5)),
                const SizedBox(height: 12),
                SizedBox(
                  height: 130,
                  child: LineChart(LineChartData(
                    gridData: const FlGridData(show: false),
                    borderData: FlBorderData(show: false),
                    titlesData: FlTitlesData(
                      leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 22,
                          interval: max(1, (trendMonths.length / 6).roundToDouble()),
                          getTitlesWidget: (v, meta) {
                            final i = v.toInt();
                            if (i < 0 || i >= trendMonths.length) return const SizedBox.shrink();
                            return SideTitleWidget(
                              axisSide: meta.axisSide,
                              child: Text(trendMonths[i].ym.short,
                                  style: const TextStyle(fontSize: 9.5, color: AppColors.muted)),
                            );
                          },
                        ),
                      ),
                    ),
                    lineTouchData: LineTouchData(
                      touchTooltipData: LineTouchTooltipData(
                        getTooltipItems: (spots) => [
                          for (final s in spots)
                            LineTooltipItem(eur(s.y), const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                    lineBarsData: [
                      LineChartBarData(
                        spots: [for (var i = 0; i < trendMonths.length; i++) FlSpot(i.toDouble(), trendMonths[i].endBalance)],
                        isCurved: true,
                        barWidth: 4,
                        gradient: brandGradient,
                        dotData: FlDotData(
                          show: true,
                          getDotPainter: (spot, percent, bar, index) =>
                              FlDotCirclePainter(radius: 3.5, color: AppColors.violet, strokeWidth: 1.5, strokeColor: Colors.white),
                        ),
                      ),
                    ],
                  )),
                ),
              ]);
            }),
          ]),
        ),
        // ---- Année par année ----
        SectionTitle('Vue par année', tip: 'forecastYear',
            trailing: TextButton.icon(
              onPressed: () {
                setState(() => _year = now.year);
                _scrollYearsToNow(animate: true);
              },
              icon: const Icon(Icons.today_rounded, size: 17),
              label: const Text('Cette année'),
            )),
        SizedBox(
          height: 46,
          child: ListView.separated(
            controller: _yearsCtl,
            scrollDirection: Axis.horizontal,
            itemCount: lastYear - firstYear + 1,
            separatorBuilder: (_, __) => const SizedBox(width: _chipGap),
            itemBuilder: (_, i) {
              final y = firstYear + i;
              // Largeur fixe : on peut calculer exactement où se trouve l'année actuelle.
              return SizedBox(
                width: _chipW,
                child: GestureDetector(
                  onTap: () => setState(() => _year = y),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: y == _year ? AppColors.violet.withAlpha(28) : Colors.transparent,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: y == _year ? AppColors.violet.withAlpha(140) : Colors.transparent,
                        width: 1.5,
                      ),
                    ),
                    child: Text('$y',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: y == _year ? FontWeight.w800 : FontWeight.w500,
                          color: y == _year ? AppColors.violet : null,
                        )),
                  ),
                ));
            },
          ),
        ),
        const SizedBox(height: 12),
        if (months.isEmpty)
          const AppCard(child: Text('Les prévisions apparaissent une fois vos revenus et charges saisis.', style: TextStyle(height: 1.4)))
        else ...[
          _YearSummary(year: _year, months: months),
          const SectionTitle('Fin de chaque mois', tip: 'forecast2'),
          for (final f in months) ...[
            _MonthCard(
              f: f,
              isCurrent: f.ym == now,
              selected: f.ym == _sel,
              onSelect: () {
                _select(f.ym);
                // remonte pour voir le résultat
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  final c = TourKeys.forecastPicker.currentContext;
                  if (c != null) Scrollable.ensureVisible(c, duration: Duration.zero, alignment: 0.0);
                });
              },
            ),
            const SizedBox(height: 10),
          ],
        ],
      ],
    );
  }

  Widget _line(String label, String value, {Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 14))),
          Text(value, style: TextStyle(fontWeight: FontWeight.w700, color: color, fontSize: 14)),
        ]),
      );
}

class _YearSummary extends StatelessWidget {
  final int year;
  final List<MonthForecast> months;
  const _YearSummary({required this.year, required this.months});

  @override
  Widget build(BuildContext context) {
    final start = months.first.startBalance;
    final end = months.last.endBalance;
    final income = months.fold(0.0, (s, f) => s + f.income);
    final out = months.fold(0.0, (s, f) => s + f.fixed + f.budgets + f.projects);
    final delta = end - start;
    final color = delta < 0 ? AppColors.pink : AppColors.success;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Solde prévu · fin ${months.last.ym.longName} $year',
            style: const TextStyle(
                color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
        const SizedBox(height: 6),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(eurDec(end),
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -1)),
        ),
        const SizedBox(height: 4),
        Text('${eur(delta, sign: true)} sur l\'année',
            style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 15)),
        const SizedBox(height: 12),
        SizedBox(
          height: 90,
          child: LineChart(LineChartData(
            gridData: const FlGridData(show: false),
            borderData: FlBorderData(show: false),
            titlesData: const FlTitlesData(show: false),
            lineTouchData: const LineTouchData(enabled: false),
            lineBarsData: [
              LineChartBarData(
                spots: [for (var i = 0; i < months.length; i++) FlSpot(i.toDouble(), months[i].endBalance)],
                isCurved: true,
                barWidth: 4,
                gradient: brandGradient,
                dotData: const FlDotData(show: false),
              ),
            ],
          )),
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _mini('Revenus', eur(income))),
          Expanded(child: _mini('Sorties', eur(out))),
        ]),
      ]),
    );
  }

  Widget _mini(String label, String value) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
      ]);
}

class _MonthCard extends ConsumerStatefulWidget {
  final MonthForecast f;
  final bool isCurrent;
  final bool selected;
  final VoidCallback onSelect;
  const _MonthCard({required this.f, required this.isCurrent, required this.selected, required this.onSelect});

  @override
  ConsumerState<_MonthCard> createState() => _MonthCardState();
}

class _MonthCardState extends ConsumerState<_MonthCard> {
  bool _open = false;

  Widget _row(String label, String value, {Color? color, bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 14))),
          Text(value, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w700, color: color, fontSize: 14)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final f = widget.f;
    final delta = f.endBalance - f.startBalance;
    final incomeLines = f.lines.where((l) => l.kind == LineKind.income).toList();
    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(children: [
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() => _open = !_open),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(f.ym.longName, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    if (widget.isCurrent) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration:
                            BoxDecoration(color: tint(AppColors.teal, .2), borderRadius: BorderRadius.circular(10)),
                        child: const Text('En cours',
                            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.success)),
                      ),
                    ],
                    if (widget.selected) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration:
                            BoxDecoration(color: tint(AppColors.violet, .2), borderRadius: BorderRadius.circular(10)),
                        child: const Text('Affiché en haut',
                            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.violet)),
                      ),
                    ],
                  ]),
                  const SizedBox(height: 2),
                  Text('${eur(delta, sign: true)} ce mois',
                      style: TextStyle(
                          color: delta >= 0 ? AppColors.success : AppColors.pink,
                          fontWeight: FontWeight.w600,
                          fontSize: 12.5)),
                ]),
              ),
              Text(eur(f.endBalance),
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 15,
                      color: f.endBalance < 0 ? AppColors.danger : context.textColor)),
              const SizedBox(width: 4),
              Icon(_open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: AppColors.muted),
            ]),
          ),
        ),
        if (_open)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _row('Solde de départ', eur(f.startBalance)),
              _row('Revenus', eur(f.income, sign: true), color: AppColors.success),
              _row('Charges fixes', eur(-f.fixed)),
              _row('Budgets & dépenses', eur(-f.budgets)),
              for (final l in f.lines.where((l) => l.kind == LineKind.project))
                _row(l.label, eur(l.amount)),
              if (f.unexpected > 0) _row('Imprévus', eur(-f.unexpected)),
              const Divider(),
              _row('Solde fin de mois', eur(f.endBalance), bold: true),
              const SizedBox(height: 8),
              SoftButton(
                icon: Icons.vertical_align_top_rounded,
                hint: Hint.forecastTop,
                label: 'Afficher ce mois en haut',
                onPressed: widget.onSelect,
              ),
              const SizedBox(height: 10),
              const Text('Revenus', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
              for (final l in incomeLines)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: l.recurringId == null
                      ? null
                      : () => showSheet(context,
                          title: 'Modifier ${l.label} · ${f.ym.longName}',
                          child: RecurringOverrideSheet(month: f.ym, recurringId: l.recurringId!)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(l.label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                          if (l.note != null)
                            Text(l.note!, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                        ]),
                      ),
                      Text(eur(l.amount, sign: true),
                          style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.success, fontSize: 14)),
                      if (l.recurringId != null)
                        const Padding(
                          padding: EdgeInsets.only(left: 6),
                          child: Icon(Icons.edit_rounded, size: 15, color: AppColors.muted),
                        ),
                      if (l.refId != null)
                        GestureDetector(
                          onTap: () => ref.read(appProvider.notifier).removeIncome(l.refId!),
                          child: const Padding(
                            padding: EdgeInsets.only(left: 8),
                            child: Icon(Icons.close_rounded, size: 18, color: AppColors.muted),
                          ),
                        ),
                    ]),
                  ),
                ),
              if (incomeLines.any((l) => l.recurringId != null))
                const Padding(
                  padding: EdgeInsets.only(bottom: 6),
                  child: Text('Touchez un revenu pour l\'ajuster ce mois-ci.',
                      style: TextStyle(color: AppColors.muted, fontSize: 12)),
                ),
              const SizedBox(height: 4),
              SoftButton(
                icon: Icons.add_card_rounded,
                hint: Hint.forecastIncome,
                label: 'Ajouter un revenu',
                onPressed: () => showSheet(context, title: 'Nouveau revenu', child: AddIncomeSheet(month: f.ym)),
              ),
            ]),
          ),
      ]),
    );
  }
}
