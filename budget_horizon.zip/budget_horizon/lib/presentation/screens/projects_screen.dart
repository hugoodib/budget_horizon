import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

/// Onglet « Voyages » : chaque voyage a un budget qui s'applique le mois du voyage.
class ProjectsScreen extends ConsumerWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    // Un voyage disparaît de la liste une fois son mois clôturé (il reste dans l'historique
    // et les calculs, mais n'encombre plus l'onglet).
    final sorted = [...d.projects.where((p) => !d.isClosed(p.targetYm))]
      ..sort((a, b) => a.targetYm.compareTo(b.targetYm));
    return ScreenScaffold(
      title: 'Voyages',
      actions: [
        IconButton.filledTonal(
          key: TourKeys.addProject,
          onPressed: () => showSheet(context, title: 'Nouveau voyage', child: const AddProjectSheet()),
          icon: const Icon(Icons.add_rounded),
        ),
      ],
      children: [
        if (sorted.isEmpty)
          AppCard(
            child: Text(
                d.projects.isEmpty
                    ? 'Aucun voyage. Touchez + pour en créer un.'
                    : 'Aucun voyage à venir. Les voyages passés disparaissent une fois leur mois clôturé.',
                style: const TextStyle(height: 1.35)),
          ),
        for (final p in sorted) ...[
          _TripCard(project: p, now: now),
          const SizedBox(height: 14),
        ],
      ],
    );
  }
}

class _TripCard extends ConsumerStatefulWidget {
  final Project project;
  final Ym now;
  const _TripCard({required this.project, required this.now});

  @override
  ConsumerState<_TripCard> createState() => _TripCardState();
}

class _TripCardState extends ConsumerState<_TripCard> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final p = widget.project;
    final now = widget.now;
    final tx = d.transactions.where((t) => t.tripId == p.id).toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    final spent = tx.where((t) => Ym.of(t.date) == p.targetYm).fold(0.0, (s, t) => s + t.amount);
    final over = spent > p.target;
    final ratio = p.target <= 0 ? 0.0 : spent / p.target;
    final diff = p.targetYm.index - now.index;
    final when = diff < 0 ? 'terminé' : (diff == 0 ? 'ce mois-ci' : 'dans $diff mois');
    final monthForecast = ref.watch(forecastProvider).at(p.targetYm);
    final endBalance = monthForecast?.endBalance;
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleEmoji('✈️', Color(0xFF0A84FF)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
              Text(
                  p.tripStart != null && p.tripEnd != null
                      ? 'Du ${_fd(p.tripStart!)} au ${_fd(p.tripEnd!)} · $when'
                      : '${p.targetYm.label} · $when',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13)),
            ]),
          ),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'edit') {
                showSheet(context, title: 'Modifier ${p.name}', child: AddProjectSheet(existing: p));
                return;
              }
              final ok = await showQuickDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text('Supprimer « ${p.name} » ?'),
                  content: const Text('Le voyage et toutes ses dépenses seront supprimés.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                    FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
                  ],
                ),
              );
              if (ok == true) ref.read(appProvider.notifier).removeProject(p.id);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('Modifier')),
              PopupMenuItem(value: 'del', child: Text('Supprimer')),
            ],
          ),
        ]),
        if (endBalance != null) ...[
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: endBalance < 0 ? tint(AppColors.danger, .12) : AppColors.field,
              borderRadius: BorderRadius.circular(16),
              border: endBalance < 0 ? Border.all(color: tint(AppColors.danger, .4)) : null,
            ),
            child: Row(children: [
              Icon(endBalance < 0 ? Icons.warning_amber_rounded : Icons.event_available_rounded,
                  size: 20, color: endBalance < 0 ? AppColors.danger : AppColors.muted),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Solde prévu fin ${p.targetYm.longName.toLowerCase()}',
                      style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                  Text(eur(endBalance),
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 17,
                          color: endBalance < 0 ? AppColors.danger : AppColors.text)),
                  if (endBalance < 0)
                    const Text('Solde négatif ce mois-là avec ce voyage.',
                        style: TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              ),
            ]),
          ),
        ],
        const SizedBox(height: 14),
        // ---- Budget du voyage ----
        Row(children: [
          Text(eur(spent), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          Text(' / ${eur(p.target)}', style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
          const Spacer(),
          Text(over ? 'Dépassé de ${eur(spent - p.target)}' : 'Reste ${eur(p.target - spent)}',
              style: TextStyle(fontWeight: FontWeight.w700, color: over ? AppColors.danger : AppColors.teal)),
        ]),
        const SizedBox(height: 10),
        AppProgress(value: ratio, color: over ? AppColors.danger : AppColors.teal),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: GradientButton(
            label: 'Ajouter une dépense de voyage',
            icon: Icons.add_rounded,
            onPressed: () => showSheet(context,
                title: 'Dépense · ${p.name}',
                child: AddExpenseSheet(month: p.targetYm, initialTripId: p.id)),
          ),
        ),
        // ---- Détails : masqués par défaut, touchez pour développer ----
        const SizedBox(height: 10),
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() => _open = !_open),
          child: Row(children: [
            const Expanded(
              child: Text('Détails', style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.muted, fontSize: 13.5)),
            ),
            Icon(_open ? Icons.expand_less_rounded : Icons.expand_more_rounded, color: AppColors.muted),
          ]),
        ),
        if (_open) ...[
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: AppColors.field, borderRadius: BorderRadius.circular(16)),
            child: Text(
              p.isExpense
                  ? 'Le budget de ${eur(p.target)} est réservé en ${p.targetYm.longName.toLowerCase()}. Notez ici les dépenses du voyage.'
                  : 'Vous mettez ${eur(p.monthlyPlan)} de côté chaque mois jusqu\'au voyage.',
              style: const TextStyle(fontSize: 13, height: 1.35, fontWeight: FontWeight.w500),
            ),
          ),
          // Passages clients retirés pendant l'absence (auto-entrepreneur)
          if (d.hasAE && p.tripStart != null && p.tripEnd != null)
            Builder(builder: (_) {
              final only = d.copyWith(projects: [p]);
              var lost = 0.0;
              var count = 0;
              for (var i = Ym.of(p.tripStart!).index; i <= Ym.of(p.tripEnd!).index; i++) {
                for (final v in only.invoicesIssuedIn(Ym.fromIndex(i))) {
                  lost += v.absentVisits * v.client.amount;
                  count += v.absentVisits;
                }
              }
              if (count == 0) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(
                    'Pendant ce voyage, $count passage${count > 1 ? 's' : ''} de vos clients ${count > 1 ? 'sont retirés' : 'est retiré'} : −${eur(d.netFromGross(lost))} de salaire net.',
                    style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
              );
            }),
          // ---- Épargne mensuelle (mode « épargner avant ») ----
          if (!p.isExpense && p.targetYm.isAfter(now)) ...[
            const SizedBox(height: 12),
            _SavingsBlock(project: p, now: now),
          ],
          // ---- Dépenses du voyage ----
          if (tx.isNotEmpty) ...[
            const SizedBox(height: 14),
            const Text('Dépenses du voyage', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            for (final t in tx)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(t.description, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      Text('${t.date.day.toString().padLeft(2, '0')}/${t.date.month.toString().padLeft(2, '0')}/${t.date.year}',
                          style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    ]),
                  ),
                  Text('−${eur(t.amount)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  CheckCircle(
                      checked: t.checked,
                      onTap: () => ref.read(appProvider.notifier).toggleTransactionChecked(t.id)),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: () => ref.read(appProvider.notifier).deleteTransaction(t.id),
                    icon: const Icon(Icons.close_rounded, size: 18, color: AppColors.muted),
                  ),
                ]),
              ),
          ],
        ],
      ]),
    );
  }
}

/// Épargne mensuelle avant le voyage (comportement « Épargner avant »).
class _SavingsBlock extends ConsumerWidget {
  final Project project;
  final Ym now;
  const _SavingsBlock({required this.project, required this.now});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = project;
    final done = p.contributions.containsKey(now.key);
    final left = p.monthsLeft(now);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text('Épargne : ${eur(p.saved)} / ${eur(p.target)}',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const Spacer(),
        Text('${(p.progress * 100).round()} %',
            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.violet)),
      ]),
      const SizedBox(height: 8),
      AppProgress(value: p.progress, color: AppColors.violet),
      const SizedBox(height: 6),
      Text('${eur(p.monthlyPlan)} à mettre de côté chaque mois · $left mois restant${left > 1 ? 's' : ''}',
          style: const TextStyle(color: AppColors.muted, fontSize: 13)),
      const SizedBox(height: 10),
      SizedBox(
        width: double.infinity,
        child: done
            ? SoftButton(
                icon: Icons.check_circle_rounded,
                label: 'Versement du mois effectué · Annuler',
                onPressed: () => ref.read(appProvider.notifier).toggleContribution(p.id))
            : SoftButton(
                icon: Icons.savings_rounded,
                label: 'Marquer le versement du mois',
                onPressed: p.saved >= p.target ? null : () => ref.read(appProvider.notifier).toggleContribution(p.id)),
      ),
    ]);
  }
}


String _fd(DateTime x) =>
    '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}/${x.year}';
