import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

class ProjectsScreen extends ConsumerWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final sorted = [...d.projects.where((p) => !d.isClosed(p.targetYm))]
      ..sort((a, b) => a.targetYm.compareTo(b.targetYm));

    return ScreenScaffold(
      title: 'Projets',
      actions: [
        IconButton.filledTonal(
          key: TourKeys.addProject,
          onPressed: () => showSheet(context, title: 'Nouveau projet', child: const AddProjectSheet()),
          icon: const Icon(Icons.add_rounded),
        ),
      ],
      children: [
        if (sorted.isEmpty)
          AppCard(
            child: Text(
                d.projects.isEmpty
                    ? 'Aucun projet. Touchez + pour créer un voyage ou un projet d\'épargne.'
                    : 'Aucun projet à venir.',
                style: const TextStyle(height: 1.35)),
          ),
        for (final p in sorted) ...[ 
          _ProjectCard(project: p, now: now),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
}

// ══════════════════════════════════════════════════════════════════════
// Carte projet — tap → sheet modale
// ══════════════════════════════════════════════════════════════════════
class _ProjectCard extends ConsumerWidget {
  final Project project;
  final Ym now;
  const _ProjectCard({required this.project, required this.now});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final p = project;
    final tx = d.transactions.where((t) => t.tripId == p.id).toList()
      ..sort((a, b) { final c = b.date.compareTo(a.date); return c != 0 ? c : b.id.compareTo(a.id); });
    final spent = tx.fold(0.0, (s, t) => s + t.amount);
    final over  = spent > p.target;
    final ratio = p.target <= 0 ? 0.0 : (spent / p.target).clamp(0.0, 1.0);
    final diff  = p.targetYm.index - now.index;
    final accent = p.isTrip ? const Color(0xFF0A84FF) : AppColors.teal;
    final statusColor = over ? AppColors.danger : (ratio > .8 ? AppColors.warning : accent);

    void openDetail() {
      HapticFeedback.mediumImpact();
      showSheet(context,
        title: '',
        child: _ProjectDetailSheet(project: p, now: now),
      );
    }

    Future<void> doDelete() async {
      final ok = await showQuickDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Supprimer « ${p.name} » ?'),
          content: const Text('Le projet et toutes ses dépenses seront supprimés.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Supprimer')),
          ],
        ),
      );
      if (ok == true && context.mounted) ref.read(appProvider.notifier).removeProject(p.id);
    }

    return Dismissible(
      key: ValueKey('proj_${p.id}'),
      direction: DismissDirection.endToStart,
      confirmDismiss: (_) async { await doDelete(); return false; },
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: AppColors.danger.withAlpha(200),
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.delete_outline_rounded, color: Colors.white, size: 28),
          SizedBox(height: 4),
          Text('Supprimer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ),
      child: GestureDetector(
        onTap: openDetail,
        child: Container(
          decoration: BoxDecoration(
            color: tint(accent, .08),
            borderRadius: BorderRadius.circular(20),
          ),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // ── Ligne principale ──────────────────────────────
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Emoji
              Container(
                width: 50, height: 50,
                decoration: BoxDecoration(color: tint(accent, .18), shape: BoxShape.circle),
                child: Center(child: Text(p.emoji, style: const TextStyle(fontSize: 26))),
              ),
              const SizedBox(width: 14),
              // Nom + date
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  const SizedBox(height: 3),
                  Row(children: [
                    Icon(p.isTrip ? Icons.flight_rounded : Icons.savings_rounded,
                        size: 13, color: context.mutedColor),
                    const SizedBox(width: 4),
                    Text(
                      diff < 0 ? 'Terminé' : (diff == 0 ? 'Ce mois-ci ✨' : 'dans $diff mois'),
                      style: TextStyle(
                        fontSize: 12.5, fontWeight: FontWeight.w600,
                        color: diff == 0 ? accent : context.mutedColor,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text('· ${p.targetYm.label}',
                        style: TextStyle(fontSize: 12, color: context.mutedColor)),
                  ]),
                ]),
              ),
              // Budget + menu
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(eur(p.target),
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18,
                        color: over ? AppColors.danger : context.textColor)),
                Text(over ? 'dépassé' : 'budget',
                    style: TextStyle(fontSize: 11.5, color: context.mutedColor)),
              ]),
              PopupMenuButton<String>(
                padding: EdgeInsets.zero,
                iconSize: 20,
                icon: Icon(Icons.more_vert_rounded, color: context.mutedColor, size: 20),
                onSelected: (v) async {
                  if (v == 'edit') showSheet(context, title: 'Modifier ${p.name}', child: AddProjectSheet(existing: p));
                  else if (v == 'del') await doDelete();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'edit', child: Text('Modifier')),
                  PopupMenuItem(value: 'del', child: Text('Supprimer')),
                ],
              ),
            ]),
            const SizedBox(height: 14),
            // ── Barre de progression ──────────────────────────
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: ratio,
                minHeight: 8,
                backgroundColor: context.trackColor,
                valueColor: AlwaysStoppedAnimation(statusColor),
              ),
            ),
            const SizedBox(height: 8),
            Builder(builder: (_) {
              var f = ref.watch(forecastProvider).at(p.targetYm);
              // Au-delà des 24 mois déjà calculés : on prolonge la prévision jusqu'au mois du projet.
              if (f == null && p.targetYm.isAfter(now) && p.targetYm.index - now.index <= 600) {
                f = Forecaster
                    .compute(d, now: now, to: p.targetYm, devMode: ref.watch(devModeProvider))
                    .at(p.targetYm);
              }
              final end = f?.endBalance;
              if (end == null) return const SizedBox.shrink();
              final neg = end < 0;
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: neg ? tint(AppColors.danger, .12) : tint(accent, .12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(children: [
                  Icon(neg ? Icons.warning_amber_rounded : Icons.account_balance_wallet_rounded,
                      size: 16, color: neg ? AppColors.danger : accent),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text('Il restera à la fin de ${p.targetYm.longName.toLowerCase()}',
                        style: TextStyle(fontSize: 12.5, color: context.mutedColor)),
                  ),
                  Text(eur(end),
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14.5,
                          color: neg ? AppColors.danger : context.textColor)),
                ]),
              );
            }),
            Row(children: [
              Text(
                spent > 0 ? '${eur(spent)} dépensés' : 'Aucune dépense',
                style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: statusColor),
              ),
              const Spacer(),
              // "Voir détails" discret
              Row(mainAxisSize: MainAxisSize.min, children: [
                Text('Voir détails',
                    style: TextStyle(fontSize: 12, color: accent, fontWeight: FontWeight.w600)),
                const SizedBox(width: 3),
                Icon(Icons.arrow_forward_ios_rounded, size: 11, color: accent),
              ]),
            ]),
          ]),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════
// Sheet de détail — s'ouvre en modal bottom sheet
// ══════════════════════════════════════════════════════════════════════
class _ProjectDetailSheet extends ConsumerWidget {
  final Project project;
  final Ym now;
  const _ProjectDetailSheet({required this.project, required this.now});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d  = ref.watch(appProvider);
    final p  = project;
    final tx = d.transactions.where((t) => t.tripId == p.id).toList()
      ..sort((a, b) { final c = b.date.compareTo(a.date); return c != 0 ? c : b.id.compareTo(a.id); });
    final spent = tx.fold(0.0, (s, t) => s + t.amount);
    final over  = spent > p.target;
    final ratio = p.target <= 0 ? 0.0 : (spent / p.target).clamp(0.0, 1.0);
    final diff  = p.targetYm.index - now.index;
    final accent = p.isTrip ? const Color(0xFF0A84FF) : AppColors.teal;
    final statusColor = over ? AppColors.danger : (ratio > .8 ? AppColors.warning : accent);
    final endYm = p.tripEnd != null ? Ym.of(p.tripEnd!) : p.targetYm;
    final dateRange = endYm != p.targetYm
        ? '${p.targetYm.longName} → ${endYm.longName}'
        : p.targetYm.longName;
    final monthForecast = ref.watch(forecastProvider).at(p.targetYm);
    final endBalance = monthForecast?.endBalance;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── En-tête de la sheet ───────────────────────────────────
      Row(children: [
        Container(
          width: 54, height: 54,
          decoration: BoxDecoration(color: tint(accent, .18), shape: BoxShape.circle),
          child: Center(child: Text(p.emoji, style: const TextStyle(fontSize: 28))),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(p.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
          const SizedBox(height: 3),
          Row(children: [
            Icon(p.isTrip ? Icons.flight_rounded : Icons.savings_rounded,
                size: 13, color: context.mutedColor),
            const SizedBox(width: 5),
            Text('$dateRange',
                style: TextStyle(fontSize: 13, color: context.mutedColor, fontWeight: FontWeight.w500)),
            if (diff >= 0) ...[ 
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: tint(accent, .15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  diff == 0 ? 'Ce mois-ci ✨' : 'dans $diff mois',
                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: accent),
                ),
              ),
            ],
          ]),
        ])),
        IconButton(
          icon: Icon(Icons.edit_rounded, size: 20, color: context.mutedColor),
          onPressed: () => showSheet(context, title: 'Modifier ${p.name}', child: AddProjectSheet(existing: p)),
        ),
      ]),
      const SizedBox(height: 20),

      // ── Jauge budget ──────────────────────────────────────────
      Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        decoration: BoxDecoration(
          color: tint(statusColor, .07),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: statusColor.withAlpha(40)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(eur(spent),
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26, color: statusColor)),
              Text('dépensés sur ${eur(p.target)}',
                  style: TextStyle(fontSize: 13, color: context.mutedColor)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(over ? '−${eur(spent - p.target)}' : '+${eur(p.target - spent)}',
                  style: TextStyle(
                      fontWeight: FontWeight.w800, fontSize: 18,
                      color: over ? AppColors.danger : AppColors.teal)),
              Text(over ? 'dépassé' : 'restant',
                  style: TextStyle(fontSize: 12, color: context.mutedColor)),
            ]),
          ]),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: ratio,
              minHeight: 10,
              backgroundColor: context.trackColor,
              valueColor: AlwaysStoppedAnimation(statusColor),
            ),
          ),
          const SizedBox(height: 8),
          Text('${(ratio * 100).round()} % du budget utilisé',
              style: TextStyle(fontSize: 12, color: context.mutedColor, fontWeight: FontWeight.w500)),
        ]),
      ),
      const SizedBox(height: 12),

      // ── Solde prévu au mois du voyage ─────────────────────────
      if (endBalance != null) ...[ 
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          decoration: BoxDecoration(
            color: endBalance < 0 ? tint(AppColors.danger, .1) : context.fieldColor,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(children: [
            Icon(endBalance < 0 ? Icons.warning_amber_rounded : Icons.account_balance_wallet_rounded,
                size: 20, color: endBalance < 0 ? AppColors.danger : context.mutedColor),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Solde prévu fin ${p.targetYm.longName.toLowerCase()}',
                  style: TextStyle(color: context.mutedColor, fontSize: 12.5)),
              Text(eur(endBalance),
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17,
                      color: endBalance < 0 ? AppColors.danger : context.textColor)),
            ])),
          ]),
        ),
        const SizedBox(height: 12),
      ],

      // ── Épargne mensuelle ─────────────────────────────────────
      if (!p.isExpense && p.targetYm.isAfter(now)) ...[ 
        _SavingsBlock(project: p, now: now),
        const SizedBox(height: 12),
      ],

      // ── Note explicative ──────────────────────────────────────
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: context.fieldColor, borderRadius: BorderRadius.circular(14)),
        child: Text(
          p.isExpense
              ? (p.isTrip
                  ? 'Budget réservé en ${p.targetYm.longName.toLowerCase()}. Notez ici vos dépenses.'
                  : '${eur(p.target)} déduit de votre solde en ${p.targetYm.longName.toLowerCase()}.')
              : 'Vous mettez ${eur(p.monthlyPlan)} de côté chaque mois jusqu\'en ${p.targetYm.longName.toLowerCase()}.',
          style: const TextStyle(fontSize: 13, height: 1.4, fontWeight: FontWeight.w500),
        ),
      ),

      // ── Dépenses ─────────────────────────────────────────────
      if (p.isTrip) ...[ 
        const SizedBox(height: 16),
        // Bouton ajouter
        SizedBox(
          width: double.infinity,
          child: GradientButton(
            label: 'Ajouter une dépense',
            icon: Icons.add_rounded,
            onPressed: () => showSheet(context,
                title: 'Dépense · ${p.name}',
                child: AddExpenseSheet(month: ref.read(nowProvider), initialTripId: p.id)),
          ),
        ),
        if (tx.isNotEmpty) ...[ 
          const SizedBox(height: 16),
          Text('Dépenses (${tx.length})',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: context.textColor)),
          const SizedBox(height: 8),
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(children: [
              for (int i = 0; i < tx.length; i++) ...[ 
                _TxRow(t: tx[i], ref: ref),
                if (i < tx.length - 1) const Divider(height: 1, indent: 16),
              ],
            ]),
          ),
        ],
      ],
    ]);
  }
}

// ── Ligne de dépense dans la sheet ───────────────────────────────────────────
class _TxRow extends StatelessWidget {
  final Transaction t;
  final WidgetRef ref;
  const _TxRow({required this.t, required this.ref});

  @override
  Widget build(BuildContext context) {
    final isCurrentMonth = Ym.of(t.date) == ref.read(nowProvider);
    return InkWell(
      onTap: () => showSheet(context,
          title: 'Modifier la dépense',
          child: AddExpenseSheet(month: Ym.of(t.date), existing: t)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.description.isEmpty ? 'Dépense' : t.description,
                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            Row(children: [
              Text(_fd(t.date), style: TextStyle(color: context.mutedColor, fontSize: 12)),
              if (!isCurrentMonth) ...[ 
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                    color: AppColors.violet.withAlpha(20),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text('payé en avance',
                      style: const TextStyle(fontSize: 10, color: AppColors.violet, fontWeight: FontWeight.w600)),
                ),
              ],
            ]),
          ])),
          Text('−${eur(t.amount)}',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          const SizedBox(width: 8),
          CheckCircle(
              checked: t.checked,
              onTap: () => ref.read(appProvider.notifier).toggleTransactionChecked(t.id)),
          IconButton(
            visualDensity: VisualDensity.compact,
            onPressed: () => ref.read(appProvider.notifier).deleteTransaction(t.id),
            icon: Icon(Icons.close_rounded, size: 18, color: context.mutedColor),
          ),
        ]),
      ),
    );
  }
}

// ── Bloc épargne mensuelle ────────────────────────────────────────────────────
class _SavingsBlock extends ConsumerWidget {
  final Project project;
  final Ym now;
  const _SavingsBlock({required this.project, required this.now});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = project;
    final done = p.contributions.containsKey(now.key);
    final left = p.monthsLeft(now);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text('Épargne : ${eur(p.saved)} / ${eur(p.target)}',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const Spacer(),
        Text('${(p.progress * 100).round()} %',
            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.violet)),
      ]),
      const SizedBox(height: 8),
      AppProgress(value: p.progress, color: AppColors.violet),
      const SizedBox(height: 6),
      Text('${eur(p.monthlyPlan)} / mois · $left mois restant${left > 1 ? 's' : ''}',
          style: const TextStyle(color: AppColors.muted, fontSize: 13)),
      const SizedBox(height: 10),
      SizedBox(
        width: double.infinity,
        child: done
            ? SoftButton(
                icon: Icons.check_circle_rounded,
                label: 'Versement effectué · Annuler',
                onPressed: () => ref.read(appProvider.notifier).toggleContribution(p.id))
            : SoftButton(
                icon: Icons.savings_rounded,
                label: 'Marquer le versement du mois',
                onPressed: p.saved >= p.target
                    ? null
                    : () => ref.read(appProvider.notifier).toggleContribution(p.id)),
      ),
    ]);
  }
}

String _fd(DateTime x) =>
    '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}/${x.year}';
