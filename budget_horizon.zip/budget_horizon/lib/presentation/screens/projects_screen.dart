import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

class ProjectsScreen extends ConsumerWidget {
  const ProjectsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final sorted = [...d.projects.where((p) => !d.isClosed(p.targetYm))]
      ..sort((a, b) => a.targetYm.compareTo(b.targetYm));

    return ScreenScaffold(
      title: 'Projets',
      actions: [
        IconButton.filledTonal(
          key: TourKeys.addProject,
          onPressed: () => showSheet(context, title: 'Nouveau projet', child: const AddProjectSheet()),
          icon: const Icon(Icons.add_rounded),
        ),
      ],
      children: [
        if (sorted.isEmpty)
          AppCard(
            child: Text(
                d.projects.isEmpty
                    ? 'Aucun projet. Touchez + pour créer un voyage ou un projet d\'épargne.'
                    : 'Aucun projet à venir.',
                style: const TextStyle(height: 1.35)),
          ),
        for (final p in sorted) ...[
          _ProjectCard(project: p, now: now),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
}

class _ProjectCard extends ConsumerStatefulWidget {
  final Project project;
  final Ym now;
  const _ProjectCard({required this.project, required this.now});

  @override
  ConsumerState<_ProjectCard> createState() => _ProjectCardState();
}

class _ProjectCardState extends ConsumerState<_ProjectCard> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final p = widget.project;
    final now = widget.now;

    final tx = d.transactions.where((t) => t.tripId == p.id).toList()
      ..sort((a, b) { final c = b.date.compareTo(a.date); return c != 0 ? c : b.id.compareTo(a.id); });
    final spent = tx.fold(0.0, (s, t) => s + t.amount);
    final over = spent > p.target;
    final ratio = p.target <= 0 ? 0.0 : (spent / p.target).clamp(0.0, 1.0);
    final diff = p.targetYm.index - now.index;
    final when = diff < 0 ? 'terminé' : (diff == 0 ? 'ce mois-ci' : 'dans $diff mois');
    final monthForecast = ref.watch(forecastProvider).at(p.targetYm);
    final endBalance = monthForecast?.endBalance;

    final endYm = p.tripEnd != null ? Ym.of(p.tripEnd!) : p.targetYm;
    final dateRange = endYm != p.targetYm
        ? '${p.targetYm.longName} → ${endYm.longName}'
        : p.targetYm.longName;

    final accent = p.isTrip ? const Color(0xFF0A84FF) : AppColors.teal;
    final statusColor = over ? AppColors.danger : (ratio > .8 ? AppColors.warning : accent);

    Future<void> doDelete() async {
      final ok = await showQuickDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('Supprimer « ${p.name} » ?'),
          content: const Text('Le projet et toutes ses dépenses seront supprimés.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(
                style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Supprimer')),
          ],
        ),
      );
      if (ok == true && context.mounted) ref.read(appProvider.notifier).removeProject(p.id);
    }

    return Dismissible(
      key: ValueKey('proj_${p.id}'),
      direction: DismissDirection.endToStart,
      confirmDismiss: (_) async { await doDelete(); return false; },
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: AppColors.danger.withAlpha(200),
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.delete_outline_rounded, color: Colors.white, size: 28),
          SizedBox(height: 4),
          Text('Supprimer', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: tint(accent, .08),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // ── En-tête ──────────────────────────────────────────
          GestureDetector(
            onTap: () => setState(() => _open = !_open),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 12, 16),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // Emoji dans un cercle coloré
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: tint(accent, .18),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(p.emoji, style: const TextStyle(fontSize: 26)),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                    const SizedBox(height: 2),
                    Row(children: [
                      Icon(p.isTrip ? Icons.flight_rounded : Icons.savings_rounded,
                          size: 13, color: context.mutedColor),
                      const SizedBox(width: 4),
                      Text('$dateRange · $when',
                          style: TextStyle(fontSize: 12.5, color: context.mutedColor,
                              fontWeight: FontWeight.w500)),
                    ]),
                  ]),
                ),
                const SizedBox(width: 8),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(eur(p.target),
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18,
                          color: over ? AppColors.danger : context.textColor)),
                  Text(over ? 'dépassé' : 'budget',
                      style: TextStyle(fontSize: 11.5, color: context.mutedColor)),
                ]),
                const SizedBox(width: 4),
                PopupMenuButton<String>(
                  padding: EdgeInsets.zero,
                  iconSize: 20,
                  icon: Icon(Icons.more_vert_rounded, color: context.mutedColor, size: 20),
                  onSelected: (v) async {
                    if (v == 'edit') showSheet(context, title: 'Modifier ${p.name}', child: AddProjectSheet(existing: p));
                    else if (v == 'del') await doDelete();
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('Modifier')),
                    PopupMenuItem(value: 'del', child: Text('Supprimer')),
                  ],
                ),
                Icon(_open ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                    color: context.mutedColor, size: 20),
              ]),
            ),
          ),
          // ── Barre de progression ──────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: ratio,
                  minHeight: 7,
                  backgroundColor: context.trackColor,
                  valueColor: AlwaysStoppedAnimation(statusColor),
                ),
              ),
              const SizedBox(height: 6),
              Row(children: [
                Text('${eur(spent)} dépensés',
                    style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: statusColor)),
                const Spacer(),
                Text(over ? 'dépassé de ${eur(spent - p.target)}' : '${eur(p.target - spent)} restant',
                    style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600,
                        color: over ? AppColors.danger : context.mutedColor)),
              ]),
              const SizedBox(height: 12),
            ]),
          ),
          // ── Détail (accordéon) ────────────────────────────────
          if (_open)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Divider(height: 1),
                const SizedBox(height: 14),
                // Solde prévu
                if (endBalance != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
                    decoration: BoxDecoration(
                      color: endBalance < 0 ? tint(AppColors.danger, .12) : context.fieldColor,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(children: [
                      Icon(endBalance < 0 ? Icons.warning_amber_rounded : Icons.event_available_rounded,
                          size: 20, color: endBalance < 0 ? AppColors.danger : context.mutedColor),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Solde prévu fin ${p.targetYm.longName.toLowerCase()}',
                            style: TextStyle(color: context.mutedColor, fontSize: 12.5)),
                        Text(eur(endBalance),
                            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17,
                                color: endBalance < 0 ? AppColors.danger : context.textColor)),
                      ])),
                    ]),
                  ),
                  const SizedBox(height: 12),
                ],
                // Note explicative
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: context.fieldColor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    p.isExpense
                        ? (p.isTrip
                            ? 'Budget réservé en ${p.targetYm.longName.toLowerCase()}. Notez ici vos dépenses.'
                            : '${eur(p.target)} déduit de votre solde en ${p.targetYm.longName.toLowerCase()}.')
                        : 'Vous mettez ${eur(p.monthlyPlan)} de côté chaque mois jusqu\'en ${p.targetYm.longName.toLowerCase()}.',
                    style: const TextStyle(fontSize: 13, height: 1.4, fontWeight: FontWeight.w500),
                  ),
                ),
                // Épargne mensuelle
                if (!p.isExpense && p.targetYm.isAfter(now)) ...[
                  const SizedBox(height: 12),
                  _SavingsBlock(project: p, now: now),
                ],
                // Bouton ajouter dépense
                if (p.isTrip) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: GradientButton(
                      label: 'Ajouter une dépense',
                      icon: Icons.add_rounded,
                      onPressed: () => showSheet(context,
                          title: 'Dépense · ${p.name}',
                          child: AddExpenseSheet(month: p.targetYm, initialTripId: p.id)),
                    ),
                  ),
                ],
                // Liste des dépenses
                if (p.isTrip && tx.isNotEmpty) ...[
                  const SizedBox(height: 14),
                  Text('Dépenses', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14,
                      color: context.textColor)),
                  const SizedBox(height: 8),
                  for (final t in tx)
                    InkWell(
                      onTap: () => showSheet(context,
                          title: 'Modifier la dépense',
                          child: AddExpenseSheet(month: Ym.of(t.date), existing: t)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 7),
                        child: Row(children: [
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(t.description.isEmpty ? 'Dépense' : t.description,
                                style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                            Text(_fd(t.date),
                                style: TextStyle(color: context.mutedColor, fontSize: 12)),
                          ])),
                          Text('−${eur(t.amount)}',
                              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                          const SizedBox(width: 8),
                          CheckCircle(
                              checked: t.checked,
                              onTap: () => ref.read(appProvider.notifier).toggleTransactionChecked(t.id)),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            onPressed: () => ref.read(appProvider.notifier).deleteTransaction(t.id),
                            icon: Icon(Icons.close_rounded, size: 18, color: context.mutedColor),
                          ),
                        ]),
                      ),
                    ),
                ],
              ]),
            ),
        ]),
      ),
    );
  }
}

class _SavingsBlock extends ConsumerWidget {
  final Project project;
  final Ym now;
  const _SavingsBlock({required this.project, required this.now});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = project;
    final done = p.contributions.containsKey(now.key);
    final left = p.monthsLeft(now);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Text('Épargne : ${eur(p.saved)} / ${eur(p.target)}',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const Spacer(),
        Text('${(p.progress * 100).round()} %',
            style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.violet)),
      ]),
      const SizedBox(height: 8),
      AppProgress(value: p.progress, color: AppColors.violet),
      const SizedBox(height: 6),
      Text('${eur(p.monthlyPlan)} / mois · $left mois restant${left > 1 ? 's' : ''}',
          style: const TextStyle(color: AppColors.muted, fontSize: 13)),
      const SizedBox(height: 10),
      SizedBox(
        width: double.infinity,
        child: done
            ? SoftButton(
                icon: Icons.check_circle_rounded,
                label: 'Versement effectué · Annuler',
                onPressed: () => ref.read(appProvider.notifier).toggleContribution(p.id))
            : SoftButton(
                icon: Icons.savings_rounded,
                label: 'Marquer le versement du mois',
                onPressed: p.saved >= p.target
                    ? null
                    : () => ref.read(appProvider.notifier).toggleContribution(p.id)),
      ),
    ]);
  }
}

String _fd(DateTime x) =>
    '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}/${x.year}';
