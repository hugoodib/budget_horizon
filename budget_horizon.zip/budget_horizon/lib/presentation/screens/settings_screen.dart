import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../data/firebase_config.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';
import '../widgets/photo_picker.dart';
import 'leave_screen.dart';



/// Revenus, charges fixes, solde de départ + emplacements futurs (compte, cloud, premium).
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final n = ref.read(appProvider.notifier);
    final auth = FirebaseConfig.enabled ? ref.watch(authProvider) : const AuthState();
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 32), children: [

        // ── 1. Thème de couleur ─────────────────────────────────
        const SectionTitle('Thème de couleur'),
        AppCard(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Wrap(spacing: 12, runSpacing: 12, children: [
              for (var i = 0; i < appThemes.length; i++)
                Builder(builder: (_) {
                  final th = appThemes[i];
                  final selected = d.user.themeIndex == i;
                  return GestureDetector(
                    onTap: () => n.setTheme(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        gradient: th.brand,
                        borderRadius: BorderRadius.circular(18),
                        border: selected
                            ? Border.all(color: context.textColor, width: 3)
                            : null,
                        boxShadow: selected
                            ? [BoxShadow(color: th.primary.withAlpha(80),
                                blurRadius: 12, offset: const Offset(0, 4))]
                            : null,
                      ),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text(th.emoji, style: const TextStyle(fontSize: 26)),
                        const SizedBox(height: 2),
                        Text(th.name,
                            style: const TextStyle(color: Colors.white,
                                fontSize: 10, fontWeight: FontWeight.w700)),
                      ]),
                    ),
                  );
                }),
            ]),
          ]),
        ),

        // ── 2. Affichage ────────────────────────────────────────
        const SectionTitle('Affichage'),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Taille de l\'interface', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            PillSelector<double>.row(
              items: const [
                PillItem(0.8, 'Petit'),
                PillItem(0.9, 'Normal'),
                PillItem(1.0, 'Grand'),
              ],
              selected: [0.8, 0.9, 1.0].firstWhere(
                (v) => (d.user.uiScale - v).abs() < 0.01,
                orElse: () => 0.9,
              ),
              onChanged: n.setUiScale,
            ),
          ]),
        ),



        // ── 4. Photo de profil ──────────────────────────────────
        const SectionTitle('Photo de profil'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            for (final p in (d.isCouple ? [1, 2] : [1]))
              ListTile(
                leading: PersonAvatar(person: p, size: 44),
                title: Text(d.personName(p), style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text((p == 2 ? d.user.photo2 : d.user.photo1) == null
                    ? 'Ajouter une photo'
                    : 'Changer la photo'),
                trailing: (p == 2 ? d.user.photo2 : d.user.photo1) == null
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.delete_outline_rounded, color: AppColors.muted),
                        onPressed: () => n.setPhoto(p, null)),
                onTap: () async {
                  final b = await pickProfilePhoto(context);
                  if (b != null) n.setPhoto(p, b);
                },
              ),
          ]),
        ),

        // ── 5. En couple ────────────────────────────────────────
        const SectionTitle('En couple'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            SwitchListTile(
              title: const Text('En couple', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(d.isCouple
                  ? '${d.user.person1} & ${d.user.person2} : un budget par personne'
                  : 'Chaque budget est doublé : un par conjoint'),
              value: d.isCouple,
              onChanged: (v) async {
                if (v) {
                  showSheet(context, title: 'Mode couple', child: const CoupleSheet());
                } else {
                  final ok = await showQuickDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Repasser en solo ?'),
                      content: Text(
                          'Seuls les budgets de ${d.user.person1} sont conservés (ceux de ${d.user.person2} sont supprimés). Toutes les dépenses restent comptées.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmer')),
                      ],
                    ),
                  );
                  if (ok == true) n.setCouple(false);
                }
              },
            ),
            if (d.isCouple)
              ListTile(
                title: const Text('Modifier les prénoms'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => showSheet(context, title: 'Prénoms', child: const CoupleSheet()),
              ),
          ]),
        ),

        // ── 6. Auto-entrepreneur ────────────────────────────────
        const SectionTitle('Auto-entrepreneur'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            SwitchListTile(
              title: Text(d.isCouple ? '${d.user.person1} est auto-entrepreneur' : 'Vous êtes auto-entrepreneur',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Un onglet Clients calcule votre salaire à partir de vos passages'),
              value: d.user.ae1,
              onChanged: (v) => n.setAutoEntrepreneur(me: v),
            ),
            if (d.isCouple)
              SwitchListTile(
                title: Text('${d.user.person2} est auto-entrepreneur',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                value: d.user.ae2,
                onChanged: (v) => n.setAutoEntrepreneur(partner: v),
              ),
            if (d.hasAE)
              ListTile(
                title: const Text('Charges URSSAF', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('Retirées du brut pour obtenir le salaire net'),
                trailing: Text('${d.user.urssafRate.toStringAsFixed(2).replaceAll('.', ',')} %',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                onTap: () async {
                  final v = await askAmount(context, 'Taux de charges URSSAF', d.user.urssafRate,
                      hint: 'En pourcentage du chiffre d\'affaires (ex. 23,68).', suffix: '%');
                  if (v != null && v >= 0 && v < 100) n.setUrssafRate(v);
                },
              ),
          ]),
        ),

        // ── 7. Comptes et synchronisation ───────────────────────
        const SectionTitle('Comptes et synchronisation'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            if (!FirebaseConfig.enabled)
              const ListTile(
                leading: Icon(Icons.cloud_off_outlined),
                title: Text('Comptes non activés'),
                subtitle: Text('Ajoutez vos clés Firebase à la compilation pour activer les comptes.'),
              )
            else if (auth.session != null) ...[
              ListTile(
                leading: const Icon(Icons.person_outline_rounded),
                title: Text(auth.session!.email, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                    '${d.user.name != 'Moi' ? '${d.user.name} · ' : ''}${_syncText(auth)}'),
              ),
              ListTile(
                leading: const Icon(Icons.sync_rounded),
                title: const Text('Synchroniser maintenant'),
                onTap: () => ref.read(authProvider.notifier).syncNow(),
              ),
              if (auth.shareId == null) ...[
                ListTile(
                  leading: const Icon(Icons.group_add_outlined),
                  title: const Text('Partager avec mon conjoint'),
                  subtitle: const Text('Deux comptes, le même budget'),
                  onTap: () async {
                    final code = await ref.read(authProvider.notifier).createShare();
                    if (!context.mounted) return;
                    if (code == null) {
                      snack(context, ref.read(authProvider).error ?? 'Partage impossible');
                    } else {
                      _showCode(context, code);
                    }
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.login_rounded),
                  title: const Text('Rejoindre un budget partagé'),
                  subtitle: const Text('Avec le code de votre conjoint'),
                  onTap: () => _joinShare(context, ref),
                ),
              ] else ...[
                ListTile(
                  leading: const Icon(Icons.group_outlined),
                  title: const Text('Budget partagé actif'),
                  subtitle: Text('Code : ${auth.shareId}'),
                  onTap: () => _showCode(context, auth.shareId!),
                ),
                ListTile(
                  leading: const Icon(Icons.link_off_rounded),
                  title: const Text('Quitter le budget partagé'),
                  onTap: () async {
                    final ok = await showQuickDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Quitter le budget partagé ?'),
                        content: const Text(
                            'Vous gardez une copie de vos données, mais elles ne seront plus synchronisées avec votre conjoint.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Quitter')),
                        ],
                      ),
                    );
                    if (ok == true) await ref.read(authProvider.notifier).leaveShare();
                  },
                ),
              ],
              ListTile(
                leading: const Icon(Icons.logout_rounded),
                title: const Text('Se déconnecter'),
                onTap: () async {
                  final ok = await showQuickDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Se déconnecter ?'),
                      content: const Text(
                          'Vos données restent dans votre compte. Cet appareil sera remis à zéro et vous pourrez vous reconnecter à tout moment.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Se déconnecter')),
                      ],
                    ),
                  );
                  if (ok == true) {
                    await ref.read(authProvider.notifier).signOut();
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete_forever_outlined, color: AppColors.danger),
                title: const Text('Supprimer mon compte', style: TextStyle(color: AppColors.danger)),
                subtitle: const Text('Efface définitivement le compte et ses données'),
                onTap: () => _deleteAccount(context, ref),
              ),
            ] else
              ListTile(
                leading: const Icon(Icons.person_add_alt_outlined),
                title: const Text('Créer un compte ou se connecter'),
                subtitle: const Text('Sauvegarde et synchronisation de vos données'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () async {
                  await ref.read(authProvider.notifier).showAuth();
                  if (context.mounted) Navigator.pop(context);
                },
              ),
            const ListTile(
              leading: Icon(Icons.workspace_premium_outlined),
              title: Text('Hever Premium'),
              trailing: Text('Bientôt', style: TextStyle(color: AppColors.muted)),
              enabled: false,
            ),
          ]),
        ),

        // ── 8. Aide ─────────────────────────────────────────────
        const SectionTitle('Aide'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            ListTile(
              leading: const Icon(Icons.history_rounded),
              title: const Text('Historique des modifications', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('30 derniers jours'),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => showSheet(context, title: 'Historique', child: const _HistorySheet()),
            ),
            const Divider(height: 1, indent: 16),
            ListTile(
              leading: const Icon(Icons.mail_outline_rounded),
              title: const Text('Nous contacter', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Hever@icloud.com'),
              trailing: const Icon(Icons.open_in_new_rounded, size: 18),
              onTap: () {
                final uri = Uri(scheme: 'mailto', path: 'Hever@icloud.com', query: 'subject=Hever%20App');
                _launchUrl(uri);
              },
            ),
          ]),
        ),

        // ── 9. Développeur ──────────────────────────────────────
        _DevModeSection(),

        // ── 10. Réinitialiser ────────────────────────────────────
        const SectionTitle('Réinitialiser'),
        SoftButton(
          icon: Icons.restart_alt_rounded,
          label: 'Tout remettre à zéro',
          onPressed: () async {
            final ok = await showQuickDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Tout remettre à zéro ?'),
                content: const Text(
                    'Revenus, charges, budgets, dépenses, voyages, clients et factures seront effacés. '
                    'Le solde repart de 0 et l\'assistant de configuration se relance. Cette action est définitive.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                  FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Tout effacer')),
                ],
              ),
            );
            if (ok == true) {
              await n.resetDemo(onboarded: false);
              if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            }
          },
        ),
      ]),
    );
  }
}


String _syncText(AuthState a) {
  if (a.offline) return 'Hors ligne · sera synchronisé plus tard';
  final t = a.lastSync;
  if (t == null) return 'Synchronisation en cours…';
  return 'Synchronisé à ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}


/// Affiche le code de partage à transmettre au conjoint.
void _showCode(BuildContext context, String code) {
  showQuickDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Budget partagé'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Donnez ce code à votre conjoint :'),
        const SizedBox(height: 10),
        SelectableText(code,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: 2)),
        const SizedBox(height: 12),
        const Text(
            'Il doit créer son compte, puis choisir « J\'ai un code » (ou Paramètres → Compte → Rejoindre un budget partagé). Ses données actuelles seront remplacées par votre budget. Seules deux personnes peuvent rejoindre.',
            style: TextStyle(fontSize: 13, color: AppColors.muted)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer'))],
    ),
  );
}

Future<void> _joinShare(BuildContext context, WidgetRef ref) async {
  final c = TextEditingController();
  final code = await showQuickDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Rejoindre un budget partagé'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Vos données actuelles seront remplacées par celles du budget partagé.'),
        const SizedBox(height: 12),
        TextField(
          controller: c,
          autofocus: true,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'Code'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Rejoindre')),
      ],
    ),
  );
  c.dispose();
  if (code == null || !context.mounted) return;
  final ok = await ref.read(authProvider.notifier).joinShare(code);
  if (context.mounted) {
    snack(context, ok ? 'Budget partagé rejoint' : (ref.read(authProvider).error ?? 'Code invalide'));
  }
}

Future<void> _deleteAccount(BuildContext context, WidgetRef ref) async {
  final c = TextEditingController();
  final pw = await showQuickDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Supprimer mon compte ?'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text(
            'Votre compte et toutes vos données seront effacés définitivement. Saisissez votre mot de passe pour confirmer.'),
        const SizedBox(height: 12),
        TextField(
          controller: c,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Mot de passe'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
          onPressed: () => Navigator.pop(ctx, c.text),
          child: const Text('Supprimer'),
        ),
      ],
    ),
  );
  c.dispose();
  if (pw == null || pw.isEmpty || !context.mounted) return;
  final ok = await ref.read(authProvider.notifier).deleteAccount(pw);
  if (!context.mounted) return;
  if (ok) {
    Navigator.pop(context);
  } else {
    snack(context, ref.read(authProvider).error ?? 'Suppression impossible');
  }
}

// ---- Utilitaire : ouvrir une URL mailto sans dépendance url_launcher ----
// Sur iOS/Android, on passe par le MethodChannel natif de Flutter.
Future<void> _launchUrl(Uri uri) async {
  try {
    await const MethodChannel('flutter/url_launcher').invokeMethod<bool>(
      'launch',
      <String, Object>{
        'url': uri.toString(),
        'useSafariVC': false,
        'useWebView': false,
        'enableJavaScript': false,
        'enableDomStorage': false,
        'universalLinksOnly': false,
        'headers': <String, String>{},
      },
    );
  } catch (_) {
    // Silencieux si la plateforme ne supporte pas
  }
}

// ── Section Développeur ───────────────────────────────────────────────────────
// Accessible uniquement après saisie du code 0807.
// Déverrouille : date de débit par dépense + date de réception des salaires.
class _DevModeSection extends ConsumerStatefulWidget {
  @override
  ConsumerState<_DevModeSection> createState() => _DevModeSectionState();
}

class _DevModeSectionState extends ConsumerState<_DevModeSection> {
  bool _unlocked = false;

  void _promptCode() async {
    final c = TextEditingController();
    final ok = await showQuickDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Row(children: [
          Text('🔐', style: TextStyle(fontSize: 22)),
          SizedBox(width: 8),
          Text('Mode développeur', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Saisissez le code pour accéder aux options avancées.',
              style: TextStyle(color: AppColors.muted, fontSize: 13.5, height: 1.4)),
          const SizedBox(height: 14),
          TextField(
            controller: c,
            autofocus: true,
            keyboardType: TextInputType.number,
            obscureText: true,
            maxLength: 4,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 8),
            decoration: const InputDecoration(counterText: '', labelText: 'Code'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Valider')),
        ],
      ),
    );
    c.dispose();
    if (ok != true || !mounted) return;
    if (c.text.trim() == '0807') {
      setState(() => _unlocked = true);
    } else {
      snack(context, 'Code incorrect');
    }
  }

  @override
  Widget build(BuildContext context) {
    final devMode = ref.watch(devModeProvider);

    if (!_unlocked) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SectionTitle('Développeur'),
        AppCard(
          onTap: _promptCode,
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
          child: Row(children: [
            const Icon(Icons.code_rounded, color: AppColors.muted),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Options développeur', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                Text('Saisir le code pour déverrouiller', style: TextStyle(color: AppColors.muted, fontSize: 13)),
              ]),
            ),
            const Icon(Icons.lock_outline_rounded, color: AppColors.muted),
          ]),
        ),
      ]);
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionTitle('Développeur'),
      AppCard(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Column(children: [
          SwitchListTile(
            secondary: Icon(
              Icons.science_rounded,
              color: devMode ? AppColors.violet : AppColors.muted,
            ),
            title: const Text('Mode développeur', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(
              devMode
                  ? 'Actif · dates de débit et réception activées'
                  : 'Inactif · comportement standard',
              style: TextStyle(
                color: devMode ? AppColors.violet : AppColors.muted,
                fontSize: 12.5,
              ),
            ),
            value: devMode,
            onChanged: (_) => ref.read(devModeProvider.notifier).toggle(),
          ),
          if (devMode) ...[ 
            const Divider(height: 1, indent: 16, endIndent: 16),
            const ListTile(
              dense: true,
              leading: Icon(Icons.calendar_today_rounded, size: 18, color: AppColors.violet),
              title: Text('Date de débit', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              subtitle: Text('Chaque dépense peut avoir une date de débit différente de la date de saisie. '
                  'Le solde prévisionnel utilise la date de débit.',
                  style: TextStyle(fontSize: 12.5, height: 1.4)),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            const ListTile(
              dense: true,
              leading: Icon(Icons.account_balance_rounded, size: 18, color: AppColors.violet),
              title: Text('Date de réception des salaires', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              subtitle: Text('Chaque revenu récurrent peut indiquer à quel jour du mois il est reçu. '
                  'Raccourcis : le 5 du mois suivant, ou le dernier jour ouvré.',
                  style: TextStyle(fontSize: 12.5, height: 1.4)),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            SwitchListTile(
              secondary: const Icon(Icons.beach_access_rounded, size: 20, color: AppColors.violet),
              title: const Text('Compteur de congés', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
              subtitle: const Text('Ajoute un onglet Congés dans la navigation', style: TextStyle(fontSize: 12.5, height: 1.4)),
              value: ref.watch(appProvider).user.leaveEnabled,
              onChanged: (_) => ref.read(appProvider.notifier).toggleLeaveEnabled(),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            Builder(builder: (ctx) {
              final schedule = ref.watch(appProvider).shiftSchedule;
              return ListTile(
                dense: true,
                leading: Icon(Icons.schedule_rounded, size: 18,
                    color: schedule != null ? AppColors.teal : AppColors.violet),
                title: Text('Tournante 3×8',
                    style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                        color: schedule != null ? AppColors.teal : null)),
                subtitle: Text(
                  schedule != null
                      ? 'Configurée · départ le ${_fmtDate(schedule.startDate)}'
                      : 'Calculer les primes déplacement et panier automatiquement.',
                  style: const TextStyle(fontSize: 12.5, height: 1.4),
                ),
                trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                onTap: () => showSheet(context,
                    title: '🔄 Tournante 3×8',
                    child: _ShiftScheduleSheet()),
              );
            }),
          ],
        ]),
      ),
    ]);
  }
}

String _fmtDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

// ── Feuille de configuration de la tournante 3x8 ─────────────────────────────
class _ShiftScheduleSheet extends ConsumerStatefulWidget {
  @override
  ConsumerState<_ShiftScheduleSheet> createState() => _ShiftScheduleSheetState();
}

class _ShiftScheduleSheetState extends ConsumerState<_ShiftScheduleSheet> {
  late DateTime _startDate;
  late TextEditingController _transportCtrl;
  late TextEditingController _mealCtrl;

  @override
  void initState() {
    super.initState();
    final existing = ref.read(appProvider).shiftSchedule;
    _startDate = existing?.startDate ?? DateTime.now();
    _transportCtrl = TextEditingController(
        text: (existing?.transportAllowance ?? 39.58).toStringAsFixed(2));
    _mealCtrl = TextEditingController(
        text: (existing?.mealAllowance ?? 4.33).toStringAsFixed(2));
  }

  @override
  void dispose() {
    _transportCtrl.dispose();
    _mealCtrl.dispose();
    super.dispose();
  }

  String _fmtD(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  @override
  Widget build(BuildContext context) {
    final existing = ref.watch(appProvider).shiftSchedule;
    final n = ref.read(appProvider.notifier);
    final now = ref.read(nowProvider);

    // Prévisualisation : jours du mois courant
    final previewSchedule = ShiftSchedule(
      cycle: ShiftSchedule.defaultCycle,
      startDate: _startDate,
      transportAllowance: double.tryParse(_transportCtrl.text.replaceAll(',', '.')) ?? 39.58,
      mealAllowance: double.tryParse(_mealCtrl.text.replaceAll(',', '.')) ?? 4.33,
    );
    final counts = previewSchedule.shiftCountIn(now);
    final totalWorking = counts.values.fold(0, (s, c) => s + c);
    final totalPrime = previewSchedule.totalAllowanceIn(now);

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Date de début ─────────────────────────────────────────
      const Text('Début du cycle', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 4),
      const Text('Le jour 1 de ta tournante. Le cycle se répète à l\'infini à partir de cette date.',
          style: TextStyle(color: AppColors.muted, fontSize: 13, height: 1.4)),
      const SizedBox(height: 10),
      SoftButton(
        icon: Icons.calendar_today_rounded,
        label: _fmtD(_startDate),
        onPressed: () async {
          final picked = await showDatePicker(
            context: context,
            initialDate: _startDate,
            firstDate: DateTime(2020),
            lastDate: DateTime(2030),
          );
          if (picked != null) setState(() => _startDate = picked);
        },
      ),
      const SizedBox(height: 16),
      // ── Primes ────────────────────────────────────────────────
      const Text('Primes par jour travaillé', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(
          child: TextField(
            controller: _transportCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
                labelText: 'Déplacement', suffixText: '€/j'),
            onChanged: (_) => setState(() {}),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: TextField(
            controller: _mealCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
                labelText: 'Panier repas', suffixText: '€/j'),
            onChanged: (_) => setState(() {}),
          ),
        ),
      ]),
      const SizedBox(height: 16),
      // ── Prévisualisation du mois courant ──────────────────────
      Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: tint(AppColors.teal, .08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.teal.withAlpha(60), width: 1.5),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Aperçu · ${now.longName}',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.teal)),
          const SizedBox(height: 8),
          if (totalWorking == 0)
            const Text('Aucun jour travaillé ce mois (vérifie la date de début)',
                style: TextStyle(color: AppColors.muted, fontSize: 13))
          else ...[
            Wrap(spacing: 10, runSpacing: 6, children: [
              for (final e in counts.entries)
                _ShiftBadge(label: '${e.value}× ${e.key.label}', type: e.key),
            ]),
            const SizedBox(height: 8),
            Text(
              '$totalWorking jours travaillés · ${eur(totalPrime)} de primes',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppColors.teal),
            ),
            Text(
              '${eur(previewSchedule.transportAllowance * totalWorking)} déplacement + '
              '${eur(previewSchedule.mealAllowance * totalWorking)} panier',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
            ),
          ],
        ]),
      ),
      const SizedBox(height: 16),
      // ── Cycle affiché ────────────────────────────────────────
      const Text('Cycle (34 jours)', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      _CycleDisplay(cycle: ShiftSchedule.defaultCycle),
      const SizedBox(height: 16),
      // ── Boutons ──────────────────────────────────────────────
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Enregistrer la tournante',
          onPressed: () {
            final transport = double.tryParse(_transportCtrl.text.replaceAll(',', '.'));
            final meal = double.tryParse(_mealCtrl.text.replaceAll(',', '.'));
            if (transport == null || meal == null || transport < 0 || meal < 0) {
              snack(context, 'Montants invalides');
              return;
            }
            n.setShiftSchedule(ShiftSchedule(
              cycle: ShiftSchedule.defaultCycle,
              startDate: _startDate,
              transportAllowance: transport,
              mealAllowance: meal,
            ));
            Navigator.pop(context);
            snack(context, 'Tournante enregistrée ✓');
          },
        ),
      ),
      if (existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer la tournante',
          onPressed: () {
            n.setShiftSchedule(null);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}

class _ShiftBadge extends StatelessWidget {
  final String label;
  final ShiftType type;
  const _ShiftBadge({required this.label, required this.type});

  Color _color() => switch (type) {
        ShiftType.morning => const Color(0xFFFFA500),
        ShiftType.afternoon => const Color(0xFF0A84FF),
        ShiftType.night => const Color(0xFF5E5CE6),
        ShiftType.rest => AppColors.muted,
      };

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: tint(_color(), .15),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(label,
            style: TextStyle(
                fontSize: 12.5, fontWeight: FontWeight.w700, color: _color())),
      );
}

class _CycleDisplay extends StatelessWidget {
  final List<ShiftType> cycle;
  const _CycleDisplay({required this.cycle});

  Color _color(ShiftType t) => switch (t) {
        ShiftType.morning => const Color(0xFFFFA500),
        ShiftType.afternoon => const Color(0xFF0A84FF),
        ShiftType.night => const Color(0xFF5E5CE6),
        ShiftType.rest => AppColors.muted,
      };

  @override
  Widget build(BuildContext context) => Wrap(
        spacing: 4,
        runSpacing: 4,
        children: [
          for (var i = 0; i < cycle.length; i++)
            Tooltip(
              message: 'J${i + 1} · ${cycle[i].label}',
              child: Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: tint(_color(cycle[i]), .15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _color(cycle[i]).withAlpha(80)),
                ),
                alignment: Alignment.center,
                child: Text(cycle[i].short,
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: _color(cycle[i]))),
              ),
            ),
        ],
      );
}

// ---- Feuille d'historique des modifications ----
class _HistorySheet extends ConsumerWidget {
  const _HistorySheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final log = [...d.historyLog]..sort((a, b) => b.date.compareTo(a.date));

    String _fmt(DateTime dt) {
      final now = DateTime.now();
      final diff = now.difference(dt);
      if (diff.inMinutes < 1) return 'À l\'instant';
      if (diff.inMinutes < 60) return 'Il y a ${diff.inMinutes} min';
      if (diff.inHours < 24) return 'Il y a ${diff.inHours} h';
      if (diff.inDays == 1) return 'Hier';
      if (diff.inDays < 7) return 'Il y a ${diff.inDays} jours';
      return '${dt.day.toString().padLeft(2,'0')}/${dt.month.toString().padLeft(2,'0')}/${dt.year}';
    }

    if (log.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Aucune modification enregistrée. L\'historique se remplit dès votre première action.',
          style: TextStyle(color: AppColors.muted, height: 1.5),
        ),
      );
    }

    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.65,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Text('${log.length} modification${log.length > 1 ? 's' : ''} sur 30 jours',
              style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          const SizedBox(height: 12),
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              children: [
                for (int i = 0; i < log.length; i++) ...[
                  if (i > 0) const Divider(height: 1, indent: 52),
                  ListTile(
                    dense: true,
                    leading: CircleAvatar(
                      radius: 18,
                      backgroundColor: context.fieldColor,
                      child: Icon(_iconFor(log[i].description), size: 18, color: AppColors.violet),
                    ),
                    title: Text(log[i].description,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                    subtitle: Text(_fmt(log[i].date),
                        style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Fermer', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  IconData _iconFor(String desc) {
    if (desc.contains('Dépense ajoutée')) return Icons.add_shopping_cart_rounded;
    if (desc.contains('Dépense modifiée')) return Icons.edit_rounded;
    if (desc.contains('Dépense supprimée')) return Icons.delete_outline_rounded;
    if (desc.contains('Charge ajoutée')) return Icons.add_circle_outline_rounded;
    if (desc.contains('Charge modifiée')) return Icons.tune_rounded;
    if (desc.contains('Charge supprimée')) return Icons.remove_circle_outline_rounded;
    if (desc.contains('Voyage') || desc.contains('Projet')) return Icons.flag_outlined;
    if (desc.contains('clôturé')) return Icons.task_alt_rounded;
    if (desc.contains('rouvert')) return Icons.lock_open_rounded;
    return Icons.history_rounded;
  }
}
