import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../data/firebase_config.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';
import '../widgets/photo_picker.dart';

/// Revenus, charges fixes, solde de départ + emplacements futurs (compte, cloud, premium).
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final n = ref.read(appProvider.notifier);
    final auth = FirebaseConfig.enabled ? ref.watch(authProvider) : const AuthState();
    return Scaffold(
      appBar: AppBar(title: const Text('Réglages financiers')),
      body: ListView(padding: const EdgeInsets.fromLTRB(20, 4, 20, 32), children: [
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            ListTile(
              title: const Text('Solde de départ', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('Au 1er ${d.startYm.longName.toLowerCase()} ${d.startYm.year}'),
              trailing: Text(eur(d.startBalance), style: const TextStyle(fontWeight: FontWeight.w800)),
              onTap: () async {
                final v = await askAmount(context, 'Solde de départ', d.startBalance,
                    hint: 'Solde de votre compte au 1er jour du premier mois suivi.');
                if (v != null) n.setStartBalance(v);
              },
            ),
          ]),
        ),
        const SectionTitle('Aide'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: ListTile(
            leading: const Icon(Icons.school_outlined),
            title: const Text('Revoir la démonstration', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Le tour guidé de l\'app, à tout moment'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () {
              Navigator.pop(context);
              ref.read(tourProvider.notifier).start();
            },
          ),
        ),
        const SectionTitle('Affichage'),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Taille de l\'interface', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, children: [
              for (final o in const [('Petit', 0.8), ('Normal', 0.9), ('Grand', 1.0)])
                ChoiceChip(
                  label: Text(o.$1),
                  selected: (d.user.uiScale - o.$2).abs() < 0.01,
                  onSelected: (_) => n.setUiScale(o.$2),
                ),
            ]),
          ]),
        ),
        const SectionTitle('Situation'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            SwitchListTile(
              title: const Text('En couple', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(d.isCouple
                  ? '${d.user.person1} & ${d.user.person2} : un budget par personne'
                  : 'Chaque budget est doublé : un par conjoint'),
              value: d.isCouple,
              onChanged: (v) async {
                if (v) {
                  showSheet(context, title: 'Mode couple', child: const CoupleSheet());
                } else {
                  final ok = await showQuickDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Repasser en solo ?'),
                      content: Text(
                          'Seuls les budgets de ${d.user.person1} sont conservés (ceux de ${d.user.person2} sont supprimés). Toutes les dépenses restent comptées.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmer')),
                      ],
                    ),
                  );
                  if (ok == true) n.setCouple(false);
                }
              },
            ),
            if (d.isCouple)
              ListTile(
                title: const Text('Modifier les prénoms'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => showSheet(context, title: 'Prénoms', child: const CoupleSheet()),
              ),
          ]),
        ),
        const SectionTitle('Photo de profil'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            for (final p in (d.isCouple ? [1, 2] : [1]))
              ListTile(
                leading: PersonAvatar(person: p, size: 44),
                title: Text(d.personName(p), style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text((p == 2 ? d.user.photo2 : d.user.photo1) == null
                    ? 'Ajouter une photo'
                    : 'Changer la photo'),
                trailing: (p == 2 ? d.user.photo2 : d.user.photo1) == null
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.delete_outline_rounded, color: AppColors.muted),
                        onPressed: () => n.setPhoto(p, null)),
                onTap: () async {
                  final b = await pickProfilePhoto();
                  if (b != null) n.setPhoto(p, b);
                },
              ),
          ]),
        ),
        const SectionTitle('Auto-entrepreneur'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            SwitchListTile(
              title: Text(d.isCouple ? '${d.user.person1} est auto-entrepreneur' : 'Vous êtes auto-entrepreneur',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('Un onglet Clients calcule votre salaire à partir de vos passages'),
              value: d.user.ae1,
              onChanged: (v) => n.setAutoEntrepreneur(me: v),
            ),
            if (d.isCouple)
              SwitchListTile(
                title: Text('${d.user.person2} est auto-entrepreneur',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                value: d.user.ae2,
                onChanged: (v) => n.setAutoEntrepreneur(partner: v),
              ),
            if (d.hasAE)
              ListTile(
                title: const Text('Charges URSSAF', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('Retirées du brut pour obtenir le salaire net'),
                trailing: Text('${d.user.urssafRate.toStringAsFixed(2).replaceAll('.', ',')} %',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                onTap: () async {
                  final v = await askAmount(context, 'Taux de charges URSSAF', d.user.urssafRate,
                      hint: 'En pourcentage du chiffre d\'affaires (ex. 23,68).', suffix: '%');
                  if (v != null && v >= 0 && v < 100) n.setUrssafRate(v);
                },
              ),
          ]),
        ),
        const SectionTitle('Compte'),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            if (!FirebaseConfig.enabled)
              const ListTile(
                leading: Icon(Icons.cloud_off_outlined),
                title: Text('Comptes non activés'),
                subtitle: Text('Ajoutez vos clés Firebase à la compilation pour activer les comptes.'),
              )
            else if (auth.session != null) ...[
              ListTile(
                leading: const Icon(Icons.person_outline_rounded),
                title: Text(auth.session!.email, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(
                    '${d.user.name != 'Moi' ? '${d.user.name} · ' : ''}${_syncText(auth)}'),
              ),
              ListTile(
                leading: const Icon(Icons.sync_rounded),
                title: const Text('Synchroniser maintenant'),
                onTap: () => ref.read(authProvider.notifier).syncNow(),
              ),
              if (auth.shareId == null) ...[
                ListTile(
                  leading: const Icon(Icons.group_add_outlined),
                  title: const Text('Partager avec mon conjoint'),
                  subtitle: const Text('Deux comptes, le même budget'),
                  onTap: () async {
                    final code = await ref.read(authProvider.notifier).createShare();
                    if (!context.mounted) return;
                    if (code == null) {
                      snack(context, ref.read(authProvider).error ?? 'Partage impossible');
                    } else {
                      _showCode(context, code);
                    }
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.login_rounded),
                  title: const Text('Rejoindre un budget partagé'),
                  subtitle: const Text('Avec le code de votre conjoint'),
                  onTap: () => _joinShare(context, ref),
                ),
              ] else ...[
                ListTile(
                  leading: const Icon(Icons.group_outlined),
                  title: const Text('Budget partagé actif'),
                  subtitle: Text('Code : ${auth.shareId}'),
                  onTap: () => _showCode(context, auth.shareId!),
                ),
                ListTile(
                  leading: const Icon(Icons.link_off_rounded),
                  title: const Text('Quitter le budget partagé'),
                  onTap: () async {
                    final ok = await showQuickDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Quitter le budget partagé ?'),
                        content: const Text(
                            'Vous gardez une copie de vos données, mais elles ne seront plus synchronisées avec votre conjoint.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Quitter')),
                        ],
                      ),
                    );
                    if (ok == true) await ref.read(authProvider.notifier).leaveShare();
                  },
                ),
              ],
              ListTile(
                leading: const Icon(Icons.logout_rounded),
                title: const Text('Se déconnecter'),
                onTap: () async {
                  final ok = await showQuickDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Se déconnecter ?'),
                      content: const Text(
                          'Vos données restent dans votre compte. Cet appareil sera remis à zéro et vous pourrez vous reconnecter à tout moment.'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Se déconnecter')),
                      ],
                    ),
                  );
                  if (ok == true) {
                    await ref.read(authProvider.notifier).signOut();
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.delete_forever_outlined, color: AppColors.danger),
                title: const Text('Supprimer mon compte', style: TextStyle(color: AppColors.danger)),
                subtitle: const Text('Efface définitivement le compte et ses données'),
                onTap: () => _deleteAccount(context, ref),
              ),
            ] else
              ListTile(
                leading: const Icon(Icons.person_add_alt_outlined),
                title: const Text('Créer un compte ou se connecter'),
                subtitle: const Text('Sauvegarde et synchronisation de vos données'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () async {
                  await ref.read(authProvider.notifier).showAuth();
                  if (context.mounted) Navigator.pop(context);
                },
              ),
            const ListTile(
              leading: Icon(Icons.workspace_premium_outlined),
              title: Text('Budget Horizon Premium'),
              trailing: Text('Bientôt', style: TextStyle(color: AppColors.muted)),
              enabled: false,
            ),
          ]),
        ),
        const SizedBox(height: 20),
        SoftButton(
          icon: Icons.restart_alt_rounded,
          label: 'Réinitialiser avec les données de démo',
          onPressed: () async {
            final ok = await showQuickDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('Tout réinitialiser ?'),
                content: const Text('Toutes vos données locales seront remplacées.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                  FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Réinitialiser')),
                ],
              ),
            );
            if (ok == true) await n.resetDemo();
          },
        ),
      ]),
    );
  }
}


String _syncText(AuthState a) {
  if (a.offline) return 'Hors ligne · sera synchronisé plus tard';
  final t = a.lastSync;
  if (t == null) return 'Synchronisation en cours…';
  return 'Synchronisé à ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}


/// Affiche le code de partage à transmettre au conjoint.
void _showCode(BuildContext context, String code) {
  showQuickDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Budget partagé'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Donnez ce code à votre conjoint :'),
        const SizedBox(height: 10),
        SelectableText(code,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: 2)),
        const SizedBox(height: 12),
        const Text(
            'Il doit créer son compte, puis choisir « J\'ai un code » (ou Réglages → Compte → Rejoindre un budget partagé). Ses données actuelles seront remplacées par votre budget. Seules deux personnes peuvent rejoindre.',
            style: TextStyle(fontSize: 13, color: AppColors.muted)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer'))],
    ),
  );
}

Future<void> _joinShare(BuildContext context, WidgetRef ref) async {
  final c = TextEditingController();
  final code = await showQuickDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Rejoindre un budget partagé'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Vos données actuelles seront remplacées par celles du budget partagé.'),
        const SizedBox(height: 12),
        TextField(
          controller: c,
          autofocus: true,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'Code'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('Rejoindre')),
      ],
    ),
  );
  c.dispose();
  if (code == null || !context.mounted) return;
  final ok = await ref.read(authProvider.notifier).joinShare(code);
  if (context.mounted) {
    snack(context, ok ? 'Budget partagé rejoint' : (ref.read(authProvider).error ?? 'Code invalide'));
  }
}

Future<void> _deleteAccount(BuildContext context, WidgetRef ref) async {
  final c = TextEditingController();
  final pw = await showQuickDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Supprimer mon compte ?'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text(
            'Votre compte et toutes vos données seront effacés définitivement. Saisissez votre mot de passe pour confirmer.'),
        const SizedBox(height: 12),
        TextField(
          controller: c,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'Mot de passe'),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
          onPressed: () => Navigator.pop(ctx, c.text),
          child: const Text('Supprimer'),
        ),
      ],
    ),
  );
  c.dispose();
  if (pw == null || pw.isEmpty || !context.mounted) return;
  final ok = await ref.read(authProvider.notifier).deleteAccount(pw);
  if (!context.mounted) return;
  if (ok) {
    Navigator.pop(context);
  } else {
    snack(context, ref.read(authProvider).error ?? 'Suppression impossible');
  }
}
