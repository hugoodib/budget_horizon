import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/forecast.dart';
import '../../domain/salary.dart';
import '../providers.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

FlTitlesData _titles(List<String> labels) => FlTitlesData(
      leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          interval: 1,
          reservedSize: 26,
          getTitlesWidget: (v, meta) {
            final i = v.toInt();
            if (i < 0 || i >= labels.length || v != i.toDouble()) return const SizedBox.shrink();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              child: Text(labels[i], style: const TextStyle(fontSize: 10, color: AppColors.muted)),
            );
          },
        ),
      ),
    );

class AnalysisScreen extends ConsumerWidget {
  const AnalysisScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final fc = ref.watch(forecastProvider);
    final now = ref.watch(nowProvider);
    final next12 = [for (var i = 0; i < 12; i++) fc.at(now.add(i))].whereType<MonthForecast>().toList();
    final next6 = next12.take(6).toList();
    final sp = d.projects.where((p) => !p.isExpense).toList();

    // Dépenses par catégorie (mois courant)
    final slices = <(String, double, Color)>[];
    for (final c in d.categories) {
      final s = d.spentIn(now, categoryId: c.id);
      if (s > 0) slices.add(('${c.emoji} ${c.name}', s, Color(c.colorValue)));
    }
    final unexp = d.unexpectedIn(now);
    if (unexp > 0) slices.add(('⚡ Imprévus', unexp, AppColors.warning));
    final totalSpent = slices.fold(0.0, (s, e) => s + e.$2);

    return ScreenScaffold(
      title: 'Analyse',
      children: [
        const SectionTitle('Évolution du solde · 12 mois'),
        AppCard(
          child: SizedBox(
            height: 210,
            child: LineChart(LineChartData(
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
              titlesData: _titles([for (final f in next12) f.ym.short]),
              lineTouchData: LineTouchData(
                touchTooltipData: LineTouchTooltipData(
                  getTooltipItems: (spots) => [
                    for (final s in spots)
                      LineTooltipItem(eur(s.y), const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              lineBarsData: [
                LineChartBarData(
                  spots: [for (var i = 0; i < next12.length; i++) FlSpot(i.toDouble(), next12[i].endBalance)],
                  isCurved: true,
                  barWidth: 4,
                  gradient: brandGradient,
                  dotData: const FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [tint(AppColors.violet, .22), tint(AppColors.blue, 0)],
                    ),
                  ),
                ),
              ],
            )),
          ),
        ),
        SectionTitle('Dépenses par catégorie · ${now.longName}'),
        AppCard(
          child: slices.isEmpty
              ? const Text('Aucune dépense saisie ce mois-ci.', style: TextStyle(color: AppColors.muted))
              : Row(children: [
                  SizedBox(
                    width: 130,
                    height: 130,
                    child: PieChart(PieChartData(
                      sectionsSpace: 3,
                      centerSpaceRadius: 34,
                      sections: [
                        for (final s in slices)
                          PieChartSectionData(value: s.$2, color: s.$3, title: '', radius: 26),
                      ],
                    )),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(children: [
                      for (final s in slices)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(children: [
                            Container(width: 10, height: 10, decoration: BoxDecoration(color: s.$3, shape: BoxShape.circle)),
                            const SizedBox(width: 8),
                            Expanded(child: Text(s.$1, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
                            Text('${(s.$2 / totalSpent * 100).round()} %',
                                style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                          ]),
                        ),
                    ]),
                  ),
                ]),
        ),
        const SectionTitle('Capacité d\'épargne · 6 mois'),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Revenus − charges fixes − budgets, avant voyages',
                style: TextStyle(color: AppColors.muted, fontSize: 12)),
            const SizedBox(height: 12),
            SizedBox(
              height: 170,
              child: BarChart(BarChartData(
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: _titles([for (final f in next6) f.ym.short]),
                barTouchData: BarTouchData(
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipItem: (g, gi, rod, ri) => BarTooltipItem(
                        eur(rod.toY), const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ),
                ),
                barGroups: [
                  for (var i = 0; i < next6.length; i++)
                    BarChartGroupData(x: i, barRods: [
                      BarChartRodData(
                        toY: next6[i].savingCapacity,
                        width: 18,
                        borderRadius: BorderRadius.circular(6),
                        color: next6[i].savingCapacity >= 0 ? AppColors.teal : AppColors.danger,
                      ),
                    ]),
                ],
              )),
            ),
          ]),
        ),
        const SectionTitle('Épargne des voyages'),
        AppCard(
          child: sp.isEmpty
              ? const Text('Aucun voyage.', style: TextStyle(color: AppColors.muted))
              : Column(children: [
                  for (var i = 0; i < sp.length; i++) ...[
                    if (i > 0) const SizedBox(height: 18),
                    BudgetRow(
                      emoji: '🎯',
                      name: sp[i].name,
                      spent: sp[i].saved,
                      planned: sp[i].target,
                    ),
                  ],
                ]),
        ),
      ],
    );
  }
}


/// [Mode dev] Récapitulatif du salaire et de l'auto-entreprise.
class SalaryRecapCard extends ConsumerStatefulWidget {
  const SalaryRecapCard({super.key});
  @override
  ConsumerState<SalaryRecapCard> createState() => SalaryRecapCardState();
}

class SalaryRecapCardState extends ConsumerState<SalaryRecapCard> {
  int _window = 3;
  bool _future = true; // par défaut : les mois à venir (l'appli ne garde pas d'historique)
  int? _person; // null = tous les auto-entrepreneurs

  double? _manualHours() =>
      double.tryParse(ref.read(repositoryProvider).readMeta('salary_hours_week') ?? '');

  String _h(double v) =>
      v == v.roundToDouble() ? '${v.round()} h' : '${v.toStringAsFixed(1).replaceAll('.', ',')} h';

  Color _violet(BuildContext c) => c.isDark ? AppColors.violetDark : AppColors.violet;
  Color _teal(BuildContext c) => c.isDark ? AppColors.tealDark : AppColors.teal;

  // ───────────── Pièces d'interface ─────────────

  Widget _controls(BuildContext context, Ym now) {
    final last = now.add(_window - 1);
    final first = now.add(-(_window - 1));
    final period = _future
        ? '${now.short} ${now.year} → ${last.short} ${last.year}'
        : '${first.short} ${first.year} → ${now.short} ${now.year}';
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        PillSelector<int>.row(
          hint: Hint.analysisPills,
          items: const [PillItem(0, 'Mois passés'), PillItem(1, 'Mois à venir')],
          selected: _future ? 1 : 0,
          onChanged: (v) => setState(() => _future = v == 1),
        ),
        const SizedBox(height: 8),
        PillSelector<int>.row(
          hint: Hint.analysisPills,
          items: const [
            PillItem(1, '1 mois'),
            PillItem(3, '3 mois'),
            PillItem(6, '6 mois'),
            PillItem(12, '1 an'),
          ],
          selected: _window,
          onChanged: (v) => setState(() => _window = v),
        ),
        const SizedBox(height: 10),
        Row(children: [
          Icon(Icons.date_range_rounded, size: 15, color: context.mutedColor),
          const SizedBox(width: 6),
          Text(period,
              style: TextStyle(color: context.mutedColor, fontSize: 12.5, fontWeight: FontWeight.w600)),
        ]),
      ]),
    );
  }

  Widget _hero(BuildContext context, SalaryStats? emp, SalaryStats? ae) {
    final e = (emp != null && emp.hasData) ? emp : null;
    final a = (ae != null && ae.hasData) ? ae : null;
    final total = (e?.avgMonthly ?? 0) + (a?.avgMonthly ?? 0);
    final hours = (e?.hoursPerWeek ?? 0) + (a?.hoursPerWeek ?? 0);
    final hasHours = (e?.hoursPerWeek != null) || (a?.hoursPerWeek != null);
    // Les deux activités ont des heures connues → taux horaire global.
    final both = e?.hoursPerWeek != null && (a == null || a.hoursPerWeek != null);
    final only = a?.hoursPerWeek != null && e == null;
    final globalHourly =
        (hasHours && hours > 0.01 && (both || only)) ? total / (hours * kWeeksPerMonth) : null;
    const ink = Color(0xFF12172B);
    final inkSoft = ink.withAlpha(170);

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
      decoration: BoxDecoration(
        gradient: brandGradient,
        borderRadius: BorderRadius.circular(26),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.auto_awesome_rounded, size: 16, color: ink),
          const SizedBox(width: 6),
          Text('Tout ce que tu gagnes, en moyenne',
              style: TextStyle(color: inkSoft, fontSize: 12.5, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 8),
        if (e == null && a == null)
          Text('Pas encore de données sur cette période.',
              style: TextStyle(color: inkSoft, fontSize: 14))
        else ...[
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: total),
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeOutCubic,
            builder: (_, v, __) => Text('${eur(v)} / mois',
                style: const TextStyle(color: ink, fontSize: 30, fontWeight: FontWeight.w900)),
          ),
          Text('≈ ${eur(total * 12)} par an',
              style: TextStyle(color: inkSoft, fontSize: 13, fontWeight: FontWeight.w600)),
          if (e != null && a != null) ...[
            const SizedBox(height: 14),
            _splitBar(e.avgMonthly, a.avgMonthly, ink),
          ],
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: _heroStat('Heures / semaine', hasHours ? _h(hours) : '—', ink, inkSoft)),
            Expanded(
                child: _heroStat('Taux horaire global',
                    globalHourly == null ? '—' : '${eur(globalHourly)}/h', ink, inkSoft)),
          ]),
        ],
      ]),
    );
  }

  Widget _heroStat(String label, String value, Color ink, Color soft) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(color: soft, fontSize: 11.5, fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text(value, style: TextStyle(color: ink, fontSize: 17, fontWeight: FontWeight.w800)),
      ]);

  Widget _splitBar(double salary, double ae, Color ink) {
    final tot = salary + ae;
    final fs = (salary / tot * 1000).round().clamp(1, 999).toInt();
    final pct = (salary / tot * 100).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(
          height: 10,
          child: Row(children: [
            Expanded(flex: fs, child: Container(color: ink.withAlpha(230))),
            Expanded(flex: 1000 - fs, child: Container(color: Colors.white.withAlpha(190))),
          ]),
        ),
      ),
      const SizedBox(height: 6),
      Row(children: [
        Text('Salaire $pct %',
            style: TextStyle(color: ink, fontSize: 11.5, fontWeight: FontWeight.w700)),
        const Spacer(),
        Text('Auto-entreprise ${100 - pct} %',
            style: TextStyle(color: ink, fontSize: 11.5, fontWeight: FontWeight.w700)),
      ]),
    ]);
  }

  Widget _tile(BuildContext context, IconData icon, Color color, String label, String value,
      String sub) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 3),
        padding: const EdgeInsets.fromLTRB(10, 10, 8, 10),
        decoration: BoxDecoration(
          color: tint(color, context.isDark ? 0.16 : 0.12),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          Text(label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: context.mutedColor, fontSize: 11, fontWeight: FontWeight.w600)),
          Text(sub, style: TextStyle(color: context.mutedColor, fontSize: 10.5)),
        ]),
      ),
    );
  }

  /// Petit histogramme mois par mois ; le meilleur mois est mis en avant.
  Widget _bars(BuildContext context, SalaryStats s, Color color) {
    final pts = s.points;
    if (pts.length < 2) return const SizedBox.shrink();
    final maxV = pts.map((p) => p.amount).reduce((a, b) => a > b ? a : b);
    final best = s.best;
    const maxH = 84.0;
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: SizedBox(
        height: maxH + 36,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (final p in pts)
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                    if (pts.length <= 6)
                      Text(eur(p.amount),
                          maxLines: 1,
                          style: TextStyle(
                              fontSize: 9.5,
                              color: context.mutedColor,
                              fontWeight: FontWeight.w600)),
                    const SizedBox(height: 3),
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: maxV > 0 ? p.amount / maxV : 0),
                      duration: const Duration(milliseconds: 600),
                      curve: Curves.easeOutCubic,
                      builder: (_, v, __) => Container(
                        height: (maxH * v).clamp(4.0, maxH).toDouble(),
                        decoration: BoxDecoration(
                          color: identical(p, best) ? color : tint(color, 0.45),
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(p.ym.short,
                        style: TextStyle(fontSize: 10, color: context.mutedColor)),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _chip(BuildContext context, IconData icon, Color color, String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: tint(color, 0.14),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(text, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
        ]),
      );

  Widget _section(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Color color,
    required SalaryStats s,
    String net = '',
    Widget? footer,
    List<Widget> extra = const [],
  }) {
    return AppCard(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(color: tint(color, 0.18), shape: BoxShape.circle),
              child: Icon(icon, size: 17, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
                child: Text(title,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5))),
            if (s.hasData)
              Text('sur ${s.months} mois',
                  style: TextStyle(
                      color: context.mutedColor, fontSize: 12, fontWeight: FontWeight.w600)),
          ]),
        ),
        const SizedBox(height: 12),
        if (!s.hasData)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: Text('Pas encore de données sur cette période.',
                style: TextStyle(color: context.mutedColor, fontSize: 13)),
          )
        else ...[
          Row(children: [
            _tile(context, Icons.payments_rounded, color, 'Moyenne$net', eur(s.avgMonthly),
                'par mois'),
            _tile(context, Icons.timer_rounded, color, 'Taux horaire$net',
                s.hourly == null ? '—' : eur(s.hourly!), 'par heure'),
            _tile(context, Icons.schedule_rounded, color, 'Heures',
                s.hoursPerWeek == null ? '—' : _h(s.hoursPerWeek!), 'par semaine'),
          ]),
          _bars(context, s, color),
          if (s.points.length >= 2 && s.best != null && s.worst != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Wrap(spacing: 8, runSpacing: 6, children: [
                _chip(context, Icons.trending_up_rounded, AppColors.success,
                    'Meilleur : ${s.best!.ym.short} · ${eur(s.best!.amount)}'),
                if ((s.best!.amount - s.worst!.amount).abs() > 0.5)
                  _chip(context, Icons.trending_down_rounded, AppColors.warning,
                      'Plus bas : ${s.worst!.ym.short} · ${eur(s.worst!.amount)}'),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text('≈ ${eur(s.yearly)} sur une année',
                style: TextStyle(
                    color: context.mutedColor, fontSize: 12.5, fontWeight: FontWeight.w600)),
          ),
        ],
        ...extra,
        if (footer != null) ...[const SizedBox(height: 10), footer],
      ]),
    );
  }

  Widget _clientRanking(BuildContext context, List<ClientStat> list, Color color) {
    if (list.isEmpty) return const SizedBox.shrink();
    final ranked = list.where((c) => c.hourly != null).toList();
    final maxH = ranked.isEmpty ? 1.0 : ranked.first.hourly!;
    final shown = list.take(5).toList();
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.emoji_events_rounded, size: 16, color: AppColors.warning),
          const SizedBox(width: 6),
          const Text('Tes clients les plus rentables',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
        ]),
        const SizedBox(height: 8),
        for (var i = 0; i < shown.length; i++) _clientRow(context, i, shown[i], maxH, color),
        Text('Classés par net horaire (net ÷ heures passées chez le client).',
            style: TextStyle(color: context.mutedColor, fontSize: 11)),
      ]),
    );
  }

  Widget _clientRow(BuildContext context, int rank, ClientStat c, double maxH, Color color) {
    final h = c.hourly;
    final frac = h == null ? 0.0 : (h / maxH).clamp(0.04, 1.0).toDouble();
    final medal = const [Color(0xFFF5B83D), Color(0xFFB7BCCB), Color(0xFFD09A6A)];
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Row(children: [
        SizedBox(
          width: 26,
          child: rank < 3 && h != null
              ? Icon(Icons.workspace_premium_rounded, size: 20, color: medal[rank])
              : Text('${rank + 1}',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: context.mutedColor, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(
                  child: Text(c.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13))),
              Text(h == null ? eur(c.net) : '${eur(h)}/h',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
            ]),
            const SizedBox(height: 4),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: frac),
              duration: const Duration(milliseconds: 600),
              curve: Curves.easeOutCubic,
              builder: (_, v, __) => ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: v,
                  minHeight: 6,
                  backgroundColor: context.trackColor,
                  valueColor: AlwaysStoppedAnimation(color),
                ),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _insight(BuildContext context, SalaryStats emp, SalaryStats ae) {
    final a = ae.hourly, e = emp.hourly;
    if (a == null || e == null || e <= 0.01) return const SizedBox.shrink();
    final diff = ((a - e) / e * 100).round();
    final better = diff >= 0;
    final text = diff.abs() < 3
        ? 'Ton heure en auto-entreprise (${eur(a)}) vaut à peu près celle de ton salaire (${eur(e)}).'
        : better
            ? 'Une heure en auto-entreprise te rapporte ${eur(a)} net : $diff % de plus qu\'une heure de salaire (${eur(e)}).'
            : 'Une heure en auto-entreprise te rapporte ${eur(a)} net : ${diff.abs()} % de moins qu\'une heure de salaire (${eur(e)}).';
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.lightbulb_rounded, size: 22, color: AppColors.warning),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 13.5, height: 1.35, fontWeight: FontWeight.w600))),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final hasSalary = d.recurringIncomes.isNotEmpty;
    final hasShift =
        d.shiftSchedule != null && SalaryRecap.salaryIncomes(d).any((r) => r.isShiftSalary);
    final manual = _manualHours();
    final emp = hasSalary
        ? SalaryRecap.employee(d, now, _window, manualHoursPerWeek: manual, future: _future)
        : null;
    final both = d.aeActive(1) && d.aeActive(2);
    final person = both ? _person : null;
    final ae = d.hasAE
        ? SalaryRecap.autoEntrepreneur(d, now, _window, person: person, future: _future)
        : null;
    final clients = d.hasAE
        ? SalaryRecap.clients(d, now, _window, person: person, future: _future)
        : const <ClientStat>[];

    final partial = (emp != null && emp.hasData && emp.months < _window) ||
        (ae != null && ae.hasData && ae.months < _window);

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _controls(context, now),
      const SizedBox(height: 12),
      if (emp == null && ae == null)
        AppCard(
          child: Text('Ajoute un salaire ou un client pour voir ton récapitulatif.',
              style: TextStyle(color: context.mutedColor, fontSize: 13)),
        )
      else ...[
        _hero(context, emp, ae),
        const SizedBox(height: 12),
        if (emp != null) ...[
          _section(
            context,
            title: hasShift ? 'Salaire (3×8)' : 'Salaire',
            icon: Icons.work_rounded,
            color: _violet(context),
            s: emp,
            footer: hasShift
                ? Text('Heures = jours travaillés × ${kShiftHours.round()} h (postes de 8 h).',
                    style: TextStyle(color: context.mutedColor, fontSize: 11.5))
                : GestureDetector(
                    onTap: () async {
                      final v = await askAmount(context, 'Heures par semaine', manual ?? 0,
                          suffix: 'h');
                      if (v == null) return;
                      await ref
                          .read(repositoryProvider)
                          .writeMeta('salary_hours_week', v > 0 ? v.toString() : null);
                      if (mounted) setState(() {});
                    },
                    child: Row(children: [
                      Icon(Icons.edit_rounded, size: 14, color: _violet(context)),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          manual == null
                              ? 'Renseigner mes heures par semaine'
                              : 'Heures par semaine : ${_h(manual)} · modifier',
                          style: TextStyle(
                              color: _violet(context),
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700),
                        ),
                      ),
                    ]),
                  ),
          ),
          const SizedBox(height: 12),
        ],
        if (ae != null) ...[
          if (both) ...[
            PillSelector<int>.row(
          hint: Hint.analysisPills,
              items: [
                const PillItem(0, 'Les deux'),
                PillItem(1, d.personName(1)),
                PillItem(2, d.personName(2)),
              ],
              selected: _person ?? 0,
              onChanged: (v) => setState(() => _person = v == 0 ? null : v),
            ),
            const SizedBox(height: 10),
          ],
          _section(
            context,
            title: 'Auto-entreprise',
            icon: Icons.storefront_rounded,
            color: _teal(context),
            s: ae,
            net: ' nette',
            extra: [_clientRanking(context, clients, _teal(context))],
            footer: Text(
                'Net après URSSAF, d\'après les factures émises. Heures = passages × durée.',
                style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
          ),
          const SizedBox(height: 12),
        ],
        if (emp != null && ae != null) ...[
          _insight(context, emp, ae),
          const SizedBox(height: 12),
        ],
      ],
      if (partial)
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            _future
                ? 'Certains mois n\'ont aucun revenu prévu (revenu qui s\'arrête, client terminé…) : ils ne comptent pas dans la moyenne.'
                : 'L\'appli ne connaît que les mois depuis ton installation (ou le début de tes revenus et clients). Les mois plus anciens ne comptent pas : choisis « Mois à venir » pour une moyenne sur plusieurs mois.',
            style: TextStyle(color: context.mutedColor, fontSize: 11.5, height: 1.3),
          ),
        ),
    ]);
  }
}


/// [Mode dev] Page « Mon salaire » (ouverte depuis les Paramètres).
class SalaryRecapScreen extends StatelessWidget {
  const SalaryRecapScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        // Les pages du thème sont transparentes : sans fond, la page précédente
        // transparaît pendant l'animation d'ouverture.
        backgroundColor: context.isDark ? AppColors.bgDark : AppColors.bg,
        appBar: AppBar(title: const Text('Mon salaire')),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: const [SalaryRecapCard()],
        ),
      );
}
