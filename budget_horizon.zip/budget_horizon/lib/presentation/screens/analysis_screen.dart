import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../domain/forecast.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';

FlTitlesData _titles(List<String> labels) => FlTitlesData(
      leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          interval: 1,
          reservedSize: 26,
          getTitlesWidget: (v, meta) {
            final i = v.toInt();
            if (i < 0 || i >= labels.length || v != i.toDouble()) return const SizedBox.shrink();
            return SideTitleWidget(
              axisSide: meta.axisSide,
              child: Text(labels[i], style: const TextStyle(fontSize: 10, color: AppColors.muted)),
            );
          },
        ),
      ),
    );

class AnalysisScreen extends ConsumerWidget {
  const AnalysisScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final fc = ref.watch(forecastProvider);
    final now = ref.watch(nowProvider);
    final next12 = [for (var i = 0; i < 12; i++) fc.at(now.add(i))].whereType<MonthForecast>().toList();
    final next6 = next12.take(6).toList();
    final sp = d.projects.where((p) => !p.isExpense).toList();

    // Dépenses par catégorie (mois courant)
    final slices = <(String, double, Color)>[];
    for (final c in d.categories) {
      final s = d.spentIn(now, categoryId: c.id);
      if (s > 0) slices.add(('${c.emoji} ${c.name}', s, Color(c.colorValue)));
    }
    final unexp = d.unexpectedIn(now);
    if (unexp > 0) slices.add(('⚡ Imprévus', unexp, AppColors.warning));
    final totalSpent = slices.fold(0.0, (s, e) => s + e.$2);

    return ScreenScaffold(
      title: 'Analyse',
      children: [
        const SectionTitle('Évolution du solde · 12 mois'),
        AppCard(
          child: SizedBox(
            height: 210,
            child: LineChart(LineChartData(
              gridData: const FlGridData(show: false),
              borderData: FlBorderData(show: false),
              titlesData: _titles([for (final f in next12) f.ym.short]),
              lineTouchData: LineTouchData(
                touchTooltipData: LineTouchTooltipData(
                  getTooltipItems: (spots) => [
                    for (final s in spots)
                      LineTooltipItem(eur(s.y), const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              lineBarsData: [
                LineChartBarData(
                  spots: [for (var i = 0; i < next12.length; i++) FlSpot(i.toDouble(), next12[i].endBalance)],
                  isCurved: true,
                  barWidth: 4,
                  gradient: brandGradient,
                  dotData: const FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [tint(AppColors.violet, .22), tint(AppColors.blue, 0)],
                    ),
                  ),
                ),
              ],
            )),
          ),
        ),
        SectionTitle('Dépenses par catégorie · ${now.longName}'),
        AppCard(
          child: slices.isEmpty
              ? const Text('Aucune dépense saisie ce mois-ci.', style: TextStyle(color: AppColors.muted))
              : Row(children: [
                  SizedBox(
                    width: 130,
                    height: 130,
                    child: PieChart(PieChartData(
                      sectionsSpace: 3,
                      centerSpaceRadius: 34,
                      sections: [
                        for (final s in slices)
                          PieChartSectionData(value: s.$2, color: s.$3, title: '', radius: 26),
                      ],
                    )),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(children: [
                      for (final s in slices)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(children: [
                            Container(width: 10, height: 10, decoration: BoxDecoration(color: s.$3, shape: BoxShape.circle)),
                            const SizedBox(width: 8),
                            Expanded(child: Text(s.$1, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
                            Text('${(s.$2 / totalSpent * 100).round()} %',
                                style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                          ]),
                        ),
                    ]),
                  ),
                ]),
        ),
        const SectionTitle('Capacité d\'épargne · 6 mois'),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Revenus − charges fixes − budgets, avant voyages',
                style: TextStyle(color: AppColors.muted, fontSize: 12)),
            const SizedBox(height: 12),
            SizedBox(
              height: 170,
              child: BarChart(BarChartData(
                gridData: const FlGridData(show: false),
                borderData: FlBorderData(show: false),
                titlesData: _titles([for (final f in next6) f.ym.short]),
                barTouchData: BarTouchData(
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipItem: (g, gi, rod, ri) => BarTooltipItem(
                        eur(rod.toY), const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                  ),
                ),
                barGroups: [
                  for (var i = 0; i < next6.length; i++)
                    BarChartGroupData(x: i, barRods: [
                      BarChartRodData(
                        toY: next6[i].savingCapacity,
                        width: 18,
                        borderRadius: BorderRadius.circular(6),
                        color: next6[i].savingCapacity >= 0 ? AppColors.teal : AppColors.danger,
                      ),
                    ]),
                ],
              )),
            ),
          ]),
        ),
        const SectionTitle('Épargne des voyages'),
        AppCard(
          child: sp.isEmpty
              ? const Text('Aucun voyage.', style: TextStyle(color: AppColors.muted))
              : Column(children: [
                  for (var i = 0; i < sp.length; i++) ...[
                    if (i > 0) const SizedBox(height: 18),
                    BudgetRow(
                      emoji: '🎯',
                      name: sp[i].name,
                      spent: sp[i].saved,
                      planned: sp[i].target,
                    ),
                  ],
                ]),
        ),
      ],
    );
  }
}
