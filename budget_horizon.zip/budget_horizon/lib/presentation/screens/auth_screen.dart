import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/firebase_config.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../root_shell.dart';
import 'onboarding_screen.dart';
import '../widgets/common.dart';

/// Enchaînement : connexion → confirmation de l'e-mail → assistant de configuration → app.
class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final Widget page;
    final String name;
    final a = FirebaseConfig.enabled ? ref.watch(authProvider) : null;
    final pending = ref.watch(pendingJoinProvider);
    // Invitation reçue par lien : une fois connecté, on rejoint le budget tout de suite.
    if (a != null && pending != null && a.session != null && a.session!.emailVerified) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final code = ref.read(pendingJoinProvider);
        if (code == null) return;
        ref.read(pendingJoinProvider.notifier).state = null;
        if (ref.read(authProvider).shareId == null) {
          await ref.read(authProvider.notifier).joinShare(code);
        }
      });
    }
    final onboarded = ref.watch(appProvider.select((d) => d.user.onboarded));
    if (a != null && a.session == null && (!a.skipped || pending != null)) {
      page = const AuthScreen();
      name = 'auth';
    } else if (a != null && a.session != null && !a.session!.emailVerified) {
      page = const VerifyEmailScreen();
      name = 'verify';
    } else if (onboarded) {
      page = const RootShell();
      name = 'app';
    } else {
      page = const OnboardingScreen();
      name = 'onboarding';
    }
    // Fondu enchaîné entre connexion → vérification → configuration → app.
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 360),
      // Les pages ont un fond transparent : l'ancienne disparaît avant que la nouvelle n'apparaisse.
      transitionBuilder: (child, anim) => FadeTransition(
        opacity: CurvedAnimation(parent: anim, curve: const Interval(0.45, 1.0, curve: Curves.easeOut)),
        child: child,
      ),
      child: KeyedSubtree(key: ValueKey(name), child: page),
    );
  }
}

/// Demande de confirmer l'adresse e-mail (lien reçu par e-mail).
class VerifyEmailScreen extends ConsumerWidget {
  const VerifyEmailScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = ref.watch(authProvider);
    final c = ref.read(authProvider.notifier);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: AppCard(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Confirmez votre e-mail ✉️',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Text(
                    'Un e-mail de confirmation a été envoyé à ${a.session?.email ?? ''}. Ouvrez-le, touchez le lien, puis revenez ici. Pensez à regarder dans les spams.',
                    style: const TextStyle(color: AppColors.muted, height: 1.35),
                  ),
                  if (a.error != null) ...[
                    const SizedBox(height: 12),
                    Text(a.error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
                  ],
                  if (a.info != null) ...[
                    const SizedBox(height: 12),
                    Text(a.info!, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w600)),
                  ],
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: GradientButton(
                      label: a.busy ? 'Patientez…' : 'J\'ai confirmé mon e-mail',
                      onPressed: a.busy ? null : c.checkVerification,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SoftButton(label: 'Renvoyer l\'e-mail', onPressed: a.busy ? null : c.resendVerification),
                  TextButton(
                    onPressed: a.busy ? null : c.signOut,
                    child: const Text('Se déconnecter'),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends ConsumerStatefulWidget {
  const AuthScreen({super.key});
  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen> {
  late bool _create = ref.read(pendingJoinProvider) != null;
  bool _hide = true;
  final _email = TextEditingController();
  final _pw = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _pw.dispose();
    super.dispose();
  }

  void _submit() {
    final e = _email.text.trim();
    final p = _pw.text;
    if (e.isEmpty || p.isEmpty) {
      snack(context, 'E-mail et mot de passe requis');
      return;
    }
    final c = ref.read(authProvider.notifier);
    _create ? c.signUp(e, p) : c.signIn(e, p);
  }

  @override
  Widget build(BuildContext context) {
    final a = ref.watch(authProvider);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const AppLogo(size: 84),
                const SizedBox(height: 10),
                const Text('Hever',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                const SizedBox(height: 6),
                const Text('Anticipez votre solde, mois après mois.',
                    style: TextStyle(color: AppColors.muted, fontSize: 14)),
                const SizedBox(height: 22),
                if (ref.watch(pendingJoinProvider) != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        color: tint(AppColors.success, .14), borderRadius: BorderRadius.circular(16)),
                    child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Icon(Icons.group_add_outlined, color: AppColors.success),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                            'Tu as été invité(e) à rejoindre un budget partagé. Crée ton compte ou connecte-toi : tu y accéderas automatiquement.',
                            style: TextStyle(fontSize: 14, height: 1.4, fontWeight: FontWeight.w600)),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 14),
                ],
                AppCard(
                  padding: const EdgeInsets.all(18),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    TabSwitcher<bool>(
                      tabs: const [
                        (value: false, label: 'Se connecter',   icon: Icons.login_rounded),
                        (value: true,  label: 'Créer un compte', icon: Icons.person_add_rounded),
                      ],
                      selected: _create,
                      onChanged: (v) => setState(() => _create = v),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.email],
                      decoration: const InputDecoration(labelText: 'E-mail'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _pw,
                      obscureText: _hide,
                      autofillHints: [_create ? AutofillHints.newPassword : AutofillHints.password],
                      onSubmitted: (_) => a.busy ? null : _submit(),
                      decoration: InputDecoration(
                        labelText: 'Mot de passe',
                        suffixIcon: IconButton(
                          icon: Icon(_hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                          onPressed: () => setState(() => _hide = !_hide),
                        ),
                      ),
                    ),
                    if (a.error != null) ...[
                      const SizedBox(height: 12),
                      Text(a.error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
                    ],
                    if (a.info != null) ...[
                      const SizedBox(height: 12),
                      Text(a.info!, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w600)),
                    ],
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: GradientButton(
                        label: a.busy ? 'Patientez…' : (_create ? 'Créer mon compte' : 'Se connecter'),
                        onPressed: a.busy ? null : _submit,
                      ),
                    ),
                    if (!_create)
                      TextButton(
                        onPressed: a.busy
                            ? null
                            : () {
                                if (_email.text.trim().isEmpty) {
                                  snack(context, 'E-mail requis');
                                } else {
                                  ref.read(authProvider.notifier).sendReset(_email.text);
                                }
                              },
                        child: const Text('Mot de passe oublié ?'),
                      ),
                    const SizedBox(height: 4),
                    Text(
                      _create
                          ? 'Un e-mail de confirmation vous sera envoyé, puis un assistant vous aidera à configurer votre budget.'
                          : 'Les données de cet appareil seront remplacées par celles de votre compte.',
                      style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
                    ),
                  ]),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: a.busy ? null : () => ref.read(authProvider.notifier).continueWithoutAccount(),
                  child: const Text('Continuer sans compte'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
