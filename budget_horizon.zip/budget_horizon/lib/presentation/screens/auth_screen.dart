import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../data/firebase_config.dart';
import '../auth_controller.dart';
import '../providers.dart';
import '../root_shell.dart';
import 'onboarding_screen.dart';
import '../widgets/common.dart';

/// Enchaînement : connexion → confirmation de l'e-mail → assistant de configuration → app.
class AuthGate extends ConsumerWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (FirebaseConfig.enabled) {
      final a = ref.watch(authProvider);
      if (a.session == null && !a.skipped) return const AuthScreen();
      if (a.session != null && !a.session!.emailVerified) return const VerifyEmailScreen();
    }
    final onboarded = ref.watch(appProvider.select((d) => d.user.onboarded));
    return onboarded ? const RootShell() : const OnboardingScreen();
  }
}

/// Demande de confirmer l'adresse e-mail (lien reçu par e-mail).
class VerifyEmailScreen extends ConsumerWidget {
  const VerifyEmailScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = ref.watch(authProvider);
    final c = ref.read(authProvider.notifier);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: AppCard(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Confirmez votre e-mail ✉️',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Text(
                    'Un e-mail de confirmation a été envoyé à ${a.session?.email ?? ''}. Ouvrez-le, touchez le lien, puis revenez ici. Pensez à regarder dans les spams.',
                    style: const TextStyle(color: AppColors.muted, height: 1.35),
                  ),
                  if (a.error != null) ...[
                    const SizedBox(height: 12),
                    Text(a.error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
                  ],
                  if (a.info != null) ...[
                    const SizedBox(height: 12),
                    Text(a.info!, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w600)),
                  ],
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: GradientButton(
                      label: a.busy ? 'Patientez…' : 'J\'ai confirmé mon e-mail',
                      onPressed: a.busy ? null : c.checkVerification,
                    ),
                  ),
                  const SizedBox(height: 8),
                  SoftButton(label: 'Renvoyer l\'e-mail', onPressed: a.busy ? null : c.resendVerification),
                  TextButton(
                    onPressed: a.busy ? null : c.signOut,
                    child: const Text('Se déconnecter'),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class AuthScreen extends ConsumerStatefulWidget {
  const AuthScreen({super.key});
  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen> {
  bool _create = false;
  bool _hide = true;
  final _email = TextEditingController();
  final _pw = TextEditingController();

  @override
  void dispose() {
    _email.dispose();
    _pw.dispose();
    super.dispose();
  }

  void _submit() {
    final e = _email.text.trim();
    final p = _pw.text;
    if (e.isEmpty || p.isEmpty) {
      snack(context, 'Renseignez votre e-mail et votre mot de passe');
      return;
    }
    final c = ref.read(authProvider.notifier);
    _create ? c.signUp(e, p) : c.signIn(e, p);
  }

  @override
  Widget build(BuildContext context) {
    final a = ref.watch(authProvider);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('Hever',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                const SizedBox(height: 6),
                const Text('Anticipez votre solde, mois après mois.',
                    style: TextStyle(color: AppColors.muted, fontSize: 14)),
                const SizedBox(height: 22),
                AppCard(
                  padding: const EdgeInsets.all(18),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Wrap(spacing: 8, children: [
                      ChoiceChip(
                          label: const Text('Se connecter'),
                          selected: !_create,
                          onSelected: (_) => setState(() => _create = false)),
                      ChoiceChip(
                          label: const Text('Créer un compte'),
                          selected: _create,
                          onSelected: (_) => setState(() => _create = true)),
                    ]),
                    const SizedBox(height: 16),
                    TextField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.email],
                      decoration: const InputDecoration(labelText: 'E-mail'),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _pw,
                      obscureText: _hide,
                      autofillHints: [_create ? AutofillHints.newPassword : AutofillHints.password],
                      onSubmitted: (_) => a.busy ? null : _submit(),
                      decoration: InputDecoration(
                        labelText: 'Mot de passe',
                        suffixIcon: IconButton(
                          icon: Icon(_hide ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                          onPressed: () => setState(() => _hide = !_hide),
                        ),
                      ),
                    ),
                    if (a.error != null) ...[
                      const SizedBox(height: 12),
                      Text(a.error!, style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w600)),
                    ],
                    if (a.info != null) ...[
                      const SizedBox(height: 12),
                      Text(a.info!, style: const TextStyle(color: AppColors.success, fontWeight: FontWeight.w600)),
                    ],
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: GradientButton(
                        label: a.busy ? 'Patientez…' : (_create ? 'Créer mon compte' : 'Se connecter'),
                        onPressed: a.busy ? null : _submit,
                      ),
                    ),
                    if (!_create)
                      TextButton(
                        onPressed: a.busy
                            ? null
                            : () {
                                if (_email.text.trim().isEmpty) {
                                  snack(context, 'Saisissez d\'abord votre e-mail');
                                } else {
                                  ref.read(authProvider.notifier).sendReset(_email.text);
                                }
                              },
                        child: const Text('Mot de passe oublié ?'),
                      ),
                    const SizedBox(height: 4),
                    Text(
                      _create
                          ? 'Un e-mail de confirmation vous sera envoyé, puis un assistant vous aidera à configurer votre budget.'
                          : 'Les données de cet appareil seront remplacées par celles de votre compte.',
                      style: const TextStyle(color: AppColors.muted, fontSize: 12.5),
                    ),
                  ]),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: a.busy ? null : () => ref.read(authProvider.notifier).continueWithoutAccount(),
                  child: const Text('Continuer sans compte'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
