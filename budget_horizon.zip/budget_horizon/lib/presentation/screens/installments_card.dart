import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../domain/installments.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

/// Paiements en plusieurs fois : échéances à confirmer ce mois-ci + liste des paiements en cours.
class InstallmentsCard extends ConsumerWidget {
  const InstallmentsCard({super.key});

  String _catName(AppData d, String id) {
    final c = d.category(id);
    return c == null ? 'Budget' : '${c.emoji} ${c.name}';
  }

  Future<void> _confirm(BuildContext context, WidgetRef ref, InstallmentPlan p, int i) async {
    final ok = await showSheet<bool>(
      context,
      title: 'Échéance ${i + 1}/${p.count} · ${p.name}',
      child: AddExpenseSheet(
        month: p.ymAt(i),
        initialCategoryId: p.categoryId,
        initialPerson: p.person == 0 ? null : p.person,
        initialAmount: p.amountAt(i),
        initialDescription: '${p.name} (${i + 1}/${p.count})',
        initialDate: p.dateAt(i),
      ),
    );
    if (ok == true) {
      ref.read(appProvider.notifier).resolveInstallment(p.id, i, done: true);
      if (context.mounted) snack(context, 'Échéance ajoutée au budget');
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final plans = d.installments.where((p) => !p.finished).toList();
    if (plans.isEmpty) return const SizedBox.shrink();

    final due = <(InstallmentPlan, int)>[
      for (final p in plans)
        for (final i in p.dueIndexes(now)) (p, i),
    ];

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (due.isNotEmpty) ...[
        for (final (p, i) in due)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: AppCard(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: tint(AppColors.violet, .18), shape: BoxShape.circle),
                    child: const Icon(Icons.event_repeat_rounded, size: 18, color: AppColors.violet),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${p.name} · échéance ${i + 1}/${p.count}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text(
                          '${eur(p.amountAt(i))} · ${_catName(d, p.categoryId)} · ${p.ymAt(i).label.toLowerCase()}',
                          style: TextStyle(color: context.mutedColor, fontSize: 12.5)),
                    ]),
                  ),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(
                    child: SoftButton(
                      label: 'Passer',
                      onPressed: () => ref.read(appProvider.notifier).resolveInstallment(p.id, i, done: false),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: GradientButton(
                      label: 'Ajouter au budget',
                      onPressed: () => _confirm(context, ref, p, i),
                    ),
                  ),
                ]),
              ]),
            ),
          ),
      ],
      AppCard(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.event_repeat_rounded, size: 18, color: AppColors.violet),
            const SizedBox(width: 8),
            const Expanded(
                child: Text('Paiements en plusieurs fois',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
          ]),
          const SizedBox(height: 6),
          for (final p in plans)
            InkWell(
              onTap: () => showSheet(context, title: p.name, child: _PlanDetail(planId: p.id)),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(
                        child: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700))),
                    Text('reste ${eur(p.remaining)}',
                        style: TextStyle(color: context.mutedColor, fontSize: 12.5)),
                    Icon(Icons.chevron_right_rounded, size: 18, color: context.mutedColor),
                  ]),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: p.doneCount / p.count,
                      minHeight: 6,
                      backgroundColor: context.trackColor,
                      valueColor: const AlwaysStoppedAnimation(AppColors.violet),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                      '${p.doneCount}/${p.count} ajoutés · ${_catName(d, p.categoryId)}'
                      '${p.nextIndex() == null ? '' : ' · prochaine : ${p.ymAt(p.nextIndex()!).short}'}',
                      style: TextStyle(color: context.mutedColor, fontSize: 11.5)),
                ]),
              ),
            ),
        ]),
      ),
    ]);
  }
}

/// Détail d'un paiement en plusieurs fois : échéances, modification, suppression.
class _PlanDetail extends ConsumerWidget {
  final String planId;
  const _PlanDetail({required this.planId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final p = d.installments.where((e) => e.id == planId).firstOrNull;
    if (p == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('Total ${eur(p.total)} en ${p.count} fois · le ${p.day} de chaque mois',
          style: TextStyle(color: context.mutedColor)),
      const SizedBox(height: 10),
      for (var i = 0; i < p.count; i++)
        ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: Icon(
            p.isDone(i)
                ? Icons.check_circle_rounded
                : (p.isSkipped(i) ? Icons.remove_circle_outline_rounded : Icons.radio_button_unchecked_rounded),
            color: p.isDone(i) ? AppColors.success : context.mutedColor,
          ),
          title: Text('${p.ymAt(i).label} · ${eur(p.amountAt(i))}'),
          subtitle: Text(p.isDone(i) ? 'Ajoutée au budget' : (p.isSkipped(i) ? 'Ignorée' : 'À venir')),
        ),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(
          child: SoftButton(
            label: 'Supprimer',
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Supprimer ce paiement ?'),
                  content: const Text('Les dépenses déjà ajoutées au budget sont conservées.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
                  ],
                ),
              );
              if (ok == true) {
                ref.read(appProvider.notifier).removeInstallment(p.id);
                if (context.mounted) Navigator.pop(context);
              }
            },
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: GradientButton(
            label: 'Modifier',
            onPressed: () async {
              Navigator.pop(context);
              await showSheet<bool>(context,
                  title: 'Modifier le paiement', child: AddInstallmentSheet(existing: p));
            },
          ),
        ),
      ]),
    ]);
  }
}
