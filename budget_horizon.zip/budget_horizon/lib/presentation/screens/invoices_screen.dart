import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/common.dart';
import '../../domain/business_models.dart';
import 'clients_screen.dart';

String fmtVisits(double v) =>
    v == v.roundToDouble() ? v.round().toString() : v.toStringAsFixed(2).replaceAll('.', ',');

String _dur(double minutes) {
  final m = minutes.round();
  final h = m ~/ 60;
  final r = m % 60;
  if (h == 0) return '$r min';
  return r == 0 ? '$h h' : '$h h ${r.toString().padLeft(2, '0')}';
}

/// Onglet « Factures » : une facture par client et par mois, brut puis net.
class InvoicesScreen extends ConsumerStatefulWidget {
  const InvoicesScreen({super.key});
  @override
  ConsumerState<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends ConsumerState<InvoicesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(invoiceMonthProvider.notifier).state = ref.read(nowProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final ym = ref.watch(invoiceMonthProvider);
    final issued = d.invoicesIssuedIn(ym);
    final carried = d.invoicesReceivedIn(ym).where((v) => v.ym != ym).toList();
    final gross = issued.fold(0.0, (s, v) => s + v.amount);
    final coop = issued.fold(0.0, (s, v) => s + d.coopCut(v));
    final net = d.netFromGross(gross - coop);
    final receivedGross = [1, 2]
        .where((p) => d.aeActive(p))
        .fold(0.0, (s, p) => s + d.grossReceivedIn(ym, p));
    final receivedNet = d.netFromGross(receivedGross);
    final rate = d.user.urssafRate.toStringAsFixed(2).replaceAll('.', ',');

    return GestureDetector(
      onHorizontalDragEnd: (details) {
        // Swipe droite → Clients
        if (details.primaryVelocity != null && details.primaryVelocity! > 300) {
          ref.read(tabProvider.notifier).state = AppTab.clients;
        }
      },
      child: ScreenScaffold(
      title: 'Factures',
      // Le mois reste affiché en haut, même en faisant défiler la page.
      pinned: Column(children: [
        const ClientsSwitch(current: AppTab.invoices),
        const SizedBox(height: 4),
        MonthSwitcher(
          value: ym,
          min: d.startYm,
          now: ref.watch(nowProvider),
          onChanged: (v) => ref.read(invoiceMonthProvider.notifier).state = v,
        ),
      ]),
      children: [
        AppCard(
          key: TourKeys.invoiceSummary,
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('En ${ym.longName}',
                style: const TextStyle(
                    color: AppColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
            const SizedBox(height: 8),
            _line('Total facturé (brut)', eur(gross)),
            if (coop > 0.005) _line('Retenue Unipro (${d.user.uniproRate.toStringAsFixed(2).replaceAll('.', ',')} %)', eur(-coop)),
            _line('Charges URSSAF ($rate %)', eur(-(gross - coop - net))),
            const Divider(height: 18),
            Row(children: [
              const Expanded(child: Text('Salaire net', style: TextStyle(fontWeight: FontWeight.w800))),
              Text(eur(net), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 26, letterSpacing: -0.6)),
            ]),
            if ((receivedNet - net).abs() > 0.5) ...[
              const SizedBox(height: 8),
              Text(
                  'Salaire compté en ${ym.longName.toLowerCase()} : ${eur(receivedNet)} net (factures impayées exclues).',
                  style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.3)),
            ],
          ]),
        ),
        if (issued.isEmpty && carried.isEmpty) ...[
          const SizedBox(height: 12),
          const AppCard(
            child: Text('Aucune facture ce mois-ci.',
                style: TextStyle(height: 1.35)),
          ),
        ],
        if (issued.isNotEmpty) ...[
          const SectionTitle('Factures du mois'),
          for (final v in issued) ...[
            _InvoiceCard(view: v, ym: ym),
            const SizedBox(height: 10),
          ],
        ],
        if (carried.isNotEmpty) ...[
          const SectionTitle('Retards de paiement (mois précédents)'),
          for (final v in carried) ...[
            _InvoiceCard(view: v, ym: ym),
            const SizedBox(height: 10),
          ],
        ],
      ],
    ),
    );
  }

  Widget _line(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(child: Text(label, style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      );
}

class _InvoiceCard extends ConsumerWidget {
  final InvoiceView view;
  final Ym ym; // mois affiché
  const _InvoiceCard({required this.view, required this.ym});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final v = view;
    final c = v.client;
    final n = ref.read(appProvider.notifier);
    final carriedIn = v.ym != ym; // facture d'un mois précédent, reportée ici
    final isForfait = v.forfait != null;
    final tags = <String>[
      if (v.overridden) 'Modifiée',
      if (isForfait && v.missed > 0)
        '${fmtVisits(v.missed)} passage${v.missed > 1 ? 's' : ''} manqué${v.missed > 1 ? 's' : ''} × ${eur(c.amount)}'
      else if (v.absentVisits > 0)
        '${v.absentVisits} passage${v.absentVisits > 1 ? 's' : ''} retiré${v.absentVisits > 1 ? 's' : ''} (voyage)',
    ];
    final String? lateText = carriedIn
        ? 'Retard de paiement · facture de ${v.ym.longName.toLowerCase()}'
        : (v.isLate ? 'Retard de paiement · reportée en ${v.receivedYm.longName.toLowerCase()}' : null);
    return AppCard(
      hint: Hint.invoiceRow,
      onTap: () => showSheet(context,
          title: '${c.name} · ${v.ym.label}', child: InvoiceSheet(clientId: c.id, ym: v.ym)),
      padding: const EdgeInsets.fromLTRB(16, 14, 12, 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleEmoji(c.name.characters.first.toUpperCase(),
              AppColors.palette[c.name.length % AppColors.palette.length], letter: true, size: 40),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 2),
              Text(
                  isForfait
                      ? 'Forfait ${eur(v.forfait!)} · ${fmtVisits(v.visits)} passage${v.visits > 1 ? 's' : ''} · ${_dur(v.visits * c.durationMin)}'
                      : '${fmtVisits(v.visits)} passage${v.visits > 1 ? 's' : ''} × ${eur(c.amount)} · ${_dur(v.visits * c.durationMin)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
              if (tags.isNotEmpty)
                Text(tags.join(' · '),
                    style: const TextStyle(color: AppColors.violet, fontSize: 12, fontWeight: FontWeight.w600)),
            ]),
          ),
          Text(eur(v.amount), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        ]),
        if (lateText != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('⚠️ $lateText',
                style: const TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w700)),
          ),
        const SizedBox(height: 4),
        Row(children: [
          CheckCircle(checked: v.sent, onTap: () => n.toggleInvoiceSent(c.id, v.ym)),
          const Text('Envoyée', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
          const SizedBox(width: 12),
          CheckCircle(checked: v.paid, onTap: () => n.toggleInvoicePaid(c.id, v.ym)),
          const Text('Payée', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
        ]),
      ]),
    );
  }
}

/// Modification d'une facture : nombre de passages OU montant (l'autre se recalcule).
class InvoiceSheet extends ConsumerStatefulWidget {
  final String clientId;
  final Ym ym;
  const InvoiceSheet({super.key, required this.clientId, required this.ym});
  @override
  ConsumerState<InvoiceSheet> createState() => _InvoiceSheetState();
}

class _InvoiceSheetState extends ConsumerState<InvoiceSheet> {
  TextEditingController? _visits;
  TextEditingController? _amount;
  String? _edited; // 'visits' ou 'amount'

  @override
  void dispose() {
    _visits?.dispose();
    _amount?.dispose();
    _missed?.dispose();
    super.dispose();
  }

  String _fmt(double v) => v == v.roundToDouble() ? v.round().toString() : v.toStringAsFixed(2);

  TextEditingController? _missed;

  /// Client au forfait : même montant chaque mois, moins les passages manqués.
  Widget _forfaitSheet(Client c, InvoiceView v) {
    final n = ref.read(appProvider.notifier);
    final manual = v.record?.missedVisits ?? 0;
    _missed ??= TextEditingController(text: manual == 0 ? '' : _fmt(manual));
    final typed = parseAmount(_missed!.text) ?? 0;
    final double missedTotal = v.absentVisits + (typed < 0 ? 0.0 : typed);
    final double preview = (v.forfait! - missedTotal * c.amount).clamp(0.0, double.infinity).toDouble();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
          'Forfait ${eur(v.forfait!)} par mois, lissé sur l\'année. '
          'Chaque passage manqué retire ${eur(c.amount)}.',
          style: const TextStyle(color: AppColors.muted, fontSize: 13, height: 1.3)),
      if (v.absentVisits > 0) ...[
        const SizedBox(height: 8),
        Text(
            '${v.absentVisits} passage${v.absentVisits > 1 ? 's' : ''} déjà retiré${v.absentVisits > 1 ? 's' : ''} automatiquement (voyage).',
            style: const TextStyle(color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600)),
      ],
      const SizedBox(height: 14),
      FieldInfo(Hint.fieldMissed, child: TextField(
        controller: _missed,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        autofocus: true,
        onChanged: (_) => setState(() {}),
        decoration: const InputDecoration(
          labelText: 'Passages manqués ce mois-ci',
          hintText: 'Aucun',
          suffixText: 'passage(s)',
        ),
      )),
      const SizedBox(height: 12),
      Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.violet.withAlpha(22),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
              missedTotal > 0
                  ? '${eur(v.forfait!)} − ${fmtVisits(missedTotal)} × ${eur(c.amount)}'
                  : 'Aucune déduction',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
          const SizedBox(height: 4),
          Text('Facture : ${eur(preview)}',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        ]),
      ),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Enregistrer',
          onPressed: () {
            final x = parseAmount(_missed!.text) ?? 0;
            if (x < 0) return;
            n.setInvoiceMissed(c.id, widget.ym, x);
            Navigator.pop(context);
          },
        ),
      ),
      if (manual > 0 || v.overridden) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.restart_alt_rounded,
          label: 'Revenir au forfait complet',
          onPressed: () {
            n.setInvoiceOverride(c.id, widget.ym);
            n.setInvoiceMissed(c.id, widget.ym, null);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final c = d.clientById(widget.clientId);
    if (c == null) return const SizedBox.shrink();
    final v = d.invoiceView(c, widget.ym);
    if (v.forfait != null) return _forfaitSheet(c, v);
    _visits ??= TextEditingController(text: _fmt(v.visits));
    _amount ??= TextEditingController(text: _fmt(v.amount));
    final n = ref.read(appProvider.notifier);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
          'Prévu automatiquement : ${fmtVisits(v.plannedVisits)} passage${v.plannedVisits > 1 ? 's' : ''} × ${eur(c.amount)}'
          '${v.absentVisits > 0 ? ' (${v.absentVisits} retiré${v.absentVisits > 1 ? 's' : ''} à cause d\'un voyage)' : ''}.',
          style: const TextStyle(color: AppColors.muted, fontSize: 13, height: 1.3)),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: FieldInfo(Hint.fieldVisitCount, child: TextField(
            controller: _visits,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Nombre de passages'),
            onChanged: (t) {
              final x = parseAmount(t);
              if (x == null) return;
              _edited = 'visits';
              _amount!.text = _fmt(x * c.amount);
            },
          )),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: FieldInfo(Hint.fieldInvoiceAmount, child: TextField(
            controller: _amount,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Montant de la facture', suffixText: '€'),
            onChanged: (t) {
              final x = parseAmount(t);
              if (x == null || c.amount <= 0) return;
              _edited = 'amount';
              _visits!.text = _fmt(x / c.amount);
            },
          )),
        ),
      ]),
      const SizedBox(height: 6),
      const Text('Modifiez l\'un : l\'autre se recalcule automatiquement.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5)),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Enregistrer',
          onPressed: () {
            if (_edited == 'amount') {
              final a = parseAmount(_amount!.text);
              if (a != null && a >= 0) n.setInvoiceOverride(c.id, widget.ym, amount: a);
            } else if (_edited == 'visits') {
              final x = parseAmount(_visits!.text);
              if (x != null && x >= 0) n.setInvoiceOverride(c.id, widget.ym, visits: x);
            }
            Navigator.pop(context);
          },
        ),
      ),
      if (v.overridden) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.restart_alt_rounded,
          label: 'Revenir au calcul automatique',
          onPressed: () {
            n.setInvoiceOverride(c.id, widget.ym);
            Navigator.pop(context);
          },
        ),
      ],
      if (c.isOneOff) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer cette facture ponctuelle',
          onPressed: () {
            n.removeClient(c.id);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}


/// Facture saisie à la main : un client (existant ou nouveau) et un montant, pour un seul mois.
/// Elle est enregistrée comme un client « ponctuel » actif uniquement ce mois-là.
class ManualInvoiceSheet extends ConsumerStatefulWidget {
  final Ym month;
  const ManualInvoiceSheet({super.key, required this.month});
  @override
  ConsumerState<ManualInvoiceSheet> createState() => _ManualInvoiceSheetState();
}

class _ManualInvoiceSheetState extends ConsumerState<ManualInvoiceSheet> {
  final _name = TextEditingController();
  final _amount = TextEditingController();
  int _owner = 1;
  bool _paid = false; // déjà payée : pointée dès la création

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final persons = [for (final p in [1, 2]) if (d.aeActive(p)) p];
    if (!persons.contains(_owner) && persons.isNotEmpty) _owner = persons.first;
    final names = <String>{for (final c in d.clients) if (!c.isOneOff) c.name}.toList()..sort();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Facture ponctuelle pour ${widget.month.longName.toLowerCase()}, en plus des automatiques.',
          style: const TextStyle(color: AppColors.muted, fontSize: 13, height: 1.3)),
      const SizedBox(height: 12),
      TextField(
        controller: _name,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(labelText: 'Client'),
      ),
      if (names.isNotEmpty) ...[
        const SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final nm in names.take(8))
            ActionChip(label: Text(nm), onPressed: () => setState(() => _name.text = nm)),
        ]),
      ],
      const SizedBox(height: 12),
      FieldInfo(Hint.fieldGross, child: TextField(
        controller: _amount,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'Montant (brut)', suffixText: '€'),
      )),
      if (persons.length > 1) ...[
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: TabSwitcher<int>(
            tabs: <({int value, String label, IconData? icon})>[
              for (final p in persons) (value: p, label: d.personName(p), icon: Icons.person_rounded),
            ],
            selected: _owner,
            onChanged: (p) => setState(() => _owner = p),
          ),
        ),
      ],
      const SizedBox(height: 8),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: labelWithInfo('Déjà payée', Hint.fieldPaid, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: const Text('Pointée dès maintenant : l\'argent est déjà sur ton compte.'),
        value: _paid,
        onChanged: (v) => setState(() => _paid = v),
      ),
      const SizedBox(height: 8),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Ajouter la facture',
          onPressed: () {
            final a = parseAmount(_amount.text);
            final nm = _name.text.trim();
            if (nm.isEmpty || a == null || a <= 0) {
              snack(context, 'Client et montant requis');
              return;
            }
            final amount = double.parse(a.toStringAsFixed(2));
            final newId = DateTime.now().microsecondsSinceEpoch.toString();
            final notifier = ref.read(appProvider.notifier);
            notifier.addClient(Client(
                  id: newId,
                  name: nm,
                  owner: _owner,
                  amount: amount,
                  kind: FreqKind.monthly,
                  times: 1,
                  start: widget.month,
                  end: widget.month,
                ));
            if (_paid) notifier.toggleInvoicePaid(newId, widget.month);
            Navigator.pop(context);
          },
        ),
      ),
    ]);
  }
}
