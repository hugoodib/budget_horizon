part of '../onboarding_screen.dart';

// ─── Fréquences disponibles ───────────────────────────────────────────────────
const _kFreqs = [1, 2, 3, 4, 6, 12];
String _freqLabel(int n) => switch (n) {
      1 => 'Chaque mois',
      2 => '1 mois sur 2',
      3 => 'Tous les 3 mois',
      4 => 'Tous les 4 mois',
      6 => 'Tous les 6 mois',
      12 => '1 fois par an',
      _ => 'Tous les $n mois',
    };

// ─── Suggestions « un clic » ──────────────────────────────────────────────────
class _Sugg {
  final IconData icon;
  final String name;
  const _Sugg(this.icon, this.name);
}

const _kIncomeSuggs = [
  _Sugg(Icons.work_outline_rounded, 'Salaire'),
  _Sugg(Icons.card_giftcard_rounded, 'Prime'),
  _Sugg(Icons.account_balance_rounded, 'Allocations'),
  _Sugg(Icons.payments_outlined, 'Pension'),
  _Sugg(Icons.home_outlined, 'Loyer perçu'),
  _Sugg(Icons.currency_exchange_rounded, 'Remboursement'),
];

const _kFixedSuggs = [
  _Sugg(Icons.home_outlined, 'Loyer'),
  _Sugg(Icons.bolt_rounded, 'Électricité'),
  _Sugg(Icons.wifi_rounded, 'Internet'),
  _Sugg(Icons.smartphone_rounded, 'Téléphone'),
  _Sugg(Icons.shield_outlined, 'Assurance'),
  _Sugg(Icons.health_and_safety_outlined, 'Mutuelle'),
  _Sugg(Icons.directions_transit_rounded, 'Transports'),
  _Sugg(Icons.subscriptions_outlined, 'Abonnements'),
  _Sugg(Icons.account_balance_outlined, 'Crédit'),
  _Sugg(Icons.water_drop_outlined, 'Eau'),
  _Sugg(Icons.fitness_center_rounded, 'Salle de sport'),
  _Sugg(Icons.receipt_long_outlined, 'Impôts'),
];

const _kBudgetSuggs = [
  _Sugg(Icons.shopping_basket_outlined, 'Courses'),
  _Sugg(Icons.local_gas_station_outlined, 'Essence'),
  _Sugg(Icons.sports_esports_outlined, 'Loisirs'),
  _Sugg(Icons.restaurant_outlined, 'Restaurants'),
  _Sugg(Icons.shopping_bag_outlined, 'Shopping'),
  _Sugg(Icons.medication_outlined, 'Santé'),
  _Sugg(Icons.directions_bus_outlined, 'Transports'),
  _Sugg(Icons.pets_outlined, 'Animaux'),
  _Sugg(Icons.card_giftcard_rounded, 'Cadeaux'),
];

// ─── Ligne de saisie ─────────────────────────────────────────────────────────
class _Line {
  final TextEditingController name;
  final TextEditingController amount;
  final FocusNode nameFocus = FocusNode();
  final FocusNode amountFocus = FocusNode();
  IconData icon;
  bool done = false; // déjà reçu / déjà débitée ce mois-ci
  bool showSpent = false; // budgets : champ « déjà dépensé » ouvert
  final TextEditingController spent = TextEditingController();
  bool isOneOff; // true = ponctuel
  int intervalMonths; // 1, 2, 3, 4, 6, 12
  Ym? startYm; // charges : null = commence ce mois-ci
  Ym? endYm; // charges : null = sans fin

  _Line({String n = '', String a = '', this.icon = Icons.sell_outlined, this.isOneOff = false, this.intervalMonths = 1})
      : name = TextEditingController(text: n),
        amount = TextEditingController(text: a);

  void dispose() {
    name.dispose();
    amount.dispose();
    spent.dispose();
    nameFocus.dispose();
    amountFocus.dispose();
  }
}

const _kLevels = [
  '',
  'Faisons connaissance',
  'Ton équipe',
  'Comment tu es payé(e)',
  'Ton point de départ',
  'Ce qui rentre',
  'Ce qui sort chaque mois',
  'Tes enveloppes',
  'Ton mois type',
];
const _kBadges = <IconData>[
  Icons.person_outline_rounded,
  Icons.people_outline_rounded,
  Icons.work_outline_rounded,
  Icons.account_balance_outlined,
  Icons.payments_outlined,
  Icons.home_outlined,
  Icons.shopping_basket_outlined,
  Icons.flag_outlined,
];
