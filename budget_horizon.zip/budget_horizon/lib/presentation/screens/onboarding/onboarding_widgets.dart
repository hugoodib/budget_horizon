part of '../onboarding_screen.dart';

/// Pastille de suggestion à toucher.
class _SuggChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  const _SuggChip({required this.icon, required this.label, required this.accent, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
          decoration: BoxDecoration(
            color: context.cardColor.withAlpha(context.isDark ? 255 : 220),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: tint(accent, .35), width: 1.2),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 18, color: accent),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            const SizedBox(width: 6),
            Icon(Icons.add_rounded, size: 16, color: context.mutedColor),
          ]),
        ),
      );
}

/// Confettis de célébration (une seule chute).
class _Confetti extends StatefulWidget {
  const _Confetti();
  @override
  State<_Confetti> createState() => _ConfettiState();
}

class _Piece {
  final double x, delay, speed, phase, size, spin;
  final Color color;
  _Piece(this.x, this.delay, this.speed, this.phase, this.size, this.spin, this.color);
}

class _ConfettiState extends State<_Confetti> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3200))..forward();
  late final List<_Piece> _pieces;

  @override
  void initState() {
    super.initState();
    final r = Random(7);
    _pieces = List.generate(
      70,
      (_) => _Piece(
        r.nextDouble(),
        r.nextDouble() * 0.35,
        0.75 + r.nextDouble() * 0.5,
        r.nextDouble() * 6.28,
        6 + r.nextDouble() * 7,
        r.nextDouble() * 6.28,
        AppColors.palette[r.nextInt(AppColors.palette.length)],
      ),
    );
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) => CustomPaint(painter: _ConfettiPainter(_pieces, _c.value)),
      );
}

class _ConfettiPainter extends CustomPainter {
  final List<_Piece> pieces;
  final double t;
  _ConfettiPainter(this.pieces, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in pieces) {
      final prog = ((t - p.delay) / (1 - p.delay)).clamp(0.0, 1.0);
      if (prog <= 0 || prog >= 1) continue;
      final y = -20 + prog * p.speed * (size.height + 40);
      final x = p.x * size.width + sin(prog * 8 + p.phase) * 22;
      final paint = Paint()..color = p.color.withAlpha(((1 - prog * prog) * 255).round());
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(p.spin + prog * 9);
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: p.size, height: p.size * .55),
            const Radius.circular(2)),
        paint,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => old.t != t;
}

/// Bouton principal des premiers pas : grand, lisible, facile à atteindre du pouce.
class _Cta extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  const _Cta({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) => Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: brandGradient,
          borderRadius: BorderRadius.circular(22),
          boxShadow: [BoxShadow(color: tint(AppColors.violet, .3), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: onPressed,
            child: Center(
              child: Text(label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w700, fontSize: 16.5)),
            ),
          ),
        ),
      );
}
