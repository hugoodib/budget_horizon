import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import '../domain/models.dart';
import '../domain/repository.dart';

class HiveRepository implements AppRepository {
  static const _boxName = 'budget_horizon';
  static const _key = 'data';
  final Box _box;
  HiveRepository._(this._box);

  static Future<HiveRepository> open() async {
    await Hive.initFlutter();
    return HiveRepository._(await Hive.openBox(_boxName));
  }

  @override
  AppData? load() {
    final raw = _box.get(_key) as String?;
    if (raw == null) return null;
    try {
      return AppData.fromJson(Map<String, dynamic>.from(jsonDecode(raw) as Map));
    } catch (_) {
      return null;
    }
  }

  @override
  Future<void> save(AppData data) => _box.put(_key, jsonEncode(data.toJson()));

  @override
  Future<void> clear() => _box.delete(_key);

  @override
  String? readMeta(String key) => _box.get('meta_$key') as String?;

  @override
  Future<void> writeMeta(String key, String? value) =>
      value == null ? _box.delete('meta_$key') : _box.put('meta_$key', value);
}
