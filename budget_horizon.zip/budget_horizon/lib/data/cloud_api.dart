import 'dart:convert';
import 'package:http/http.dart' as http;

class CloudException implements Exception {
  final String code;
  const CloudException(this.code);

  bool get isAuthInvalid => const {
        'TOKEN_EXPIRED',
        'INVALID_REFRESH_TOKEN',
        'USER_DISABLED',
        'USER_NOT_FOUND',
        'INVALID_ID_TOKEN',
        'CREDENTIAL_TOO_OLD_LOGIN_AGAIN',
      }.contains(code);

  String get message => switch (code) {
        'EMAIL_EXISTS' => 'Un compte existe déjà avec cet e-mail.',
        'INVALID_EMAIL' => 'Adresse e-mail invalide.',
        'WEAK_PASSWORD' => 'Mot de passe trop court (6 caractères minimum).',
        'EMAIL_NOT_FOUND' ||
        'INVALID_PASSWORD' ||
        'INVALID_LOGIN_CREDENTIALS' =>
          'E-mail ou mot de passe incorrect.',
        'USER_DISABLED' => 'Ce compte est désactivé.',
        'TOO_MANY_ATTEMPTS_TRY_LATER' => 'Trop de tentatives. Réessayez plus tard.',
        'OPERATION_NOT_ALLOWED' => 'La connexion par e-mail n\'est pas activée dans Firebase.',
        'MISSING_PASSWORD' => 'Saisissez un mot de passe.',
        'PERMISSION_DENIED' => 'Accès refusé : vérifiez les règles Firestore.',
        'OFFLINE' => 'Connexion impossible. Vérifiez votre réseau.',
        'SHARE_NOT_FOUND' => 'Code invalide : aucun budget partagé trouvé.',
        'SHARE_FULL' => 'Ce budget partagé est déjà utilisé par deux personnes.',
        _ => 'Erreur ($code).',
      };
}

class Session {
  final String uid;
  final String email;
  final String idToken;
  final String refreshToken;
  final DateTime expiresAt;
  final bool emailVerified;
  const Session({
    required this.uid,
    required this.email,
    required this.idToken,
    required this.refreshToken,
    required this.expiresAt,
    this.emailVerified = false,
  });

  bool get needsRefresh => DateTime.now().isAfter(expiresAt.subtract(const Duration(minutes: 2)));

  Session copyWith({bool? emailVerified}) => Session(
        uid: uid,
        email: email,
        idToken: idToken,
        refreshToken: refreshToken,
        expiresAt: expiresAt,
        emailVerified: emailVerified ?? this.emailVerified,
      );

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'email': email,
        'idToken': idToken,
        'refreshToken': refreshToken,
        'expiresAt': expiresAt.toIso8601String(),
        'emailVerified': emailVerified,
      };

  factory Session.fromJson(Map<String, dynamic> j) => Session(
        uid: j['uid'] as String,
        email: j['email'] as String,
        idToken: j['idToken'] as String,
        refreshToken: j['refreshToken'] as String,
        expiresAt: DateTime.parse(j['expiresAt'] as String),
        emailVerified: j['emailVerified'] == true,
      );
}

class CloudDoc {
  final String data;
  final DateTime updatedAt;
  final List<String> members; // uniquement pour les budgets partagés
  const CloudDoc(this.data, this.updatedAt, [this.members = const []]);
}

/// Accès direct aux API REST de Firebase (Authentication + Firestore).
///
/// Firestore :
///  - users/{uid}    : données personnelles + éventuel shareId
///  - shares/{code}  : budget partagé entre deux comptes (liste `members`)
class CloudApi {
  final String apiKey;
  final String projectId;
  const CloudApi(this.apiKey, this.projectId);

  static const _idt = 'https://identitytoolkit.googleapis.com/v1';

  Map<String, dynamic> _decode(http.Response r) {
    try {
      return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }

  String _code(Map<String, dynamic> j) {
    final e = j['error'];
    if (e is Map) {
      final first = (e['message'] ?? '').toString().split(RegExp(r'[ :]')).first;
      if (RegExp(r'^[A-Z_]+$').hasMatch(first)) return first;
      final st = (e['status'] ?? '').toString();
      if (st.isNotEmpty) return st;
    }
    return 'UNKNOWN';
  }

  // ---------------- Authentication ----------------
  Future<Session> signUp(String email, String password) => _auth('accounts:signUp', email, password);
  Future<Session> signIn(String email, String password) =>
      _auth('accounts:signInWithPassword', email, password);

  Future<Session> _auth(String path, String email, String password) async {
    final r = await http.post(
      Uri.parse('$_idt/$path?key=$apiKey'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password, 'returnSecureToken': true}),
    );
    final j = _decode(r);
    if (r.statusCode != 200) throw CloudException(_code(j));
    return Session(
      uid: j['localId'] as String,
      email: (j['email'] ?? email) as String,
      idToken: j['idToken'] as String,
      refreshToken: j['refreshToken'] as String,
      expiresAt: DateTime.now().add(Duration(seconds: int.parse(j['expiresIn'].toString()))),
    );
  }

  Future<Session> refresh(Session s) async {
    final r = await http.post(
      Uri.parse('https://securetoken.googleapis.com/v1/token?key=$apiKey'),
      body: {'grant_type': 'refresh_token', 'refresh_token': s.refreshToken},
    );
    final j = _decode(r);
    if (r.statusCode != 200) throw CloudException(_code(j));
    return Session(
      uid: s.uid,
      email: s.email,
      idToken: j['id_token'] as String,
      refreshToken: (j['refresh_token'] ?? s.refreshToken) as String,
      expiresAt: DateTime.now().add(Duration(seconds: int.parse(j['expires_in'].toString()))),
      emailVerified: s.emailVerified,
    );
  }

  Future<void> sendPasswordReset(String email) => _oob({'requestType': 'PASSWORD_RESET', 'email': email});

  /// Envoie l'e-mail de confirmation d'adresse.
  Future<void> sendVerification(String idToken) =>
      _oob({'requestType': 'VERIFY_EMAIL', 'idToken': idToken});

  Future<void> _oob(Map<String, dynamic> body) async {
    final r = await http.post(
      Uri.parse('$_idt/accounts:sendOobCode?key=$apiKey'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );
    if (r.statusCode != 200) throw CloudException(_code(_decode(r)));
  }

  /// L'adresse e-mail est-elle confirmée ?
  Future<bool> isEmailVerified(String idToken) async {
    final r = await http.post(
      Uri.parse('$_idt/accounts:lookup?key=$apiKey'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({'idToken': idToken}),
    );
    final j = _decode(r);
    if (r.statusCode != 200) throw CloudException(_code(j));
    final users = j['users'];
    if (users is List && users.isNotEmpty) {
      return (users.first as Map)['emailVerified'] == true;
    }
    return false;
  }

  /// Supprime le compte d'authentification (les documents doivent l'être avant).
  Future<void> deleteAccount(String idToken) async {
    final r = await http.post(
      Uri.parse('$_idt/accounts:delete?key=$apiKey'),
      headers: const {'Content-Type': 'application/json'},
      body: jsonEncode({'idToken': idToken}),
    );
    if (r.statusCode != 200) throw CloudException(_code(_decode(r)));
  }

  // ---------------- Firestore ----------------
  Uri _uri(String path, [List<String> mask = const []]) {
    final q = mask.isEmpty ? '' : '?${mask.map((m) => 'updateMask.fieldPaths=$m').join('&')}';
    return Uri.parse(
        'https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/$path$q');
  }

  Map<String, String> _h(Session s, {bool json = false}) => {
        'Authorization': 'Bearer ${s.idToken}',
        if (json) 'Content-Type': 'application/json',
      };

  String _path(Session s, String? shareId) => shareId != null ? 'shares/$shareId' : 'users/${s.uid}';

  Map<String, dynamic> _str(String v) => {'stringValue': v};

  /// Données de l'utilisateur (ou du budget partagé), null si le document n'existe pas.
  Future<CloudDoc?> loadDoc(Session s, {String? shareId}) async {
    final r = await http.get(_uri(_path(s, shareId)), headers: _h(s));
    if (r.statusCode == 404) return null;
    final j = _decode(r);
    if (r.statusCode != 200) throw CloudException(_code(j));
    final f = (j['fields'] ?? {}) as Map;
    final data = (f['data'] as Map?)?['stringValue'] as String?;
    final ts = (f['updatedAt'] as Map?)?['stringValue'] as String?;
    final vals = ((f['members'] as Map?)?['arrayValue'] as Map?)?['values'];
    final members = vals is List
        ? vals.map((e) => (e as Map)['stringValue'] as String).toList()
        : <String>[];
    if (data == null) return null;
    return CloudDoc(
      data,
      DateTime.tryParse(ts ?? '') ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
      members,
    );
  }

  Future<void> saveDoc(Session s, String data, DateTime updatedAt, {String? shareId}) async {
    final r = await http.patch(
      _uri(_path(s, shareId), const ['data', 'updatedAt']),
      headers: _h(s, json: true),
      body: jsonEncode({
        'fields': {'data': _str(data), 'updatedAt': _str(updatedAt.toUtc().toIso8601String())},
      }),
    );
    if (r.statusCode != 200) throw CloudException(_code(_decode(r)));
  }

  /// Code de partage éventuel enregistré dans le document personnel.
  Future<String?> loadUserShareId(Session s) async {
    final r = await http.get(_uri('users/${s.uid}'), headers: _h(s));
    if (r.statusCode == 404) return null;
    final j = _decode(r);
    if (r.statusCode != 200) throw CloudException(_code(j));
    final f = (j['fields'] ?? {}) as Map;
    final v = (f['shareId'] as Map?)?['stringValue'] as String?;
    return (v == null || v.isEmpty) ? null : v;
  }

  Future<void> setUserShareId(Session s, String? shareId) async {
    final r = await http.patch(
      _uri('users/${s.uid}', const ['shareId']),
      headers: _h(s, json: true),
      body: jsonEncode({
        'fields': shareId == null ? <String, dynamic>{} : {'shareId': _str(shareId)},
      }),
    );
    if (r.statusCode != 200) throw CloudException(_code(_decode(r)));
  }

  Future<void> createShare(Session s, String code, String data, DateTime updatedAt) async {
    final r = await http.patch(
      _uri('shares/$code'),
      headers: _h(s, json: true),
      body: jsonEncode({
        'fields': {
          'data': _str(data),
          'updatedAt': _str(updatedAt.toUtc().toIso8601String()),
          'members': {
            'arrayValue': {
              'values': [_str(s.uid)],
            },
          },
        },
      }),
    );
    if (r.statusCode != 200) throw CloudException(_code(_decode(r)));
  }

  Future<void> setShareMembers(Session s, String code, List<String> members) async {
    final r = await http.patch(
      _uri('shares/$code', const ['members']),
      headers: _h(s, json: true),
      body: jsonEncode({
        'fields': {
          'members': {
            'arrayValue': {
              'values': [for (final m in members) _str(m)],
            },
          },
        },
      }),
    );
    if (r.statusCode != 200) throw CloudException(_code(_decode(r)));
  }

  Future<void> deleteDoc(Session s, String path) async {
    final r = await http.delete(_uri(path), headers: _h(s));
    if (r.statusCode != 200 && r.statusCode != 404) throw CloudException(_code(_decode(r)));
  }
}
