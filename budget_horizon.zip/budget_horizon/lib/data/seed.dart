import 'package:flutter/material.dart' show Color;
import '../core/theme.dart';
import '../core/ym.dart';
import '../domain/models.dart';

/// Données de démonstration (correspondent aux exemples du cahier des charges).
class SeedData {
  /// [onboarded] = false : l'assistant de configuration s'affichera au premier lancement.
  static AppData create(Ym now, {bool onboarded = false}) {
    Category cat(String id, String name, String emoji, Color c) =>
        Category(id: id, name: name, emoji: emoji, colorValue: c.value);
    final cats = [
      cat('courses', 'Courses', '🥕', const Color(0xFF34C759)),
      cat('restaurant', 'Restaurant', '🍕', const Color(0xFFFF9F0A)),
      cat('essence', 'Essence', '⛽', const Color(0xFF0A84FF)),
      cat('loisirs', 'Loisirs', '🎮', const Color(0xFFBF5AF2)),
    ];
    const amounts = {'courses': 350.0, 'restaurant': 150.0, 'essence': 120.0, 'loisirs': 100.0};
    return AppData(
      user: UserProfile(id: 'local', name: 'Moi', onboarded: onboarded),
      startYm: now,
      startBalance: 985, // -> solde actuel 2 320 € avec salaire 2 000 € et charges 665 €
      categories: cats,
      budgets: [
        for (final c in cats) Budget(id: 'b_${c.id}', categoryId: c.id, amount: amounts[c.id]!),
      ],
      transactions: const [],
      recurringIncomes: [
        RecurringIncome(id: 'salary', label: 'Salaire', amount: 2000, start: now),
      ],
      incomes: const [],
      fixedExpenses: [
        FixedExpense(id: 'loyer', name: 'Loyer', amount: 650, start: now),
        const FixedExpense(
            id: 'netflix', name: 'Netflix', amount: 15, start: Ym(2026, 1), end: Ym(2027, 3)),
      ],
      projects: [
        Project(
          id: 'thailande',
          name: 'Voyage Thaïlande',
          target: 5000,
          startYm: now,
          targetYm: const Ym(2027, 3),
        ),
      ],
      snapshots: const {},
    );
  }

  /// Remplace les anciens styles par défaut (emoji ternes, couleurs pâles) par des styles
  /// vifs, uniquement pour les catégories d'origine restées inchangées.
  static AppData upgradeStyles(AppData d) {
    const oldStyle = {
      'courses': ('🛒', {0xFF4F8CFF, 0xFF6C8DF0}, '🥕', 0xFF34C759),
      'restaurant': ('🍽️', {0xFF8B6CF6, 0xFF9E8DF3}, '🍕', 0xFFFF9F0A),
      'essence': ('⛽', {0xFF2DD4BF, 0xFF6FD3BE}, '⛽', 0xFF0A84FF),
      'loisirs': ('🎬', {0xFFEC6FA8}, '🎮', 0xFFBF5AF2),
    };
    var changed = false;
    final cats = d.categories.map((c) {
      final o = oldStyle[c.id];
      if (o != null && c.emoji == o.$1 && o.$2.contains(c.colorValue)) {
        changed = true;
        return Category(id: c.id, name: c.name, emoji: o.$3, colorValue: o.$4);
      }
      return c;
    }).toList();
    return changed ? d.copyWith(categories: cats) : d;
  }
}
