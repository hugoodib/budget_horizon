import '../core/ym.dart';
import '../domain/models.dart';

/// Données de départ de l'app.
class SeedData {
  /// Données vides — utilisées si l'utilisateur décide de ne pas voir la démo.
  static AppData empty(Ym now) => AppData(
        user: UserProfile(id: 'local', name: 'Hugo', onboarded: false, tourSeen: false),
        startYm: now,
        startBalance: 0,
        categories: const [],
        budgets: const [],
        transactions: const [],
        recurringIncomes: const [],
        incomes: const [],
        fixedExpenses: const [],
        projects: const [],
        snapshots: const {},
      );

  /// Données d'exemple réalistes — montrées au premier lancement pour que l'utilisateur
  /// comprenne immédiatement à quoi ressemble une app bien configurée.
  /// isDemo = true : un bandeau "Mode démo" apparaît avec le bouton "Tout effacer".
  static AppData create(Ym now, {bool onboarded = false}) {
    final catCourses = Category(id: 'courses', name: 'Courses', emoji: '🥕', colorValue: 0xFF34C759);
    final catResto   = Category(id: 'restaurant', name: 'Restaurant', emoji: '🍕', colorValue: 0xFFFF9F0A);
    final catEssence = Category(id: 'essence', name: 'Essence', emoji: '⛽', colorValue: 0xFF0A84FF);
    final catLoisirs = Category(id: 'loisirs', name: 'Loisirs', emoji: '🎮', colorValue: 0xFFBF5AF2);

    final budgetCourses = Budget(id: 'b_courses', categoryId: 'courses', person: 0,
        amount: 350, overrides: const {});
    final budgetResto   = Budget(id: 'b_resto', categoryId: 'restaurant', person: 0,
        amount: 150, overrides: const {});
    final budgetEssence = Budget(id: 'b_essence', categoryId: 'essence', person: 0,
        amount: 120, overrides: const {});
    final budgetLoisirs = Budget(id: 'b_loisirs', categoryId: 'loisirs', person: 0,
        amount: 200, overrides: const {});

    final salary = RecurringIncome(
        id: 'ri_salaire', label: 'Salaire', amount: 2800,
        start: now.add(-2), intervalMonths: 1);
    final loyer  = FixedExpense(
        id: 'fe_loyer', name: 'Loyer', amount: 750,
        start: now.add(-2), intervalMonths: 1);
    final elec   = FixedExpense(
        id: 'fe_elec', name: 'Électricité', amount: 65,
        start: now.add(-2), intervalMonths: 1);
    final phone  = FixedExpense(
        id: 'fe_phone', name: 'Téléphone', amount: 20,
        start: now.add(-2), intervalMonths: 1);

    // Quelques dépenses du mois en cours
    final d1 = now.firstDay;
    final txs = [
      Transaction(id: 'tx1', categoryId: 'courses',    description: 'Carrefour',     amount: 87.50, date: d1.add(const Duration(days: 1)),  person: 0, checked: true),
      Transaction(id: 'tx2', categoryId: 'restaurant', description: 'Casa Norma',    amount: 52.00, date: d1.add(const Duration(days: 3)),  person: 0, checked: true),
      Transaction(id: 'tx3', categoryId: 'essence',    description: 'Total',         amount: 68.00, date: d1.add(const Duration(days: 5)),  person: 0, checked: false),
      Transaction(id: 'tx4', categoryId: 'courses',    description: 'Lidl',          amount: 43.20, date: d1.add(const Duration(days: 7)),  person: 0, checked: true),
      Transaction(id: 'tx5', categoryId: 'loisirs',    description: 'Netflix',       amount: 15.99, date: d1.add(const Duration(days: 2)),  person: 0, checked: true),
      Transaction(id: 'tx6', categoryId: 'loisirs',    description: 'Cinéma',        amount: 22.00, date: d1.add(const Duration(days: 9)),  person: 0, checked: false),
      Transaction(id: 'tx7', categoryId: 'restaurant', description: 'Burger King',   amount: 18.50, date: d1.add(const Duration(days: 11)), person: 0, checked: false),
      Transaction(id: 'tx8', categoryId: 'courses',    description: 'Monoprix',      amount: 31.80, date: d1.add(const Duration(days: 13)), person: 0, checked: false),
    ];

    final project = Project(
        id: 'proj_thailand', name: 'Thaïlande', isTrip: true,
        target: 3000, targetYm: now.add(8), mode: ProjectMode.savings,
        contributions: const {}, startYm: now);

    return AppData(
      user: UserProfile(
          id: 'local', name: 'Hugo',
          onboarded: onboarded, tourSeen: false,
          isDemo: true),  // flag démo
      startYm: now,
      startBalance: 1240,
      categories: [catCourses, catResto, catEssence, catLoisirs],
      budgets: [budgetCourses, budgetResto, budgetEssence, budgetLoisirs],
      transactions: txs,
      recurringIncomes: [salary],
      incomes: const [],
      fixedExpenses: [loyer, elec, phone],
      projects: [project],
      snapshots: const {},
    );
  }

  /// Remplace les anciens styles par défaut (emoji ternes, couleurs pâles) par des styles
  /// vifs, uniquement pour les catégories d'origine restées inchangées.
  static AppData upgradeStyles(AppData d) {
    const oldStyle = {
      'courses': ('🛒', {0xFF4F8CFF, 0xFF6C8DF0}, '🥕', 0xFF34C759),
      'restaurant': ('🍽️', {0xFF8B6CF6, 0xFF9E8DF3}, '🍕', 0xFFFF9F0A),
      'essence': ('⛽', {0xFF2DD4BF, 0xFF6FD3BE}, '⛽', 0xFF0A84FF),
      'loisirs': ('🎬', {0xFFEC6FA8}, '🎮', 0xFFBF5AF2),
    };
    var changed = false;
    final cats = d.categories.map((c) {
      final o = oldStyle[c.id];
      if (o != null && c.emoji == o.$1 && o.$2.contains(c.colorValue)) {
        changed = true;
        return Category(id: c.id, name: c.name, emoji: o.$3, colorValue: o.$4);
      }
      return c;
    }).toList();
    return changed ? d.copyWith(categories: cats) : d;
  }
}
