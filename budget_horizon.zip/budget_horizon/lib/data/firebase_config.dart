/// Configuration Firebase (projet « Horizon »).
/// La clé API web de Firebase n'est pas secrète : elle identifie le projet, ce sont
/// les règles Firestore qui protègent les données. Elle peut être remplacée à la
/// compilation avec --dart-define=FIREBASE_API_KEY=... --dart-define=FIREBASE_PROJECT_ID=...
class FirebaseConfig {
  static const apiKey = String.fromEnvironment(
    'FIREBASE_API_KEY',
    defaultValue: 'AIzaSyDG6UDGKCmQK-TsAuAzLcNfJnVe_GUSWso',
  );
  static const projectId = String.fromEnvironment(
    'FIREBASE_PROJECT_ID',
    defaultValue: 'horizon-5cb74',
  );
  static bool get enabled => apiKey.isNotEmpty && projectId.isNotEmpty;
}
