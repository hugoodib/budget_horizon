import 'dart:convert';
import 'package:http/http.dart' as http;

/// Compréhension des phrases de l'assistant par Google Gemini (offre gratuite).
/// Gemini voit un résumé du budget (soldes, catégories, charges, projets) pour pouvoir
/// répondre à n'importe quelle question, en plus de comprendre les saisies.
class Gemini {
  static const model = 'gemini-2.5-flash';
  static const metaKey = 'gemini_key';

  /// Raison du dernier échec (affichée à l'utilisateur).
  static String lastError = '';

  /// Analyse [text] et renvoie un dictionnaire (voir le prompt), ou null en cas d'échec
  /// (pas de réseau, quota dépassé, clé invalide, réponse illisible).
  static Future<Map<String, dynamic>?> parse({
    required String apiKey,
    required String text,
    required List<String> categories,
    required List<String> projects,
    required List<String> people,
    required DateTime today,
    String context = '',
    List<(bool, String)> history = const [],
  }) async {
    final conv = history.isEmpty
        ? ''
        : '\nÉchange récent :\n${history.map((m) => '${m.$1 ? 'Utilisateur' : 'Assistant'} : ${m.$2}').join('\n')}\n';
    final prompt = '''
Tu es l'assistant personnel d'une appli de budget française. Tu es libre, utile, direct et chaleureux :
tu peux répondre à toute question (sur son budget, l'épargne, les impôts, l'auto-entreprise, un achat, la vie de tous les jours...),
donner des conseils, faire des calculs, et aussi enregistrer des opérations quand l'utilisateur le demande.
Appuie-toi sur les données du budget ci-dessous quand c'est pertinent, sans inventer de chiffres.
Date du jour : ${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}.
Catégories de dépenses existantes : ${categories.isEmpty ? 'aucune' : categories.join(', ')}.
Projets / voyages existants : ${projects.isEmpty ? 'aucun' : projects.join(', ')}.
Personnes : ${people.isEmpty ? 'une seule' : people.join(', ')}.

Données du budget :
$context
$conv
Réponds UNIQUEMENT par un objet JSON avec ces clés (null si inconnu) :
- "reply" : ta réponse en français, naturelle, claire, sans markdown lourd (texte simple, courtes phrases, retours à la ligne autorisés). Obligatoire si ce n'est pas une saisie ; pour une saisie, mets null.
- "kind" : si l'utilisateur veut ENREGISTRER quelque chose : "expense" (dépense ponctuelle), "income" (revenu ponctuel), "recurring_income" (revenu régulier),
  "fixed" (charge fixe récurrente : loyer, abonnement...), "budget" (créer une enveloppe mensuelle). Sinon "other".
- "amount" : nombre en euros (ex. 23.5).
- "category" : pour une dépense, le nom EXACT d'une catégorie existante la plus proche, "Imprévu" si c'est un imprévu, ou le nom exact d'un projet/voyage s'il s'agit de ce voyage ; null sinon.
- "label" : courte description ou nom (ex. "McDo", "Loyer", "Prime"), commençant par une majuscule.
- "date" : AAAA-MM-JJ pour une dépense (« hier » = veille de la date du jour).
- "month" : AAAA-MM pour un revenu ou une charge (mois concerné ou de départ), sinon null.
- "interval_months" : 1 par défaut, 12 si annuel, N si « tous les N mois ».
- "person" : prénom exact de la personne qui a payé si cité, sinon null.
- "income_kind" : "salary", "bonus", "refund" ou "sale" pour un revenu.

Phrase de l'utilisateur : ${jsonEncode(text)}
''';
    try {
      final res = await http
          .post(
            Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent'),
            headers: {'Content-Type': 'application/json', 'x-goog-api-key': apiKey},
            body: jsonEncode({
              'contents': [
                {
                  'parts': [
                    {'text': prompt}
                  ]
                }
              ],
              'generationConfig': {'temperature': 0, 'responseMimeType': 'application/json'},
            }),
          )
          .timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) {
        lastError = switch (res.statusCode) {
          400 || 401 || 403 => 'clé refusée par Google (vérifie-la dans les paramètres)',
          404 => 'modèle introuvable',
          429 => 'quota gratuit atteint, réessaie dans un instant',
          _ => 'erreur Google ${res.statusCode}',
        };
        return null;
      }
      final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final out = body['candidates']?[0]?['content']?['parts']?[0]?['text'];
      if (out is! String) {
        lastError = 'réponse vide';
        return null;
      }
      final json = jsonDecode(out);
      if (json is Map<String, dynamic>) return json;
      lastError = 'réponse illisible';
      return null;
    } catch (_) {
      lastError = 'pas de connexion ou délai dépassé';
      return null;
    }
  }
}
