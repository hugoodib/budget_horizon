import 'package:flutter/material.dart' show Color;
import '../core/theme.dart';
import '../core/ym.dart';
import '../domain/models.dart';

class NamedAmount {
  final String name;
  final double amount;
  const NamedAmount(this.name, this.amount);
}

/// Réponses saisies dans l'assistant de configuration.
class OnboardingAnswers {
  final String firstName;
  final String lastName;
  final bool isCouple;
  final String partnerName;
  final double currentBalance;
  final List<NamedAmount> incomes; // récurrents (salaires...)
  final List<NamedAmount> fixed; // charges fixes
  final List<NamedAmount> budgets; // par catégorie (par personne en couple)
  final bool ae1; // la personne 1 est auto-entrepreneur
  final bool ae2; // le conjoint est auto-entrepreneur
  final double urssaf; // taux de charges URSSAF (%)
  const OnboardingAnswers({
    required this.firstName,
    required this.lastName,
    required this.isCouple,
    required this.partnerName,
    required this.currentBalance,
    required this.incomes,
    required this.fixed,
    required this.budgets,
    this.ae1 = false,
    this.ae2 = false,
    this.urssaf = 23.68,
  });
}

class OnboardingBuilder {
  static String emojiFor(String name) {
    final n = name.toLowerCase();
    if (n.contains('cours') || n.contains('aliment') || n.contains('super')) return '🥕';
    if (n.contains('resto') || n.contains('restaurant')) return '🍕';
    if (n.contains('essence') || n.contains('carbur') || n.contains('voiture')) return '⛽';
    if (n.contains('transport')) return '🚌';
    if (n.contains('loisir') || n.contains('sortie')) return '🎮';
    if (n.contains('sant') || n.contains('pharma')) return '💊';
    if (n.contains('v\u00eatement') || n.contains('vetement') || n.contains('shopping')) return '👗';
    return '💰';
  }

  static AppData build(OnboardingAnswers a, Ym now, String userId) {
    final full = [a.firstName.trim(), a.lastName.trim()].where((e) => e.isNotEmpty).join(' ');
    final totalIncome = a.incomes.fold(0.0, (s, e) => s + e.amount);
    final totalFixed = a.fixed.fold(0.0, (s, e) => s + e.amount);

    final categories = <Category>[];
    final budgets = <Budget>[];
    for (var i = 0; i < a.budgets.length; i++) {
      final b = a.budgets[i];
      // Couple : budgets communs, sauf « Loisirs » (un par personne) ; modifiable ensuite
      final persons = (a.isCouple && b.name.toLowerCase().contains('loisir')) ? [1, 2] : [0];
      final cid = 'c$i';
      final Color color = AppColors.palette[i % AppColors.palette.length];
      categories.add(Category(id: cid, name: b.name, emoji: emojiFor(b.name), colorValue: color.value));
      for (final p in persons) {
        budgets.add(Budget(id: '${cid}_b$p', categoryId: cid, amount: b.amount, person: p));
      }
    }

    return AppData(
      user: UserProfile(
        id: userId,
        name: full.isEmpty ? 'Moi' : full,
        isCouple: a.isCouple,
        person1: a.firstName.trim().isEmpty ? 'Moi' : a.firstName.trim(),
        person2: a.partnerName.trim().isEmpty ? 'Conjoint' : a.partnerName.trim(),
        onboarded: true,
        ae1: a.ae1,
        ae2: a.isCouple && a.ae2,
        urssafRate: a.urssaf,
        tourSeen: false, // la démonstration guidée démarre après la configuration
      ),
      startYm: now,
      // Le solde actuel affiché = départ + revenus - charges (aucune dépense saisie au départ).
      startBalance: a.currentBalance - totalIncome + totalFixed,
      categories: categories,
      budgets: budgets,
      transactions: const [],
      recurringIncomes: [
        for (var i = 0; i < a.incomes.length; i++)
          RecurringIncome(id: 'inc$i', label: a.incomes[i].name, amount: a.incomes[i].amount, start: now),
      ],
      incomes: const [],
      fixedExpenses: [
        for (var i = 0; i < a.fixed.length; i++)
          FixedExpense(id: 'fx$i', name: a.fixed[i].name, amount: a.fixed[i].amount, start: now),
      ],
      projects: const [],
      snapshots: const {},
    );
  }
}
