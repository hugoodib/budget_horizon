import 'package:flutter/material.dart' show Color;
import '../core/theme.dart';
import '../core/ym.dart';
import '../domain/models.dart';

/// Une ligne saisie pendant l'onboarding (revenu ou charge fixe).
///
/// [isOneOff] = true  → revenu ponctuel (Income) ou charge ponctuelle supprimée après un mois
/// [intervalMonths]   → fréquence pour les récurrents (1 = chaque mois, 2 = un sur deux, etc.)
/// [oneOffYm]         → mois concerné si ponctuel (null = mois actuel)
class OnboardingEntry {
  final String name;
  final double amount;
  final bool isOneOff;
  final int intervalMonths; // ignoré si isOneOff
  final Ym? oneOffYm; // ignoré si !isOneOff
  const OnboardingEntry(
    this.name,
    this.amount, {
    this.isOneOff = false,
    this.intervalMonths = 1,
    this.oneOffYm,
  });
}

// Alias de compatibilité pour les budgets (toujours récurrents sans fréquence spéciale)
typedef NamedAmount = OnboardingEntry;

/// Réponses saisies dans l'assistant de configuration.
class OnboardingAnswers {
  final String firstName;
  final String lastName;
  final bool isCouple;
  final String partnerName;
  final double currentBalance;
  final List<OnboardingEntry> incomes;
  final List<OnboardingEntry> fixed;
  final List<OnboardingEntry> budgets;
  final bool ae1;
  final bool ae2;
  final double urssaf;
  const OnboardingAnswers({
    required this.firstName,
    required this.lastName,
    required this.isCouple,
    required this.partnerName,
    required this.currentBalance,
    required this.incomes,
    required this.fixed,
    required this.budgets,
    this.ae1 = false,
    this.ae2 = false,
    this.urssaf = 23.68,
  });
}

class OnboardingBuilder {
  static String emojiFor(String name) {
    final n = name.toLowerCase();
    if (n.contains('cours') || n.contains('aliment') || n.contains('super')) return '🥕';
    if (n.contains('resto') || n.contains('restaurant')) return '🍕';
    if (n.contains('essence') || n.contains('carbur') || n.contains('voiture')) return '⛽';
    if (n.contains('transport')) return '🚌';
    if (n.contains('loisir') || n.contains('sortie')) return '🎮';
    if (n.contains('sant') || n.contains('pharma')) return '💊';
    if (n.contains('v\u00eatement') || n.contains('vetement') || n.contains('shopping')) return '👗';
    return '💰';
  }

  static AppData build(OnboardingAnswers a, Ym now, String userId) {
    final full = [a.firstName.trim(), a.lastName.trim()].where((e) => e.isNotEmpty).join(' ');

    // ── Revenus ──────────────────────────────────────────────────────────────
    final recurringIncomes = <RecurringIncome>[];
    final oneOffIncomes = <Income>[];
    for (var i = 0; i < a.incomes.length; i++) {
      final e = a.incomes[i];
      if (e.isOneOff) {
        oneOffIncomes.add(Income(
          id: 'inc_o$i',
          kind: IncomeKind.salary,
          label: e.name,
          amount: e.amount,
          ym: e.oneOffYm ?? now,
        ));
      } else {
        recurringIncomes.add(RecurringIncome(
          id: 'inc$i',
          label: e.name,
          amount: e.amount,
          start: now,
          intervalMonths: e.intervalMonths,
        ));
      }
    }

    // ── Charges fixes ────────────────────────────────────────────────────────
    final fixedExpenses = <FixedExpense>[];
    for (var i = 0; i < a.fixed.length; i++) {
      final e = a.fixed[i];
      fixedExpenses.add(FixedExpense(
        id: 'fx$i',
        name: e.name,
        amount: e.amount,
        start: now,
        // ponctuel = se termine le même mois (1 mois actif uniquement)
        end: e.isOneOff ? now : null,
        intervalMonths: e.isOneOff ? 1 : e.intervalMonths,
      ));
    }

    // ── Calcul du solde de départ ────────────────────────────────────────────
    // On tient compte uniquement des récurrents actifs ce mois-ci pour le solde initial
    final totalRecurringIncome =
        recurringIncomes.fold(0.0, (s, r) => r.activeIn(now) ? s + r.amount : s);
    final totalOneOffIncome =
        oneOffIncomes.where((o) => o.ym == now).fold(0.0, (s, o) => s + o.amount);
    final totalIncome = totalRecurringIncome + totalOneOffIncome;
    final totalFixed =
        fixedExpenses.fold(0.0, (s, f) => f.activeIn(now) ? s + f.amount : s);

    // ── Budgets ──────────────────────────────────────────────────────────────
    final categories = <Category>[];
    final budgets = <Budget>[];
    for (var i = 0; i < a.budgets.length; i++) {
      final b = a.budgets[i];
      final persons =
          (a.isCouple && b.name.toLowerCase().contains('loisir')) ? [1, 2] : [0];
      final cid = 'c$i';
      final Color color = AppColors.palette[i % AppColors.palette.length];
      categories
          .add(Category(id: cid, name: b.name, emoji: emojiFor(b.name), colorValue: color.value));
      for (final p in persons) {
        budgets.add(Budget(id: '${cid}_b$p', categoryId: cid, amount: b.amount, person: p));
      }
    }

    return AppData(
      user: UserProfile(
        id: userId,
        name: full.isEmpty ? 'Moi' : full,
        isCouple: a.isCouple,
        person1: a.firstName.trim().isEmpty ? 'Moi' : a.firstName.trim(),
        person2: a.partnerName.trim().isEmpty ? 'Conjoint' : a.partnerName.trim(),
        onboarded: true,
        ae1: a.ae1,
        ae2: a.isCouple && a.ae2,
        urssafRate: a.urssaf,
        tourSeen: false,
      ),
      startYm: now,
      startBalance: a.currentBalance - totalIncome + totalFixed,
      categories: categories,
      budgets: budgets,
      transactions: const [],
      recurringIncomes: recurringIncomes,
      incomes: oneOffIncomes,
      fixedExpenses: fixedExpenses,
      projects: const [],
      snapshots: const {},
    );
  }
}
