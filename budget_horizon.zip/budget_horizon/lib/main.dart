import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme.dart';
import 'data/hive_repository.dart';
import 'presentation/providers.dart';
import 'presentation/screens/auth_screen.dart';
import 'presentation/widgets/common.dart';
import 'presentation/widgets/tour_overlay.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repo = await HiveRepository.open();
  runApp(ProviderScope(
    overrides: [repositoryProvider.overrideWithValue(repo)],
    child: const BudgetHorizonApp(),
  ));
}

/// Défilement "iOS" partout : rebond, pas d'effet d'étirement Android.
class _AppScrollBehavior extends MaterialScrollBehavior {
  const _AppScrollBehavior();
  @override
  Set<PointerDeviceKind> get dragDevices => {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.trackpad,
        PointerDeviceKind.stylus,
      };
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) =>
      const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) => child;
}

class BudgetHorizonApp extends ConsumerWidget {
  const BudgetHorizonApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scale = ref.watch(appProvider.select((d) => d.user.uiScale));
    return MaterialApp(
      title: 'Budget Horizon',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('fr'),
      supportedLocales: const [Locale('fr')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      scrollBehavior: const _AppScrollBehavior(),
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(mq.textScaler.scale(1.0) * scale)),
          child: AppBackground(
            // La couche de démonstration guidée recouvre toute l'app (et n'apparaît que si active).
            child: Stack(fit: StackFit.expand, children: [
              child ?? const SizedBox.shrink(),
              const TourLayer(),
            ]),
          ),
        );
      },
      home: const AuthGate(),
    );
  }
}
