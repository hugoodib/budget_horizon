import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const bg = Color(0xFFF3F3FB);
  static const text = Color(0xFF12172B);
  static const muted = Color(0xFF7D8298);
  static const track = Color(0xFFE3E5EB);
  static const blue = Color(0xFF6C8DF0);
  static const violet = Color(0xFF9E8DF3);
  static const teal = Color(0xFF6FD3BE);
  static const pink = Color(0xFFF08CA6);
  static const success = Color(0xFF3CBFA0);
  static const warning = Color(0xFFF59E0B);
  static const danger = Color(0xFFEF6B7E);
  static const field = Color(0xFFF1F2F9);
  /// Couleurs vives pour les catégories (bien distinctes les unes des autres).
  static const palette = [
    Color(0xFF34C759), // vert
    Color(0xFFFF9F0A), // orange
    Color(0xFF0A84FF), // bleu
    Color(0xFFBF5AF2), // violet
    Color(0xFFFF5FA2), // rose
    Color(0xFFFF5252), // rouge
    Color(0xFF14B8A6), // turquoise
    Color(0xFFFFCC00), // jaune
  ];
}

/// Dégradé principal (menthe → violet), utilisé sur boutons, barres, avatar.
const brandGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF7BD9C6), Color(0xFF9E8DF3)],
);

/// Fond de page : lavande → blanc → menthe.
const pageGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFFE8E4FA), Color(0xFFF2F2FB), Color(0xFFDDF4EE)],
);

Color tint(Color c, double opacity) => c.withAlpha((opacity * 255).round());

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.violet,
    brightness: Brightness.light,
  ).copyWith(surface: Colors.white);
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.transparent, // le fond est posé par MaterialApp.builder
  );
  final text = GoogleFonts.plusJakartaSansTextTheme(base.textTheme)
      .apply(bodyColor: AppColors.text, displayColor: AppColors.text);
  return base.copyWith(
    textTheme: text,
    splashFactory: NoSplash.splashFactory,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white.withAlpha(235),
      indicatorColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      height: 62,
      iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
            size: 24,
            color: states.contains(WidgetState.selected) ? AppColors.text : AppColors.muted,
          )),
      labelTextStyle: WidgetStateProperty.resolveWith((states) => GoogleFonts.plusJakartaSans(
            fontSize: 10,
            fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w500,
            color: states.contains(WidgetState.selected) ? AppColors.text : AppColors.muted,
          )),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.field,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
  );
}
