import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // ── Light ────────────────────────────────────────────────────
  static const bg = Color(0xFFF3F3FB);
  static const text = Color(0xFF12172B);
  static const muted = Color(0xFF7D8298);
  static const track = Color(0xFFE3E5EB);
  static const blue = Color(0xFF6C8DF0);
  static const violet = Color(0xFF9E8DF3);
  static const teal = Color(0xFF6FD3BE);
  static const pink = Color(0xFFF08CA6);
  static const success = Color(0xFF3CBFA0);
  static const warning = Color(0xFFF59E0B);
  static const danger = Color(0xFFEF6B7E);
  static const field = Color(0xFFF1F2F9);

  // ── Dark ─────────────────────────────────────────────────────
  static const bgDark = Color(0xFF0F1120);
  static const textDark = Color(0xFFF0F2FF);
  static const mutedDark = Color(0xFF7A7F9A);
  static const trackDark = Color(0xFF252A40);
  static const fieldDark = Color(0xFF1A1F33);
  static const cardDark = Color(0xFF171C2E);
  // Accents : légèrement plus lumineux en dark pour ressortir
  static const violetDark = Color(0xFFB09DF7);
  static const tealDark = Color(0xFF7DE4CE);
  static const successDark = Color(0xFF4DD8B5);
  static const warningDark = Color(0xFFFBB040);
  static const dangerDark = Color(0xFFFF7B8C);

  /// Couleurs vives pour les catégories (bien distinctes les unes des autres).
  static const palette = [
    Color(0xFF34C759),
    Color(0xFFFF9F0A),
    Color(0xFF0A84FF),
    Color(0xFFBF5AF2),
    Color(0xFFFF5FA2),
    Color(0xFFFF5252),
    Color(0xFF14B8A6),
    Color(0xFFFFCC00),
  ];

  static const paletteLabels = [
    'Vert', 'Orange', 'Bleu', 'Violet',
    'Rose', 'Rouge', 'Turquoise', 'Jaune',
  ];
}

/// Dégradé principal — identique light/dark (il reste lumineux).
const brandGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF7BD9C6), Color(0xFF9E8DF3)],
);

/// Fond light.
const pageGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFFE8E4FA), Color(0xFFF2F2FB), Color(0xFFDDF4EE)],
);

/// Fond dark : bleu très sombre nuancé.
const pageGradientDark = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF111425), Color(0xFF0F1120), Color(0xFF0E1A1D)],
);

Color tint(Color c, double opacity) => c.withAlpha((opacity * 255).round());


// ═══════════════════════════════════════════════════════════════
// Palettes de thème personnalisables
// ═══════════════════════════════════════════════════════════════
class AppTheme {
  final String name;
  final String emoji;
  final Color primary;   // violet/accent principal
  final Color secondary; // teal/accent secondaire
  final LinearGradient brand;
  final LinearGradient page;
  final LinearGradient pageDark;
  const AppTheme({
    required this.name, required this.emoji,
    required this.primary, required this.secondary,
    required this.brand, required this.page, required this.pageDark,
  });
}

const appThemes = [
  // 0 — Améthyste (défaut)
  AppTheme(
    name: 'Améthyste', emoji: '💜',
    primary: Color(0xFF9E8DF3), secondary: Color(0xFF6FD3BE),
    brand: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF7BD9C6), Color(0xFF9E8DF3)]),
    page: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFE8E4FA), Color(0xFFF2F2FB), Color(0xFFDDF4EE)]),
    pageDark: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF111425), Color(0xFF0F1120), Color(0xFF0E1A1D)]),
  ),
  // 1 — Saphir
  AppTheme(
    name: 'Saphir', emoji: '🌊',
    primary: Color(0xFF0A84FF), secondary: Color(0xFF34C7E8),
    brand: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF34C7E8), Color(0xFF0A84FF)]),
    page: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFDCEEFF), Color(0xFFF0F8FF), Color(0xFFD8F5FC)]),
    pageDark: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF091828), Color(0xFF0A1420), Color(0xFF091720)]),
  ),
  // 2 — Aurore
  AppTheme(
    name: 'Aurore', emoji: '🌅',
    primary: Color(0xFFFF9F0A), secondary: Color(0xFFFF5FA2),
    brand: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFFFCC44), Color(0xFFFF5FA2)]),
    page: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFFFF4DC), Color(0xFFFFF8F0), Color(0xFFFFEDF4)]),
    pageDark: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF1E1208), Color(0xFF1A0F10), Color(0xFF1A0E14)]),
  ),
  // 3 — Jade
  AppTheme(
    name: 'Jade', emoji: '🌿',
    primary: Color(0xFF34C759), secondary: Color(0xFF14B8A6),
    brand: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF14B8A6), Color(0xFF34C759)]),
    page: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFFE0F4E8), Color(0xFFF0FBF4), Color(0xFFD8F5F0)]),
    pageDark: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF091409), Color(0xFF0A1510), Color(0xFF091410)]),
  ),
];

ThemeData buildTheme({bool dark = false, int themeIndex = 0}) {
  final theme = appThemes[themeIndex.clamp(0, appThemes.length - 1)];
  final scheme = ColorScheme.fromSeed(
    seedColor: theme.primary,
    brightness: dark ? Brightness.dark : Brightness.light,
  ).copyWith(
    surface: dark ? AppColors.cardDark : Colors.white,
    onSurface: dark ? AppColors.textDark : AppColors.text,
  );

  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    brightness: dark ? Brightness.dark : Brightness.light,
    scaffoldBackgroundColor: Colors.transparent,
  );

  final textTheme = GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(
    bodyColor: dark ? AppColors.textDark : AppColors.text,
    displayColor: dark ? AppColors.textDark : AppColors.text,
  );

  final cardColor = dark ? AppColors.cardDark : Colors.white;
  final fieldColor = dark ? AppColors.fieldDark : AppColors.field;
  final mutedColor = dark ? AppColors.mutedDark : AppColors.muted;
  final trackColor = dark ? AppColors.trackDark : AppColors.track;

  return base.copyWith(
    textTheme: textTheme,
    splashFactory: NoSplash.splashFactory,
    cardColor: cardColor,
    dialogBackgroundColor: dark ? AppColors.fieldDark : Colors.white,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark
          ? AppColors.cardDark.withAlpha(235)
          : Colors.white.withAlpha(235),
      indicatorColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      height: 62,
      iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
            size: 24,
            color: states.contains(WidgetState.selected)
                ? (dark ? AppColors.textDark : AppColors.text)
                : mutedColor,
          )),
      labelTextStyle: WidgetStateProperty.resolveWith((states) =>
          GoogleFonts.plusJakartaSans(
            fontSize: 10,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w800
                : FontWeight.w500,
            color: states.contains(WidgetState.selected)
                ? (dark ? AppColors.textDark : AppColors.text)
                : mutedColor,
          )),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: fieldColor,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: BorderSide.none,
      ),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: TextStyle(color: mutedColor),
      labelStyle: TextStyle(color: mutedColor),
    ),
    chipTheme: ChipThemeData(
      color: WidgetStateProperty.resolveWith((states) =>
          states.contains(WidgetState.selected)
              ? AppColors.violet
              : (dark ? AppColors.trackDark : AppColors.track)),
      labelStyle: const TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
      side: BorderSide.none,
      showCheckmark: false,
    ),
    dividerColor: trackColor,
    iconTheme: IconThemeData(color: mutedColor),
    popupMenuTheme: PopupMenuThemeData(
      color: dark ? AppColors.fieldDark : Colors.white,
      textStyle: TextStyle(color: dark ? AppColors.textDark : AppColors.text, fontWeight: FontWeight.w600, fontSize: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: dark ? AppColors.fieldDark : AppColors.text,
      contentTextStyle: TextStyle(color: dark ? AppColors.textDark : Colors.white),
    ),
  );
}

// ─── Extension utilitaire : couleurs adaptatives selon le mode ───────────────
extension AppColorsContext on BuildContext {
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
  Color get textColor => isDark ? AppColors.textDark : AppColors.text;
  Color get mutedColor => isDark ? AppColors.mutedDark : AppColors.muted;
  Color get fieldColor => isDark ? AppColors.fieldDark : AppColors.field;
  Color get trackColor => isDark ? AppColors.trackDark : AppColors.track;
  Color get cardColor => isDark ? AppColors.cardDark : Colors.white;
}
