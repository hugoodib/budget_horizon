import 'package:flutter/foundation.dart' show kIsWeb;

/// Lien d'invitation à un budget partagé : `https://…/?join=CODE`.
///
/// Sur le web, l'adresse de la page sert de base. Sur l'iPhone, l'app ne connaît pas son
/// adresse web : renseigne [webAppUrl] (ex. https://toncompte.github.io/budget_horizon/) ou
/// compile avec --dart-define=WEB_APP_URL=… Sans adresse, l'invitation contient seulement le code.
class ShareLink {
  static const webAppUrl = String.fromEnvironment('WEB_APP_URL', defaultValue: '');

  static String? get _base {
    if (kIsWeb) {
      final u = Uri.base;
      return Uri(scheme: u.scheme, host: u.host, port: u.hasPort ? u.port : null, path: u.path).toString();
    }
    return webAppUrl.isEmpty ? null : webAppUrl;
  }

  /// Lien complet vers l'invitation, ou null si l'adresse de l'app web est inconnue.
  static String? link(String code) {
    final b = _base;
    if (b == null) return null;
    final u = Uri.parse(b);
    return u.replace(queryParameters: {...u.queryParameters, 'join': code}).toString();
  }

  /// Code d'invitation présent dans l'adresse ouverte (web uniquement), sinon null.
  static String? initialCode() {
    if (!kIsWeb) return null;
    final c = Uri.base.queryParameters['join'];
    if (c == null) return null;
    final clean = c.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    return clean.length >= 8 ? clean : null;
  }

  /// Texte prêt à envoyer (message, WhatsApp, e-mail…).
  static String message(String code, {String? from}) {
    final l = link(code);
    final who = (from == null || from.isEmpty || from == 'Moi') ? 'Je' : '$from';
    final head = who == 'Je'
        ? 'Je te partage mon budget sur Hever.'
        : '$who te partage son budget sur Hever.';
    if (l != null) {
      return '$head\nOuvre ce lien, crée ton compte ou connecte-toi : tu rejoindras le budget automatiquement.\n$l\n\n(Ou saisis le code $code dans Paramètres → Compte → Rejoindre un budget partagé.)';
    }
    return '$head\nCrée ton compte dans Hever, puis saisis ce code dans « J\'ai un code » (ou Paramètres → Compte → Rejoindre un budget partagé) :\n$code';
  }
}
