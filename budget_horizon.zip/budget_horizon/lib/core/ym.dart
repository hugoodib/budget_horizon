const _long = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août',
  'Septembre', 'Octobre', 'Novembre', 'Décembre'
];
const _short = [
  'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Août', 'Sept', 'Oct',
  'Nov', 'Déc'
];

/// Mois calendaire (année + mois 1..12), comparable et sérialisable.
class Ym implements Comparable<Ym> {
  final int year;
  final int month;
  const Ym(this.year, this.month);

  factory Ym.now() {
    final n = DateTime.now();
    return Ym(n.year, n.month);
  }
  factory Ym.of(DateTime d) => Ym(d.year, d.month);
  factory Ym.fromIndex(int i) => Ym(i ~/ 12, i % 12 + 1);
  factory Ym.parse(String s) {
    final p = s.split('-');
    return Ym(int.parse(p[0]), int.parse(p[1]));
  }

  int get index => year * 12 + month - 1;
  Ym add(int n) => Ym.fromIndex(index + n);
  String get key => '$year-${month.toString().padLeft(2, '0')}';
  String get label => '${_long[month - 1]} $year';
  String get longName => _long[month - 1];
  String get short => _short[month - 1];
  DateTime get firstDay => DateTime(year, month, 1);

  bool isBefore(Ym o) => index < o.index;
  bool isAfter(Ym o) => index > o.index;

  @override
  int compareTo(Ym o) => index.compareTo(o.index);
  @override
  bool operator ==(Object o) => o is Ym && o.index == index;
  @override
  int get hashCode => index;
  @override
  String toString() => key;
}
