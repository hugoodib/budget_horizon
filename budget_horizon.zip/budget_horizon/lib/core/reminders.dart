import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Rappels locaux (sans serveur) : un rappel quotidien le soir pour pointer ses
/// dépenses, et un rappel mensuel pour clôturer le mois. Sans effet sur le web.
class Reminders {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const _idDaily = 1001;
  static const _idMonth = 1002;

  /// Les rappels ne sont disponibles que dans l'appli installée (pas sur le web).
  static bool get supported => !kIsWeb;

  static Future<void> init() async {
    if (kIsWeb) return;
    try {
      tzdata.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation('Europe/Paris'));
      await _plugin.initialize(const InitializationSettings(
        iOS: DarwinInitializationSettings(
          requestAlertPermission: false,
          requestBadgePermission: false,
          requestSoundPermission: false,
        ),
      ));
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  /// Demande l'autorisation d'envoyer des notifications. Retourne vrai si accordée.
  static Future<bool> requestPermission() async {
    if (!_ready) return false;
    try {
      final ios = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      final ok = await ios?.requestPermissions(alert: true, badge: false, sound: true);
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static const _details = NotificationDetails(
    iOS: DarwinNotificationDetails(presentAlert: true, presentSound: false),
  );

  /// (Re)programme les rappels selon les réglages. Tout est annulé puis recréé.
  static Future<void> apply(
      {required bool daily, required int hour, int minute = 0, required bool month}) async {
    if (!_ready) return;
    try {
      await _plugin.cancel(_idDaily);
      await _plugin.cancel(_idMonth);
      final now = tz.TZDateTime.now(tz.local);
      if (daily) {
        var t = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
        if (!t.isAfter(now)) t = t.add(const Duration(days: 1));
        await _plugin.zonedSchedule(
          _idDaily,
          'Hever',
          'Pense à pointer tes dépenses du jour.',
          t,
          _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.time,
        );
      }
      if (month) {
        var t = tz.TZDateTime(tz.local, now.year, now.month, 28, 19);
        if (!t.isAfter(now)) t = tz.TZDateTime(tz.local, now.year, now.month + 1, 28, 19);
        await _plugin.zonedSchedule(
          _idMonth,
          'Hever · Fin du mois',
          'Le mois se termine bientôt : pense à le clôturer.',
          t,
          _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.dayOfMonthAndTime,
        );
      }
    } catch (_) {}
  }
}
