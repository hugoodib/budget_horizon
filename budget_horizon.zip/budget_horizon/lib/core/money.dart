/// Format "2 320,00 €" (espace fine insécable), toujours avec les centimes,
/// signe optionnel. Aucun arrondi : les centimes sont toujours affichés.
String eur(double v, {bool sign = false}) {
  final cents = (v.abs() * 100).round();
  final whole = (cents ~/ 100).toString();
  final frac = (cents % 100).toString().padLeft(2, '0');
  final buf = StringBuffer();
  for (var i = 0; i < whole.length; i++) {
    if (i > 0 && (whole.length - i) % 3 == 0) buf.write('\u202f');
    buf.write(whole[i]);
  }
  final prefix = v < 0 ? '−' : (sign && v > 0 ? '+' : '');
  return '$prefix$buf,$frac\u00a0€';
}

/// Alias historique de [eur] (même format, avec centimes).
String eurDec(double v) => eur(v);

double? parseAmount(String s) =>
    double.tryParse(s.replaceAll(',', '.').replaceAll(RegExp(r'\s'), ''));
