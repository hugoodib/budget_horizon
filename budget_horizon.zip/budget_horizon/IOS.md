# Installer Budget Horizon sur iPhone depuis un Mac (gratuit)

## Une seule fois
1. Installez **Xcode** (App Store) et ouvrez-le une fois pour accepter la licence.
2. Terminal :
   ```
   brew install --cask flutter
   brew install cocoapods
   ```
3. Décompressez `budget_horizon.zip`, puis :
   ```
   cd budget_horizon
   flutter create --platforms ios --org com.votrenom .
   flutter pub get
   flutter doctor
   ```

## Icône de l'app (optionnel)
Une icône est fournie : `assets/icon/icon.png` (1024×1024).
```
flutter pub add --dev flutter_launcher_icons
```
Ajoutez à la fin de `pubspec.yaml` :
```
flutter_launcher_icons:
  ios: true
  android: false
  image_path: "assets/icon/icon.png"
  remove_alpha_ios: true
```
puis `dart run flutter_launcher_icons`.

## Signature (Apple ID gratuit)
1. Ouvrez `ios/Runner.xcworkspace` dans Xcode.
2. Runner → **Signing & Capabilities** → cochez *Automatically manage signing*.
3. **Team** : ajoutez votre Apple ID → « Personal Team ».
4. **Bundle Identifier** unique, ex. `com.votrenom.budgethorizon`.

## Sur l'iPhone
1. Réglages → Confidentialité et sécurité → **Mode développeur** (redémarrage).
2. Branchez l'iPhone, touchez « Faire confiance ».
3. `flutter run --release` (choisissez l'iPhone) ou ▶ dans Xcode.
4. iPhone : Réglages → Général → **VPN et gestion de l'appareil** → faire confiance à votre Apple ID.

Avec un Apple ID gratuit, l'app expire après **7 jours** : relancez `flutter run --release`
(ou utilisez AltStore). Avec un compte développeur (99 €/an) : 1 an, TestFlight, App Store.

## À savoir
- Les données de l'app iOS sont séparées de la version web tant que vous n'êtes pas connecté à un compte :
  connectez-vous avec le même compte pour les retrouver.
- Les polices se téléchargent au premier lancement (réseau nécessaire la première fois).
- Les clés Firebase sont déjà intégrées à l'app (`lib/data/firebase_config.dart`).
