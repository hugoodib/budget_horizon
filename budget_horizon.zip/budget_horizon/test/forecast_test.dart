import 'package:budget_horizon/core/money.dart';
import 'package:budget_horizon/core/ym.dart';
import 'package:budget_horizon/data/onboarding_builder.dart';
import 'package:budget_horizon/domain/forecast.dart';
import 'package:budget_horizon/domain/models.dart';
import 'package:flutter_test/flutter_test.dart';

/// Tests du cœur de l'appli : « Solde actuel » et « Prévision de fin de mois ».
///
/// Règles vérifiées :
///  - Solde actuel = départ + revenus cochés − charges cochées − dépenses cochées.
///  - Fin de mois  = départ + tous les revenus − toutes les charges − Σ max(prévu, dépensé).
///  - L'assistant de démarrage règle le départ pour que le Solde actuel soit EXACTEMENT
///    le solde saisi, quelles que soient les lignes déjà passées ce mois-ci.

final _now = Ym.now();

class _Result {
  final AppData data;
  final MonthForecast month;
  final double current;
  _Result(this.data, this.month, this.current);
  double get end => month.endBalance;
}

_Result _build({
  double balance = 1000,
  List<OnboardingEntry> incomes = const [],
  List<OnboardingEntry> fixed = const [],
  List<OnboardingEntry> budgets = const [],
}) {
  final data = OnboardingBuilder.build(
    OnboardingAnswers(
      firstName: 'Test',
      lastName: '',
      isCouple: false,
      partnerName: '',
      currentBalance: balance,
      incomes: incomes,
      fixed: fixed,
      budgets: budgets,
    ),
    _now,
    'u1',
  );
  final list = Forecaster.compute(data, now: _now, to: _now);
  final m = list.at(_now)!;
  return _Result(data, m, Forecaster.currentBalance(data, m));
}

Matcher _eq(double v) => closeTo(v, 0.01);

void main() {
  group('Solde actuel et fin de mois', () {
    test('rien n\'est encore passé : le solde actuel est celui saisi', () {
      final r = _build(
        incomes: const [OnboardingEntry('Salaire', 2000)],
        fixed: const [OnboardingEntry('Loyer', 600)],
        budgets: const [OnboardingEntry('Courses', 300)],
      );
      expect(r.current, _eq(1000));
      // 1000 + 2000 − 600 − 300
      expect(r.end, _eq(2100));
    });

    test('le salaire est déjà tombé : il n\'est pas compté deux fois', () {
      final r = _build(
        incomes: const [OnboardingEntry('Salaire', 2000, alreadyDone: true)],
        fixed: const [OnboardingEntry('Loyer', 600)],
        budgets: const [OnboardingEntry('Courses', 300)],
      );
      expect(r.current, _eq(1000));
      // 1000 (déjà sur le compte) − 600 − 300
      expect(r.end, _eq(100));
    });

    test('le loyer est déjà prélevé et 120 € déjà dépensés en courses', () {
      final r = _build(
        incomes: const [OnboardingEntry('Salaire', 2000)],
        fixed: const [OnboardingEntry('Loyer', 600, alreadyDone: true)],
        budgets: const [OnboardingEntry('Courses', 300, spent: 120)],
      );
      expect(r.current, _eq(1000));
      // 1000 + 2000 à venir − 180 restant à dépenser sur l'enveloppe
      expect(r.end, _eq(2820));
    });

    test('enveloppe dépassée : le plafond dépassé baisse la fin de mois', () {
      final r = _build(
        budgets: const [OnboardingEntry('Courses', 300, spent: 450)],
      );
      expect(r.current, _eq(1000));
      // plus rien à dépenser : max(300, 450) = 450 déjà sorti
      expect(r.end, _eq(1000));
    });

    test('le solde actuel égale toujours le solde saisi (toutes combinaisons)', () {
      for (final salaryDone in [false, true]) {
        for (final rentDone in [false, true]) {
          for (final spent in [0.0, 80.0, 450.0]) {
            final r = _build(
              balance: 1234.56,
              incomes: [OnboardingEntry('Salaire', 2000, alreadyDone: salaryDone)],
              fixed: [OnboardingEntry('Loyer', 600, alreadyDone: rentDone)],
              budgets: [OnboardingEntry('Courses', 300, spent: spent)],
            );
            expect(r.current, _eq(1234.56),
                reason: 'salaire=$salaryDone loyer=$rentDone dépensé=$spent');
          }
        }
      }
    });

    test('un revenu ponctuel déjà reçu est aussi pris en compte', () {
      final r = _build(
        incomes: [
          OnboardingEntry('Prime', 500, isOneOff: true, alreadyDone: true),
        ],
        fixed: const [OnboardingEntry('Loyer', 600)],
      );
      expect(r.current, _eq(1000));
      expect(r.end, _eq(400)); // 1000 − 600
    });
  });

  group('Pointage des dépenses', () {
    Transaction tx(String cat, double amount, {bool checked = false}) => Transaction(
          id: 't${amount}_$checked',
          categoryId: cat,
          description: 'Test',
          amount: amount,
          date: DateTime.now(),
          checked: checked,
        );

    _Result withTx(_Result base, Transaction t) {
      final d = base.data.copyWith(transactions: [...base.data.transactions, t]);
      final m = Forecaster.compute(d, now: _now, to: _now).at(_now)!;
      return _Result(d, m, Forecaster.currentBalance(d, m));
    }

    test('une dépense notée mais non cochée ne change pas le solde actuel', () {
      final base = _build(budgets: const [OnboardingEntry('Courses', 300)]);
      final r = withTx(base, tx(base.data.categories.first.id, 50));
      expect(r.current, _eq(1000));
    });

    test('une dépense cochée baisse le solde actuel', () {
      final base = _build(budgets: const [OnboardingEntry('Courses', 300)]);
      final r = withTx(base, tx(base.data.categories.first.id, 50, checked: true));
      expect(r.current, _eq(950));
    });

    test('dans le budget prévu, la fin de mois ne bouge pas', () {
      final base = _build(budgets: const [OnboardingEntry('Courses', 300)]);
      final r = withTx(base, tx(base.data.categories.first.id, 50));
      expect(r.end, _eq(base.end));
    });

    test('au-delà du budget prévu, la fin de mois baisse du dépassement', () {
      final base = _build(budgets: const [OnboardingEntry('Courses', 300)]);
      final r = withTx(base, tx(base.data.categories.first.id, 350));
      expect(r.end, _eq(base.end - 50));
    });

    test('un imprévu est déduit directement de la fin de mois', () {
      final base = _build(budgets: const [OnboardingEntry('Courses', 300)]);
      final r = withTx(base, tx(kUnexpectedId, 80));
      expect(r.end, _eq(base.end - 80));
    });
  });

  group('Mois suivants', () {
    test('le mois suivant repart de la fin du mois courant', () {
      final data = _build(
        incomes: const [OnboardingEntry('Salaire', 2000)],
        fixed: const [OnboardingEntry('Loyer', 600)],
        budgets: const [OnboardingEntry('Courses', 300)],
      ).data;
      final list = Forecaster.compute(data, now: _now, to: _now.add(2));
      final m0 = list.at(_now)!;
      final m1 = list.at(_now.add(1))!;
      final m2 = list.at(_now.add(2))!;
      expect(m1.startBalance, _eq(m0.endBalance));
      expect(m2.startBalance, _eq(m1.endBalance));
      // Chaque mois ajoute 2000 − 600 − 300 = 1100
      expect(m1.endBalance - m0.endBalance, _eq(1100));
    });

    test('ce qui a été coché ce mois-ci ne l\'est pas pour les mois suivants', () {
      final data = _build(
        incomes: const [OnboardingEntry('Salaire', 2000, alreadyDone: true)],
        fixed: const [OnboardingEntry('Loyer', 600, alreadyDone: true)],
      ).data;
      final list = Forecaster.compute(data, now: _now, to: _now.add(1));
      expect(list.at(_now)!.receivedIncome, _eq(2000));
      expect(list.at(_now)!.fixedPaid, _eq(600));
      expect(list.at(_now.add(1))!.receivedIncome, _eq(0));
      expect(list.at(_now.add(1))!.fixedPaid, _eq(0));
    });

    test('un revenu une fois sur deux n\'apparaît qu\'un mois sur deux', () {
      final data = _build(
        incomes: const [OnboardingEntry('Prime', 600, intervalMonths: 2)],
      ).data;
      final list = Forecaster.compute(data, now: _now, to: _now.add(3));
      expect(list.at(_now)!.income, _eq(600));
      expect(list.at(_now.add(1))!.income, _eq(0));
      expect(list.at(_now.add(2))!.income, _eq(600));
      expect(list.at(_now.add(3))!.income, _eq(0));
    });

    test('une charge ponctuelle ne revient pas le mois suivant', () {
      final data = _build(
        fixed: [OnboardingEntry('Impôt', 400, isOneOff: true)],
      ).data;
      final list = Forecaster.compute(data, now: _now, to: _now.add(1));
      expect(list.at(_now)!.fixed, _eq(400));
      expect(list.at(_now.add(1))!.fixed, _eq(0));
    });
  });

  group('Montants saisis', () {
    test('virgule et point sont acceptés', () {
      expect(parseAmount('12,5'), 12.5);
      expect(parseAmount('12.5'), 12.5);
      expect(parseAmount('1 234,50'), 1234.5);
    });

    test('un texte vide ou invalide donne null', () {
      expect(parseAmount(''), isNull);
      expect(parseAmount('abc'), isNull);
    });
  });
}
