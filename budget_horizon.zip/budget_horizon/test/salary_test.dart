import 'package:budget_horizon/core/ym.dart';
import 'package:budget_horizon/data/onboarding_builder.dart';
import 'package:budget_horizon/domain/business_models.dart';
import 'package:budget_horizon/domain/models.dart';
import 'package:budget_horizon/domain/salary.dart';
import 'package:flutter_test/flutter_test.dart';

final _now = Ym.now();

AppData _base({List<OnboardingEntry> incomes = const []}) => OnboardingBuilder.build(
      OnboardingAnswers(
        firstName: 'Test',
        lastName: '',
        isCouple: false,
        partnerName: '',
        currentBalance: 0,
        incomes: incomes,
        fixed: const [],
        budgets: const [],
      ),
      _now,
      'u1',
    );

void main() {
  test('salaire : moyenne et taux horaire avec des heures par semaine saisies', () {
    final d = _base(incomes: const [OnboardingEntry('Salaire', 2000)]);
    final s = SalaryRecap.employee(d, _now, 6, manualHoursPerWeek: 35);
    expect(s.months, 1); // seul le mois en cours est suivi au départ
    expect(s.avgMonthly, closeTo(2000, 0.01));
    expect(s.hoursPerWeek, 35);
    expect(s.hourly, closeTo(2000 / (35 * 4.33), 0.001));
  });

  test('salaire sans heures connues : pas de taux horaire', () {
    final d = _base(incomes: const [OnboardingEntry('Salaire', 2000)]);
    final s = SalaryRecap.employee(d, _now, 3);
    expect(s.avgMonthly, closeTo(2000, 0.01));
    expect(s.hourly, isNull);
    expect(s.hoursPerWeek, isNull);
  });

  test('aucun salaire : pas de données', () {
    expect(SalaryRecap.employee(_base(), _now, 6).hasData, isFalse);
  });

  test('auto-entreprise : net après URSSAF, taux horaire net et heures par semaine', () {
    final base = _base();
    final d = base.copyWith(
      user: base.user.copyWith(ae1: true, urssafRate: 20),
      clients: [
        Client(
          id: 'c1',
          name: 'Client',
          amount: 50,
          durationMin: 60,
          kind: FreqKind.monthly,
          times: 4,
          start: _now,
        ),
      ],
    );
    final s = SalaryRecap.autoEntrepreneur(d, _now, 3);
    // 4 passages × 50 € = 200 € brut, net = 200 × 0,8 = 160 €, 4 h
    expect(s.months, 1);
    expect(s.avgMonthly, closeTo(160, 0.01));
    expect(s.hourly, closeTo(40, 0.01));
    final days = DateTime(_now.year, _now.month + 1, 0).day;
    expect(s.hoursPerWeek, closeTo(4 / (days / 7), 0.001));
  });

  test('mois à venir : plus la période est longue, plus il y a de mois pris en compte', () {
    final d = _base(incomes: const [OnboardingEntry('Salaire', 2000)]);
    final one = SalaryRecap.employee(d, _now, 1, future: true);
    final three = SalaryRecap.employee(d, _now, 3, future: true);
    final year = SalaryRecap.employee(d, _now, 12, future: true);
    expect(one.months, 1);
    expect(three.months, 3);
    expect(year.months, 12);
    // salaire fixe : la moyenne reste 2000 €
    expect(year.avgMonthly, closeTo(2000, 0.01));
  });

  test('mois passés : on ne compte pas avant le début du suivi', () {
    final d = _base(incomes: const [OnboardingEntry('Salaire', 2000)]);
    expect(SalaryRecap.employee(d, _now, 12).months, 1);
  });

  test('auto-entreprise : les mois à venir comptent chacun leurs passages', () {
    final base = _base();
    final d = base.copyWith(
      user: base.user.copyWith(ae1: true, urssafRate: 0),
      clients: [
        Client(
          id: 'c1',
          name: 'Client',
          amount: 100,
          durationMin: 60,
          kind: FreqKind.monthly,
          times: 2,
          start: _now,
        ),
      ],
    );
    final s = SalaryRecap.autoEntrepreneur(d, _now, 6, future: true);
    expect(s.months, 6);
    expect(s.avgMonthly, closeTo(200, 0.01));
    expect(s.hourly, closeTo(100, 0.01));
  });

  test('détail mensuel et classement des clients', () {
    final base = _base();
    final d = base.copyWith(
      user: base.user.copyWith(ae1: true, urssafRate: 0),
      clients: [
        Client(
          id: 'c1',
          name: 'Bon client',
          amount: 100,
          durationMin: 60,
          kind: FreqKind.monthly,
          times: 2,
          start: _now,
        ),
        Client(
          id: 'c2',
          name: 'Petit client',
          amount: 30,
          durationMin: 60,
          kind: FreqKind.monthly,
          times: 2,
          start: _now,
        ),
      ],
    );
    final s = SalaryRecap.autoEntrepreneur(d, _now, 3, future: true);
    expect(s.points.length, 3);
    expect(s.best, isNotNull);
    expect(s.yearly, closeTo(s.avgMonthly * 12, 0.001));
    final c = SalaryRecap.clients(d, _now, 3, future: true);
    expect(c.length, 2);
    expect(c.first.name, 'Bon client');
    expect(c.first.hourly, closeTo(100, 0.01));
  });

  test('le classement des clients ignore les factures ponctuelles', () {
    final base = _base();
    final d = base.copyWith(
      user: base.user.copyWith(ae1: true, urssafRate: 0),
      clients: [
        Client(
          id: 'c1',
          name: 'Régulier',
          amount: 50,
          durationMin: 60,
          kind: FreqKind.monthly,
          times: 2,
          start: _now,
        ),
        Client(
          id: 'c2',
          name: 'Ponctuel',
          amount: 500,
          durationMin: 60,
          kind: FreqKind.monthly,
          times: 1,
          start: _now,
          end: _now,
        ),
      ],
    );
    final c = SalaryRecap.clients(d, _now, 1);
    expect(c.map((e) => e.name), ['Régulier']);
  });
}
