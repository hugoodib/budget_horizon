import 'package:budget_horizon/core/ym.dart';
import 'package:budget_horizon/data/onboarding_builder.dart';
import 'package:budget_horizon/domain/business.dart';
import 'package:budget_horizon/domain/business_models.dart';
import 'package:budget_horizon/domain/models.dart';
import 'package:flutter_test/flutter_test.dart';

/// Clients au forfait (mode dev) : facture lissée, seuls les passages manqués sont déduits.
final _now = Ym.now();

AppData _data({double? forfait, double? missed}) {
  final base = OnboardingBuilder.build(
    const OnboardingAnswers(
      firstName: 'Test',
      lastName: '',
      isCouple: false,
      partnerName: '',
      currentBalance: 0,
      incomes: [],
      fixed: [],
      budgets: [],
    ),
    _now,
    'u1',
  );
  return base.copyWith(
    user: base.user.copyWith(ae1: true),
    clients: [
      Client(
        id: 'c1',
        name: 'Maregiano',
        amount: 40.41,
        kind: FreqKind.weekdays,
        weekdays: const [1, 2, 3, 4],
        start: _now,
        forfait: forfait,
      ),
    ],
    invoices: missed == null
        ? const []
        : [InvoiceRecord(clientId: 'c1', ym: _now, missedVisits: missed)],
  );
}

void main() {
  test('forfait sans absence : on facture le forfait, quel que soit le mois', () {
    final d = _data(forfait: 700);
    for (var i = 0; i < 12; i++) {
      final v = d.invoiceView(d.clients.first, _now.add(i));
      expect(v.amount, closeTo(700, 0.001), reason: 'mois +$i');
      expect(v.forfait, 700);
    }
  });

  test('2 passages manqués : 700 − 2 × 40,41 = 619,18', () {
    final d = _data(forfait: 700, missed: 2);
    final v = d.invoiceView(d.clients.first, _now);
    expect(v.amount, closeTo(619.18, 0.001));
    expect(v.missed, 2);
  });

  test('les absences d\'un mois ne touchent pas les autres mois', () {
    final d = _data(forfait: 700, missed: 2);
    expect(d.invoiceView(d.clients.first, _now.add(1)).amount, closeTo(700, 0.001));
  });

  test('la facture ne descend jamais sous zéro', () {
    final d = _data(forfait: 100, missed: 10);
    expect(d.invoiceView(d.clients.first, _now).amount, 0);
  });

  test('sans forfait, la facturation au passage reste inchangée', () {
    final d = _data();
    final v = d.invoiceView(d.clients.first, _now);
    final planned = d.plannedVisits(d.clients.first, _now);
    expect(v.forfait, isNull);
    expect(v.amount, closeTo(planned.visits * 40.41, 0.001));
  });

  test('le forfait et les absences survivent à la sauvegarde (JSON)', () {
    final d = _data(forfait: 700, missed: 1.5);
    final c = Client.fromJson(d.clients.first.toJson());
    final r = InvoiceRecord.fromJson(d.invoices.first.toJson());
    expect(c.forfait, 700);
    expect(r.missedVisits, 1.5);
  });
}
