import 'package:budget_horizon/core/ym.dart';
import 'package:budget_horizon/domain/installments.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final start = Ym(2026, 11);
  InstallmentPlan plan({List<String> done = const [], List<String> skipped = const []}) =>
      InstallmentPlan(
        id: 'p1',
        name: 'Canapé',
        categoryId: 'c1',
        total: 100,
        count: 3,
        start: start,
        day: 31,
        done: done,
        skipped: skipped,
      );

  test('les échéances somment exactement le total (arrondi sur la dernière)', () {
    final p = plan();
    expect(p.amountAt(0), 33.33);
    expect(p.amountAt(1), 33.33);
    expect(p.amountAt(2), closeTo(33.34, 0.001));
    expect(p.amountAt(0) + p.amountAt(1) + p.amountAt(2), closeTo(100, 0.001));
  });

  test('une échéance est proposée à son mois, puis plus quand elle est traitée', () {
    final p = plan();
    expect(p.dueIndexes(Ym(2026, 10)), isEmpty);
    expect(p.dueIndexes(Ym(2026, 11)), [0]);
    expect(p.dueIndexes(Ym(2027, 1)), [0, 1, 2]); // en retard : toujours proposées
    final q = plan(done: [start.key], skipped: [start.add(1).key]);
    expect(q.dueIndexes(Ym(2027, 1)), [2]);
    expect(q.doneCount, 1);
    expect(q.remaining, closeTo(33.34, 0.001));
    expect(plan(done: [start.key, start.add(1).key, start.add(2).key]).finished, isTrue);
  });

  test('le jour est ramené à la fin du mois si besoin', () {
    final p = plan(); // jour 31, novembre a 30 jours
    expect(p.dateAt(0).day, 30);
    expect(p.dateAt(2).day, 31);
  });

  test('sérialisation aller-retour', () {
    final p = plan(done: [start.key]);
    final q = InstallmentPlan.fromJson(p.toJson());
    expect(q.total, 100);
    expect(q.start, start);
    expect(q.done, [start.key]);
  });
}
