#!/bin/bash
# Applique le nom « Hever » et le logo à l'app iPhone.
# À lancer depuis le dossier du projet, après `flutter create --platforms ios .`
set -e
PLIST=ios/Runner/Info.plist
/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Hever" "$PLIST" 2>/dev/null \
  || /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string Hever" "$PLIST"
/usr/libexec/PlistBuddy -c "Set :CFBundleName Hever" "$PLIST"
echo "✓ Nom de l'app : Hever"
ls ios/Runner/Assets.xcassets/AppIcon.appiconset/Icon-App-1024x1024@1x.png >/dev/null && echo "✓ Logo en place"
flutter clean
flutter pub get
echo "Supprimez l'ancienne app de l'iPhone, puis lancez : flutter run --release"
