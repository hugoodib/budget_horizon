#!/bin/bash
# deploy.sh — place ce script dans le même dossier que budget_horizon.zip
# Lance-le avec : bash deploy.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ZIP="$SCRIPT_DIR/budget_horizon.zip"
DEST="$SCRIPT_DIR/budget_horizon"

echo "🗂  Extraction du zip..."
unzip -o "$ZIP" -d "$SCRIPT_DIR" > /dev/null

echo "📦  Installation des dépendances..."
cd "$DEST"
flutter pub get

echo "🚀  Lancement sur l'iPhone (release)..."
flutter run --release

