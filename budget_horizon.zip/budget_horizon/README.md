# Hever

Assistant financier personnel (Flutter, Material 3, Riverpod, Hive).

## Lancer
```bash
flutter create --org com.budgethorizon --project-name budget_horizon .
# (garde lib/ et pubspec.yaml de ce dossier ; accepte d'écraser si demandé)
flutter pub get
flutter run
```

## Architecture
- `lib/core` : thème, formats (€ / mois FR), type `Ym` (mois)
- `lib/domain` : modèles, moteur de prévision (`forecast.dart`), contrat `AppRepository`
- `lib/data` : `HiveRepository` (JSON dans une box Hive), données de démo
- `lib/presentation` : providers Riverpod, widgets réutilisables, 5 écrans + réglages

Pour le cloud / la connexion : implémenter un nouvel `AppRepository` et le brancher
dans `main.dart` via `repositoryProvider`.

## Règles de calcul
Solde fin de mois = début + revenus − charges fixes − budgets (max(prévu, réel), ou réel si clôturé)
− projets (versement marqué, sinon versement prévu). Le solde de fin repart au mois suivant.
La clôture fige le réel : l'économie (prévu − dépensé) enrichit donc le solde du mois suivant.

## Comptes (Firebase)
Les comptes utilisent l'API REST Firebase (Authentication e-mail/mot de passe + Firestore).
Sans clés, l'app reste 100 % locale. Pour activer :
```
flutter build web --release \
  --dart-define=FIREBASE_API_KEY=... --dart-define=FIREBASE_PROJECT_ID=...
```
Règles Firestore :
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

## Règles Firestore complètes (comptes + budget partagé)
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
    match /shares/{shareId} {
      allow get: if request.auth != null &&
        (request.auth.uid in resource.data.members || resource.data.members.size() < 2);
      allow create: if request.auth != null &&
        request.resource.data.members == [request.auth.uid];
      allow update: if request.auth != null && (
        request.auth.uid in resource.data.members ||
        (resource.data.members.size() < 2 &&
         request.resource.data.diff(resource.data).affectedKeys().hasOnly(['members']) &&
         request.resource.data.members.size() <= 2 &&
         request.resource.data.members.hasAll(resource.data.members) &&
         request.auth.uid in request.resource.data.members));
      allow delete: if request.auth != null && request.auth.uid in resource.data.members;
    }
  }
}
```
