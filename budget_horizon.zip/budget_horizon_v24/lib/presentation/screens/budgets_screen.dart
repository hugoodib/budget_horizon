import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../tour.dart';
import '../widgets/close_month.dart';
import '../widgets/total_budget.dart';
import '../widgets/trip_cards.dart';
import '../widgets/common.dart';
import '../widgets/forms.dart';

enum _TxSort { date, amount, alpha, category, unchecked }

class BudgetsScreen extends ConsumerStatefulWidget {
  const BudgetsScreen({super.key});
  @override
  ConsumerState<BudgetsScreen> createState() => _BudgetsScreenState();
}

class _BudgetsScreenState extends ConsumerState<BudgetsScreen> {
  String _search = '';
  _TxSort _sort = _TxSort.date;

  @override
  void initState() {
    super.initState();
    // À chaque ouverture de l'onglet : revenir sur le mois actuel.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) ref.read(budgetMonthProvider.notifier).state = ref.read(nowProvider);
    });
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final ym = ref.watch(budgetMonthProvider);
    final planned = d.plannedIn(ym);
    final spent = d.spentIn(ym);
    // Tri des transactions selon le choix
    final allTxs = d.transactionsIn(ym)..sort((a, b) {
      switch (_sort) {
        case _TxSort.alpha:
          return a.description.toLowerCase().compareTo(b.description.toLowerCase());
        case _TxSort.amount:
          return b.amount.compareTo(a.amount);
        case _TxSort.category:
          final ca = d.category(a.categoryId)?.name ?? '';
          final cb = d.category(b.categoryId)?.name ?? '';
          return ca.compareTo(cb);
        case _TxSort.unchecked:
          final ca = a.checked ? 1 : 0;
          final cb = b.checked ? 1 : 0;
          if (ca != cb) return ca.compareTo(cb);
          final dc = b.date.compareTo(a.date);
          return dc != 0 ? dc : b.id.compareTo(a.id);
        case _TxSort.date:
          final c = b.date.compareTo(a.date);
          return c != 0 ? c : b.id.compareTo(a.id);
      }
    });
    final txs = _search.isEmpty
        ? allTxs
        : allTxs.where((t) {
            final q = _search.toLowerCase();
            final catName = d.category(t.categoryId)?.name.toLowerCase() ?? '';
            return t.description.toLowerCase().contains(q) ||
                catName.contains(q) ||
                eur(t.amount).contains(q);
          }).toList();
    final cats = d.categories.where((c) => d.budgets.any((b) => b.categoryId == c.id)).toList();

    return ScreenScaffold(
      title: 'Budgets',
      actions: [
        RoundIconButton(
          icon: Icons.add_rounded,
          onTap: () => showSheet(context, title: 'Nouvelle catégorie', child: const AddCategorySheet()),
        ),
      ],
      children: [
        _BudgetHeader(ym: ym, now: now),
        const SizedBox(height: 12),
        for (final p in d.projects.where((p) => p.tripIn(ym))) ...[
          TripBudgetCard(project: p, month: ym),
          const SizedBox(height: 10),
        ],
        // ── Budgets : même présentation que l'accueil ──────────
        Builder(builder: (ctx) {
          final sharedCats = cats.where((c) => !d.budgets.any((b) => b.categoryId == c.id && b.person != 0)).toList();
          final splitCats = <({Category cat, Budget b1, Budget b2})>[];
          for (final c in cats) {
            final b1 = d.budgets.where((b) => b.categoryId == c.id && b.person == 1).firstOrNull;
            final b2 = d.budgets.where((b) => b.categoryId == c.id && b.person == 2).firstOrNull;
            if (b1 != null && b2 != null) splitCats.add((cat: c, b1: b1, b2: b2));
          }
          List<({Category cat, String? budgetId, double spent, double planned})> itemsFor(int person) =>
              splitCats.map((e) {
                final b = person == 1 ? e.b1 : e.b2;
                return (cat: e.cat, budgetId: b.id, spent: d.spentForBudget(b, ym), planned: b.amountIn(ym));
              }).toList();

          void openDetail(String budgetId, Category cat, int person, Ym month) {
            showBudgetDetailSheet(context,
                budgetId: budgetId, categoryId: cat.id,
                month: month, person: person);
          }

          return Column(children: [
            for (final c in sharedCats) ...[
              _BudgetCard(
                budget: d.budgets.firstWhere((b) => b.categoryId == c.id),
                category: c,
                month: ym,
              ),
              const SizedBox(height: 10),
            ],
            if (splitCats.isNotEmpty) ...[
              IntrinsicHeight(
                child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Expanded(child: PersonBudgetBubble(
                      person: 1, items: itemsFor(1), month: ym, onItemTap: openDetail)),
                  const SizedBox(width: 10),
                  Expanded(child: PersonBudgetBubble(
                      person: 2, items: itemsFor(2), month: ym, onItemTap: openDetail)),
                ]),
              ),
              const SizedBox(height: 10),
            ],
          ]);
        }),
        UnexpectedCard(month: ym),
        const SizedBox(height: 16),
        // ── Barre de recherche ──────────────────────────────────
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: TextField(
            onChanged: (v) => setState(() => _search = v),
            decoration: InputDecoration(
              hintText: 'Rechercher une dépense…',
              prefixIcon: const Icon(Icons.search_rounded, size: 20),
              suffixIcon: _search.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.close_rounded, size: 18),
                      onPressed: () => setState(() => _search = ''),
                    )
                  : null,
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            ),
          ),
        ),
        // ── Trier par ──────────────────────────────────────────
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(children: [
            Text('Trier : ', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: context.mutedColor)),
            const SizedBox(width: 4),
            for (final (s, label) in [
              (_TxSort.date, 'Date'),
              (_TxSort.amount, 'Montant'),
              (_TxSort.alpha, 'A → Z'),
              (_TxSort.category, 'Catégorie'),
              (_TxSort.unchecked, 'Non pointées'),
            ])
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                  label: Text(label, style: const TextStyle(fontSize: 12)),
                  selected: _sort == s,
                  visualDensity: VisualDensity.compact,
                  onSelected: (_) => setState(() => _sort = s),
                ),
              ),
          ]),
        ),
        const SizedBox(height: 4),
        SectionTitle('Dépenses de ${ym.longName}',
            trailing: txs.isEmpty
                ? null
                : _search.isNotEmpty
                    ? Text('${txs.length} résultat${txs.length > 1 ? 's' : ''}',
                        style: const TextStyle(color: AppColors.violet, fontWeight: FontWeight.w700, fontSize: 13))
                    : Text('${txs.where((t) => t.checked).length}/${txs.length} pointées',
                        style: const TextStyle(color: AppColors.muted, fontSize: 13))),
        if (txs.isEmpty)
          AppCard(child: Text(
              _search.isNotEmpty ? 'Aucun résultat pour « $_search ».' : 'Aucune dépense ce mois-ci.',
              style: const TextStyle(color: AppColors.muted)))
        else
          AppCard(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(children: [
              for (final t in txs)
                Dismissible(
                  key: ValueKey(t.id),
                  direction: DismissDirection.horizontal,
                  // ← swipe gauche→droite : pointer/dépointer (Quickscan)
                  background: Container(
                    decoration: BoxDecoration(
                      color: t.checked ? AppColors.muted : AppColors.teal,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.only(left: 20),
                    child: Icon(
                      t.checked ? Icons.remove_done_rounded : Icons.check_circle_rounded,
                      color: Colors.white,
                    ),
                  ),
                  // swipe droite→gauche : supprimer
                  secondaryBackground: Container(
                    decoration: BoxDecoration(
                      color: AppColors.danger,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 20),
                    child: const Icon(Icons.delete_rounded, color: Colors.white),
                  ),
                  confirmDismiss: (dir) async {
                    if (dir == DismissDirection.startToEnd) {
                      // Pointer/dépointer sans supprimer la ligne
                      ref.read(appProvider.notifier).toggleTransactionChecked(t.id);
                      return false; // ne retire pas la tuile
                    }
                    // Supprimer : demander confirmation
                    return await showQuickDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Supprimer cette dépense ?'),
                        content: Text('${t.description.isEmpty ? 'Dépense' : t.description} · ${eur(t.amount)}'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
                        ],
                      ),
                    ) ?? false;
                  },
                  onDismissed: (_) => ref.read(appProvider.notifier).deleteTransaction(t.id),
                  child: InkWell(
                    // Toucher une dépense : la modifier
                    onTap: () => showSheet(context,
                        title: 'Modifier la dépense', child: AddExpenseSheet(month: ym, existing: t)),
                    child: _TxTile(
                    tx: t,
                    cat: d.category(t.categoryId),
                    who: d.isCouple ? d.personName(t.person) : '',
                    tripName: t.tripId == null
                        ? null
                        : d.projects.where((p) => p.id == t.tripId).firstOrNull?.name,
                    onCheck: () => ref.read(appProvider.notifier).toggleTransactionChecked(t.id)),
                  ),
                ),
            ]),
          ),
        const SizedBox(height: 12),
        CloseMonthCard(key: TourKeys.closeMonth, month: ym),
      ],
    );
  }
}

class _Chevron extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _Chevron({required this.icon, this.onTap});
  @override
  Widget build(BuildContext context) => IconButton(
        onPressed: onTap,
        icon: Icon(icon, color: onTap == null ? context.trackColor : context.mutedColor),
      );
}

Future<void> _confirmDeleteCategory(BuildContext context, WidgetRef ref, Category c) async {
  final ok = await showQuickDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text('Supprimer « ${c.name} » ?'),
      content: const Text('Le budget est supprimé pour tous les mois. Les dépenses déjà saisies restent comptées.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
      ],
    ),
  );
  if (ok == true) ref.read(appProvider.notifier).removeBudget(c.id);
}

Color _statusColor(AppData d, Ym month, double planned, double spent) {
  final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
  final overColor = d.spentIn(month) > d.plannedIn(month) ? AppColors.danger : AppColors.warning;
  return ratio >= 1 ? overColor : (ratio >= .8 ? AppColors.warning : AppColors.teal);
}

/// Carte pleine largeur (mode solo).
// ── En-tête fusionné : sélecteur de mois + résumé budget total ───────────────
class _BudgetHeader extends ConsumerWidget {
  final Ym ym;
  final Ym now;
  const _BudgetHeader({required this.ym, required this.now});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final planned = d.plannedIn(ym);
    final spent = d.spentIn(ym);
    final remaining = planned - spent;
    final over = spent > planned;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = over ? AppColors.danger : (ratio >= .85 ? AppColors.warning : AppColors.teal);

    final today = DateTime.now();
    final isRealMonth = ym == Ym.of(today) && !d.isClosed(ym);
    final daysInMonth = DateTime(today.year, today.month + 1, 0).day;
    final daysLeftInc = daysInMonth - today.day + 1;
    final perDay = (isRealMonth && remaining > 0 && daysLeftInc > 0) ? remaining / daysLeftInc : null;
    final projected = isRealMonth && today.day > 0 ? spent / today.day * daysInMonth : null;
    final paceWarning = projected != null && !over && planned > 0 && projected > planned;

    final envelopeOver = d.budgets.any((b) => d.spentForBudget(b, ym) > b.amountIn(ym));
    final Color hintColor;
    final String hint;
    if (over) {
      hintColor = AppColors.danger;
      hint = 'Budget dépassé de ${eur(spent - planned)}.';
    } else if (envelopeOver) {
      hintColor = AppColors.warning;
      hint = 'Une catégorie est dépassée, mais pas le total.';
    } else {
      hintColor = AppColors.success;
      hint = 'Vous êtes dans votre budget.';
    }

    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Sélecteur de mois ──────────────────────────────────
        MonthSwitcher(
          value: ym,
          min: ref.read(appProvider).startYm,
          now: now,
          onChanged: (v) => ref.read(budgetMonthProvider.notifier).state = v,
        ),
        const SizedBox(height: 14),
        const Divider(height: 1),
        const SizedBox(height: 14),
        // ── Résumé budget total ────────────────────────────────
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          // Anneau
          SizedBox(
            width: 120, height: 120,
            child: ArcProgress(
              value: ratio.clamp(0.0, 1.0),
              color: color,
              trackColor: context.trackColor,
              strokeWidth: 11,
              child: Text('${(ratio * 100).round()}%',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(over ? 'Dépassement' : 'Reste sur le budget',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(eur(over ? spent - planned : remaining),
                    style: TextStyle(
                        fontSize: 28, fontWeight: FontWeight.w900,
                        letterSpacing: -0.8,
                        color: over ? AppColors.danger : context.textColor)),
              ),
              Text('${eur(spent)} dépensés sur ${eur(planned)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
            ]),
          ),
        ]),
        const SizedBox(height: 10),
        Text(hint,
            style: TextStyle(color: hintColor, fontSize: 12.5,
                fontWeight: FontWeight.w600, height: 1.3)),
        if (perDay != null) ...[
          const SizedBox(height: 4),
          Text('Environ ${eur(perDay)} par jour restant.',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
        ],
        if (paceWarning) ...[
          const SizedBox(height: 4),
          Text('À ce rythme, dépassement de ${eur(projected! - planned)}.',
              style: const TextStyle(color: AppColors.warning,
                  fontSize: 12.5, fontWeight: FontWeight.w600)),
        ],
      ]),
    );
  }
}

class _BudgetCard extends ConsumerWidget {
  final Budget budget;
  final Category category;
  final Ym month;
  const _BudgetCard({required this.budget, required this.category, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final planned = budget.amountIn(month);
    final spent = d.spentForBudget(budget, month);
    final remaining = planned - spent;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = _statusColor(d, month, planned, spent);
    final catColor = Color(category.colorValue);

    return GestureDetector(
      onTap: () => showBudgetDetailSheet(context,
          budgetId: budget.id, categoryId: category.id, month: month),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
        decoration: BoxDecoration(
          color: tint(catColor, .08),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleEmoji(category.emoji, catColor, size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(category.name,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                if (budget.hasOverride(month))
                  const Text('Modifié ce mois',
                      style: TextStyle(color: AppColors.violet, fontWeight: FontWeight.w600, fontSize: 11.5)),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(eur(spent),
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: color)),
              Text('sur ${eur(planned)}',
                  style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w500, fontSize: 12)),
            ]),
            const SizedBox(width: 4),
            GestureDetector(
              onTap: () => _confirmDeleteCategory(context, ref, category),
              child: const Padding(
                padding: EdgeInsets.all(6),
                child: Icon(Icons.delete_outline_rounded, color: AppColors.muted, size: 18),
              ),
            ),
          ]),
          const SizedBox(height: 10),
          AppProgress(value: ratio, color: color),
          const SizedBox(height: 4),
          Text(
            ratio >= 1
                ? 'Budget dépassé'
                : '${eur(remaining)} restant · ${(ratio * 100).round()}%',
            style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: ratio >= 1 ? AppColors.danger : AppColors.muted),
          ),
        ]),
      ),
    );
  }
}

/// Mode couple : budgets communs en tuiles pleines, tous les budgets séparés
/// regroupés dans une seule carte compacte avec une ligne par catégorie.
class _CoupleBudgets extends ConsumerWidget {
  final Ym month;
  final List<Category> cats;
  const _CoupleBudgets({required this.month, required this.cats});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);

    bool separate(Category c) =>
        d.budgets.any((b) => b.categoryId == c.id && b.person != 0);

    final sharedCats = cats.where((c) => !separate(c)).toList();
    final splitCats = cats.where(separate).toList();

    return Column(children: [
      // ── Budgets communs : une tuile par catégorie ─────────────
      for (final c in sharedCats) ...[
        for (final b in d.budgets.where((b) => b.categoryId == c.id))
          _BudgetCard(budget: b, category: c, month: month),
        const SizedBox(height: 10),
      ],

      // ── Budgets séparés : une seule carte compacte ────────────
      if (splitCats.isNotEmpty) ...[
        _SplitBudgetsCard(cats: splitCats, month: month),
        const SizedBox(height: 10),
      ],
    ]);
  }
}

/// Carte unique regroupant tous les budgets séparés.
/// En-tête avec les deux noms, puis une ligne par catégorie.
/// Carte unique regroupant tous les budgets séparés.
/// Même look que BudgetRow : fond teinté, dépensé à droite, barre, restant.
/// Les deux personnes sont affichées côte à côte dans chaque ligne de catégorie.
class _SplitBudgetsCard extends ConsumerWidget {
  final List<Category> cats;
  final Ym month;
  const _SplitBudgetsCard({required this.cats, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(children: [
      for (final c in cats) ...[
        _SplitCategoryLine(category: c, month: month),
        const SizedBox(height: 10),
      ],
    ]);
  }
}

/// Une tuile pour un budget séparé : même structure que BudgetRow,
/// mais affiche deux mini-colonnes Hugo | Lisa en dessous de la barre.
class _SplitCategoryLine extends ConsumerWidget {
  final Category category;
  final Ym month;
  const _SplitCategoryLine({required this.category, required this.month});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final catColor = Color(category.colorValue);

    // Agrégats pour la barre globale
    double totalSpent = 0, totalPlanned = 0;
    for (final p in [1, 2]) {
      final b = d.budgets.where((b) => b.categoryId == category.id && b.person == p).firstOrNull;
      if (b != null) {
        totalSpent += d.spentForBudget(b, month);
        totalPlanned += b.amountIn(month);
      }
    }
    final totalRemaining = totalPlanned - totalSpent;
    final ratio = totalPlanned <= 0 ? (totalSpent > 0 ? 1.0 : 0.0) : totalSpent / totalPlanned;
    final statusColor = ratio >= 1 ? AppColors.danger : ratio >= .8 ? AppColors.warning : AppColors.teal;

    Widget personCol(int person) {
      final b = d.budgets.where((b) => b.categoryId == category.id && b.person == person).firstOrNull;
      if (b == null) return const SizedBox.shrink();
      final planned = b.amountIn(month);
      final spent = d.spentForBudget(b, month);
      final remaining = planned - spent;
      final pRatio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
      final pColor = _statusColor(d, month, planned, spent);

      return GestureDetector(
        onTap: () => showBudgetDetailSheet(context,
            budgetId: b.id, categoryId: category.id, month: month, person: person),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            PersonAvatar(person: person, size: 16),
            const SizedBox(width: 5),
            Text(d.personName(person),
                style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: context.mutedColor)),
          ]),
          const SizedBox(height: 3),
          Text(eur(spent),
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: pColor)),
          Text('sur ${eur(planned)}',
              style: TextStyle(fontSize: 11, color: context.mutedColor)),
          const SizedBox(height: 4),
          AppProgress(value: pRatio, color: pColor),
          const SizedBox(height: 3),
          Text('${eur(remaining)} restant',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: context.mutedColor)),
        ]),
      );
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: tint(catColor, .08),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Même en-tête que BudgetRow
        Row(children: [
          CircleEmoji(category.emoji, catColor, size: 36),
          const SizedBox(width: 12),
          Expanded(
            child: Text(category.name,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(eur(totalSpent),
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: statusColor)),
            Text('sur ${eur(totalPlanned)}',
                style: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w500, fontSize: 12)),
          ]),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: () => _confirmDeleteCategory(context, ref, category),
            child: const Padding(
              padding: EdgeInsets.all(6),
              child: Icon(Icons.delete_outline_rounded, color: AppColors.muted, size: 18),
            ),
          ),
        ]),
        const SizedBox(height: 10),
        // Barre globale
        AppProgress(value: ratio, color: statusColor),
        const SizedBox(height: 4),
        Text(
          ratio >= 1 ? 'Budget dépassé' : '${eur(totalRemaining)} restant · ${(ratio * 100).round()}%',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
              color: ratio >= 1 ? AppColors.danger : AppColors.muted),
        ),
        const SizedBox(height: 10),
        // Détail par personne — même padding que la tuile, pas de séparateur
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: personCol(1)),
          Container(width: 1, margin: const EdgeInsets.symmetric(horizontal: 12), color: AppColors.muted.withAlpha(25)),
          Expanded(child: personCol(2)),
        ]),
      ]),
    );
  }
}

class _TxTile extends StatelessWidget {
  final Transaction tx;
  final Category? cat;
  final String who;
  final String? tripName;
  final VoidCallback onCheck;
  const _TxTile(
      {required this.tx, required this.cat, required this.who, this.tripName, required this.onCheck});

  @override
  Widget build(BuildContext context) => ListTile(
        tileColor: Colors.transparent,
        leading: CircleEmoji(cat?.emoji ?? '💶', Color(cat?.colorValue ?? AppColors.blue.value)),
        title: Text(tx.description, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
            '${tripName ?? (cat?.name ?? '')}${who.isEmpty ? '' : ' · $who'} · ${tx.date.day.toString().padLeft(2, '0')}/${tx.date.month.toString().padLeft(2, '0')}'),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          Text('−${eur(tx.amount)}', style: const TextStyle(fontWeight: FontWeight.w800)),
          CheckCircle(checked: tx.checked, onTap: onCheck),
        ]),
      );
}

class _ClosedSummary extends StatelessWidget {
  final MonthSnapshot snapshot;
  const _ClosedSummary({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    final s = snapshot.savings;
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: AppCard(
        child: Row(children: [
          Icon(s >= 0 ? Icons.savings_rounded : Icons.warning_amber_rounded,
              color: s >= 0 ? AppColors.success : AppColors.danger),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              s >= 0
                  ? 'Prévu ${eur(snapshot.planned)} · Dépensé ${eur(snapshot.spent)}\nÉconomie de ${eur(s)} ajoutée au solde du mois suivant.'
                  : 'Prévu ${eur(snapshot.planned)} · Dépensé ${eur(snapshot.spent)}\nDépassement de ${eur(-s)} déduit du mois suivant.',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ]),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
/// Ouvre le sheet de détail d'un budget avec le tri sticky en header.
void showBudgetDetailSheet(BuildContext context,
    {required String budgetId,
    required String categoryId,
    required Ym month,
    int? person}) {
  // On passe par un StatefulBuilder pour que le tri soit dans le stickyHeader
  // tout en restant lié à l'état du sheet.
  _DetailSort sort = _DetailSort.date;

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    enableDrag: true,
    backgroundColor: Theme.of(context).brightness == Brightness.dark
        ? AppColors.fieldDark
        : Colors.white,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) {
      final handleColor = const Color(0xFFD9DCE8).withAlpha(
          Theme.of(ctx).brightness == Brightness.dark ? 60 : 255);
      final bottom = MediaQuery.of(ctx).viewInsets.bottom;
      return StatefulBuilder(
        builder: (ctx, setState) => Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Poignée + titre draggable ───────────────────────
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onVerticalDragUpdate: (d) {
                if ((d.primaryDelta ?? 0) > 6) Navigator.of(ctx).pop();
              },
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 38, height: 4,
                        decoration: BoxDecoration(
                            color: handleColor,
                            borderRadius: BorderRadius.circular(4)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Consumer(builder: (_, ref, __) {
                      final d = ref.watch(appProvider);
                      final cat = d.category(categoryId);
                      return Text(
                        cat != null ? '${cat.emoji} ${cat.name}' : 'Budget',
                        style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                      );
                    }),
                    const SizedBox(height: 10),
                  ],
                ),
              ),
            ),
            // ── Trier par (sticky) ──────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
              child: Row(children: [
                Text('Trier : ',
                    style: TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: Theme.of(ctx).colorScheme.onSurface.withAlpha(120))),
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      for (final (s, label) in [
                        (_DetailSort.date, 'Date'),
                        (_DetailSort.alpha, 'A → Z'),
                        (_DetailSort.unchecked, 'Non pointées'),
                        (_DetailSort.amount, 'Montant'),
                      ])
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(label),
                            selected: sort == s,
                            onSelected: (_) => setState(() => sort = s),
                          ),
                        ),
                    ]),
                  ),
                ),
              ]),
            ),
            // ── Contenu scrollable ──────────────────────────────
            Flexible(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(18, 0, 18, bottom + 20),
                child: BudgetDetailSheet(
                  budgetId: budgetId,
                  categoryId: categoryId,
                  month: month,
                  person: person,
                  sort: sort,
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}

// Sheet de détail d'un budget : résumé + liste des dépenses filtrées
// ═══════════════════════════════════════════════════════════════════
enum _DetailSort { date, alpha, unchecked, amount }

class BudgetDetailSheet extends ConsumerWidget {
  final String budgetId;
  final String categoryId;
  final Ym month;
  final int? person;
  final _DetailSort sort;

  const BudgetDetailSheet({
    super.key,
    required this.budgetId,
    required this.categoryId,
    required this.month,
    this.person,
    this.sort = _DetailSort.date,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final d = ref.watch(appProvider);
    final b = d.budgets.where((b) => b.id == budgetId).firstOrNull;
    final cat = d.category(categoryId);
    if (b == null || cat == null) return const SizedBox.shrink();

    final planned = b.amountIn(month);
    final spent = d.spentForBudget(b, month);
    final remaining = planned - spent;
    final ratio = planned <= 0 ? (spent > 0 ? 1.0 : 0.0) : spent / planned;
    final color = _statusColor(d, month, planned, spent);
    final personName = person != null ? d.personName(person!) : null;

    // Dépenses filtrées + triées
    final txs = d.transactionsIn(month, categoryId: categoryId)
        .where((t) => person == null || t.person == person || t.person == 0)
        .toList()
      ..sort((a, b) {
        switch (sort) {
          case _DetailSort.alpha:
            return a.description.toLowerCase().compareTo(b.description.toLowerCase());
          case _DetailSort.amount:
            return b.amount.compareTo(a.amount);
          case _DetailSort.unchecked:
            if (a.checked == b.checked) return b.date.compareTo(a.date);
            return a.checked ? 1 : -1;
          case _DetailSort.date:
            final c = b.date.compareTo(a.date);
            return c != 0 ? c : b.id.compareTo(a.id);
        }
      });

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // ── Résumé visuel ──────────────────────────────────────────
      AppCard(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleEmoji(cat.emoji, Color(cat.colorValue), size: 36),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(cat.name,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                if (personName != null)
                  Text(personName,
                      style: const TextStyle(color: AppColors.muted, fontSize: 13.5,
                          fontWeight: FontWeight.w600)),
              ]),
            ),
            // Bouton modifier
            TextButton.icon(
              onPressed: () {
                Navigator.pop(context);
                showSheet(context,
                    title: 'Modifier le budget',
                    child: EditBudgetSheet(budgetId: budgetId, month: month));
              },
              icon: const Icon(Icons.edit_outlined, size: 16),
              label: const Text('Modifier'),
              style: TextButton.styleFrom(foregroundColor: AppColors.violet),
            ),
          ]),
          const SizedBox(height: 16),
          // Grand montant restant
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(eur(remaining),
                style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    color: color,
                    letterSpacing: -0.5)),
            const SizedBox(width: 8),
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('restant sur ${eur(planned)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 13,
                      fontWeight: FontWeight.w500)),
            ),
          ]),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: ratio.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: context.trackColor,
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
          const SizedBox(height: 8),
          Text('${eur(spent)} dépensé · ${(ratio * 100).round()} % du budget utilisé',
              style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
        ]),
      ),
      const SizedBox(height: 20),

      // ── Liste des dépenses ─────────────────────────────────────
      Row(children: [
        Expanded(
          child: Text(
            txs.isEmpty
                ? 'Aucune dépense ce mois-ci'
                : '${txs.length} dépense${txs.length > 1 ? 's' : ''}',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
        ),
        // Bouton ajouter une dépense directement dans ce budget
        FilledButton.icon(
          onPressed: () => showSheet(context,
              title: 'Nouvelle dépense · ${cat.name}',
              child: AddExpenseSheet(
                  month: month,
                  initialCategoryId: categoryId,
                  initialPerson: person)),
          icon: const Icon(Icons.add_rounded, size: 18),
          label: const Text('Ajouter'),
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.violet,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
          ),
        ),
      ]),

      if (txs.isEmpty) ...[
        const SizedBox(height: 12),
        const Text('Touchez « Ajouter » pour saisir votre première dépense ici.',
            style: TextStyle(color: AppColors.muted, fontSize: 13, height: 1.4)),
      ] else ...[
        const SizedBox(height: 10),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(children: [
            for (final t in txs)
              Dismissible(
                key: ValueKey('detail_${t.id}'),
                direction: DismissDirection.horizontal,
                background: Container(
                  color: t.checked ? AppColors.muted : AppColors.teal,
                  alignment: Alignment.centerLeft,
                  padding: const EdgeInsets.only(left: 20),
                  child: Icon(t.checked ? Icons.remove_done_rounded : Icons.check_circle_rounded,
                      color: Colors.white),
                ),
                secondaryBackground: Container(
                  color: AppColors.danger,
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  child: const Icon(Icons.delete_rounded, color: Colors.white),
                ),
                confirmDismiss: (dir) async {
                  if (dir == DismissDirection.startToEnd) {
                    ref.read(appProvider.notifier).toggleTransactionChecked(t.id);
                    return false;
                  }
                  return await showQuickDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('Supprimer cette dépense ?'),
                      content: Text('${t.description.isEmpty ? cat.name : t.description} · ${eur(t.amount)}'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
                      ],
                    ),
                  ) ?? false;
                },
                onDismissed: (_) => ref.read(appProvider.notifier).deleteTransaction(t.id),
                child: InkWell(
                  onTap: () => showSheet(context,
                      title: 'Modifier la dépense',
                      child: AddExpenseSheet(month: Ym.of(t.date), existing: t)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(children: [
                      SizedBox(
                        width: 36,
                        child: Text(
                          "${t.date.day.toString().padLeft(2, '0')}/${t.date.month.toString().padLeft(2, '0')}",
                          style: const TextStyle(color: AppColors.muted, fontSize: 12,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          t.description.isEmpty ? cat.name : t.description,
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text('−${eur(t.amount)}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      const SizedBox(width: 4),
                      CheckCircle(
                        checked: t.checked,
                        onTap: () => ref.read(appProvider.notifier)
                            .toggleTransactionChecked(t.id),
                      ),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      ],
      const SizedBox(height: 8),
    ]);
  }
}
