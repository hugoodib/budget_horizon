import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/money.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/business.dart';
import '../../domain/models.dart';
import '../providers.dart';
import 'common.dart';

// ---------------- Icône + couleur d'une catégorie ----------------
const kEmojiChoices = [
  '🥕', '🛒', '🍕', '🍔', '☕', '🍷', '⛽', '🚗', '🚌', '✈️',
  '🏠', '💡', '📱', '🎮', '🎬', '🎉', '🏋️', '💊', '🧴', '👗',
  '🛍️', '🎁', '🐶', '🐱', '👶', '📚', '🎓', '💇', '💄', '🧾',
  '🏖️', '🍿', '🎵', '🧹', '🔧', '🌿', '💰', '🥂', '🚴', '🎨',
];

/// Garde uniquement le dernier emoji saisi (un seul caractère « visuel »).
class _OneEmojiFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final chars = newValue.text.characters;
    if (chars.isEmpty) return newValue;
    final last = chars.last;
    return TextEditingValue(text: last, selection: TextSelection.collapsed(offset: last.length));
  }
}

/// Un rond de couleur avec son label de catégorie en dessous.
class _PaletteItem extends StatelessWidget {
  final Color color;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _PaletteItem({required this.color, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: selected ? context.textColor : Colors.transparent, width: 2.5),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 9,
              fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              color: selected ? context.textColor : context.mutedColor,
            ),
            textAlign: TextAlign.center,
          ),
        ]),
      );
}

/// Choix d'un emoji (grille + clavier emoji complet de l'iPhone) et d'une couleur vive.
class StylePicker extends StatelessWidget {
  final String emoji;
  final int color;
  final ValueChanged<String> onEmoji;
  final ValueChanged<int> onColor;
  final bool showEmoji; // faux : couleur seule (logo « première lettre »)
  final String previewLetter;
  const StylePicker({
    super.key,
    required this.emoji,
    required this.color,
    required this.onEmoji,
    required this.onColor,
    this.showEmoji = true,
    this.previewLetter = '?',
  });

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          showEmoji
              ? CircleEmoji(emoji.isEmpty ? '💰' : emoji, Color(color), size: 48)
              : CircleEmoji(previewLetter, Color(color), size: 48, letter: true),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
                showEmoji
                    ? 'Choisissez une icône et une couleur bien distinctes.'
                    : 'Choisissez une couleur.',
                style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          ),
        ]),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            for (var i = 0; i < AppColors.palette.length; i++)
              _PaletteItem(
                color: AppColors.palette[i],
                label: AppColors.paletteLabels[i],
                selected: AppColors.palette[i].value == color,
                onTap: () => onColor(AppColors.palette[i].value),
              ),
          ],
        ),
        if (showEmoji) ...[
        const SizedBox(height: 12),
        TextField(
          inputFormatters: [_OneEmojiFormatter()],
          decoration: const InputDecoration(
            labelText: 'N\'importe quel emoji : touchez ici puis 🌐 sur le clavier',
          ),
          onChanged: (v) {
            final t = v.trim();
            if (t.isNotEmpty) onEmoji(t.characters.last);
          },
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final e in kEmojiChoices)
            GestureDetector(
              onTap: () => onEmoji(e),
              child: Container(
                width: 40,
                height: 40,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: e == emoji ? tint(Color(color), .22) : context.fieldColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: e == emoji ? Color(color) : Colors.transparent, width: 2),
                ),
                child: Text(e, style: const TextStyle(fontSize: 22)),
              ),
            ),
        ]),
        ],
      ]);
}

// ---------------- Ajouter une dépense ----------------
/// Une dépense va dans une enveloppe (catégorie), dans les « imprévus » (compteur qui baisse
/// directement l'estimation) ou dans le budget d'un voyage.

/// Mots-clés → nom de catégorie (insensible à la casse, normalisé).
/// Si le nom de catégorie de l'utilisateur contient le slug, on pré-sélectionne.
const _smartCategoryKeywords = <String, List<String>>{
  'courses': ['carrefour','leclerc','lidl','auchan','intermarche','monoprix','franprix',
               'aldi','casino','biocoop','marche','epicerie','boulangerie','supermarche',
               'spar','picard','naturalia','grand frais','netto','super u','simply market'],
  'restaurant': ['mcdo','mcdonald','macdo','burger king','kfc','subway','pizza','sushi',
                  'kebab','resto','restaurant','brasserie','bistrot','uber eats','deliveroo',
                  'just eat','tablapizza','dominos','quick','five guys','popeyes','chipotle',
                  'noodles','poke','wok','thai','indien','libanais','japonais','buffet'],
  'essence': ['total','bp','shell','esso','leclerc carb','intermarche carb','carrefour carb',
               'essence','gasoil','diesel','gazole','station','plein','carburant','e10','sp95',
               'sp98','gnv','peage','autoroute','vinci','sanef','cofiroute'],
  'loisirs': ['cinema','cine','pathé','ugc','mk2','fnac','micromania','steam','playstation',
               'xbox','netflix','disney','canal','spotify','deezer','amazon prime','apple tv',
               'hulu','twitch','youtube','concert','spectacle','theatre','musee','zoo','parc',
               'laser game','bowling','karting','accrobranche','escape game','billeterie'],
  'sante': ['pharmacie','medecin','docteur','dentiste','opticien','kiné','osteo','psy',
             'laboratoire','optique','krys','atol','afflelou','généraliste','urgences',
             'hopital','clinique','mutuelle','cpam','maternite','sage femme','podologue'],
  'vetements': ['zara','h&m','primark','bershka','pull bear','mango','uniqlo','asos','shein',
                 'zalando','kiabi','la redoute','camaieu','promod','jennyfer','sandro','maje',
                 'decathlon','nike','adidas','new balance','courir','foot locker','chaussures'],
  'maison': ['leroy merlin','castorama','brico depot','ikea','conforama','but','maisons du monde',
              'bricorama','mr bricolage','bricomarche','lapeyre','saint maclou','gedimat',
              'jardiland','truffaut','botanic','gamm vert','weldom'],
  'transport': ['sncf','ratp','transilien','ter','ouigo','thalys','eurostar','blablacar',
                 'uber','lyft','bolt','heetch','taxi','vtc','metro','bus','tramway','navigo',
                 'velib','lime','tier','bird','trottinette','stationnement','parking','horodateur'],
  'abonnement': ['sfr','orange','bouygues','free','sosh','b&you','red','prixtel','youprice',
                  'coriolis','auchan telecom','nrj mobile','fnac mobile','lebara','lycamobile',
                  'netflix','spotify','deezer','disney','canal','youtube premium','apple one',
                  'icloud','google one','dropbox','adobe','microsoft','office 365'],
  'alimentation': ['franprix','naturalia','bio c bon','day by day','metro','promocash',
                    'cuisine','repas','dejeuner','diner','snack','sandwicherie','traiteur'],
};

/// Normalise un texte : minuscules, accents retirés.
String _normCat(String s) {
  const from = 'àâäáãéèêëíìîïóòôöõúùûüçœ';
  const to   = 'aaaaaeeeeiiiiooooouuuuco';
  final b = StringBuffer();
  for (final ch in s.toLowerCase().split('')) {
    final i = from.indexOf(ch);
    b.write(i >= 0 ? to[i] : ch);
  }
  return b.toString();
}
class AddExpenseSheet extends ConsumerStatefulWidget {
  final Ym month;
  final String? initialTripId;
  final String? initialCategoryId; // pré-sélectionne une catégorie
  final int? initialPerson;        // pré-sélectionne une personne (mode couple)
  final bool initialUnexpected;
  final Transaction? existing; // dépense à modifier (null = nouvelle dépense)
  const AddExpenseSheet(
      {super.key, required this.month, this.initialTripId, this.initialCategoryId,
       this.initialPerson, this.initialUnexpected = false, this.existing});
  @override
  ConsumerState<AddExpenseSheet> createState() => _AddExpenseState();
}

class _AddExpenseState extends ConsumerState<AddExpenseSheet> {
  String? _cat; // id de catégorie, kUnexpectedId ou kTripCatId
  String? _tripId;
  int _person = 1;
  final _desc = TextEditingController();
  final _amt = TextEditingController();
  late DateTime _date;
  DateTime? _debitDate; // [Mode dev] date de débit bancaire
  List<Transaction> _suggestions = [];  // dernières dépenses similaires
  bool _showSuggestions = false;

  @override
  void initState() {
    super.initState();
    _date = widget.month == Ym.now() ? DateTime.now() : widget.month.firstDay;
    if (widget.initialUnexpected) _cat = kUnexpectedId;
    if (widget.initialTripId != null) {
      _cat = kTripCatId;
      _tripId = widget.initialTripId;
    }
    if (widget.initialCategoryId != null) _cat = widget.initialCategoryId;
    if (widget.initialPerson != null) _person = widget.initialPerson!;
    _desc.addListener(_onDescChanged);
    final e = widget.existing;
    if (e != null) {
      _date = e.date;
      _debitDate = e.debitDate;
      _desc.text = e.description == 'Dépense' ? '' : e.description;
      _amt.text = e.amount == e.amount.roundToDouble() ? e.amount.round().toString() : e.amount.toString();
      _person = e.person == 0 ? 1 : e.person;
      if (e.tripId != null) {
        _cat = kTripCatId;
        _tripId = e.tripId;
      } else {
        _cat = e.categoryId;
      }
    }
  }

  void _onDescChanged() {
    final query = _desc.text.trim().toLowerCase();
    if (query.length < 2) {
      if (_showSuggestions) setState(() { _suggestions = []; _showSuggestions = false; });
      return;
    }
    final d = ref.read(appProvider);
    // ── Catégorie intelligente ──────────────────────────────────
    // Chercher si la description correspond à un mot-clé connu
    final qNorm = _normCat(query);
    String? autocat;
    outer:
    for (final entry in _smartCategoryKeywords.entries) {
      for (final kw in entry.value) {
        if (qNorm.contains(_normCat(kw)) || _normCat(kw).contains(qNorm)) {
          // Trouver la catégorie de l'utilisateur dont le slug correspond
          final match = d.categories.where((c) =>
              _normCat(c.name).contains(entry.key) || entry.key.contains(_normCat(c.name))).firstOrNull;
          if (match != null) { autocat = match.id; break outer; }
          break;
        }
      }
    }
    if (autocat != null && _cat != autocat) {
      setState(() { _cat = autocat; _tripId = null; });
    }
    // Chercher dans toutes les transactions passées (hors mois actuel)
    final now = ref.read(nowProvider);
    final all = d.transactions
        .where((t) =>
            Ym.of(t.date) != now &&       // pas du mois en cours
            t.description.toLowerCase().contains(query))
        .toList()
      ..sort((a, b) => b.date.compareTo(a.date));
    // Dédupliquer par description+catégorie, garder les 4 plus récentes
    final seen = <String>{};
    final unique = <Transaction>[];
    for (final t in all) {
      final key = '${t.description.toLowerCase()}_${t.categoryId}';
      if (seen.add(key)) unique.add(t);
      if (unique.length >= 4) break;
    }
    setState(() {
      _suggestions = unique;
      _showSuggestions = unique.isNotEmpty;
    });
  }

  void _applySuggestion(Transaction t) {
    setState(() {
      _desc.text = t.description;
      _amt.text = t.amount == t.amount.roundToDouble()
          ? t.amount.round().toString()
          : t.amount.toStringAsFixed(2);
      if (t.tripId != null) {
        _cat = kTripCatId;
        _tripId = t.tripId;
      } else {
        _cat = t.categoryId;
        _tripId = null;
      }
      if (t.person != 0) _person = t.person;
      _showSuggestions = false;
    });
  }

  bool _isToday(DateTime x) {
    final n = DateTime.now();
    return x.year == n.year && x.month == n.month && x.day == n.day;
  }

  @override
  void dispose() {
    _desc.removeListener(_onDescChanged);
    _desc.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseAmount(_amt.text);
    if (a == null || a <= 0 || _cat == null) {
      snack(context, 'Renseignez une catégorie et un montant valide');
      return;
    }
    if (_cat == kTripCatId && _tripId == null) {
      snack(context, 'Choisissez le voyage concerné');
      return;
    }
    final d = ref.read(appProvider);
    final couple = d.isCouple;
    final amount = double.parse(a.toStringAsFixed(2));
    final e = widget.existing;

    // ── Détection des doublons ────────────────────────────────────
    // On cherche une dépense du même montant dans le même mois,
    // sauf si on est en train de modifier une dépense existante.
    if (e == null) {
      final ym = Ym.of(_date);
      final duplicates = d.transactionsIn(ym).where((t) =>
          (t.amount - amount).abs() < 0.01 &&
          t.categoryId == _cat &&
          (t.person == 0 || !couple || t.person == _person)).toList();
      if (duplicates.isNotEmpty) {
        final dup = duplicates.first;
        final dupDesc = dup.description.isEmpty ? '' : ' (${dup.description})';
        final dupDate = '${dup.date.day.toString().padLeft(2, '0')}/${dup.date.month.toString().padLeft(2, '0')}';
        // Afficher un avertissement — l'utilisateur peut confirmer ou annuler
        showQuickDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Row(children: [
              Text('⚠️', style: TextStyle(fontSize: 22)),
              SizedBox(width: 8),
              Text('Doublon possible', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            ]),
            content: Text(
              'Tu as déjà une dépense de ${eur(amount)}$dupDesc le $dupDate ce mois-ci.\n\nTu veux quand même l\'enregistrer ?',
              style: const TextStyle(fontSize: 14, height: 1.45),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer quand même')),
            ],
          ),
        ).then((confirmed) {
          if (confirmed == true && mounted) _doSave(amount, couple);
        });
        return;
      }
    }
    _doSave(amount, couple);
  }

  void _doSave(double amount, bool couple) {
    final e = widget.existing;
    final devMode = ref.read(devModeProvider);
    final debitDate = devMode ? _debitDate : null;
    if (e != null) {
      ref.read(appProvider.notifier).updateTransaction(e.id, _cat!, _desc.text.trim(), amount, _date,
          person: couple ? _person : 0, tripId: _cat == kTripCatId ? _tripId : null,
          debitDate: debitDate);
    } else {
      ref.read(appProvider.notifier).addTransaction(_cat!, _desc.text.trim(), amount, _date,
          person: couple ? _person : 0, tripId: _cat == kTripCatId ? _tripId : null,
          debitDate: debitDate);
    }
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final cats = d.categories;
    // Voyages du mois de la dépense (le budget d'un voyage ne s'applique que le mois du voyage)
    final dateYm = Ym.of(_date);
    final trips = d.projects.where((p) => p.tripIn(dateYm)).toList();
    if (_cat == kTripCatId && !trips.any((t) => t.id == _tripId)) {
      _cat = null;
      _tripId = null;
    }
    _cat ??= cats.isEmpty ? kUnexpectedId : cats.first.id;

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Où va cette dépense ?', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      // Grille de cartes larges — bien plus facile à toucher qu'un petit chip
      GridView.extent(
        maxCrossAxisExtent: 110,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 1.15,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          for (final c in cats)
            _CatCard(
              emoji: c.emoji,
              name: c.name,
              color: Color(c.colorValue),
              selected: _cat == c.id,
              onTap: () => setState(() { _cat = c.id; _tripId = null; }),
            ),
          _CatCard(
            emoji: '⚡',
            name: 'Imprévu',
            color: AppColors.warning,
            selected: _cat == kUnexpectedId,
            onTap: () => setState(() { _cat = kUnexpectedId; _tripId = null; }),
          ),
          for (final t in trips)
            _CatCard(
              emoji: t.emoji,
              name: t.name,
              color: const Color(0xFF0A84FF),
              selected: _cat == kTripCatId && _tripId == t.id,
              onTap: () => setState(() { _cat = kTripCatId; _tripId = t.id; }),
            ),
        ],
      ),
      if (_cat == kUnexpectedId) ...[
        const SizedBox(height: 8),
        const Text(
            'Imprévu : hors budget, retiré directement de votre fin de mois.',
            style: TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600)),
      ],
      if (_cat == kTripCatId) ...[
        const SizedBox(height: 8),
        const Text('Dépense de voyage : comptée dans le budget du voyage.',
            style: TextStyle(color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600)),
      ],
      if (d.isCouple) ...[
        const SizedBox(height: 16),
        const Text('Dépense de', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          for (final p in [1, 2])
            ChoiceChip(
              label: Text(d.personName(p)),
              selected: _person == p,
              onSelected: (_) => setState(() => _person = p),
            ),
        ]),
      ],
      const SizedBox(height: 16),
      TextField(
        controller: _desc,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(labelText: 'Description (ex. McDonald\'s)')),
      // ── Suggestions de dépenses similaires ──────────────────────
      if (_showSuggestions) ...[ 
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: context.fieldColor,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(14, 10, 14, 4),
                child: Text('Dépenses similaires',
                    style: TextStyle(color: AppColors.muted, fontSize: 12,
                        fontWeight: FontWeight.w600)),
              ),
              for (final s in _suggestions)
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => _applySuggestion(s),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    child: Row(children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(s.description,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          Text(
                            '${d.category(s.categoryId)?.name ?? ''} · '
                            '${s.date.day.toString().padLeft(2, '0')}/${s.date.month.toString().padLeft(2, '0')}/${s.date.year}',
                            style: const TextStyle(color: AppColors.muted, fontSize: 12),
                          ),
                        ]),
                      ),
                      const SizedBox(width: 8),
                      Text(eur(s.amount),
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                      const SizedBox(width: 4),
                      const Icon(Icons.north_west_rounded, size: 16, color: AppColors.muted),
                    ]),
                  ),
                ),
              const SizedBox(height: 4),
            ],
          ),
        ),
      ],
      const SizedBox(height: 12),
      TextField(
        controller: _amt,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'Montant', suffixText: '€'),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: SoftButton(
            icon: Icons.event_rounded,
            label: '${_date.day.toString().padLeft(2, '0')}/${_date.month.toString().padLeft(2, '0')}/${_date.year}',
            onPressed: () async {
              final picked = await pickDay(context, _date);
              if (picked != null) setState(() => _date = picked);
            },
          ),
        ),
        if (!_isToday(_date)) ...[
          const SizedBox(width: 8),
          IconButton.filledTonal(
            tooltip: 'Aujourd\'hui',
            onPressed: () => setState(() => _date = DateTime.now()),
            icon: const Icon(Icons.today_rounded),
          ),
        ],
      ]),
      // ── [Mode dev] Date de débit ──────────────────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 8),
        _DebitDatePicker(
          expenseDate: _date,
          debitDate: _debitDate,
          onChanged: (d) => setState(() => _debitDate = d),
        ),
      ],
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: GradientButton(label: 'Enregistrer', onPressed: _save)),
    ]);
  }
}


/// Carte de sélection de catégorie dans le formulaire de dépense.
/// Remplace les petits ChoiceChip — plus faciles à toucher sur mobile.
class _CatCard extends StatelessWidget {
  final String emoji;
  final String name;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  const _CatCard({required this.emoji, required this.name, required this.color, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: selected ? color.withAlpha(30) : context.fieldColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? color : Colors.transparent,
            width: 2,
          ),
        ),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 26)),
            const SizedBox(height: 5),
            Text(
              name,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                color: selected ? color : context.textColor,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- Nouvelle catégorie + budget ----------------
class AddCategorySheet extends ConsumerStatefulWidget {
  const AddCategorySheet({super.key});
  @override
  ConsumerState<AddCategorySheet> createState() => _AddCategoryState();
}

class _AddCategoryState extends ConsumerState<AddCategorySheet> {
  final _name = TextEditingController();
  final _amt = TextEditingController();
  String _emoji = '🍕';
  int _color = AppColors.palette[2].value;
  bool _separate = false;

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final a = parseAmount(_amt.text);
    if (_name.text.trim().isEmpty || a == null || a < 0) {
      snack(context, 'Renseignez un nom et un montant valide');
      return;
    }
    ref.read(appProvider.notifier).addCategoryWithBudget(_name.text.trim(), _emoji, a,
        colorValue: _color, separate: _separate);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        TextField(
          controller: _name,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Nom')),
        const SizedBox(height: 12),
        TextField(
          controller: _amt,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
              labelText: ref.watch(appProvider).isCouple ? 'Budget mensuel par personne' : 'Budget mensuel',
              suffixText: '€'),
        ),
        if (ref.watch(appProvider).isCouple)
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Un budget par personne', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text(_separate ? 'Chacun a son budget.' : 'Un seul budget pour le couple.'),
            value: _separate,
            onChanged: (v) => setState(() => _separate = v),
          ),
        const SizedBox(height: 14),
        StylePicker(
          emoji: _emoji,
          color: _color,
          onEmoji: (e) => setState(() => _emoji = e),
          onColor: (c) => setState(() => _color = c),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: GradientButton(label: 'Créer', onPressed: _save)),
      ]);
}

// ---------------- Saisie d'un montant simple ----------------
Future<double?> askAmount(BuildContext context, String title, double initial,
    {String? hint, String suffix = '€'}) {
  final c = TextEditingController(
      text: initial == 0 ? '' : (initial == initial.roundToDouble() ? initial.round().toString() : initial.toString()));
  return showQuickDialog<double>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        if (hint != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(hint)),
        TextField(
          controller: c,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
          decoration: InputDecoration(suffixText: suffix),
        ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(
            onPressed: () {
              final v = parseAmount(c.text);
              if (v != null) Navigator.pop(ctx, v);
            },
            child: const Text('OK')),
      ],
    ),
  );
}

// ---------------- Revenu récurrent : modifier un seul mois ----------------
class RecurringOverrideSheet extends ConsumerStatefulWidget {
  final Ym month;
  final String recurringId;
  const RecurringOverrideSheet({super.key, required this.month, required this.recurringId});
  @override
  ConsumerState<RecurringOverrideSheet> createState() => _RecurringOverrideState();
}

class _RecurringOverrideState extends ConsumerState<RecurringOverrideSheet> {
  late final TextEditingController _amt;
  @override
  void initState() {
    super.initState();
    final r = ref.read(appProvider).recurring(widget.recurringId);
    _amt = TextEditingController(text: (r?.amountIn(widget.month) ?? 0).round().toString());
  }

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = ref.watch(appProvider).recurring(widget.recurringId);
    if (r == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
          'Montant habituel : ${eur(r.amount)}. Cette modification ne concerne que ${widget.month.label}, les autres mois ne changent pas (ex. heures supplémentaires).',
          style: const TextStyle(color: AppColors.muted)),
      const SizedBox(height: 12),
      TextField(
        controller: _amt,
        autofocus: true,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: '${r.label} en ${widget.month.longName}', suffixText: '€'),
      ),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Enregistrer pour ce mois',
          onPressed: () {
            final v = parseAmount(_amt.text);
            if (v == null || v < 0) return;
            ref.read(appProvider.notifier).setRecurringOverride(r.id, widget.month, v);
            Navigator.pop(context);
          },
        ),
      ),
      if (r.hasOverride(widget.month)) ...[
        const SizedBox(height: 10),
        SoftButton(
          label: 'Revenir au montant habituel',
          onPressed: () {
            ref.read(appProvider.notifier).setRecurringOverride(r.id, widget.month, null);
            Navigator.pop(context);
          },
        ),
      ],
      const SizedBox(height: 10),
      SoftButton(
        icon: Icons.delete_outline_rounded,
        label: 'Supprimer ce revenu',
        onPressed: () async {
          final choice = await showQuickDialog<String>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Text('Supprimer ${r.label} ?'),
              content: Text(
                  'Uniquement ${widget.month.label}, ou aussi tous les mois suivants ? Les mois précédents ne sont jamais touchés.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                TextButton(
                    onPressed: () => Navigator.pop(ctx, 'one'), child: const Text('Ce mois seulement')),
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, 'future'),
                    child: const Text('Ce mois et les suivants')),
              ],
            ),
          );
          if (choice == null || !context.mounted) return;
          final n = ref.read(appProvider.notifier);
          if (choice == 'one') {
            n.excludeRecurringMonth(r.id, widget.month);
          } else {
            n.endRecurringFrom(r.id, widget.month);
          }
          Navigator.pop(context);
        },
      ),
    ]);
  }
}

// ---------------- Modifier un revenu récurrent (tout : nom, montant, fréquence...) ----------------
class EditRecurringIncomeSheet extends ConsumerStatefulWidget {
  final String recurringId;
  const EditRecurringIncomeSheet({super.key, required this.recurringId});
  @override
  ConsumerState<EditRecurringIncomeSheet> createState() => _EditRecurringIncomeState();
}

class _EditRecurringIncomeState extends ConsumerState<EditRecurringIncomeSheet> {
  late RecurringIncome _r = ref.read(appProvider).recurring(widget.recurringId)!;
  late final TextEditingController _label = TextEditingController(text: _r.label);
  late final TextEditingController _amt = TextEditingController(
      text: _r.amount == _r.amount.roundToDouble() ? _r.amount.round().toString() : _r.amount.toString());
  late Ym _start = _r.start;
  late Ym? _end = _r.end;
  late int _interval = _r.intervalMonths;
  late ReceiptDayRule _receiptDay = _r.receiptDay;

  @override
  void dispose() {
    _label.dispose();
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final still = ref.watch(appProvider).recurring(widget.recurringId);
    if (still == null) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(
        controller: _label,
        textCapitalization: TextCapitalization.sentences,
        decoration: const InputDecoration(labelText: 'Nom'),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _amt,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'Montant habituel', suffixText: '€'),
      ),
      const SizedBox(height: 14),
      const Text('Fréquence', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final n2 in const [1, 2, 3, 4, 6, 12])
          ChoiceChip(
            label: Text(n2 == 1 ? 'Chaque mois' : (n2 == 12 ? '1 fois par an' : 'Tous les $n2 mois')),
            selected: _interval == n2,
            onSelected: (_) => setState(() => _interval = n2),
          ),
      ]),
      const SizedBox(height: 12),
      SoftButton(
        icon: Icons.play_arrow_rounded,
        label: 'À partir de : ${_start.label}',
        onPressed: () async {
          final y = await pickYm(context, _start);
          if (y != null) setState(() => _start = y);
        },
      ),
      const SizedBox(height: 8),
      SoftButton(
        icon: Icons.stop_rounded,
        label: _end == null ? 'Fin : jamais (à l\'infini)' : 'Fin : ${_end!.label}',
        onPressed: () async {
          final y = await pickYm(context, _end ?? _start.add(12));
          if (y != null) setState(() => _end = y);
        },
      ),
      if (_end != null)
        TextButton(onPressed: () => setState(() => _end = null), child: const Text('Sans date de fin')),
      // ── [Mode dev] Date de réception ─────────────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 12),
        _ReceiptDayPicker(
          receiptDay: _receiptDay,
          onChanged: (r) => setState(() => _receiptDay = r),
        ),
      ],
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Enregistrer',
          onPressed: () {
            final v = parseAmount(_amt.text);
            if (_label.text.trim().isEmpty || v == null || v <= 0) {
              snack(context, 'Renseignez un nom et un montant valide');
              return;
            }
            if (_end != null && _end!.isBefore(_start)) {
              snack(context, 'La fin doit être après le début');
              return;
            }
            final devMode = ref.read(devModeProvider);
            ref.read(appProvider.notifier).updateRecurringIncome(widget.recurringId,
                label: _label.text.trim(), amount: v, start: _start, end: _end,
                intervalMonths: _interval,
                receiptDay: devMode ? _receiptDay : null);
            Navigator.pop(context);
          },
        ),
      ),
    ]);
  }
}


class AddIncomeSheet extends ConsumerStatefulWidget {
  final Ym month;
  final bool startRecurring;
  const AddIncomeSheet({super.key, required this.month, this.startRecurring = false});
  @override
  ConsumerState<AddIncomeSheet> createState() => _AddIncomeState();
}

class _AddIncomeState extends ConsumerState<AddIncomeSheet> {
  late bool _recurring = widget.startRecurring;
  IncomeKind _kind = IncomeKind.salary;
  late Ym _start = widget.month;
  Ym? _end;
  int _interval = 1;
  final _label = TextEditingController();
  final _amt = TextEditingController();

  @override
  void dispose() {
    _label.dispose();
    _amt.dispose();
    super.dispose();
  }

  void _save() {
    final v = parseAmount(_amt.text);
    if (v == null || v <= 0) {
      snack(context, 'Renseignez un montant valide');
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (_recurring) {
      if (_end != null && _end!.isBefore(_start)) {
        snack(context, 'La fin doit être après le début');
        return;
      }
      n.addRecurringIncome(_label.text.trim(), v, _start, _end, intervalMonths: _interval);
    } else {
      n.addExtraIncome(_kind, _label.text.trim(), v, widget.month);
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Ponctuel')),
              ButtonSegment(value: true, label: Text('Fréquence')),
            ],
            selected: {_recurring},
            onSelectionChanged: (s) => setState(() => _recurring = s.first),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          _recurring
              ? 'Vous pourrez modifier un mois précis dans le Calendrier.'
              : 'Versé une seule fois en ${widget.month.label}.',
          style: const TextStyle(color: AppColors.muted, fontSize: 13),
        ),
        const SizedBox(height: 14),
        if (!_recurring) ...[
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final k in IncomeKind.values)
              ChoiceChip(label: Text(k.label), selected: _kind == k, onSelected: (_) => setState(() => _kind = k)),
          ]),
          const SizedBox(height: 12),
        ],
        TextField(
            controller: _label,
            textCapitalization: TextCapitalization.sentences,
            decoration: InputDecoration(labelText: _recurring ? 'Nom (ex. Salaire, Loyer perçu)' : 'Libellé (optionnel)')),
        const SizedBox(height: 12),
        TextField(
          controller: _amt,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Montant', suffixText: '€'),
        ),
        if (_recurring) ...[
          const SizedBox(height: 14),
          SoftButton(
            icon: Icons.play_arrow_rounded,
            label: 'À partir de : ${_start.label}',
            onPressed: () async {
              final y = await pickYm(context, _start);
              if (y != null) setState(() => _start = y);
            },
          ),
          const SizedBox(height: 12),
          const Text('Fréquence', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final n2 in const [1, 2, 3, 4, 6, 12])
              ChoiceChip(
                label: Text(n2 == 1 ? 'Chaque mois' : (n2 == 12 ? '1 fois par an' : 'Tous les $n2 mois')),
                selected: _interval == n2,
                onSelected: (_) => setState(() => _interval = n2),
              ),
          ]),
          const SizedBox(height: 12),
          SoftButton(
            icon: Icons.stop_rounded,
            label: _end == null ? 'Fin : jamais (à l\'infini)' : 'Fin : ${_end!.label}',
            onPressed: () async {
              final y = await pickYm(context, _end ?? _start.add(12));
              if (y != null) setState(() => _end = y);
            },
          ),
          if (_end != null)
            TextButton(onPressed: () => setState(() => _end = null), child: const Text('Sans date de fin')),
        ],
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: GradientButton(label: 'Ajouter', onPressed: _save)),
      ]);
}

// ---------------- Charge fixe (création ou modification) ----------------
class AddFixedExpenseSheet extends ConsumerStatefulWidget {
  final FixedExpense? existing;
  const AddFixedExpenseSheet({super.key, this.existing});
  @override
  ConsumerState<AddFixedExpenseSheet> createState() => _AddFixedState();
}

class _AddFixedState extends ConsumerState<AddFixedExpenseSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _amt = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.amount == widget.existing!.amount.roundToDouble()
              ? widget.existing!.amount.round().toString()
              : widget.existing!.amount.toStringAsFixed(2)));
  late Ym _start = widget.existing?.start ?? ref.read(nowProvider);
  late Ym? _end = widget.existing?.end;
  late String _emoji = widget.existing?.emoji ?? '';
  late bool _useEmoji = (widget.existing?.emoji ?? '').isNotEmpty;
  late int _color = widget.existing?.colorValue ?? _defaultColor();
  late int _interval = widget.existing?.intervalMonths ?? 1;
  bool _onlyThisMonth = false; // raccourci "seulement ce mois-ci"

  /// Nouvelle charge : couleur du thème par défaut (on peut la changer ensuite).
  int _defaultColor() {
    if (widget.existing != null) return widget.existing!.colorValue ?? AppColors.teal.value;
    return AppColors.teal.value;
  }

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    final letter = _name.text.trim().isEmpty ? '?' : _name.text.trim().characters.first.toUpperCase();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(
          controller: _name,
          textCapitalization: TextCapitalization.sentences,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(labelText: 'Nom (ex. Loyer)')),
      const SizedBox(height: 12),
      TextField(
        controller: _amt,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'Montant mensuel', suffixText: '€'),
      ),
      const SizedBox(height: 12),
      // Raccourci : juste ce mois-ci (une seule occurrence)
      if (widget.existing == null)
        Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () {
              final now = ref.read(nowProvider);
              setState(() {
                _onlyThisMonth = !_onlyThisMonth;
                if (_onlyThisMonth) {
                  _start = now;
                  _end = now;
                  _interval = 1;
                } else {
                  _end = null;
                }
              });
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: _onlyThisMonth ? AppColors.teal.withAlpha(20) : context.fieldColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: _onlyThisMonth ? AppColors.teal : Colors.transparent,
                  width: 1.5,
                ),
              ),
              child: Row(children: [
                Icon(_onlyThisMonth ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                    color: _onlyThisMonth ? AppColors.teal : AppColors.muted, size: 20),
                const SizedBox(width: 10),
                const Text('Seulement ce mois-ci',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              ]),
            ),
          ),
        ),
      if (!_onlyThisMonth) ...[
        SoftButton(
          icon: Icons.play_arrow_rounded,
          label: 'Début : ${_start.label}',
          onPressed: () async {
            final y = await pickYm(context, _start);
            if (y != null) setState(() => _start = y);
          },
        ),
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.stop_rounded,
          label: _end == null ? 'Fin : toujours (sans date)' : 'Fin : ${_end!.label}',
          onPressed: () async {
            final y = await pickYm(context, _end ?? _start.add(12));
            if (y != null) setState(() => _end = y);
          },
        ),
        if (_end != null)
          TextButton(onPressed: () => setState(() => _end = null), child: const Text('Sans date de fin')),
      ],
      const SizedBox(height: 14),
      const Text('Fréquence', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: [
        for (final n in const [1, 2, 3, 4, 6, 12])
          ChoiceChip(
            label: Text(n == 1 ? 'Chaque mois' : (n == 12 ? '1 fois par an' : 'Tous les $n mois')),
            selected: _interval == n,
            onSelected: (_) => setState(() => _interval = n),
          ),
      ]),
      const SizedBox(height: 14),
      const Text('Logo', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Wrap(spacing: 8, children: [
        ChoiceChip(
          label: const Text('Première lettre'),
          selected: !_useEmoji,
          onSelected: (_) => setState(() => _useEmoji = false),
        ),
        ChoiceChip(
          label: const Text('Emoji'),
          selected: _useEmoji,
          onSelected: (_) => setState(() {
            _useEmoji = true;
            if (_emoji.isEmpty) _emoji = '🏠';
          }),
        ),
      ]),
      const SizedBox(height: 12),
      StylePicker(
        emoji: _emoji,
        color: _color,
        showEmoji: _useEmoji,
        previewLetter: letter,
        onEmoji: (e) => setState(() => _emoji = e),
        onColor: (c) => setState(() => _color = c),
      ),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: editing ? 'Enregistrer' : 'Ajouter la charge',
          onPressed: () {
            final v = parseAmount(_amt.text);
            if (_name.text.trim().isEmpty || v == null || v <= 0) {
              snack(context, 'Renseignez un nom et un montant valide');
              return;
            }
            if (_end != null && _end!.isBefore(_start)) {
              snack(context, 'La fin doit être après le début');
              return;
            }
            final n = ref.read(appProvider.notifier);
            final emoji = _useEmoji ? _emoji : '';
            if (editing) {
              n.updateFixedExpense(FixedExpense(
                  id: widget.existing!.id,
                  name: _name.text.trim(),
                  amount: v,
                  start: _start,
                  end: _end,
                  emoji: emoji,
                  colorValue: _color,
                  intervalMonths: _interval,
                  checkedMonths: widget.existing!.checkedMonths));
            } else {
              n.addFixedExpense(_name.text.trim(), v, _start, _end,
                  emoji: emoji, colorValue: _color, intervalMonths: _interval);
            }
            Navigator.pop(context);
          },
        ),
      ),
      if (editing) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer...',
          onPressed: () async {
            final choice = await showQuickDialog<String>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('Supprimer ${widget.existing!.name} ?'),
                content: const Text('Pour toujours, seulement un mois, ou une période précise ?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
                  TextButton(onPressed: () => Navigator.pop(ctx, 'one'), child: const Text('Un seul mois')),
                  TextButton(onPressed: () => Navigator.pop(ctx, 'range'), child: const Text('Une période')),
                  FilledButton(
                      onPressed: () => Navigator.pop(ctx, 'all'), child: const Text('Pour toujours')),
                ],
              ),
            );
            if (choice == null || !context.mounted) return;
            final n = ref.read(appProvider.notifier);
            if (choice == 'all') {
              n.removeFixedExpense(widget.existing!.id);
              Navigator.pop(context);
              return;
            }
            if (choice == 'one') {
              final y = await pickYm(context, ref.read(chargeMonthProvider));
              if (y != null) n.excludeFixedMonths(widget.existing!.id, [y]);
            } else if (choice == 'range') {
              final from = await pickYm(context, ref.read(chargeMonthProvider));
              if (from == null || !context.mounted) return;
              final to = await pickYm(context, from);
              if (to == null) return;
              final a = from.index <= to.index ? from : to;
              final b = from.index <= to.index ? to : from;
              final months = [for (var i = a.index; i <= b.index; i++) Ym.fromIndex(i)];
              n.excludeFixedMonths(widget.existing!.id, months);
            }
            if (context.mounted) Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}

class AddProjectSheet extends ConsumerStatefulWidget {
  final Project? existing; // non nul : modification d'un voyage
  const AddProjectSheet({super.key, this.existing});
  @override
  ConsumerState<AddProjectSheet> createState() => _AddProjectState();
}

class _AddProjectState extends ConsumerState<AddProjectSheet> {
  late final TextEditingController _name = TextEditingController(text: widget.existing?.name ?? '');
  late final TextEditingController _amt = TextEditingController(
      text: widget.existing == null
          ? ''
          : (widget.existing!.target == widget.existing!.target.roundToDouble()
              ? widget.existing!.target.round().toString()
              : widget.existing!.target.toStringAsFixed(2)));
  late ProjectMode _mode = widget.existing?.mode ?? ProjectMode.expense;
  late Ym _target = widget.existing?.targetYm ?? Ym.now().add(6);
  late DateTime? _start = widget.existing?.tripStart;
  late DateTime? _end = widget.existing?.tripEnd;
  late int _who = widget.existing?.who ?? 0;
  late bool _trip = widget.existing?.isTrip ?? true;

  String _fd(DateTime x) =>
      '${x.day.toString().padLeft(2, '0')}/${x.month.toString().padLeft(2, '0')}/${x.year}';

  /// Un seul calendrier : on touche un jour (départ), puis un autre (retour),
  /// et l'intervalle se sélectionne automatiquement. Il s'ouvre sur le mois actuel,
  /// avec un bouton « Aujourd'hui » directement dans le calendrier.
  Future<void> _pickDates() async {
    final range = await showSheet<DateTimeRange>(
      context,
      title: 'Dates du voyage',
      child: RangeCalendarSheet(
        initialMonth: _start ?? ref.read(nowProvider).firstDay,
        initialStart: _start,
        initialEnd: _end,
      ),
    );
    if (range == null) return;
    setState(() {
      _start = range.start;
      _end = range.end;
      _target = Ym.of(range.start); // le mois du voyage est déduit de la date de départ
    });
  }

  @override
  void dispose() {
    _name.dispose();
    _amt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final expense = _mode == ProjectMode.expense;
    final days = (_start != null && _end != null) ? _end!.difference(_start!).inDays + 1 : 0;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // Voyage, ou tout autre projet d'épargne (voiture, apport, épargne de précaution…)
      SizedBox(
        width: double.infinity,
        child: SegmentedButton<bool>(
          segments: const [
            ButtonSegment(value: true, label: Text('✈️ Voyage')),
            ButtonSegment(value: false, label: Text('🎯 Autre projet')),
          ],
          selected: {_trip},
          showSelectedIcon: false,
          onSelectionChanged: (s) => setState(() {
            _trip = s.first;
            if (!_trip) {
              _start = null;
              _end = null;
              if (widget.existing == null) _mode = ProjectMode.savings;
            }
          }),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _name,
        textCapitalization: TextCapitalization.sentences,
        decoration: InputDecoration(
            labelText: _trip ? 'Nom du voyage (ex. Thaïlande)' : 'Nom du projet (ex. Voiture, Apport maison)')),
      const SizedBox(height: 12),
      TextField(
        controller: _amt,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: _trip ? 'Budget du voyage' : 'Montant à réunir', suffixText: '€'),
      ),
      const SizedBox(height: 12),
      if (!_trip)
        SoftButton(
          icon: Icons.flag_rounded,
          label: 'Objectif pour : ${_target.label}',
          onPressed: () async {
            final y = await pickYm(context, _target);
            if (y != null) setState(() => _target = y);
          },
        ),
      if (_trip) ...[
      Row(children: [
        Expanded(
          child: SoftButton(
            icon: Icons.flight_takeoff_rounded,
            label: _start == null ? 'Date de départ' : 'Départ : ${_fd(_start!)}',
            onPressed: _pickDates,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: SoftButton(
            icon: Icons.flight_land_rounded,
            label: _end == null ? 'Date de retour' : 'Retour : ${_fd(_end!)}',
            onPressed: _pickDates,
          ),
        ),
      ]),
      const SizedBox(height: 8),
      if (_start == null)
        SoftButton(
          icon: Icons.calendar_month_rounded,
          label: 'Ou seulement le mois : ${_target.label}',
          onPressed: () async {
            final y = await pickYm(context, _target);
            if (y != null) setState(() => _target = y);
          },
        )
      else
        Text(
            'Voyage de $days jour${days > 1 ? 's' : ''} en ${_target.longName.toLowerCase()} ${_target.year}.'
            '${d.hasAE ? ' Vos passages clients pendant ces dates sont retirés.' : ''}',
            style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
      ],
      if (_trip && d.isCouple && d.hasAE) ...[
        const SizedBox(height: 12),
        const Text('Qui part ?', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          ChoiceChip(label: const Text('Les deux'), selected: _who == 0, onSelected: (_) => setState(() => _who = 0)),
          for (final p in [1, 2])
            ChoiceChip(
                label: Text(d.personName(p)), selected: _who == p, onSelected: (_) => setState(() => _who = p)),
        ]),
      ],
      const SizedBox(height: 14),
      const Text('Comment le financer ?', style: TextStyle(color: AppColors.muted, fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      Wrap(spacing: 8, runSpacing: 8, children: [
        ChoiceChip(
          label: Text(_trip ? 'Payer pendant le voyage' : 'Payer le mois venu'),
          selected: expense,
          onSelected: (_) => setState(() => _mode = ProjectMode.expense),
        ),
        ChoiceChip(
          label: const Text('Épargner avant'),
          selected: !expense,
          onSelected: (_) => setState(() => _mode = ProjectMode.savings),
        ),
      ]),
      const SizedBox(height: 8),
      Text(
        expense
            ? (_trip
                ? 'Le budget est réservé le mois du voyage. Vous notez vos dépenses sur place.'
                : 'Le montant est réservé le mois de l\'objectif.')
            : (_trip
                ? 'Vous mettez de l\'argent de côté chaque mois avant le voyage.'
                : 'Vous mettez de l\'argent de côté chaque mois jusqu\'à l\'objectif.'),
        style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.35),
      ),
      if (widget.existing != null) ...[
        const SizedBox(height: 8),
        const Text(
            'Les dépenses déjà notées restent liées au projet.',
            style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.3)),
      ],
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: widget.existing == null ? (_trip ? 'Créer le voyage' : 'Créer le projet') : 'Enregistrer',
          onPressed: () {
            final v = parseAmount(_amt.text);
            if (_name.text.trim().isEmpty || v == null || v <= 0) {
              snack(context, 'Renseignez un nom et un budget valide');
              return;
            }
            final now = ref.read(nowProvider);
            if (_start != null && _end != null && _end!.isBefore(_start!)) {
              snack(context, 'Le retour doit être après le départ');
              return;
            }
            if (widget.existing == null) {
              if (expense ? _target.isBefore(now) : !_target.isAfter(now)) {
                snack(context, expense ? 'Choisissez le mois courant ou un mois futur' : 'Le mois de l\'objectif doit être dans le futur pour épargner');
                return;
              }
              ref.read(appProvider.notifier).addProject(_name.text.trim(), v, _target, _mode,
                  tripStart: _start, tripEnd: _end, who: _who, isTrip: _trip);
            } else {
              ref.read(appProvider.notifier).updateProject(widget.existing!.id,
                  name: _name.text.trim(), target: v, targetYm: _target, mode: _mode,
                  tripStart: _start, tripEnd: _end, who: _who, isTrip: _trip);
            }
            Navigator.pop(context);
          },
        ),
      ),
    ]);
  }
}

// ---------------- Modifier un budget (tous les mois ou un seul mois) ----------------
class EditBudgetSheet extends ConsumerStatefulWidget {
  final String budgetId;
  final Ym month;
  const EditBudgetSheet({super.key, required this.budgetId, required this.month});
  @override
  ConsumerState<EditBudgetSheet> createState() => _EditBudgetState();
}

class _EditBudgetState extends ConsumerState<EditBudgetSheet> {
  bool _onlyThisMonth = false;
  late final TextEditingController _amt;
  late String _emojiSel;
  late int _colorSel;
  late ReceiptDayRule _debitDay;

  Budget? _find() {
    for (final b in ref.read(appProvider).budgets) {
      if (b.id == widget.budgetId) return b;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    final b = _find();
    _amt = TextEditingController(text: (b?.amount ?? 0).round().toString());
    final cat = b == null ? null : ref.read(appProvider).category(b.categoryId);
    _emojiSel = cat?.emoji ?? '💰';
    _colorSel = cat?.colorValue ?? AppColors.palette[2].value;
    _debitDay = b?.debitDay ?? ReceiptDayRule.none;
  }

  @override
  void dispose() {
    _amt.dispose();
    super.dispose();
  }

  void _setMode(bool only) {
    final b = _find();
    if (b == null) return;
    setState(() {
      _onlyThisMonth = only;
      _amt.text = (only ? b.amountIn(widget.month) : b.amount).round().toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    final b = ref.watch(appProvider).budgets.where((x) => x.id == widget.budgetId).firstOrNull;
    if (b == null) return const SizedBox.shrink();
    final n = ref.read(appProvider.notifier);
    final overridden = b.hasOverride(widget.month);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Budget habituel : ${eur(b.amount)}'
          '${overridden ? ' · ${widget.month.label} : ${eur(b.amountIn(widget.month))}' : ''}',
          style: const TextStyle(color: AppColors.muted)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: [
        ChoiceChip(
          label: const Text('Tous les mois'),
          selected: !_onlyThisMonth,
          onSelected: (_) => _setMode(false),
        ),
        ChoiceChip(
          label: Text('Seulement ${widget.month.label}'),
          selected: _onlyThisMonth,
          onSelected: (_) => _setMode(true),
        ),
      ]),
      const SizedBox(height: 8),
      Text(
        _onlyThisMonth
            ? 'Les autres mois gardent leur budget habituel.'
            : 'Le budget habituel change pour tous les mois'
                '${overridden ? ' (sauf ${widget.month.longName.toLowerCase()} ${widget.month.year}, déjà modifié)' : ''}.',
        style: const TextStyle(color: AppColors.muted, fontSize: 13),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _amt,
        autofocus: true,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: const InputDecoration(labelText: 'Montant du budget', suffixText: '€'),
      ),
      if (ref.watch(appProvider).isCouple) ...[
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Un budget par personne', style: TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(b.person != 0 ? 'Chacun a son budget.' : 'Un seul budget pour le couple.'),
          value: b.person != 0,
          onChanged: (v) {
            n.setBudgetSeparate(b.categoryId, v);
            Navigator.pop(context);
          },
        ),
      ],
      const SizedBox(height: 16),
      const Text('Icône et couleur', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      StylePicker(
        emoji: _emojiSel,
        color: _colorSel,
        onEmoji: (e) => setState(() => _emojiSel = e),
        onColor: (c) => setState(() => _colorSel = c),
      ),
      // ── [Mode dev] Règle de débit du budget ──────────────────
      if (ref.watch(devModeProvider)) ...[
        const SizedBox(height: 16),
        const Text('Date de débit par défaut',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 4),
        const Text(
          'S\'applique à toutes les dépenses de ce budget. '
          'Une dépense avec sa propre date de débit la garde.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.4),
        ),
        const SizedBox(height: 10),
        _BudgetDebitDayPicker(
          debitDay: _debitDay,
          onChanged: (r) => setState(() => _debitDay = r),
        ),
      ],
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: 'Enregistrer',
          onPressed: () {
            final v = parseAmount(_amt.text);
            if (v == null || v < 0) return;
            if (_onlyThisMonth) {
              n.setBudgetOverride(b.id, widget.month, v);
            } else {
              n.setBudgetAmount(b.id, v);
            }
            n.setCategoryStyle(b.categoryId, _emojiSel, _colorSel);
            // [Mode dev] Sauvegarder la règle de débit
            if (ref.read(devModeProvider)) {
              n.setBudgetDebitDay(b.id, _debitDay);
            }
            Navigator.pop(context);
          },
        ),
      ),
      if (overridden) ...[
        const SizedBox(height: 10),
        SoftButton(
          label: 'Revenir au budget habituel pour ce mois',
          onPressed: () {
            n.setBudgetOverride(b.id, widget.month, null);
            Navigator.pop(context);
          },
        ),
      ],
    ]);
  }
}

// ---------------- Couple : noms des deux conjoints ----------------
class CoupleSheet extends ConsumerStatefulWidget {
  const CoupleSheet({super.key});
  @override
  ConsumerState<CoupleSheet> createState() => _CoupleState();
}

class _CoupleState extends ConsumerState<CoupleSheet> {
  late final TextEditingController _p1;
  late final TextEditingController _p2;

  @override
  void initState() {
    super.initState();
    final u = ref.read(appProvider).user;
    _p1 = TextEditingController(text: u.isCouple ? u.person1 : '');
    _p2 = TextEditingController(text: u.isCouple ? u.person2 : '');
  }

  @override
  void dispose() {
    _p1.dispose();
    _p2.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isCouple = ref.watch(appProvider).isCouple;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
        isCouple
            ? 'Modifiez les prénoms affichés sur les budgets et les dépenses.'
            : 'Vous pourrez séparer certains budgets (un par personne) et garder les autres en commun.',
        style: const TextStyle(color: AppColors.muted, fontSize: 13),
      ),
      const SizedBox(height: 14),
      TextField(
        controller: _p1,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(labelText: 'Prénom du conjoint 1 (vous)')),
      const SizedBox(height: 12),
      TextField(
        controller: _p2,
        textCapitalization: TextCapitalization.words,
        decoration: const InputDecoration(labelText: 'Prénom du conjoint 2')),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: GradientButton(
          label: isCouple ? 'Enregistrer' : 'Activer le mode couple',
          onPressed: () {
            final a = _p1.text.trim();
            final b = _p2.text.trim();
            if (a.isEmpty || b.isEmpty) {
              snack(context, 'Renseignez les deux prénoms');
              return;
            }
            if (a.toLowerCase() == b.toLowerCase()) {
              snack(context, 'Les deux prénoms doivent être différents');
              return;
            }
            ref.read(appProvider.notifier).setCouple(true, person1: a, person2: b);
            Navigator.pop(context);
          },
        ),
      ),
    ]);
  }
}


// ── [Mode dev] Sélecteur de date de débit ────────────────────────────────────
/// Permet de choisir la date à laquelle une dépense sera débitée.
/// Raccourcis : "5 du mois prochain", "dernier jour ouvré", calendrier libre.
class _DebitDatePicker extends StatelessWidget {
  final DateTime expenseDate; // date de la dépense (référence pour les raccourcis)
  final DateTime? debitDate;
  final ValueChanged<DateTime?> onChanged;
  const _DebitDatePicker({required this.expenseDate, required this.debitDate, required this.onChanged});

  DateTime _fifthNextMonth() {
    final next = DateTime(expenseDate.year, expenseDate.month + 1, 5);
    return next;
  }

  DateTime _lastWorkingDayOfMonth() {
    final lastDay = DateTime(expenseDate.year, expenseDate.month + 1, 0).day;
    var d = DateTime(expenseDate.year, expenseDate.month, lastDay);
    while (d.weekday == DateTime.saturday || d.weekday == DateTime.sunday) {
      d = d.subtract(const Duration(days: 1));
    }
    return d;
  }

  String _fmt(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  Widget build(BuildContext context) {
    final fifth = _fifthNextMonth();
    final lastWorking = _lastWorkingDayOfMonth();
    final hasFifth = debitDate != null && _isSameDay(debitDate!, fifth);
    final hasLast = debitDate != null && _isSameDay(debitDate!, lastWorking);
    final hasCustom = debitDate != null && !hasFifth && !hasLast;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: debitDate != null
            ? tint(AppColors.violet, .08)
            : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: debitDate != null ? AppColors.violet.withAlpha(80) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_outlined, size: 15,
              color: debitDate != null ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            debitDate != null ? 'Débit le ${_fmt(debitDate!)}' : 'Date de débit (optionnel)',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: debitDate != null ? AppColors.violet : AppColors.muted,
            ),
          ),
          if (debitDate != null) ...[
            const Spacer(),
            GestureDetector(
              onTap: () => onChanged(null),
              child: const Icon(Icons.close_rounded, size: 18, color: AppColors.muted),
            ),
          ],
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          // Raccourci 1 : le 5 du mois prochain
          _DebitChip(
            label: '5 du mois prochain',
            selected: hasFifth,
            onTap: () => onChanged(hasFifth ? null : fifth),
          ),
          // Raccourci 2 : dernier jour ouvré du mois
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: hasLast,
            onTap: () => onChanged(hasLast ? null : lastWorking),
          ),
          // Raccourci 3 : calendrier libre
          _DebitChip(
            label: hasCustom ? _fmt(debitDate!) : 'Autre date…',
            selected: hasCustom,
            icon: Icons.calendar_today_rounded,
            onTap: () async {
              final now = DateTime.now();
              final picked = await showDatePicker(
                context: context,
                initialDate: debitDate ?? expenseDate.add(const Duration(days: 3)),
                firstDate: DateTime(now.year - 1),
                lastDate: DateTime(now.year + 2),
              );
              if (picked != null) onChanged(picked);
            },
          ),
        ]),
      ]),
    );
  }
}

class _DebitChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;
  const _DebitChip({required this.label, required this.selected, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppColors.violet.withAlpha(25) : context.fieldColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.violet : context.trackColor,
            width: 1.5,
          ),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: selected ? AppColors.violet : AppColors.muted),
            const SizedBox(width: 5),
          ],
          Text(label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? AppColors.violet : context.textColor,
              )),
        ]),
      ),
    );
  }
}


// ── [Mode dev] Sélecteur de date de réception (revenus récurrents) ────────────
class _ReceiptDayPicker extends StatefulWidget {
  final ReceiptDayRule receiptDay;
  final ValueChanged<ReceiptDayRule> onChanged;
  const _ReceiptDayPicker({required this.receiptDay, required this.onChanged});

  @override
  State<_ReceiptDayPicker> createState() => _ReceiptDayPickerState();
}

class _ReceiptDayPickerState extends State<_ReceiptDayPicker> {
  late TextEditingController _dayCtrl;

  @override
  void initState() {
    super.initState();
    _dayCtrl = TextEditingController(
      text: widget.receiptDay.kind == ReceiptDayKind.fixedDay
          ? widget.receiptDay.day.toString()
          : '',
    );
  }

  @override
  void dispose() {
    _dayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rule = widget.receiptDay;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: rule.kind != ReceiptDayKind.none
            ? tint(AppColors.teal, .08)
            : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: rule.kind != ReceiptDayKind.none
              ? AppColors.teal.withAlpha(80)
              : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_rounded, size: 15,
              color: rule.kind != ReceiptDayKind.none ? AppColors.teal : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            _ruleLabel(rule),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: rule.kind != ReceiptDayKind.none ? AppColors.teal : AppColors.muted,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _DebitChip(
            label: 'Aucune règle',
            selected: rule.kind == ReceiptDayKind.none,
            onTap: () {
              widget.onChanged(ReceiptDayRule.none);
              setState(() => _dayCtrl.text = '');
            },
          ),
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: rule.kind == ReceiptDayKind.lastWorkingDay,
            onTap: () => widget.onChanged(
                const ReceiptDayRule(kind: ReceiptDayKind.lastWorkingDay)),
          ),
        ]),
        const SizedBox(height: 10),
        // Saisie d'un jour fixe
        Row(children: [
          Expanded(
            child: TextField(
              controller: _dayCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Jour fixe du mois (ex. 26)',
                suffixText: 'du mois',
                filled: true,
                fillColor: rule.kind == ReceiptDayKind.fixedDay
                    ? AppColors.teal.withAlpha(15)
                    : null,
              ),
              onChanged: (v) {
                final d = int.tryParse(v);
                if (d != null && d >= 1 && d <= 31) {
                  widget.onChanged(ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: d));
                }
              },
            ),
          ),
        ]),
        if (rule.kind == ReceiptDayKind.fixedDay)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              'Le salaire sera reçu le ${rule.day} de chaque mois.',
              style: const TextStyle(color: AppColors.teal, fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
          ),
      ]),
    );
  }

  String _ruleLabel(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => 'Date de réception (optionnel)',
        ReceiptDayKind.fixedDay => 'Reçu le ${r.day} du mois',
        ReceiptDayKind.lastWorkingDay => 'Reçu le dernier jour ouvré',
      };
}


// ── [Mode dev] Sélecteur de règle de débit pour un budget ────────────────────
class _BudgetDebitDayPicker extends StatefulWidget {
  final ReceiptDayRule debitDay;
  final ValueChanged<ReceiptDayRule> onChanged;
  const _BudgetDebitDayPicker({required this.debitDay, required this.onChanged});

  @override
  State<_BudgetDebitDayPicker> createState() => _BudgetDebitDayPickerState();
}

class _BudgetDebitDayPickerState extends State<_BudgetDebitDayPicker> {
  late TextEditingController _dayCtrl;

  @override
  void initState() {
    super.initState();
    _dayCtrl = TextEditingController(
      text: widget.debitDay.kind == ReceiptDayKind.fixedDay
          ? widget.debitDay.day.toString()
          : '',
    );
  }

  @override
  void dispose() {
    _dayCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rule = widget.debitDay;
    final active = rule.kind != ReceiptDayKind.none;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
      decoration: BoxDecoration(
        color: active ? tint(AppColors.violet, .08) : context.fieldColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: active ? AppColors.violet.withAlpha(80) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Icon(Icons.account_balance_outlined, size: 15,
              color: active ? AppColors.violet : AppColors.muted),
          const SizedBox(width: 6),
          Text(
            _ruleLabel(rule),
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 13.5,
              color: active ? AppColors.violet : AppColors.muted,
            ),
          ),
        ]),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _DebitChip(
            label: 'Aucune règle',
            selected: rule.kind == ReceiptDayKind.none,
            onTap: () {
              widget.onChanged(ReceiptDayRule.none);
              setState(() => _dayCtrl.text = '');
            },
          ),
          _DebitChip(
            label: '5 du mois prochain',
            selected: rule.kind == ReceiptDayKind.fixedDay && rule.day == 5,
            onTap: () {
              widget.onChanged(const ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: 5));
              setState(() => _dayCtrl.text = '5');
            },
          ),
          _DebitChip(
            label: 'Dernier jour ouvré',
            selected: rule.kind == ReceiptDayKind.lastWorkingDay,
            onTap: () => widget.onChanged(
                const ReceiptDayRule(kind: ReceiptDayKind.lastWorkingDay)),
          ),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: TextField(
              controller: _dayCtrl,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Autre jour fixe (ex. 10)',
                suffixText: 'du mois',
                filled: true,
                fillColor: rule.kind == ReceiptDayKind.fixedDay
                    ? AppColors.violet.withAlpha(15)
                    : null,
              ),
              onChanged: (v) {
                final d = int.tryParse(v);
                if (d != null && d >= 1 && d <= 31) {
                  widget.onChanged(ReceiptDayRule(kind: ReceiptDayKind.fixedDay, day: d));
                }
              },
            ),
          ),
        ]),
        if (active)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              _ruleExplain(rule),
              style: const TextStyle(
                  color: AppColors.violet, fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.4),
            ),
          ),
      ]),
    );
  }

  String _ruleLabel(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => 'Pas de règle (débit immédiat)',
        ReceiptDayKind.fixedDay => r.day == 5
            ? 'Débité le 5 du mois prochain'
            : 'Débité le ${r.day} du mois',
        ReceiptDayKind.lastWorkingDay => 'Débité le dernier jour ouvré',
      };

  String _ruleExplain(ReceiptDayRule r) => switch (r.kind) {
        ReceiptDayKind.none => '',
        ReceiptDayKind.fixedDay => r.day == 5
            ? 'Toutes les dépenses de ce budget seront comptées dans le mois suivant (débit le 5).'
            : 'Toutes les dépenses de ce budget seront débitées le ${r.day} du mois.',
        ReceiptDayKind.lastWorkingDay =>
            'Toutes les dépenses de ce budget seront débitées le dernier jour ouvré du mois.',
      };
}
