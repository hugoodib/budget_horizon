import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme.dart';
import '../../core/ym.dart';
import '../../domain/models.dart';
import '../providers.dart';
import '../widgets/common.dart';

// ══════════════════════════════════════════════════════════════════════════════
// Écran Congés
// ══════════════════════════════════════════════════════════════════════════════

class LeaveScreen extends ConsumerStatefulWidget {
  const LeaveScreen({super.key});
  @override
  ConsumerState<LeaveScreen> createState() => _LeaveScreenState();
}

class _LeaveScreenState extends ConsumerState<LeaveScreen> {
  late Ym _month;
  int _horizon = 12; // nombre de mois affichés dans la vue d'ensemble

  @override
  void initState() {
    super.initState();
    _month = ref.read(leaveMonthProvider);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Sync si leaveMonthProvider a été changé depuis l'extérieur (ex. alerte)
    final providerMonth = ref.read(leaveMonthProvider);
    if (providerMonth != _month) {
      setState(() => _month = providerMonth);
    }
  }

  /// Solde à la fin du mois [ym] = soldeDebut(ym) + cumul(ym) - poses(ym).
  double _soldeFin(LeaveType lt, Ym ym, AppData d) {
    return _soldeDebut(lt, ym, d) + lt.accrualPerMonth - _poses(lt, ym, d);
  }

  /// Solde au début du mois [ym].
  double _soldeDebut(LeaveType lt, Ym ym, AppData d) {
    final manual = d.leaveEntries
        .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note == '__solde__')
        .firstOrNull;
    if (manual != null) return manual.days;
    if (ym.index <= d.startYm.index) return lt.initialBalance;
    return _soldeFin(lt, ym.add(-1), d);
  }

  /// Jours posés pour un type dans un mois.
  double _poses(LeaveType lt, Ym ym, AppData d) => d.leaveEntries
      .where((e) => e.leaveTypeId == lt.id && e.month == ym && e.note != '__solde__')
      .fold(0.0, (s, e) => s + e.days);

  /// Solde disponible = soldeDebut + cumul du mois.
  double _disponible(LeaveType lt, Ym ym, AppData d) =>
      _soldeDebut(lt, ym, d) + lt.accrualPerMonth;

  /// Maximum posable dans [ym] pour [lt].
  int _maxPosable(LeaveType lt, Ym ym, AppData d) =>
      _disponible(lt, ym, d).floor().clamp(0, 999).toInt();

  /// Maximum total posable tous types confondus.
  int _maxTotal(List<LeaveType> types, AppData d) =>
      types.fold(0, (s, lt) => s + _maxPosable(lt, _month, d));

  /// Total posé tous types confondus.
  double _totalPose(List<LeaveType> types, AppData d) =>
      types.fold(0.0, (s, lt) => s + _poses(lt, _month, d));

  _LeaveConflict? _findConflict(LeaveType lt, Ym from, double extraDays, AppData d) {
    final futurePoses = d.leaveEntries
        .where((e) => e.leaveTypeId == lt.id && e.month.index > from.index && e.note != '__solde__')
        .toList();
    if (futurePoses.isEmpty) return null;
    for (final entry in futurePoses) {
      final soldeFinReel = _soldeFin(lt, entry.month, d);
      final soldeFinSimule = soldeFinReel - extraDays;
      if (soldeFinSimule < 0) {
        return _LeaveConflict(month: entry.month, manque: -soldeFinSimule);
      }
    }
    return null;
  }

  /// Touche un mois de la vue d'ensemble : il devient le mois affiché et on peut
  /// directement modifier le nombre de jours posés (0 pour tout retirer).
  Future<void> _editMonth(Ym ym, List<LeaveType> types, AppData d, AppNotifier n) async {
    setState(() => _month = ym);
    ref.read(leaveMonthProvider.notifier).state = ym;
    final maxTotal = types.fold(0, (s, lt) => s + _maxPosable(lt, ym, d));
    final current = types.fold(0.0, (s, lt) => s + _poses(lt, ym, d));
    final v = await _askDays(
      context,
      title: 'Congés · ${ym.label}',
      subtitle: maxTotal > 0
          ? '$maxTotal j disponibles${types.length > 1 ? ' au total' : ''}'
          : 'Aucun jour disponible ce mois',
      initial: current,
      max: maxTotal.toDouble(),
    );
    if (v == null || !mounted) return;
    final conflicts = n.checkTotalLeave(ym, v);
    if (conflicts.isNotEmpty) {
      final ok = await _showConflictDialog(context, conflicts, v, _fmt);
      if (ok != true) return;
    }
    n.setTotalLeave(ym, v);
  }

  /// Vue année : les 12 prochains mois (à partir du mois en cours), avec les jours posés
  /// par type, les jours disponibles et ce qu'il reste en fin de mois.
  List<_YearMonth> _yearOverview(List<LeaveType> types, AppData d, Ym now) {
    final first = now.isBefore(d.startYm) ? d.startYm : now;
    return [
      for (var i = 0; i < _horizon; i++)
        () {
          final ym = first.add(i);
          final parts = <({LeaveType type, double days})>[
            for (final lt in types)
              if (_poses(lt, ym, d) > 0.001) (type: lt, days: _poses(lt, ym, d)),
          ];
          final dispo = types.fold(0.0, (s, lt) => s + _disponible(lt, ym, d));
          final reste = types.fold(0.0, (s, lt) => s + _soldeFin(lt, ym, d));
          return _YearMonth(ym, parts, dispo, reste);
        }(),
    ];
  }

  String _fmt(double v) => v == v.roundToDouble()
      ? v.round().toString()
      : v.toStringAsFixed(2).replaceAll('.', ',');

  @override
  Widget build(BuildContext context) {
    final d = ref.watch(appProvider);
    final now = ref.watch(nowProvider);
    final n = ref.read(appProvider.notifier);
    final types = [...d.leaveTypes]..sort((a, b) => a.priority.compareTo(b.priority));

    return ScreenScaffold(
      title: 'Congés',
      actions: [
        RoundIconButton(
          icon: Icons.settings_rounded,
          onTap: () => showSheet(context,
              title: 'Catégories de congés', child: _LeaveTypesManagerSheet()),
        ),
      ],
      pinned: MonthSwitcher(
        value: _month,
        min: d.startYm,
        now: now,
        onChanged: (v) {
          setState(() => _month = v);
          ref.read(leaveMonthProvider.notifier).state = v;
        },
      ),
      children: types.isEmpty
          ? [
              const SizedBox(height: 60),
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('🏖️', style: TextStyle(fontSize: 52)),
                  const SizedBox(height: 16),
                  const Text('Aucune catégorie',
                      style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                  const SizedBox(height: 8),
                  const Text(
                    'Ajoutez vos types de congés (CP, RTT…)\ndepuis l\'icône ⚙️ en haut à droite.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.muted, height: 1.5),
                  ),
                ]),
              ),
            ]
          : [
              // ── Alerte si un mois précédent a changé et impacte ici ──
              ..._buildPrevMonthAlerts(types, d, n),

              // ══════════════════════════════════════════════════
              // 1. CARTE SOLDE FIN DE MOIS (tout en haut)
              // ══════════════════════════════════════════════════
              _SoldeFinCard(
                types: types,
                soldeFin: (lt) => _soldeFin(lt, _month, d),
                fmt: _fmt,
              ),
              const SizedBox(height: 16),

              // Vue d'ensemble : tous les mois où des congés sont posés
              _LeaveOverviewCard(
                months: _yearOverview(types, d, now),
                horizon: _horizon,
                onHorizon: (v) => setState(() => _horizon = v),
                current: _month,
                now: now,
                fmt: _fmt,
                onTap: (ym) => _editMonth(ym, types, d, n),
              ),
              const SizedBox(height: 16),

              // ══════════════════════════════════════════════════
              // 2. SAISIE : combien je veux poser + répartition auto
              // ══════════════════════════════════════════════════
              _QuickDistributionCard(
                month: _month,
                types: types,
                d: d,
                maxTotal: _maxTotal(types, d),
                totalPose: _totalPose(types, d),
                maxPosable: (lt) => _maxPosable(lt, _month, d),
                fmt: _fmt,
                onDistribute: (totalDays) async {
                  // Vérifier si des mois futurs deviennent impossibles
                  final conflicts = n.checkTotalLeave(_month, totalDays);
                  if (conflicts.isNotEmpty) {
                    final ok = await _showConflictDialog(context, conflicts, totalDays, _fmt);
                    if (ok != true) return;
                  }
                  n.setTotalLeave(_month, totalDays);
                },
              ),
              const SizedBox(height: 16),

              // ══════════════════════════════════════════════════
              // 3. DÉTAIL PAR TYPE (réglage fin si besoin)
              // ══════════════════════════════════════════════════
              const SectionTitle('Répartition par type'),
              AppCard(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(children: [
                  for (final lt in types) ...[
                    _PoseTile(
                      lt: lt,
                      taken: _poses(lt, _month, d),
                      maxPosable: _maxPosable(lt, _month, d),
                      onConflictCheck: (extra) => _findConflict(lt, _month, extra, d),
                      soldeAvant: _soldeDebut(lt, _month, d),
                      accrual: lt.accrualPerMonth,
                      fmt: _fmt,
                      onChanged: (v) async {
                        // Calculer le nouveau total ce mois si on change ce type
                        final autresTypes = types.where((t) => t.id != lt.id);
                        final autresPoses = autresTypes.fold(0.0, (s, t) => s + _poses(t, _month, d));
                        final newTotal = autresPoses + v;

                        final conflicts = n.checkTotalLeave(_month, newTotal);
                        if (conflicts.isNotEmpty) {
                          final ok = await _showConflictDialog(context, conflicts, newTotal, _fmt);
                          if (ok != true) return;
                        }
                        n.setTotalLeave(_month, newTotal);
                      },
                    ),
                    if (lt != types.last) const Divider(height: 1, indent: 16),
                  ],
                ]),
              ),
            ],
    );
  }

  List<Widget> _buildPrevMonthAlerts(List<LeaveType> types, AppData d, AppNotifier n) {
    final alerts = <Widget>[];
    for (final lt in types) {
      final dispo = _disponible(lt, _month, d);
      final pose = _poses(lt, _month, d);
      if (pose > dispo && pose > 0) {
        final surplus = pose - dispo;
        alerts.add(Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          decoration: BoxDecoration(
            color: AppColors.warning.withAlpha(18),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.warning.withAlpha(80)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.warning_amber_rounded, size: 16, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(
                '${lt.name} : tu poses ${_fmt(pose)} j mais seulement ${_fmt(dispo)} j sont disponibles ce mois.',
                style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.w700, fontSize: 13),
              )),
            ]),
            const SizedBox(height: 6),
            Text(
              'Un mois précédent a peut-être été modifié. Il manque ${_fmt(surplus)} j.',
              style: const TextStyle(color: AppColors.warning, fontSize: 12, height: 1.4),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => n.setLeaveEntry(lt.id, _month, dispo.floorToDouble()),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.warning),
                    foregroundColor: AppColors.warning,
                    minimumSize: const Size.fromHeight(36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: Text('Ajuster à ${_fmt(dispo.floorToDouble())} j'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () => n.setLeaveEntry(lt.id, _month, 0),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.danger),
                    foregroundColor: AppColors.danger,
                    minimumSize: const Size.fromHeight(36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('Effacer'),
                ),
              ),
            ]),
          ]),
        ));
      }
    }
    return alerts;
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Vue année : 12 mois, une barre par mois (jours posés) + reste en fin de mois
// ══════════════════════════════════════════════════════════════════════════════
class _YearMonth {
  final Ym ym;
  final List<({LeaveType type, double days})> parts;
  final double dispo; // jours disponibles dans le mois (avant pose)
  final double reste; // jours restants en fin de mois
  const _YearMonth(this.ym, this.parts, this.dispo, this.reste);
  double get posed => parts.fold(0.0, (a, p) => a + p.days);
}

class _LeaveOverviewCard extends StatelessWidget {
  final List<_YearMonth> months;
  final int horizon;
  final ValueChanged<int> onHorizon;
  final Ym current;
  final Ym now;
  final String Function(double) fmt;
  final ValueChanged<Ym> onTap;
  const _LeaveOverviewCard(
      {required this.months,
      required this.horizon,
      required this.onHorizon,
      required this.current,
      required this.now,
      required this.fmt,
      required this.onTap});

  Widget _bar(BuildContext context, _YearMonth m) {
    final scale = m.dispo > 0.001 ? m.dispo : (m.posed > 0.001 ? m.posed : 1.0);
    final restFlex = ((scale - m.posed).clamp(0.0, scale) / scale * 1000).round().toInt();
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: SizedBox(
        height: 9,
        child: Row(children: [
          for (final p in m.parts)
            Expanded(
              flex: ((p.days / scale) * 1000).round().clamp(1, 1000).toInt(),
              child: Container(color: Color(p.type.colorValue)),
            ),
          if (restFlex > 0 || m.parts.isEmpty)
            Expanded(
              flex: restFlex > 0 ? restFlex : 1,
              child: Container(color: context.trackColor),
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final total = months.fold(0.0, (s, m) => s + m.posed);
    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.calendar_month_rounded, size: 18, color: AppColors.violet),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
                horizon % 12 == 0
                    ? 'Mes congés sur ${horizon ~/ 12 == 1 ? '12 mois' : '${horizon ~/ 12} ans'}'
                    : 'Mes congés sur $horizon mois',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
          Text('${fmt(total)} j posés',
              style: TextStyle(
                  color: context.mutedColor, fontSize: 12.5, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 4),
        Text('Chaque barre montre les jours posés sur les jours disponibles. Touche un mois pour le modifier.',
            style: TextStyle(color: context.mutedColor, fontSize: 12.5, height: 1.3)),
        const SizedBox(height: 10),
        PillSelector<int>.row(
          items: const [
            PillItem(12, '1 an'),
            PillItem(24, '2 ans'),
            PillItem(36, '3 ans'),
            PillItem(60, '5 ans'),
          ],
          selected: horizon,
          onChanged: onHorizon,
        ),
        const SizedBox(height: 10),
        for (final m in months)
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => onTap(m.ym),
            child: Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: m.ym == current ? AppColors.violet.withAlpha(24) : context.fieldColor,
                borderRadius: BorderRadius.circular(12),
                border: m.ym == current
                    ? Border.all(color: AppColors.violet.withAlpha(120), width: 1.2)
                    : null,
              ),
              child: Row(children: [
                SizedBox(
                  width: 62,
                  child: Text(
                    '${m.ym.short} ${m.ym.year % 100}',
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
                  ),
                ),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _bar(context, m),
                    const SizedBox(height: 4),
                    Text(
                      m.posed > 0.001 ? '${fmt(m.posed)} j posés' : 'Rien de posé',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: m.posed > 0.001 ? FontWeight.w700 : FontWeight.w500,
                          color: m.posed > 0.001 ? AppColors.violet : context.mutedColor),
                    ),
                  ]),
                ),
                const SizedBox(width: 10),
                Text(
                  m.reste < -0.001 ? 'manque ${fmt(-m.reste)} j' : 'reste ${fmt(m.reste)} j',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: m.reste < -0.001 ? AppColors.danger : context.textColor,
                  ),
                ),
              ]),
            ),
          ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Carte SOLDE FIN DE MOIS — tout en haut, mise en avant
// ══════════════════════════════════════════════════════════════════════════════
class _SoldeFinCard extends StatelessWidget {
  final List<LeaveType> types;
  final double Function(LeaveType) soldeFin;
  final String Function(double) fmt;

  const _SoldeFinCard({
    required this.types,
    required this.soldeFin,
    required this.fmt,
  });

  @override
  Widget build(BuildContext context) {
    // Jours entiers seulement : 0,21 + 0,22 = 0 j (on ne peut pas additionner des fractions)
    final totalFin = types.fold(0, (s, lt) => s + soldeFin(lt).floor());
    final totalNeg = totalFin < 0;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── En-tête : total fin de mois ──────────────────────
        Row(children: [
          const Text('🏖️', style: TextStyle(fontSize: 20)),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('Solde fin du mois',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(
              '$totalFin j',
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 26,
                color: totalNeg ? AppColors.danger : AppColors.violet,
              ),
            ),
            Text(
              'au total',
              style: TextStyle(
                fontSize: 11,
                color: AppColors.muted,
                fontWeight: FontWeight.w500,
              ),
            ),
          ]),
        ]),

        // ── Séparateur si plusieurs types ─────────────────────
        if (types.length > 1) ...[
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 10),
          // Détail par type
          for (final lt in types) ...[
            _SoldeFinRow(lt: lt, solde: soldeFin(lt), fmt: fmt),
            if (lt != types.last) const SizedBox(height: 8),
          ],
        ],
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Carte SAISIE RAPIDE — "je veux poser X jours" avec répartition auto
// ══════════════════════════════════════════════════════════════════════════════
class _QuickDistributionCard extends StatefulWidget {
  final Ym month;
  final List<LeaveType> types;
  final AppData d;
  final int maxTotal;
  final double totalPose;
  final int Function(LeaveType) maxPosable;
  final String Function(double) fmt;
  final void Function(double totalDays) onDistribute;

  const _QuickDistributionCard({
    required this.month,
    required this.types,
    required this.d,
    required this.maxTotal,
    required this.totalPose,
    required this.maxPosable,
    required this.fmt,
    required this.onDistribute,
  });

  @override
  State<_QuickDistributionCard> createState() => _QuickDistributionCardState();
}

class _QuickDistributionCardState extends State<_QuickDistributionCard> {
  Future<void> _edit() async {
    final v = await _askDays(
      context,
      title: 'Jours posés ce mois',
      subtitle: widget.maxTotal > 0
          ? '${widget.maxTotal} j disponibles${widget.types.length > 1 ? ' au total' : ''}'
          : 'Aucun jour disponible ce mois',
      initial: widget.totalPose,
      max: widget.maxTotal.toDouble(),
    );
    if (v != null) widget.onDistribute(v);
  }

  @override
  Widget build(BuildContext context) {
    final hasPose = widget.totalPose > 0;
    final maxTotal = widget.maxTotal;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.beach_access_rounded, size: 18, color: AppColors.violet),
          const SizedBox(width: 8),
          const Expanded(
            child: Text('Jours posés ce mois',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
        ]),
        const SizedBox(height: 4),
        Text(
          maxTotal > 0
              ? '$maxTotal j disponibles${widget.types.length > 1 ? ' au total' : ''}'
              : 'Aucun jour disponible ce mois',
          style: TextStyle(
            color: maxTotal > 0 ? AppColors.muted : AppColors.danger,
            fontSize: 12.5,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: _edit,
          child: Container(
            height: 56,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: context.fieldColor,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(children: [
              Expanded(
                child: Text(
                  '${widget.fmt(widget.totalPose)} j',
                  style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 20,
                      color: hasPose ? AppColors.violet : AppColors.muted),
                ),
              ),
              const Icon(Icons.edit_rounded, size: 18, color: AppColors.muted),
            ]),
          ),
        ),
        if (widget.types.length > 1 && maxTotal > 0) ...[
          const SizedBox(height: 10),
          _PriorityHint(types: widget.types, maxPosable: widget.maxPosable),
        ],
      ]),
    );
  }
}

/// Feuille de saisie d'un nombre de jours : champ pré-rempli, Annuler / Enregistrer
/// juste au-dessus du clavier numérique. Retourne null si annulé.
Future<double?> _askDays(
  BuildContext context, {
  required String title,
  required String subtitle,
  required double initial,
  required double max,
}) {
  return showModalBottomSheet<double>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Theme.of(context).colorScheme.surface,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => _DaysSheet(title: title, subtitle: subtitle, initial: initial, max: max),
  );
}

class _DaysSheet extends StatefulWidget {
  final String title;
  final String subtitle;
  final double initial;
  final double max;
  const _DaysSheet(
      {required this.title, required this.subtitle, required this.initial, required this.max});
  @override
  State<_DaysSheet> createState() => _DaysSheetState();
}

class _DaysSheetState extends State<_DaysSheet> {
  late final TextEditingController _ctrl;
  String? _error;

  @override
  void initState() {
    super.initState();
    final i = widget.initial;
    _ctrl = TextEditingController(
        text: i == i.roundToDouble() ? i.round().toString() : i.toString().replaceAll('.', ','));
    _ctrl.selection = TextSelection(baseOffset: 0, extentOffset: _ctrl.text.length);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _save() {
    final t = _ctrl.text.trim().replaceAll(',', '.');
    final v = t.isEmpty ? 0.0 : double.tryParse(t);
    if (v == null || v < 0) {
      setState(() => _error = 'Entre un nombre de jours valide');
      return;
    }
    if (v > widget.max + 0.001) {
      final m = widget.max;
      setState(() => _error =
          'Tu n\'as que ${m == m.roundToDouble() ? m.round() : m} j disponibles');
      return;
    }
    Navigator.of(context).pop(v);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        const SizedBox(height: 4),
        Text(widget.subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
        const SizedBox(height: 14),
        TextField(
          controller: _ctrl,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          onChanged: (_) => setState(() => _error = null),
          decoration: InputDecoration(suffixText: 'j', errorText: _error),
        ),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
            flex: 2,
            child: TextButton(
              onPressed: () => Navigator.of(context).pop(),
              style: TextButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
                backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                foregroundColor: Theme.of(context).colorScheme.onSurface,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(flex: 3, child: GradientButton(label: 'Enregistrer', onPressed: _save)),
        ]),
      ]),
    );
  }
}

class _PriorityHint extends StatelessWidget {
  final List<LeaveType> types;
  final int Function(LeaveType) maxPosable;
  const _PriorityHint({required this.types, required this.maxPosable});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      decoration: BoxDecoration(
        color: AppColors.violet.withAlpha(10),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.violet.withAlpha(30)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.info_outline_rounded, size: 14, color: AppColors.violet),
        const SizedBox(width: 8),
        Expanded(
          child: Wrap(
            spacing: 4,
            runSpacing: 2,
            children: [
              const Text(
                'Ordre de priorité : ',
                style: TextStyle(fontSize: 12, color: AppColors.muted),
              ),
              for (int i = 0; i < types.length; i++) ...[
                Row(mainAxisSize: MainAxisSize.min, children: [
                  CircleAvatar(radius: 5, backgroundColor: Color(types[i].colorValue)),
                  const SizedBox(width: 4),
                  Text(
                    '${types[i].name} (${maxPosable(types[i])} j max)',
                    style: TextStyle(
                        fontSize: 12,
                        color: AppColors.muted,
                        fontWeight: FontWeight.w600),
                  ),
                  if (i < types.length - 1)
                    const Text(' → ',
                        style: TextStyle(fontSize: 12, color: AppColors.muted)),
                ]),
              ],
            ],
          ),
        ),
      ]),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Modèle de conflit prospectif
// ══════════════════════════════════════════════════════════════════════════════
class _LeaveConflict {
  final Ym month;
  final double manque;
  const _LeaveConflict({required this.month, required this.manque});
}

// ══════════════════════════════════════════════════════════════════════════════
// Tile de pose par type (réglage fin)
// ══════════════════════════════════════════════════════════════════════════════
class _PoseTile extends StatefulWidget {
  final LeaveType lt;
  final double taken;
  final int maxPosable;
  final _LeaveConflict? Function(double extra) onConflictCheck;
  final double soldeAvant;
  final double accrual;
  final String Function(double) fmt;
  final ValueChanged<double> onChanged;
  const _PoseTile({
    required this.lt,
    required this.taken,
    required this.maxPosable,
    required this.onConflictCheck,
    required this.soldeAvant,
    required this.accrual,
    required this.fmt,
    required this.onChanged,
  });
  @override
  State<_PoseTile> createState() => _PoseTileState();
}

class _PoseTileState extends State<_PoseTile> {
  _LeaveConflict? _conflict;

  Future<void> _edit() async {
    final v = await _askDays(
      context,
      title: widget.lt.name,
      subtitle: 'Maximum ce mois : ${widget.maxPosable} j',
      initial: widget.taken,
      max: widget.maxPosable.toDouble(),
    );
    if (v != null) _trySet(v);
  }

  void _trySet(double newVal) {
    final capped = newVal.clamp(0.0, widget.maxPosable.toDouble());
    final extra = capped - widget.taken;
    if (extra > 0) {
      setState(() => _conflict = widget.onConflictCheck(extra));
    } else {
      setState(() => _conflict = null);
    }
    widget.onChanged(capped.toDouble());
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(widget.lt.colorValue);
    final taken = widget.taken;
    final max = widget.maxPosable;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(radius: 8, backgroundColor: color),
          const SizedBox(width: 10),
          Expanded(child: Text(widget.lt.name,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
          Text('Max : $max j',
              style: TextStyle(
                  color: max <= 0 ? AppColors.danger : AppColors.muted,
                  fontSize: 12, fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 8),
        InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: max <= 0 && taken <= 0 ? null : _edit,
          child: Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: context.fieldColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(children: [
              Expanded(
                child: Text('${widget.fmt(taken)} j posés',
                    style: TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 16,
                        color: taken > 0 ? color : AppColors.muted)),
              ),
              const Icon(Icons.edit_rounded, size: 16, color: AppColors.muted),
            ]),
          ),
        ),

        if (_conflict != null)
          Container(
            margin: const EdgeInsets.only(top: 6),
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            decoration: BoxDecoration(
              color: AppColors.warning.withAlpha(18),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.warning.withAlpha(80)),
            ),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.warning_amber_rounded, size: 15, color: AppColors.warning),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'Attention : en posant ces jours, il te manquera ${widget.fmt(_conflict!.manque)} j '
                'en ${_conflict!.month.longName} pour tes congés déjà planifiés.',
                style: const TextStyle(
                    color: AppColors.warning, fontSize: 12,
                    fontWeight: FontWeight.w600, height: 1.4),
              )),
            ]),
          ),
        if (max == 0)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(children: [
              const Icon(Icons.block_rounded, size: 13, color: AppColors.danger),
              const SizedBox(width: 4),
              const Expanded(child: Text('Solde insuffisant — impossible de poser des jours ce mois.',
                  style: TextStyle(color: AppColors.danger, fontSize: 12, fontWeight: FontWeight.w600))),
            ]),
          ),
      ]),
    );
  }
}

// ── Ligne solde fin ───────────────────────────────────────────────────────────
class _SoldeFinRow extends StatelessWidget {
  final LeaveType lt;
  final double solde;
  final String Function(double) fmt;
  const _SoldeFinRow({required this.lt, required this.solde, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final color = Color(lt.colorValue);
    final isNeg = solde < 0;
    return Row(children: [
      CircleAvatar(radius: 8, backgroundColor: color),
      const SizedBox(width: 10),
      Expanded(child: Text(lt.name,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
      if (isNeg)
        const Padding(
          padding: EdgeInsets.only(right: 6),
          child: Icon(Icons.warning_rounded, size: 15, color: AppColors.danger),
        ),
      Text('${fmt(solde)} j',
          style: TextStyle(
              fontWeight: FontWeight.w800, fontSize: 15,
              color: isNeg ? AppColors.danger : color)),
    ]);
  }
}

// ── Dialogue d'avertissement : mois futurs impactés ──────────────────────────
Future<bool?> _showConflictDialog(
  BuildContext context,
  List<LeaveConflict> conflicts,
  double totalDays,
  String Function(double) fmt,
) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      title: Row(children: [
        const Text('⚠️', style: TextStyle(fontSize: 22)),
        const SizedBox(width: 10),
        const Expanded(
          child: Text('Congés futurs impactés',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        ),
      ]),
      content: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(
            'En posant ces ${fmt(totalDays)} jours, tu n\'auras plus assez de solde pour :',
            style: const TextStyle(fontSize: 14, height: 1.4),
          ),
          const SizedBox(height: 12),
          for (final c in conflicts) ...[
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                color: AppColors.warning.withAlpha(18),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.warning.withAlpha(60)),
              ),
              child: Row(children: [
                const Icon(Icons.beach_access_rounded, size: 18, color: AppColors.warning),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.month.longName,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                  Text(
                    'Tu as prévu ${fmt(c.demande)} j — il n\'en restera que ${fmt(c.disponible)} j disponibles.',
                    style: const TextStyle(fontSize: 12.5, height: 1.3, color: AppColors.warning),
                  ),
                ])),
              ]),
            ),
          ],
          const SizedBox(height: 4),
          const Text(
            'Tu peux quand même confirmer — il faudra ajuster ces mois-là manuellement.',
            style: TextStyle(fontSize: 12.5, color: AppColors.muted, height: 1.4),
          ),
        ]),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
        FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.warning,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('Confirmer quand même', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// Sheet : gérer les catégories
// ══════════════════════════════════════════════════════════════════════════════

class _LeaveTypesManagerSheet extends ConsumerWidget {
  const _LeaveTypesManagerSheet();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final types = [...ref.watch(appProvider).leaveTypes]
      ..sort((a, b) => a.priority.compareTo(b.priority));

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      if (types.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text('Aucune catégorie de congé. Commencez par en ajouter une.',
              style: TextStyle(color: AppColors.muted)),
        )
      else
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(children: [
            for (final lt in types) ...[
              ListTile(
                leading: CircleAvatar(radius: 12, backgroundColor: Color(lt.colorValue)),
                title: Text(lt.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('+${lt.accrualPerMonth.toStringAsFixed(2).replaceAll('.', ',')} j/mois'),
                trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                onTap: () => showSheet(context,
                    title: 'Modifier ${lt.name}', child: _LeaveTypeSheet(existing: lt)),
              ),
              if (lt != types.last) const Divider(height: 1, indent: 16),
            ],
          ]),
        ),
      const SizedBox(height: 16),
      if (types.length > 1) ...[
        const SizedBox(height: 16),
        const Text('Ordre de priorité', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(
          'Glissez pour définir quel type est utilisé en premier lors de la répartition automatique.',
          style: TextStyle(color: AppColors.muted, fontSize: 12.5),
        ),
        const SizedBox(height: 8),
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: SizedBox(
            height: types.length * 56.0,
            child: ReorderableListView(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              onReorder: (oldIdx, newIdx) {
                if (newIdx > oldIdx) newIdx--;
                final reordered = [...types];
                final item = reordered.removeAt(oldIdx);
                reordered.insert(newIdx, item);
                ref.read(appProvider.notifier).reorderLeaveTypes([
                  for (int i = 0; i < reordered.length; i++)
                    reordered[i].copyWith(priority: i),
                ]);
              },
              children: [
                for (int i = 0; i < types.length; i++)
                  ListTile(
                    key: ValueKey(types[i].id),
                    dense: true,
                    leading: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('${i + 1}', style: TextStyle(
                          color: AppColors.muted, fontWeight: FontWeight.w800, fontSize: 13)),
                      const SizedBox(width: 8),
                      CircleAvatar(radius: 10, backgroundColor: Color(types[i].colorValue)),
                    ]),
                    title: Text(types[i].name,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('+${types[i].accrualPerMonth.toStringAsFixed(2).replaceAll('.', ',')} j/mois',
                        style: const TextStyle(fontSize: 12)),
                    trailing: const Icon(Icons.drag_handle_rounded, color: AppColors.muted),
                  ),
              ],
            ),
          ),
        ),
      ],
      const SizedBox(height: 16),
      GradientButton(
        label: 'Ajouter une catégorie',
        onPressed: () => showSheet(context,
            title: 'Nouvelle catégorie', child: const _LeaveTypeSheet()),
      ),
    ]);
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// Sheet : créer / modifier un type
// ══════════════════════════════════════════════════════════════════════════════

class _LeaveTypeSheet extends ConsumerStatefulWidget {
  final LeaveType? existing;
  const _LeaveTypeSheet({super.key, this.existing});
  @override
  ConsumerState<_LeaveTypeSheet> createState() => _LeaveTypeSheetState();
}

class _LeaveTypeSheetState extends ConsumerState<_LeaveTypeSheet> {
  late final TextEditingController _name;
  late final TextEditingController _accrual;
  late final TextEditingController _initial;
  late int _color;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _name = TextEditingController(text: e?.name ?? '');
    _accrual = TextEditingController(
        text: e == null ? '2,50' : e.accrualPerMonth.toStringAsFixed(2).replaceAll('.', ','));
    _initial = TextEditingController(
        text: e == null ? '0,00' : e.initialBalance.toStringAsFixed(2).replaceAll('.', ','));
    _color = e?.colorValue ?? AppColors.palette[0].value;
  }

  @override
  void dispose() {
    _name.dispose();
    _accrual.dispose();
    _initial.dispose();
    super.dispose();
  }

  void _save() {
    final accrual = double.tryParse(_accrual.text.replaceAll(',', '.'));
    final initial = double.tryParse(_initial.text.replaceAll(',', '.'));
    if (_name.text.trim().isEmpty || accrual == null) {
      snack(context, 'Nom et cumul mensuel requis');
      return;
    }
    final n = ref.read(appProvider.notifier);
    if (widget.existing == null) {
      n.addLeaveType(_name.text.trim(), accrual, initial ?? 0, _color);
    } else {
      n.updateLeaveType(widget.existing!.copyWith(
        name: _name.text.trim(),
        accrualPerMonth: accrual,
        initialBalance: initial ?? 0,
        colorValue: _color,
      ));
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final color = Color(_color);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Center(child: Container(
        width: 36, height: 4,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
            color: color.withAlpha(80), borderRadius: BorderRadius.circular(2)),
      )),
      TextField(
        controller: _name,
        textCapitalization: TextCapitalization.sentences,
        autofocus: true,
        decoration: const InputDecoration(
          labelText: 'Nom (ex. Congés payés, RTT)',
          prefixIcon: Icon(Icons.beach_access_rounded),
        ),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: TextField(
          controller: _accrual,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Cumul par mois', suffixText: 'j'),
        )),
        const SizedBox(width: 10),
        Expanded(child: TextField(
          controller: _initial,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Solde initial', suffixText: 'j'),
        )),
      ]),
      const SizedBox(height: 14),
      const Text('Couleur', style: TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (int i = 0; i < AppColors.palette.length; i++)
          GestureDetector(
            onTap: () => setState(() => _color = AppColors.palette[i].value),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 36, height: 36,
              decoration: BoxDecoration(
                color: AppColors.palette[i],
                shape: BoxShape.circle,
                border: _color == AppColors.palette[i].value
                    ? Border.all(color: context.textColor, width: 3)
                    : null,
              ),
            ),
          ),
      ]),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          flex: 2,
          child: TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              minimumSize: const Size.fromHeight(50),
              backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
              foregroundColor: Theme.of(context).colorScheme.onSurface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            child: const Text('Annuler', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          flex: 3,
          child: GradientButton(
            label: widget.existing == null ? 'Créer' : 'Enregistrer',
            onPressed: _save,
          ),
        ),
      ]),
      if (widget.existing != null) ...[
        const SizedBox(height: 10),
        SoftButton(
          icon: Icons.delete_outline_rounded,
          label: 'Supprimer ${widget.existing!.name}',
          onPressed: () async {
            final ok = await showQuickDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text('Supprimer ${widget.existing!.name} ?'),
                content: const Text('Toutes les poses associées seront aussi supprimées.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                  FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('Supprimer'),
                  ),
                ],
              ),
            );
            if (ok == true) {
              ref.read(appProvider.notifier).deleteLeaveType(widget.existing!.id);
              if (context.mounted) Navigator.pop(context);
            }
          },
        ),
      ],
    ]);
  }
}
